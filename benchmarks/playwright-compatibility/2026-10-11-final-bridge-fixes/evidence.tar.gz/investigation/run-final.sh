#!/bin/bash
set -u
cd /workspace/suitecut
export pnpm_config_verify_deps_before_run=warn
export SUITECUT_RUNTIME_EXECUTABLE=/tmp/suitecut-cef-full-regression-build/suitecut-browser
sha256sum native/browser/browser.cc benchmarks/playwright-compatibility/compatibility.spec.ts benchmarks/native-engine/engine.e2e.spec.ts "$SUITECUT_RUNTIME_EXECUTABLE" > /tmp/suitecut-final-fixes/frozen-sha256.txt
run_matrix() {
 local name=$1 backend=$2
 COMPAT_BACKEND="$backend" COMPAT_DIRECTORY="/tmp/suitecut-final-fixes/$name" MEMORY_DIRECTORY="/tmp/suitecut-final-fixes/$name" taskset -c 0-3 python3 benchmarks/native-memory/runtime.py exec pnpm exec playwright test --config benchmarks/playwright-compatibility/playwright.config.ts > "/tmp/suitecut-final-fixes/$name.log" 2>&1
 printf '%s %s\n' "$name" "$?" >> /tmp/suitecut-final-fixes/final-exit-codes.txt
}
run_matrix final-cef cef
run_matrix final-chromium chromium
MEMORY_DIRECTORY=/tmp/suitecut-final-fixes/final-engine taskset -c 0-3 python3 benchmarks/native-memory/runtime.py playwright > /tmp/suitecut-final-fixes/final-engine.log 2>&1
printf 'final-engine %s\n' "$?" >> /tmp/suitecut-final-fixes/final-exit-codes.txt
MEMORY_DIRECTORY=/tmp/suitecut-final-fixes/lifecycle taskset -c 0-3 python3 benchmarks/native-memory/runtime.py exec node --expose-gc /tmp/suitecut-final-fixes/lifecycle-profile.mjs > /tmp/suitecut-final-fixes/lifecycle.log 2>&1
printf 'lifecycle %s\n' "$?" >> /tmp/suitecut-final-fixes/final-exit-codes.txt
bash /tmp/suitecut-suite-pass/run-upstream.sh final-cookies-screenshots library/browsercontext-add-cookies.spec.ts library/browsercontext-clearcookies.spec.ts library/browsercontext-cookies.spec.ts page/elementhandle-screenshot.spec.ts page/page-screenshot.spec.ts --grep-invert 'should isolate cookies between launches|should work for webgl|should throw if screenshot size is too large' --global-timeout=180000
printf 'final-cookies-screenshots %s\n' "$?" >> /tmp/suitecut-final-fixes/final-exit-codes.txt
bash /tmp/suitecut-suite-pass/run-upstream.sh final-known-issues library/popup.spec.ts:20 library/popup.spec.ts:177 library/permissions.spec.ts:222 library/permissions.spec.ts:317 page/page-aria-snapshot-ai.spec.ts:70 --global-timeout=60000
printf 'final-known-issues %s\n' "$?" >> /tmp/suitecut-final-fixes/final-exit-codes.txt
