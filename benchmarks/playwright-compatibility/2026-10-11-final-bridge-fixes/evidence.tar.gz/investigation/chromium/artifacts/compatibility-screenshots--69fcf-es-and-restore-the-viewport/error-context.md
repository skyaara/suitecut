# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compatibility.spec.ts >> screenshots: independent sessions serialize captures and restore the viewport
- Location: benchmarks/playwright-compatibility/compatibility.spec.ts:1124:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 1

  Array [
    500,
-   500,
+   602,
  ]
```

# Test source

```ts
  1053 |           secure: true,
  1054 |           sameSite: 'None',
  1055 |           partitionKey: 'https://example.com',
  1056 |         },
  1057 |         { name: 'plain', value: 'three', url: tlsOrigin },
  1058 |       ])
  1059 |       expect((await context.cookies()).filter((cookie) => cookie.name === 'chip')).toEqual(
  1060 |         expect.arrayContaining([
  1061 |           expect.objectContaining({ value: 'one', partitionKey: 'https://localhost' }),
  1062 |           expect.objectContaining({ value: 'two', partitionKey: 'https://example.com' }),
  1063 |         ]),
  1064 |       )
  1065 |       expect(await other.cookies()).toEqual([])
  1066 |       expect(context.pages()).toHaveLength(pagesFirst ? 1 : 0)
  1067 |       const state = await context.storageState()
  1068 |       await other.addCookies(state.cookies)
  1069 |       expect(await other.cookies()).toEqual(await context.cookies())
  1070 |       await context.clearCookies({ name: 'chip' })
  1071 |       expect(await context.cookies()).toEqual([expect.objectContaining({ name: 'plain' })])
  1072 |       expect(await other.cookies()).toHaveLength(3)
  1073 |       await context.clearCookies()
  1074 |       expect(await context.cookies()).toEqual([])
  1075 |     } finally {
  1076 |       await context.close()
  1077 |       await other.close()
  1078 |     }
  1079 |   })
  1080 | }
  1081 | 
  1082 | for (const deviceScaleFactor of [1, 2]) {
  1083 |   test(`screenshots: oversized elements preserve pixels and viewport at DPR ${deviceScaleFactor}`, async ({
  1084 |     browser,
  1085 |   }, info) => {
  1086 |     const context = await browser.newContext({
  1087 |       viewport: { width: 500, height: 500 },
  1088 |       deviceScaleFactor,
  1089 |     })
  1090 |     try {
  1091 |       const page = await context.newPage()
  1092 |       await page.setContent(
  1093 |         '<style>::-webkit-scrollbar{display:none}.box{border:1px solid blue;width:600px;height:600px;margin-left:50px}</style><div class="box"></div><div class="box"></div>',
  1094 |       )
  1095 |       const images = await Promise.all(
  1096 |         (await page.$$('.box')).map((element) => element.screenshot()),
  1097 |       )
  1098 |       const { default: sharp } = await import('sharp')
  1099 |       for (const [index, image] of images.entries()) {
  1100 |         const { data, info: pixels } = await sharp(image)
  1101 |           .ensureAlpha()
  1102 |           .raw()
  1103 |           .toBuffer({ resolveWithObject: true })
  1104 |         expect(pixels.width).toBe(602 * deviceScaleFactor)
  1105 |         expect(pixels.height).toBe(602 * deviceScaleFactor)
  1106 |         for (let x = 0; x < pixels.width; x++) {
  1107 |           expect([...data.subarray(x * 4, x * 4 + 4)]).toEqual([0, 0, 255, 255])
  1108 |           const bottom = ((pixels.height - 1) * pixels.width + x) * 4
  1109 |           expect([...data.subarray(bottom, bottom + 4)]).toEqual([0, 0, 255, 255])
  1110 |         }
  1111 |         await writeFile(info.outputPath(`oversized-${index}.png`), image)
  1112 |       }
  1113 |       expect(await page.evaluate(() => [innerWidth, innerHeight, devicePixelRatio])).toEqual([
  1114 |         500,
  1115 |         500,
  1116 |         deviceScaleFactor,
  1117 |       ])
  1118 |     } finally {
  1119 |       await context.close()
  1120 |     }
  1121 |   })
  1122 | }
  1123 | 
  1124 | test('screenshots: independent sessions serialize captures and restore the viewport', async ({
  1125 |   page,
  1126 | }, info) => {
  1127 |   await page.setViewportSize({ width: 500, height: 500 })
  1128 |   await page.setContent(
  1129 |     '<style>body{margin:0}::-webkit-scrollbar{display:none}</style><div style="width:100%;height:10000px;background:blue"></div>',
  1130 |   )
  1131 |   const sessions = await Promise.all([
  1132 |     page.context().newCDPSession(page),
  1133 |     page.context().newCDPSession(page),
  1134 |   ])
  1135 |   try {
  1136 |     const captures = await Promise.all(
  1137 |       sessions.map((session, index) =>
  1138 |         session.send('Page.captureScreenshot', {
  1139 |           format: 'png',
  1140 |           captureBeyondViewport: true,
  1141 |           clip: { x: 0, y: 0, width: 500, height: index ? 10000 : 602, scale: 1 },
  1142 |         }),
  1143 |       ),
  1144 |     )
  1145 |     const { default: sharp } = await import('sharp')
  1146 |     for (const [index, result] of captures.entries()) {
  1147 |       const image = Buffer.from(result.data, 'base64')
  1148 |       const metadata = await sharp(image).metadata()
  1149 |       expect(metadata.width).toBe(500)
  1150 |       expect(metadata.height).toBe(index ? 10000 : 602)
  1151 |       await writeFile(info.outputPath(`parallel-${index}.png`), image)
  1152 |     }
> 1153 |     expect(await page.evaluate(() => [innerWidth, innerHeight])).toEqual([500, 500])
       |                                                                  ^ Error: expect(received).toEqual(expected) // deep equality
  1154 |   } finally {
  1155 |     await Promise.all(sessions.map((session) => session.detach()))
  1156 |   }
  1157 | })
  1158 | 
  1159 | test('native: screenshot bounds reject excessive pixel allocation', async ({ page, engine }) => {
  1160 |   test.skip(!engine, 'Native bounded capture policy')
  1161 |   const session = await page.context().newCDPSession(page)
  1162 |   try {
  1163 |     await expect(
  1164 |       session.send('Page.captureScreenshot', {
  1165 |         clip: { x: 0, y: 0, width: 16384, height: 16384, scale: 1 },
  1166 |       }),
  1167 |     ).rejects.toThrow('pixel')
  1168 |     expect(await page.evaluate(() => 21 * 2)).toBe(42)
  1169 |     expect(await page.evaluate(() => [innerWidth, innerHeight])).toEqual([640, 360])
  1170 |   } finally {
  1171 |     await session.detach()
  1172 |   }
  1173 | })
  1174 | 
  1175 | test('cookies: partition keys determine which cookie reaches a cross-site frame', async ({
  1176 |   browser,
  1177 | }) => {
  1178 |   const context = await browser.newContext({ ignoreHTTPSErrors: true })
  1179 |   try {
  1180 |     await context.addCookies([
  1181 |       {
  1182 |         name: 'chip',
  1183 |         value: 'one',
  1184 |         domain: '127.0.0.1',
  1185 |         path: '/',
  1186 |         secure: true,
  1187 |         sameSite: 'None',
  1188 |         partitionKey: 'https://localhost',
  1189 |       },
  1190 |       {
  1191 |         name: 'chip',
  1192 |         value: 'two',
  1193 |         domain: '127.0.0.1',
  1194 |         path: '/',
  1195 |         secure: true,
  1196 |         sameSite: 'None',
  1197 |         partitionKey: 'https://example.com',
  1198 |       },
  1199 |     ])
  1200 |     const page = await context.newPage()
  1201 |     await page.goto(tlsOrigin.replace('127.0.0.1', 'localhost'))
  1202 |     await page.setContent(`<iframe src="${tlsOrigin}/cookie-echo"></iframe>`)
  1203 |     await expect(page.frameLocator('iframe').locator('body')).toHaveText('chip=one')
  1204 |   } finally {
  1205 |     await context.close()
  1206 |   }
  1207 | })
  1208 | 
  1209 | test('native: repeated empty cookie contexts reclaim private control targets', async ({
  1210 |   browser,
  1211 |   engine,
  1212 | }) => {
  1213 |   test.skip(!engine, 'Native context-agent lifecycle')
  1214 |   test.setTimeout(60000)
  1215 |   const session = await browser.newBrowserCDPSession()
  1216 |   try {
  1217 |     const before = (await session.send('Target.getTargets')).targetInfos
  1218 |       .map((target) => target.targetId)
  1219 |       .sort()
  1220 |     for (let i = 0; i < 70; i++) {
  1221 |       const context = await browser.newContext()
  1222 |       await context.addCookies([{ name: 'cycle', value: String(i), url: origin }])
  1223 |       expect(context.pages()).toEqual([])
  1224 |       expect(await context.cookies()).toEqual([
  1225 |         expect.objectContaining({ name: 'cycle', value: String(i) }),
  1226 |       ])
  1227 |       await context.close()
  1228 |     }
  1229 |     expect(
  1230 |       (await session.send('Target.getTargets')).targetInfos.map((target) => target.targetId).sort(),
  1231 |     ).toEqual(before)
  1232 |   } finally {
  1233 |     await session.detach()
  1234 |   }
  1235 | })
  1236 | 
```