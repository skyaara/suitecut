#!/usr/bin/env node
import {spawn} from 'node:child_process';
const child=spawn('/tmp/suitecut-cef-full-regression-build/suitecut-browser',[...process.argv.slice(2),'--remote-debugging-pipe'],{stdio:['pipe','pipe','inherit','pipe','pipe']});
process.stdin.pipe(child.stdin);
child.stdout.pipe(process.stdout);
let rest='',id=0,initialized=false;
child.stdio[4].on('data',b=>{
 rest+=b.toString();let end;
 while((end=rest.indexOf('\0'))>=0){const m=JSON.parse(rest.slice(0,end));rest=rest.slice(end+1);process.stderr.write('PIPE '+JSON.stringify(m)+'\n');
 if(m.method==='Target.attachedToTarget'&&!m.params.waitingForDebugger) send('Runtime.runIfWaitingForDebugger',{},m.params.sessionId);
 }
});
function send(method,params,sessionId){child.stdio[3].write(JSON.stringify({id:++id,method,params,...(sessionId?{sessionId}:{})})+'\0')}
child.stdout.on('data',b=>{if(!initialized){initialized=true;setTimeout(()=>send('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:true,flatten:true,filter:[{type:'page'},{exclude:true}]}),250)}});
child.on('exit',(code,signal)=>process.exit(code??1));
