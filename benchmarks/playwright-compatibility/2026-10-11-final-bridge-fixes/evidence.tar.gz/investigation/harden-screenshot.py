from pathlib import Path
p=Path('/workspace/suitecut/native/browser/browser.cc');s=p.read_text()
s=s.replace('''      if(screenshot_command_==message->GetInt("id")) {
        screenshot_command_=0;screenshot_width_=screenshot_height_=0;browser_->GetHost()->WasResized();
      }''','      if(screenshot_command_==message->GetInt("id")) FinishScreenshot();')
s=s.replace('    const double captured = Now();\n    writer_.Captured(true, captured);','''    // CDP temporarily changes the capture surface/offset. Keep those pixels
    // out of the synchronized media stream; its normal last-frame hold applies.
    if(screenshot_command_)return;
    const double captured = Now();
    writer_.Captured(true, captured);''')
a=s.index('  void DispatchCDP(')
s=s[:a]+'''  struct ScreenshotJob {int id;std::string method;Dict params;std::string session;bool native;std::string raw_params;};
  void CDPError(int id,const std::string& session,bool native,const char* text) {
    if(native) {writer_.Reply(id,false,text);return;}
    auto response=CefDictionaryValue::Create();response->SetInt("id",id);if(!session.empty())response->SetString("sessionId",session);
    auto error=CefDictionaryValue::Create();error->SetInt("code",-32000);error->SetString("message",text);response->SetDictionary("error",error);root_->CDPMessage(response);
  }
  void FinishScreenshot() {
    const bool resized=screenshot_width_ || screenshot_height_;
    screenshot_command_=0;screenshot_width_=screenshot_height_=0;
    if(resized && browser_)browser_->GetHost()->WasResized();
    if(screenshot_jobs_.empty())return;
    auto job=std::move(screenshot_jobs_.front());screenshot_jobs_.pop_front();screenshot_draining_=true;
    CefPostTask(TID_UI,new Task([self=CefRefPtr<Source>(this),job=std::move(job)] {
      self->screenshot_draining_=false;
      if(self->closing_ || self->stopped_) {self->CDPError(job.id,job.session,job.native,"CEF target closed");return;}
      self->DispatchCDP(job.id,job.method,job.params,job.session,job.native,job.raw_params);
    }));
  }
'''+s[a:]
s=s.replace('''    if(devtools_pending_.size()>=256) {if(native) writer_.Reply(id,false,"CEF command capacity exceeded");else {auto response=CefDictionaryValue::Create();response->SetInt("id",id);if(!session.empty())response->SetString("sessionId",session);auto error=CefDictionaryValue::Create();error->SetInt("code",-32000);error->SetString("message","CEF command capacity exceeded");response->SetDictionary("error",error);root_->CDPMessage(response);}return;}''','''    if(method=="Page.captureScreenshot") {
      if(Json(params).size()>4096 || raw_params.size()>4096) {CDPError(id,session,native,"CEF screenshot argument limit exceeded");return;}
      if(screenshot_command_ || screenshot_draining_) {
        if(screenshot_jobs_.size()>=8) {CDPError(id,session,native,"CEF screenshot queue capacity exceeded");return;}
        screenshot_jobs_.push_back({id,method,params->Copy(false),session,native,raw_params});return;
      }
    }
    if(devtools_pending_.size()>=256) {CDPError(id,session,native,"CEF command capacity exceeded");return;}''')
s=s.replace('''    if(method=="Page.captureScreenshot" && !screenshot_command_) {
      auto clip=''','''    if(method=="Emulation.clearDeviceMetricsOverride")emulated_scale_=scale_;
    if(method=="Page.captureScreenshot") {
      screenshot_command_=internal;
      auto clip=''')
s=s.replace('if(std::isfinite(width) && std::isfinite(height) && width>0 && height>0 && width*scale_<=3840 && height*scale_<=2160)', 'if(std::isfinite(width) && std::isfinite(height) && width>0 && height>0 && width*scale_<=16384 && height*scale_<=16384 && width*height*scale_*scale_<=3840.0*2160)')
s=s.replace('''screenshot_command_=internal;screenshot_width_=int(width);screenshot_height_=int(height);browser_->GetHost()->WasResized();
        }''','''screenshot_width_=int(width);screenshot_height_=int(height);browser_->GetHost()->WasResized();
        } else if(width>0 && height>0) {FinishScreenshot();CDPError(id,session,native,"CEF screenshot exceeds the 8,294,400-pixel or 16,384-axis limit");return;}''')
s=s.replace('devtools_pending_.erase(internal);writer_.Reply(id,false,"CEF DevTools dispatch failed");', 'devtools_pending_.erase(internal);if(screenshot_command_==internal)FinishScreenshot();CDPError(id,session,native,"CEF DevTools dispatch failed");')
s=s.replace('  int screenshot_command_=0,screenshot_width_=0,screenshot_height_=0;', '  std::deque<ScreenshotJob> screenshot_jobs_;\n  bool screenshot_draining_=false;\n  int screenshot_command_=0,screenshot_width_=0,screenshot_height_=0;')
s=s.replace('    observer_ = nullptr;','    screenshot_jobs_.clear();\n    observer_ = nullptr;')
p.write_text(s)
