# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/popup.spec.ts >> should inherit touch support from browser context
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/popup.spec.ts:102:3

# Error details

```
Test timeout of 10000ms exceeded.
```