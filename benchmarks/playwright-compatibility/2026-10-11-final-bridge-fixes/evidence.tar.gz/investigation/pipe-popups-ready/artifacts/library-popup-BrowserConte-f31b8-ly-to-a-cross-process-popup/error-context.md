# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/popup.spec.ts >> BrowserContext.addInitScript should apply to a cross-process popup
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/popup.spec.ts:190:3

# Error details

```
Test timeout of 10000ms exceeded.
```