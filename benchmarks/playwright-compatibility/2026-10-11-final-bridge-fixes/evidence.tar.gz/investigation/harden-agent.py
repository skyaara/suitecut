from pathlib import Path
p=Path('/workspace/suitecut/native/browser/browser.cc');s=p.read_text().replace('CefRefPtr<CefRequestHandler> GetRequestHandler() override { return nullptr; }','CefRefPtr<CefRequestHandler> GetRequestHandler() override { return this; }')
s=s.replace('// Each CEF context owns a private, tiny control page. Page-scoped CDP agents\n// select their own browser context; passing a browserContextId is forbidden on\n// those agents. Never expose this page as a user target or capture its media.', '// Cookie commands use a page-scoped Network agent to preserve CHIPS and context\n// isolation. A context without user pages gets a tiny private page, retired\n// once a user page is available. This page is never exposed or captured.')
s=s.replace('  using Reply=std::function<void(Dict)>;','  using Reply=std::function<void(Dict)>;\n  explicit ContextAgent(std::function<void()> closed):closed_(std::move(closed)) {}')
s=s.replace('    const int id=index_;pending_[id]=std::move(reply);\n    auto command=', '    const int id=index_;\n    auto command=')
s=s.replace('    CefPostTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this),id,wire=Json(command)] {', '''    const auto wire=Json(command);
    if(wire.size()+pending_bytes_>16777216) {reply(Error("CEF cookie command byte capacity exceeded"));return;}
    pending_bytes_+=wire.size();pending_[id]={std::move(reply),wire.size(),Now()+10000};
    CefPostTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this),id,wire] {''')
s=s.replace('    CefPostDelayedTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this),id] {self->Complete(id,Error("CEF context command timed out"));}),10000);','    ScheduleTimeout();')
s=s.replace('      CefPostTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this),id,message] {self->Complete(id,message);}));','      Complete(id,message);')
s=s.replace('observer_=nullptr;browser_=nullptr;FailPending();}', 'observer_=nullptr;browser_=nullptr;FailPending();NotifyClosed();}')
s=s.replace('    closing_=true;FailPending();\n    CefPostTask', '    closing_=true;FailPending();\n    if(!browser_) {NotifyClosed();return;}\n    CefPostTask')
a=s.index('  void Complete(int id,Dict message)');b=s.index('  CefRefPtr<CefBrowser> browser_;',a)
s=s[:a]+'''  void Complete(int id,Dict message) {
    auto found=pending_.find(id);if(found==pending_.end())return;
    auto reply=std::move(found->second.reply);pending_bytes_-=found->second.bytes;pending_.erase(found);reply(message);
  }
  void FailPending() {auto pending=std::move(pending_);pending_.clear();pending_bytes_=0;for(auto& [id,item]:pending)item.reply(Error("CEF context closed"));}
  void NotifyClosed() {if(closed_) {auto closed=std::move(closed_);closed();}}
  void ScheduleTimeout() {
    if(timeout_scheduled_ || pending_.empty() || closing_)return;
    timeout_scheduled_=true;
    CefPostDelayedTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this)] {
      self->timeout_scheduled_=false;
      std::vector<int> expired;for(const auto& [id,item]:self->pending_)if(item.deadline<=Now())expired.push_back(id);
      for(int id:expired)self->Complete(id,Error("CEF context command timed out"));
      self->ScheduleTimeout();
    }),1000);
  }
  struct Pending {Reply reply;size_t bytes;double deadline;};
  int index_=0;
  size_t pending_bytes_=0;
  bool closing_=false,timeout_scheduled_=false;
  std::map<int,Pending> pending_;
  std::function<void()> closed_;
'''+s[b:]
s=s.replace('          CefRefPtr<ContextAgent> agent=new ContextAgent();context_agents_[key]=agent;', '''          ++context_agent_count_;
          CefRefPtr<ContextAgent> agent=new ContextAgent([self=CefRefPtr<Source>(this)] {
            --self->context_agent_count_;if(self->targets_.empty() && !self->context_agent_count_)CefQuitMessageLoop();
          });context_agents_[key]=agent;''')
s=s.replace('context_agents_.erase(key);reply(nullptr,"CEF cookie agent initialization failed")', 'agent->Close();context_agents_.erase(key);reply(nullptr,"CEF cookie agent initialization failed")')
s=s.replace('if (root_->targets_.empty()) CefQuitMessageLoop();','if (root_->targets_.empty() && !root_->context_agent_count_) CefQuitMessageLoop();')
s=s.replace('  std::map<std::string,CefRefPtr<ContextAgent>> context_agents_;', '  std::map<std::string,CefRefPtr<ContextAgent>> context_agents_;\n  size_t context_agent_count_=0;')
p.write_text(s)
