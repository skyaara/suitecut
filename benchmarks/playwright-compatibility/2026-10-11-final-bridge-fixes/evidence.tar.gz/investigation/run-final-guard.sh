#!/bin/bash
set -u
cd /workspace/suitecut
export pnpm_config_verify_deps_before_run=warn
export SUITECUT_RUNTIME_EXECUTABLE=/tmp/suitecut-cef-full-regression-build/suitecut-browser
sha256sum native/browser/browser.cc benchmarks/playwright-compatibility/compatibility.spec.ts benchmarks/native-engine/engine.e2e.spec.ts "$SUITECUT_RUNTIME_EXECUTABLE" > /tmp/suitecut-final-fixes/reply-guard-frozen-sha256.txt
COMPAT_BACKEND=cef COMPAT_DIRECTORY=/tmp/suitecut-final-fixes/reply-guard-cef MEMORY_DIRECTORY=/tmp/suitecut-final-fixes/reply-guard-cef taskset -c 0-3 python3 benchmarks/native-memory/runtime.py exec pnpm exec playwright test --config benchmarks/playwright-compatibility/playwright.config.ts > /tmp/suitecut-final-fixes/reply-guard-cef.log 2>&1
printf 'reply-guard-cef %s\n' "$?" >> /tmp/suitecut-final-fixes/reply-guard-exit-codes.txt
MEMORY_DIRECTORY=/tmp/suitecut-final-fixes/reply-guard-engine taskset -c 0-3 python3 benchmarks/native-memory/runtime.py playwright > /tmp/suitecut-final-fixes/reply-guard-engine.log 2>&1
printf 'reply-guard-engine %s\n' "$?" >> /tmp/suitecut-final-fixes/reply-guard-exit-codes.txt
MEMORY_DIRECTORY=/tmp/suitecut-final-fixes/reply-guard-lifecycle taskset -c 0-3 python3 benchmarks/native-memory/runtime.py exec node --expose-gc /tmp/suitecut-final-fixes/lifecycle-profile.mjs > /tmp/suitecut-final-fixes/reply-guard-lifecycle.log 2>&1
printf 'reply-guard-lifecycle %s\n' "$?" >> /tmp/suitecut-final-fixes/reply-guard-exit-codes.txt
bash /tmp/suitecut-suite-pass/run-upstream.sh reply-guard-cookies-screenshots library/browsercontext-add-cookies.spec.ts library/browsercontext-clearcookies.spec.ts library/browsercontext-cookies.spec.ts page/elementhandle-screenshot.spec.ts page/page-screenshot.spec.ts --grep-invert 'should isolate cookies between launches|should work for webgl|should throw if screenshot size is too large' --global-timeout=180000
printf 'reply-guard-cookies-screenshots %s\n' "$?" >> /tmp/suitecut-final-fixes/reply-guard-exit-codes.txt
bash /tmp/suitecut-suite-pass/run-upstream.sh reply-guard-known-issues library/popup.spec.ts:20 library/popup.spec.ts:177 library/permissions.spec.ts:222 library/permissions.spec.ts:317 page/page-aria-snapshot-ai.spec.ts:70 --global-timeout=60000
printf 'reply-guard-known-issues %s\n' "$?" >> /tmp/suitecut-final-fixes/reply-guard-exit-codes.txt
COMPAT_BACKEND=chromium bash /tmp/suitecut-suite-pass/run-upstream.sh stock-known-issues library/popup.spec.ts:20 library/popup.spec.ts:177 library/permissions.spec.ts:222 library/permissions.spec.ts:317 page/page-aria-snapshot-ai.spec.ts:70 --global-timeout=60000
printf 'stock-known-issues %s\n' "$?" >> /tmp/suitecut-final-fixes/reply-guard-exit-codes.txt
