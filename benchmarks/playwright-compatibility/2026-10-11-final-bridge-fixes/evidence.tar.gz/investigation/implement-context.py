from pathlib import Path
p=Path('/workspace/suitecut/native/browser/browser.cc')
s=p.read_text()
start=s.index('class CookieVisitor :')
end=s.index('class Source :',start)
s=s[:start]+'''// A short-lived page initializes a CEF request context and obtains its real
// Chromium context ID. Browser-domain commands can then run on the root agent
// without a visible page, a network listener, or retained control renderers.
class ContextProbe : public CefClient, public CefLifeSpanHandler,
                     public CefRenderHandler, public CefDevToolsMessageObserver {
 public:
  explicit ContextProbe(std::function<void(std::string)> complete):complete_(std::move(complete)) {}
  CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override {return this;}
  CefRefPtr<CefRenderHandler> GetRenderHandler() override {return this;}
  void GetViewRect(CefRefPtr<CefBrowser>,CefRect& rect) override {rect=CefRect(0,0,2,2);}
  void OnPaint(CefRefPtr<CefBrowser>,PaintElementType,const RectList&,const void*,int,int) override {}
  void OnAfterCreated(CefRefPtr<CefBrowser> browser) override {
    browser_=browser;observer_=browser->GetHost()->AddDevToolsMessageObserver(this);
    const std::string command=R"({"id":1,"method":"Target.getTargetInfo"})";
    browser->GetHost()->SendDevToolsMessage(command.data(),command.size());
    CefPostDelayedTask(TID_UI,new Task([self=CefRefPtr<ContextProbe>(this)] {self->Finish("");}),10000);
  }
  bool OnDevToolsMessage(CefRefPtr<CefBrowser>,const void* data,size_t size) override {
    if(size>1048576)return true;
    auto value=CefParseJSON(static_cast<const char*>(data),size,JSON_PARSER_RFC);
    auto message=value ? value->GetDictionary() : nullptr;
    if(message && message->GetInt("id")==1) {
      auto result=message->GetDictionary("result");auto info=result ? result->GetDictionary("targetInfo") : nullptr;
      Finish(info ? info->GetString("browserContextId").ToString() : "");
    }
    return true;
  }
  void OnBeforeClose(CefRefPtr<CefBrowser>) override {observer_=nullptr;browser_=nullptr;Finish("");}
  void Close() {Finish("");}
 private:
  void Finish(std::string context) {
    CefRefPtr<ContextProbe> keep_alive=this;
    if(complete_) {auto callback=std::move(complete_);callback(std::move(context));}
    if(browser_ && !closing_) {closing_=true;browser_->GetHost()->CloseBrowser(true);}
  }
  bool closing_=false;
  std::function<void(std::string)> complete_;
  CefRefPtr<CefBrowser> browser_;
  CefRefPtr<CefRegistration> observer_;
  IMPLEMENT_REFCOUNTING(ContextProbe);
};

'''+s[end:]
start=s.index('  void ApplyPermissions(')
end=s.index('  bool OnShowPermissionPrompt(',start)
s=s[:start]+s[end:]
start=s.index('  void CookieCommand(')
end=s.index('  void CDP(',start)
s=s[:start]+s[end:]
s=s.replace('root_->targets_[target_id_]=this;\n        {auto created=', 'root_->targets_[target_id_]=this;\n        if(this==root_) root_->chromium_contexts_["default"]=info->GetString("browserContextId").ToString();\n        {auto created=')
s=s.replace('result->SetString("browserContextId",key);reply(result);return;','''CefWindowInfo window;window.SetAsWindowless(0);CefBrowserSettings probe_settings;probe_settings.windowless_frame_rate=1;
        auto complete=[self=CefRefPtr<Source>(this),key,id,session](std::string actual) {
          self->context_probes_.erase(key);
          auto response=CefDictionaryValue::Create();response->SetInt("id",id);if(!session.empty())response->SetString("sessionId",session);
          if(!actual.empty() && self->contexts_.contains(key)) {
            self->chromium_contexts_[key]=actual;auto result=CefDictionaryValue::Create();result->SetString("browserContextId",key);response->SetDictionary("result",result);
          } else {
            self->contexts_.erase(key);auto error=CefDictionaryValue::Create();error->SetInt("code",-32000);error->SetString("message","CEF context initialization failed");response->SetDictionary("error",error);
          }
          self->CDPMessage(response);
        };
        CefRefPtr<ContextProbe> probe=new ContextProbe(std::move(complete));context_probes_[key]=probe;
        if(!CefBrowserHost::CreateBrowserSync(window,probe,"about:blank",probe_settings,nullptr,contexts_[key]))probe->Close();
        return;''')
s=s.replace('CloseTargets(key);contexts_.erase(key);', 'CloseTargets(key);contexts_.erase(key);chromium_contexts_.erase(key);')
start=s.index('      if(method=="Storage.getCookies"')
end=s.index('      if(method.starts_with("Storage."))',start)
s=s[:start]+'''      if(method=="Storage.getCookies" || method=="Storage.setCookies" || method=="Storage.clearCookies" ||
         method=="Browser.grantPermissions" || method=="Browser.resetPermissions") {
        const auto supplied=params->GetString("browserContextId").ToString();const auto key=supplied.empty() ? "default" : supplied;
        if(!chromium_contexts_.contains(key)) {reply(nullptr,"Unknown browser context");return;}
        if(method=="Storage.setCookies") {auto cookies=params->GetList("cookies");if(!cookies || cookies->GetSize()>500) {reply(nullptr,"Invalid cookie batch");return;}}
        if(method=="Browser.grantPermissions") {
          auto permissions=params->GetList("permissions");if(!permissions) {reply(nullptr,"Permission list is required");return;}
          for(size_t i=0;i<permissions->GetSize();++i) if(!PermissionBit(permissions->GetString(i).ToString()) && permissions->GetString(i)!="storageAccess" && permissions->GetString(i)!="wakeLockScreen") {reply(nullptr,"Unsupported native permission: "+permissions->GetString(i).ToString());return;}
          const auto origin=params->GetString("origin").ToString();auto& policies=pending_permissions_[key];
          if(policies.size()>=128) {reply(nullptr,"Context permission limit exceeded");return;}
          policies.erase(std::remove_if(policies.begin(),policies.end(),[&](const auto& policy){return policy->GetString("origin").ToString()==origin;}),policies.end());
          policies.push_back(params->Copy(false));
        } else if(method=="Browser.resetPermissions") pending_permissions_.erase(key);
        auto forwarded=params->Copy(false);forwarded->SetString("browserContextId",chromium_contexts_.at(key));
        DispatchCDP(id,method,forwarded,session,false);return;
      }
'''+s[end:]
s=s.replace('    std::vector<CefRefPtr<CefBrowser>> browsers;\n    for(auto& [key,source]:targets_)', '''    std::vector<CefRefPtr<ContextProbe>> probes;
    for(const auto& [key,probe]:context_probes_)if(context.empty() || key==context)probes.push_back(probe);
    for(const auto& probe:probes)probe->Close();
    std::vector<CefRefPtr<CefBrowser>> browsers;
    for(auto& [key,source]:targets_)''')
s=s.replace('  std::map<std::string,CefRefPtr<CefRequestContext>> contexts_;', '''  std::map<std::string,CefRefPtr<CefRequestContext>> contexts_;
  std::map<std::string,std::string> chromium_contexts_;
  std::map<std::string,CefRefPtr<ContextProbe>> context_probes_;''')
p.write_text(s)
