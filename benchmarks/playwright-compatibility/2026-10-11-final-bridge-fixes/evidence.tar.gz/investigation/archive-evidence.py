from pathlib import Path
import json,hashlib,tarfile,shutil
root=Path('/workspace/suitecut');out=root/'benchmarks/playwright-compatibility/2026-10-11-final-bridge-fixes';raw=Path('/tmp/suitecut-final-fixes');up=Path('/tmp/suitecut-suite-pass')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=[]
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=9) as tar:
 sources=[(raw,'investigation')]
 for name in ['final-cookies-screenshots','final-known-issues','reply-guard-cookies-screenshots','reply-guard-known-issues','stock-known-issues','final-upstream-extra','white-default','context-protocol','context-protocol-deferred','context-agent','context-agent-built','debug-popup','jpeg-fix','jpeg-default-fix']:
  sources.append((up/name,'upstream/'+name))
 for directory,prefix in sources:
  for p in sorted(directory.rglob('*')):
   if not p.is_file() or p.is_symlink():continue
   rel=p.relative_to(directory)
   if any(part in ['minimal-profile','standalone-profile','windowed-profile','cache','Cache','Code Cache'] for part in rel.parts):continue
   arc=prefix+'/'+str(rel);tar.add(p,arcname=arc,recursive=False);manifest.append({'path':arc,'bytes':p.stat().st_size,'sha256':digest(p)})
(out/'archive-manifest.json').write_text(json.dumps({'archive':'evidence.tar.gz','sha256':digest(out/'evidence.tar.gz'),'files':manifest},indent=2)+'\n')
# Seal all committed evidence except this seal itself.
with (out/'SHA256SUMS').open('w') as f:
 for p in sorted(out.rglob('*')):
  if p.is_file() and p.name!='SHA256SUMS':f.write(digest(p)+'  '+str(p.relative_to(out))+'\n')
shared=Path('/workspace/shared/suitecut-final-bridge-fixes-2026-10-11');shared.mkdir(exist_ok=True)
for name in ['report.md','metadata.json','summary.json','archive-manifest.json','evidence.tar.gz','SHA256SUMS']:
 shutil.copy2(out/name,shared/name)
shutil.copy2('/tmp/suitecut-cef-full-regression-build/suitecut-browser',shared/'suitecut-browser')
(shared/'README.md').write_text('''# Final bridge-fix evidence and helper\n\nThe fallback runtime archives are unchanged. `suitecut-browser` is the tested\nRelease helper from the final branch changes, not a complete runtime bundle.\nReplace the helper in a COPY of the matching Linux x64 CEF 152.0.6 codec-enabled\nruntime with it. Keep all original resources/locales/native libraries.\nThe existing complete bundle is\n`/workspace/shared/suitecut-native-2.1.0/suitecut-native-2.1.0-linux-x86_64.tar.gz`.\n\nSee report.md for passing checks, explicit limits and remaining failures.\nEvidence SHA256SUMS refers to the complete repository evidence directory; only\nselected files are mirrored here. The complete raw archive is evidence.tar.gz.\nNo new release tag or npm package was published.\n''')
(shared/'suitecut-browser.sha256').write_text(digest(shared/'suitecut-browser')+'  suitecut-browser\n')
print(json.dumps({'files':len(manifest),'archiveBytes':(out/'evidence.tar.gz').stat().st_size,'archiveSha256':digest(out/'evidence.tar.gz'),'shared':str(shared)},indent=2))
