import { launchNativeBrowser } from '/workspace/suitecut/dist/native-browser.js';
const b=await launchNativeBrowser({executablePath:process.env.SUITECUT_NATIVE_EXECUTABLE,width:640,height:360,framesPerSecond:30});
for(const [method,params] of [['Storage.getCookies',{}],['Network.getAllCookies',{}],['Network.setCookies',{cookies:[{name:'chip',value:'value',url:'https://example.com',secure:true,sameSite:'None',partitionKey:{topLevelSite:'https://top.example',hasCrossSiteAncestor:true}}]}],['Network.getAllCookies',{}],['Browser.grantPermissions',{permissions:['wakeLockScreen']}],['Browser.grantPermissions',{permissions:['storageAccess']}]]) {
 try {console.log(method, JSON.stringify(await b.sendDevToolsCommand(method,params)))} catch(e) {console.log(method,'ERROR',e.message)}
}
for(const url of ['data:text/html,blank','about:blank']) {
 await b.sendDevToolsCommand('Page.navigate',{url});await new Promise(r=>setTimeout(r,500));
 console.log('navigate',url);
}
try {console.log('srcdoc',await b.sendDevToolsCommand('Runtime.evaluate',{expression:'document.open();document.write(`<iframe srcdoc="hello"></iframe>`);document.close()'}));await new Promise(r=>setTimeout(r,500));console.log(await b.sendDevToolsCommand('Runtime.evaluate',{expression:'document.querySelector("iframe").contentDocument.body.innerText',returnByValue:true}))}catch(e){console.log('srcdoc ERROR',e.message)}
await b.close();
