#!/bin/bash
set -eu
export COMPAT_DIRECTORY=/tmp/suitecut-final-fixes/pipe-popups-ready
export MEMORY_DIRECTORY=$COMPAT_DIRECTORY
export SUITECUT_RUNTIME_EXECUTABLE=/tmp/suitecut-final-fixes/pipe-wrapper-ready.mjs
export PWTEST_UNDER_TEST=1 pnpm_config_verify_deps_before_run=warn
mkdir -p "$COMPAT_DIRECTORY"
taskset -c 0-3 python3 benchmarks/native-memory/runtime.py exec pnpm exec playwright test --config /tmp/suitecut-playwright-upstream/playwright-1.62.1/suitecut.config.ts library/popup.spec.ts --grep 'inherit user agent|inherit touch|expose function|addInitScript|respect routes' --timeout=10000 > "$COMPAT_DIRECTORY/run.log" 2>&1
