#!/usr/bin/env node
import {spawn} from 'node:child_process';
const child=spawn('/tmp/suitecut-cef-full-regression-build/suitecut-browser',[...process.argv.slice(2),'--remote-debugging-pipe'],{stdio:['pipe','pipe','inherit','pipe','pipe']});
process.stdin.pipe(child.stdin);
let rest='',id=0,initialized=false,forward=false,buf=Buffer.alloc(0),attachId=0, root='';
child.stdio[4].on('data',b=>{
 rest+=b.toString();let end;
 while((end=rest.indexOf('\0'))>=0){const m=JSON.parse(rest.slice(0,end));rest=rest.slice(end+1);process.stderr.write('PIPE '+JSON.stringify(m)+'\n');
 if(m.method==='Target.attachedToTarget'&&!m.params.targetInfo.openerId&&!root){root=m.params.sessionId;send('Runtime.runIfWaitingForDebugger',{},root)}
 if(m.id===attachId){forward=true;process.stdout.write(buf);buf=Buffer.alloc(0)}
 }
});
function send(method,params,sessionId){const n=++id;child.stdio[3].write(JSON.stringify({id:n,method,params,...(sessionId?{sessionId}:{})})+'\0');return n}
child.stdout.on('data',b=>{
 if(forward){process.stdout.write(b);return}
 buf=Buffer.concat([buf,b]);
 let offset=0;
 while(buf.length-offset>=4){const len=buf.readUInt32LE(offset);if(buf.length-offset<4+len)break;const h=JSON.parse(buf.subarray(offset+4,offset+4+len));if(buf.length-offset<4+len+h.bytes)break;offset+=4+len+h.bytes;
 if(h.type==='ready'&&!initialized){initialized=true;attachId=send('Target.setAutoAttach',{autoAttach:true,waitForDebuggerOnStart:true,flatten:true,filter:[{type:'page'},{exclude:true}]})}
 }
});
child.on('exit',(code,signal)=>process.exit(code??1));
