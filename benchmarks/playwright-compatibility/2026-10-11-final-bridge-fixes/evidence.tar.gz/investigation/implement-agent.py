from pathlib import Path
p=Path('/workspace/suitecut/native/browser/browser.cc');s=p.read_text();a=s.index('// A short-lived page');b=s.index('class Source :',a)
s=s[:a]+'''// Each CEF context owns a private, tiny control page. Page-scoped CDP agents
// select their own browser context; passing a browserContextId is forbidden on
// those agents. Never expose this page as a user target or capture its media.
class ContextAgent : public CefClient, public CefLifeSpanHandler,
                     public CefRenderHandler, public CefDevToolsMessageObserver {
 public:
  using Reply=std::function<void(Dict)>;
  CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override {return this;}
  CefRefPtr<CefRenderHandler> GetRenderHandler() override {return this;}
  void GetViewRect(CefRefPtr<CefBrowser>,CefRect& rect) override {rect=CefRect(0,0,2,2);}
  void OnPaint(CefRefPtr<CefBrowser>,PaintElementType,const RectList&,const void*,int,int) override {}
  void OnAfterCreated(CefRefPtr<CefBrowser> browser) override {
    browser_=browser;observer_=browser->GetHost()->AddDevToolsMessageObserver(this);
  }
  void Send(const std::string& method,Dict params,Reply reply) {
    if(!browser_ || closing_ || pending_.size()>=64) {reply(Error("CEF context agent unavailable or at capacity"));return;}
    do {index_=suitecut::NextCommandID(index_);}while(pending_.contains(index_));
    const int id=index_;pending_[id]=std::move(reply);
    auto command=CefDictionaryValue::Create();command->SetInt("id",id);command->SetString("method",method);command->SetDictionary("params",params);
    CefPostTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this),id,wire=Json(command)] {
      if(!self->pending_.contains(id))return;
      if(!self->browser_ || !self->browser_->GetHost()->SendDevToolsMessage(wire.data(),wire.size()))self->Complete(id,Error("CEF context command dispatch failed"));
    }));
    CefPostDelayedTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this),id] {self->Complete(id,Error("CEF context command timed out"));}),10000);
  }
  bool OnDevToolsMessage(CefRefPtr<CefBrowser>,const void* data,size_t size) override {
    if(size>16777216) {Close();return true;}
    auto value=CefParseJSON(static_cast<const char*>(data),size,JSON_PARSER_RFC);
    auto message=value ? value->GetDictionary() : nullptr;
    if(message && message->HasKey("id")) {
      const int id=message->GetInt("id");
      CefPostTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this),id,message] {self->Complete(id,message);}));
    }
    return true;
  }
  void OnBeforeClose(CefRefPtr<CefBrowser>) override {observer_=nullptr;browser_=nullptr;FailPending();}
  void Close() {
    if(closing_)return;closing_=true;FailPending();
    CefPostTask(TID_UI,new Task([self=CefRefPtr<ContextAgent>(this)] {if(self->browser_)self->browser_->GetHost()->CloseBrowser(true);}));
  }
 private:
  static Dict Error(const char* text) {auto message=CefDictionaryValue::Create();auto error=CefDictionaryValue::Create();error->SetInt("code",-32000);error->SetString("message",text);message->SetDictionary("error",error);return message;}
  void Complete(int id,Dict message) {auto found=pending_.find(id);if(found==pending_.end())return;auto reply=std::move(found->second);pending_.erase(found);reply(message);}
  void FailPending() {auto pending=std::move(pending_);pending_.clear();for(auto& [id,reply]:pending)reply(Error("CEF context closed"));}
  int index_=0;
  bool closing_=false;
  std::map<int,Reply> pending_;
  CefRefPtr<CefBrowser> browser_;
  CefRefPtr<CefRegistration> observer_;
  IMPLEMENT_REFCOUNTING(ContextAgent);
};

'''+s[b:]
s=s.replace('        if(this==root_) root_->chromium_contexts_["default"]=info->GetString("browserContextId").ToString();\n','')
a=s.index('        CefWindowInfo window;window.SetAsWindowless(0);CefBrowserSettings probe_settings;');b=s.index('\n      }\n      if(method=="Target.createTarget")',a)
s=s[:a]+'''        CefWindowInfo window;window.SetAsWindowless(0);CefBrowserSettings agent_settings;agent_settings.windowless_frame_rate=1;
        CefRefPtr<ContextAgent> agent=new ContextAgent();context_agents_[key]=agent;
        if(!CefBrowserHost::CreateBrowserSync(window,agent,"about:blank",agent_settings,nullptr,contexts_[key])) {
          context_agents_.erase(key);contexts_.erase(key);reply(nullptr,"CEF context initialization failed");return;
        }
        result->SetString("browserContextId",key);reply(result);return;'''+s[b:]
s=s.replace('chromium_contexts_.erase(key);','context_agents_.erase(key);')
s=s.replace('if(!chromium_contexts_.contains(key))', 'if(key!="default" && !context_agents_.contains(key))')
s=s.replace('auto forwarded=params->Copy(false);forwarded->SetString("browserContextId",chromium_contexts_.at(key));\n        DispatchCDP(id,method,forwarded,session,false);return;', '''auto forwarded=params->Copy(false);forwarded->Remove("browserContextId");
        if(key=="default") DispatchCDP(id,method,forwarded,session,false);
        else context_agents_.at(key)->Send(method,forwarded,[self=CefRefPtr<Source>(this),id,session](Dict response) {
          response->SetInt("id",id);if(!session.empty())response->SetString("sessionId",session);self->CDPMessage(response);
        });
        return;''')
s=s.replace('std::vector<CefRefPtr<ContextProbe>> probes;\n    for(const auto& [key,probe]:context_probes_)if(context.empty() || key==context)probes.push_back(probe);\n    for(const auto& probe:probes)probe->Close();','std::vector<CefRefPtr<ContextAgent>> agents;\n    for(const auto& [key,agent]:context_agents_)if(context.empty() || key==context)agents.push_back(agent);\n    for(const auto& agent:agents)agent->Close();')
s=s.replace('  std::map<std::string,std::string> chromium_contexts_;\n  std::map<std::string,CefRefPtr<ContextProbe>> context_probes_;','  std::map<std::string,CefRefPtr<ContextAgent>> context_agents_;')
p.write_text(s)
