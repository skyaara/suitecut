from pathlib import Path
import json, hashlib, shutil, csv, tarfile, statistics, subprocess
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/workspace/suitecut'); raw=Path('/tmp/suitecut-final-fixes'); up=Path('/tmp/suitecut-suite-pass')
out=root/'benchmarks/playwright-compatibility/2026-10-11-final-bridge-fixes'
out.mkdir(parents=True,exist_ok=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def writej(p,obj):p.write_text(json.dumps(obj,indent=2)+'\n')
def copy(src,dest):dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
runs={
 'final-cef':raw/'reply-guard-cef/results.json',
 'stock-chromium':raw/'final-chromium/results.json',
 'native-engine':raw/'reply-guard-engine/playwright-results.json',
 'upstream-cookies-screenshots':up/'reply-guard-cookies-screenshots/results.json',
 'upstream-known-issues':up/'reply-guard-known-issues/results.json',
 'stock-known-issues':up/'stock-known-issues/results.json',
}
rows=[];summaries={}
def visit(s,run,prefix=()):
 title=prefix+(s.get('title',''),)
 for spec in s.get('specs',[]):
  for test in spec.get('tests',[]):
   results=test.get('results',[])
   rows.append(dict(run=run,file=spec.get('file',''),line=spec.get('line'),title=' > '.join(t for t in title+(spec['title'],) if t),project=test.get('projectName',''),outcome=test.get('status'),expectedStatus=test.get('expectedStatus'),executionStatus=results[-1].get('status') if results else 'not-run',durationMs=sum(r.get('duration',0) for r in results),error=' | '.join(e.get('message','') for r in results for e in r.get('errors',[]))))
 for child in s.get('suites',[]):visit(child,run,title)
for name,p in runs.items():
 d=json.loads(p.read_text());summaries[name]=d['stats'];copy(p,out/'results'/f'{name}.json')
 for s in d['suites']:visit(s,name)
writej(out/'summary.json',summaries)
with (out/'cases.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for name in ['build-reply-guard.log','typecheck-guard.log','lint-guard.log','format-guard.log','unit.log','ctest.log','reply-guard-exit-codes.txt','reply-guard-frozen-sha256.txt','reply-guard-cef.log','reply-guard-engine.log','reply-guard-lifecycle.log']:
 copy(raw/name,out/'logs'/name)
for name in ['reply-guard-cookies-screenshots','reply-guard-known-issues','stock-known-issues']:
 copy(up/name/'run.log',out/'logs'/f'{name}.log')
files=['native/browser/browser.cc','native/browser/ENGINE.md','native/browser/BROWSER_SUPPORT.md','native/browser/cef-build-linux-codecs.json','benchmarks/playwright-compatibility/compatibility.spec.ts','benchmarks/playwright-compatibility/playwright.config.ts','benchmarks/native-engine/engine.e2e.spec.ts','benchmarks/native-engine/playwright.config.ts','benchmarks/native-memory/runtime.py','benchmarks/publication/sample.py','patches/playwright-core@1.62.1.patch','patches/README.md','src/native-browser.ts','src/engine.ts','src/engine-test.ts','src/engine-connection.ts']
for name in files:
 if (root/name).exists():copy(root/name,out/'tested-sources'/name)
harness=Path('/tmp/suitecut-playwright-upstream/playwright-1.62.1')
for name in ['tests/config/browserTest.ts','suitecut.config.ts']:
 copy(harness/name,out/'tested-sources/upstream-harness'/name)
for name in ['tests/library/browsercontext-add-cookies.spec.ts','tests/library/browsercontext-clearcookies.spec.ts','tests/library/browsercontext-cookies.spec.ts','tests/page/elementhandle-screenshot.spec.ts','tests/page/page-screenshot.spec.ts','tests/library/popup.spec.ts','tests/library/permissions.spec.ts','tests/page/page-aria-snapshot-ai.spec.ts']:
 copy(harness/name,out/'tested-sources/upstream-tests'/name)
# This is the same workload; only the import path changes for repository reuse.
(out/'lifecycle-profile.mjs').write_text((raw/'lifecycle-profile.mjs').read_text().replace("'/workspace/suitecut/dist/engine.js'","'../../../dist/engine.js'"))
for name in ['result.json','processes.jsonl']:
 copy(raw/'reply-guard-lifecycle'/name,out/'memory'/name)
d=json.loads((out/'memory/result.json').read_text());snapshots=[]
for s in d['snapshots']:
 native=[p for p in s['processes'] if p['name']=='suitecut-browser']
 snapshots.append(dict(label=s['label'],nativeProcesses=len(native),nativePssMiB=sum(p['pss'] for p in native)/2**20,nativeUssMiB=sum(p['uss'] for p in native)/2**20,nativeRssSumMiB=sum(p['rss'] for p in native)/2**20,nativeFds=sum(p['fds'] for p in native),nativeThreads=sum(p['threads'] for p in native),nodeHeapMiB=s['node']['heapUsed']/2**20))
writej(out/'memory/summary.json',dict(seed=d['seed'],cycles=len(d['cycles']),status=d['status'],startedAt=d['startedAt'],finishedAt=d['finishedAt'],snapshots=snapshots))
measured=snapshots[:-1];fig,axes=plt.subplots(1,2,figsize=(10,3.5),layout='constrained');x=[20,60,100,140]
for field,label in [('nativePssMiB','Native process tree PSS'),('nativeUssMiB','Native process tree USS')]:axes[0].plot(x,[r[field] for r in measured],marker='o',label=label)
axes[0].set(ylabel='MiB',xlabel='Completed context cycles',title='Settled native memory');axes[0].set_ylim(0,max(r['nativePssMiB'] for r in measured)*1.1);axes[0].legend(fontsize=8)
axes[1].plot(x,[r['nativeFds'] for r in measured],marker='o',label='Open descriptors');axes[1].plot(x,[r['nativeThreads'] for r in measured],marker='o',label='Threads');axes[1].set(xlabel='Completed context cycles',title='Native process tree resources');axes[1].set_ylim(bottom=0);axes[1].legend(fontsize=8)
for a in axes:a.grid(alpha=.2);a.set_xticks(x)
fig.suptitle('140-cycle CEF lifecycle regression; four CPUs / 16 GiB host\nNo native processes remain after shutdown',fontsize=11)
fig.savefig(out/'memory/lifecycle.svg');plt.close(fig)
copy(raw/'cef-srcdoc-repro.cc',out/'standalone-cef/cef-srcdoc-repro.cc')
for mode in ['standalone-cef','standalone-windowed']:
 copy(raw/mode/'browser-stderr.log',out/'standalone-cef'/f'{mode}-stderr.log')
copy(raw/'renderer-gdb-1159023.log',out/'standalone-cef/renderer-gdb.log')
(out/'standalone-cef/README.md').write_text('''# Standalone CEF srcdoc reproduction\n\nThis diagnostic links only CEF, its C++ wrapper and X11. It reproduces the\ninitial about:blank/srcdoc crash without SuiteCut or Playwright. Both recorded\nmodes report `SRC_CRASH:status=2 exit=5`; the program returns 2 on failure.\nThe codec-enabled pinned CEF version and digest are in the parent metadata.\n\nBuild command on the tested workspace (use matching SDK/runtime paths elsewhere):\n\n```bash\n/usr/bin/c++ -std=c++20 -DCEF_USE_SANDBOX \\\n  -I/workspace/suitecut/.suitecut/cef-codecs-sdk \\\n  cef-srcdoc-repro.cc \\\n  /tmp/suitecut-cef-full-regression-build/libcef_dll_wrapper/libcef_dll_wrapper.a \\\n  /workspace/suitecut/.suitecut/cef-codecs-sdk/Release/libcef.so \\\n  -Wl,-rpath,/tmp/suitecut-cef-full-regression-build -pthread \\\n  -L/workspace/suitecut/.suitecut/obs-deps/root/usr/lib/x86_64-linux-gnu \\\n  -l:libX11.so.6 -o /tmp/suitecut-cef-full-regression-build/cef-srcdoc-repro\n```\n\nRun under the same Xvfb/library environment with a distinct absolute profile\ndirectory per trial. `--no-sandbox --disable-gpu --profile=/tmp/unique-cef-profile`\nselects the tested host configuration. Add `--windowed` for the windowed trial.\nThe binary must live with the matching CEF resources, locales and native\nlibraries; this source is not a standalone runtime distribution.\n''')
metadata=dict(preparedAt=d['finishedAt'],baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),fallbackCommit='80759aeb30cc4f6bd4ab488554569c62851985d2',branch='suitecut-2.1-compatibility-fixes',suitecutVersion='2.1.0',cefPin=json.loads((root/'native/browser/cef-build-linux-codecs.json').read_text()),playwrightVersion='1.62.1',stockChromiumVersion='151.0.7922.34',cpuAffinity=[0,1,2,3],cpuQuota=(Path('/sys/fs/cgroup/cpu.max').read_text().strip()),memoryCgroupBytes=int(Path('/sys/fs/cgroup/memory.max').read_text()),enforcedEightGiBLimit=False,performanceBenchmark=False,helper={'path':'/tmp/suitecut-cef-full-regression-build/suitecut-browser','sha256':digest(Path('/tmp/suitecut-cef-full-regression-build/suitecut-browser')),'buildType':'Release','sanitizers':False},sourceHashes={name:digest(root/name) for name in files if (root/name).exists()},excludedUpstreamTitlePatterns=['should isolate cookies between launches','should work for webgl','should throw if screenshot size is too large'],unresolved=['early popup initialization','initial blank-origin srcdoc crash','storageAccess override','wakeLockScreen override'],fullUpstreamSuitePassing=False,wholeCefLeakFreedomProven=False)
# Freeze the installed Playwright transport identity as well as the patch source.
bundle=root/'node_modules/playwright-core/lib/coreBundle.js'
if bundle.exists():metadata['installedDriverCoreBundleSha256']=digest(bundle)
writej(out/'metadata.json',metadata)
validation='| Check | Result |\n| --- | --- |\n'
for key,label in [('final-cef','Focused CEF matrix'),('stock-chromium','Same matrix on stock Chromium'),('native-engine','Native media engine'),('upstream-cookies-screenshots','Selected upstream cookie/screenshot files'),('upstream-known-issues','Selected remaining CEF failures'),('stock-known-issues','Same remaining cases on stock Chromium')]:
 s=summaries[key];validation+=f"| {label} | {s['expected']} passed, {s['unexpected']} failed, {s['skipped']} skipped |\n"
validation+='| SDK delivery/native/connection unit tests | 41 passed |\n| Native CTest groups | 9 passed |\n| Native build, TypeScript, targeted ESLint and formatting | Passed |\n| Seeded lifecycle workload on final helper | 140 cycles passed |'
memtable='| Snapshot | Native processes | PSS MiB | USS MiB | Open FDs | Threads |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'
for r in snapshots:memtable+=f"| {r['label']} | {r['nativeProcesses']} | {r['nativePssMiB']:.2f} | {r['nativeUssMiB']:.2f} | {r['nativeFds']} | {r['nativeThreads']} |\n"
memtable+='\n![Settled native memory and resources](memory/lifecycle.svg)'
growth=measured[-1]['nativePssMiB']-measured[0]['nativePssMiB'];lastgrowth=measured[-1]['nativePssMiB']-measured[-2]['nativePssMiB']
interpret=f"Native PSS increased {growth:.2f} MiB between cycles 20 and 140, including {lastgrowth:.2f} MiB\nin the last 40-cycle block. Descriptor and thread counts stayed constant at\n{measured[-1]['nativeFds']} and {measured[-1]['nativeThreads']}. All native processes exited at final shutdown. These\nmeasurements show small retained growth, not zero growth; allocation caching and\na small leak cannot be distinguished by this short run. RSS sums double-count\nshared CEF pages, so PSS and USS are the primary figures. Node/controller memory\nis preserved separately in the raw snapshots."
report=(raw/'report-template.md').read_text().replace('@VALIDATION_TABLE@',validation).replace('@MEMORY_TABLE@',memtable).replace('@MEMORY_INTERPRETATION@',interpret).replace('@CONTROL_RESULTS@','The same five selected remaining cases pass on stock Chromium with the same\npinned Playwright driver. They are confirmed CEF/SuiteCut-path failures on this\nhost, rather than failures shared by this stock-browser control.')
(out/'report.md').write_text(report)
print(json.dumps({'out':str(out),'cases':len(rows),'nativePssGrowthMiB':growth,'summaries':summaries},indent=2))
