# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-clearcookies.spec.ts >> should remove partitioned cookies by name
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-clearcookies.spec.ts:205:3

# Error details

```
Error: browser.newContext: Target page, context or browser has been closed
Browser logs:

Native browser exited unexpectedly (null)

```

# Test source

```ts
  109 |   expect(await page.evaluate('document.cookie')).toBe('cookie2=2');
  110 |   await context.clearCookies({ domain: new URL(server.CROSS_PROCESS_PREFIX).hostname });
  111 |   expect(await page.evaluate('document.cookie')).toBe('');
  112 |   await page.goto(server.PREFIX);
  113 |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1');
  114 | });
  115 | 
  116 | it('should remove cookies by path', async ({ context, page, server }) => {
  117 |   await context.addCookies([{
  118 |     name: 'cookie1',
  119 |     value: '1',
  120 |     domain: new URL(server.PREFIX).hostname,
  121 |     path: '/api/v1',
  122 |   },
  123 |   {
  124 |     name: 'cookie2',
  125 |     value: '2',
  126 |     domain: new URL(server.PREFIX).hostname,
  127 |     path: '/api/v2',
  128 |   },
  129 |   {
  130 |     name: 'cookie3',
  131 |     value: '3',
  132 |     domain: new URL(server.PREFIX).hostname,
  133 |     path: '/',
  134 |   }
  135 |   ]);
  136 |   await page.goto(server.PREFIX + '/api/v1');
  137 |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1; cookie3=3');
  138 |   await context.clearCookies({ path: '/api/v1' });
  139 |   expect(await page.evaluate('document.cookie')).toBe('cookie3=3');
  140 |   await page.goto(server.PREFIX + '/api/v2');
  141 |   expect(await page.evaluate('document.cookie')).toBe('cookie2=2; cookie3=3');
  142 |   await page.goto(server.PREFIX + '/');
  143 |   expect(await page.evaluate('document.cookie')).toBe('cookie3=3');
  144 | });
  145 | 
  146 | it('should remove cookies by name and domain', async ({ context, page, server }) => {
  147 |   await context.addCookies([{
  148 |     name: 'cookie1',
  149 |     value: '1',
  150 |     domain: new URL(server.PREFIX).hostname,
  151 |     path: '/',
  152 |   },
  153 |   {
  154 |     name: 'cookie1',
  155 |     value: '1',
  156 |     domain: new URL(server.CROSS_PROCESS_PREFIX).hostname,
  157 |     path: '/',
  158 |   }
  159 |   ]);
  160 |   await page.goto(server.PREFIX);
  161 |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1');
  162 |   await context.clearCookies({ name: 'cookie1', domain: new URL(server.PREFIX).hostname });
  163 |   expect(await page.evaluate('document.cookie')).toBe('');
  164 |   await page.goto(server.CROSS_PROCESS_PREFIX);
  165 |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1');
  166 | });
  167 | 
  168 | it('should not transiently delete non-matching cookies when filtering', {
  169 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40953' },
  170 | }, async ({ context, page, server, browserName, isWindows, isFrozenWebkit }) => {
  171 |   it.skip(browserName === 'webkit' && isWindows, 'cookieStore change events not supported on WebKit/Windows (curl backend lacks cookie change notifications)');
  172 |   it.skip(isFrozenWebkit);
  173 | 
  174 |   await context.addCookies([{
  175 |     name: 'keep_me',
  176 |     value: '1',
  177 |     domain: new URL(server.PREFIX).hostname,
  178 |     path: '/',
  179 |   },
  180 |   {
  181 |     name: 'delete_me',
  182 |     value: '2',
  183 |     domain: new URL(server.PREFIX).hostname,
  184 |     path: '/',
  185 |   }
  186 |   ]);
  187 |   await page.goto(server.PREFIX);
  188 | 
  189 |   const eventsHandle = await page.evaluateHandle(() => {
  190 |     const events: string[] = [];
  191 |     cookieStore.addEventListener('change', event => {
  192 |       for (const changed of event.changed)
  193 |         events.push(`changed ${changed.name}`);
  194 |       for (const deleted of event.deleted)
  195 |         events.push(`deleted ${deleted.name}`);
  196 |     });
  197 |     return events;
  198 |   });
  199 | 
  200 |   await context.clearCookies({ name: 'delete_me' });
  201 |   await expect.poll(() => eventsHandle.jsonValue()).toEqual(['deleted delete_me']);
  202 |   expect(await page.evaluate('document.cookie')).toBe('keep_me=1');
  203 | });
  204 | 
  205 | it('should remove partitioned cookies by name', {
  206 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40953' },
  207 | }, async ({ browser, httpsServer, browserName }) => {
  208 |   it.skip(browserName !== 'chromium', 'Partitioned cookies (CHIPS) are Chromium-specific');
> 209 |   const context = await browser.newContext({ ignoreHTTPSErrors: true });
      |                   ^ Error: browser.newContext: Target page, context or browser has been closed
  210 |   await context.addCookies([
  211 |     {
  212 |       name: 'delete_me',
  213 |       value: '1',
  214 |       domain: httpsServer.HOSTNAME,
  215 |       path: '/',
  216 |       secure: true,
  217 |       sameSite: 'None',
  218 |       partitionKey: `https://${httpsServer.HOSTNAME}`,
  219 |     },
  220 |     {
  221 |       name: 'keep_me',
  222 |       value: '2',
  223 |       domain: httpsServer.HOSTNAME,
  224 |       path: '/',
  225 |       secure: true,
  226 |       sameSite: 'None',
  227 |       partitionKey: `https://${httpsServer.HOSTNAME}`,
  228 |     },
  229 |   ]);
  230 |   const before = await context.cookies();
  231 |   expect(before).toEqual([
  232 |     expect.objectContaining({ name: 'delete_me', partitionKey: `https://${httpsServer.HOSTNAME}` }),
  233 |     expect.objectContaining({ name: 'keep_me', partitionKey: `https://${httpsServer.HOSTNAME}` }),
  234 |   ]);
  235 | 
  236 |   await context.clearCookies({ name: 'delete_me' });
  237 |   expect(await context.cookies()).toEqual([
  238 |     expect.objectContaining({ name: 'keep_me', partitionKey: `https://${httpsServer.HOSTNAME}` }),
  239 |   ]);
  240 |   await context.close();
  241 | });
  242 | 
```