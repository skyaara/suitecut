# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/permissions.spec.ts >> permissions >> should isolate permissions between browser contexts
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/permissions.spec.ts:145:5

# Error details

```
Error: browser.newContext: Target page, context or browser has been closed
Browser logs:

Native browser exited unexpectedly (null)

```

# Test source

```ts
  48  |   });
  49  | 
  50  |   it('should fail when bad permission is given', async ({ page, context, server, isBidi }) => {
  51  |     await page.goto(server.EMPTY_PAGE);
  52  |     let error: Error;
  53  |     await context.grantPermissions(['foo'], { origin: server.EMPTY_PAGE }).catch(e => error = e);
  54  |     if (isBidi)
  55  |       expect(error.message).toContain('Protocol error (permissions.setPermission): invalid argument');
  56  |     else
  57  |       expect(error.message).toContain('Unknown permission: foo');
  58  |   });
  59  | 
  60  |   it('should grant geolocation permission when origin is listed', async ({ page, context, server }) => {
  61  |     await page.goto(server.EMPTY_PAGE);
  62  |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  63  |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  64  |   });
  65  | 
  66  |   it('should prompt for geolocation permission when origin is not listed', async ({ page, context, server }) => {
  67  |     await page.goto(server.EMPTY_PAGE);
  68  |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  69  |     await page.goto(server.CROSS_PROCESS_PREFIX + '/empty.html');
  70  |     expect(await getPermission(page, 'geolocation')).toBe('prompt');
  71  |   });
  72  | 
  73  |   it('should grant notifications permission when listed', async ({ page, context, server }) => {
  74  |     await page.goto(server.EMPTY_PAGE);
  75  |     await context.grantPermissions(['notifications'], { origin: server.EMPTY_PAGE });
  76  |     expect(await getPermission(page, 'notifications')).toBe('granted');
  77  |   });
  78  | 
  79  |   it('should accumulate when adding', async ({ page, context, server }) => {
  80  |     await page.goto(server.EMPTY_PAGE);
  81  |     await context.grantPermissions(['geolocation']);
  82  |     await context.grantPermissions(['notifications']);
  83  |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  84  |     expect(await getPermission(page, 'notifications')).toBe('granted');
  85  |   });
  86  | 
  87  |   it('should clear permissions', async ({ page, context, server }) => {
  88  |     await page.goto(server.EMPTY_PAGE);
  89  |     await context.grantPermissions(['geolocation']);
  90  |     await context.clearPermissions();
  91  |     await context.grantPermissions(['notifications']);
  92  |     expect(await getPermission(page, 'geolocation')).not.toBe('granted');
  93  |     expect(await getPermission(page, 'notifications')).toBe('granted');
  94  |   });
  95  | 
  96  |   it('should grant permission when listed for all domains', async ({ page, context, server }) => {
  97  |     await page.goto(server.EMPTY_PAGE);
  98  |     await context.grantPermissions(['geolocation']);
  99  |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  100 |   });
  101 | 
  102 |   it('should grant permission when creating context', async ({ server, browser }) => {
  103 |     const context = await browser.newContext({ permissions: ['geolocation'] });
  104 |     const page = await context.newPage();
  105 |     await page.goto(server.EMPTY_PAGE);
  106 |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  107 |     await context.close();
  108 |   });
  109 | 
  110 |   it('should reset permissions', async ({ page, context, server }) => {
  111 |     await page.goto(server.EMPTY_PAGE);
  112 |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  113 |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  114 |     await context.clearPermissions();
  115 |     expect(await getPermission(page, 'geolocation')).toBe('prompt');
  116 |   });
  117 | 
  118 |   it('should trigger permission onchange', async ({ page, context, server, browserName, isBidi }) => {
  119 |     it.fail(browserName === 'webkit');
  120 | 
  121 |     await page.goto(server.EMPTY_PAGE);
  122 |     await page.evaluate(() => {
  123 |       window['events'] = [];
  124 |       return navigator.permissions.query({ name: 'geolocation' }).then(function(result) {
  125 |         window['events'].push(result.state);
  126 |         result.onchange = function() {
  127 |           window['events'].push(result.state);
  128 |         };
  129 |       });
  130 |     });
  131 |     const expectedEvents = ['prompt'];
  132 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  133 |     await context.grantPermissions([], { origin: server.EMPTY_PAGE });
  134 |     if (!isBidi)
  135 |       expectedEvents.push('denied');
  136 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  137 |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  138 |     expectedEvents.push('granted');
  139 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  140 |     await context.clearPermissions();
  141 |     expectedEvents.push('prompt');
  142 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  143 |   });
  144 | 
  145 |   it('should isolate permissions between browser contexts', async ({ server, browser, browserName, isBidi, isFrozenWebkit }) => {
  146 |     it.skip(isFrozenWebkit);
  147 | 
> 148 |     const context = await browser.newContext();
      |                     ^ Error: browser.newContext: Target page, context or browser has been closed
  149 |     const page = await context.newPage();
  150 |     await page.goto(server.EMPTY_PAGE);
  151 |     const otherContext = await browser.newContext();
  152 |     const otherPage = await otherContext.newPage();
  153 |     await otherPage.goto(server.EMPTY_PAGE);
  154 |     expect(await getPermission(page, 'geolocation')).toBe('prompt');
  155 |     expect(await getPermission(otherPage, 'geolocation')).toBe('prompt');
  156 | 
  157 |     await context.grantPermissions([], { origin: server.EMPTY_PAGE });
  158 |     await otherContext.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  159 |     if (browserName === 'webkit') {
  160 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  161 |       // Since https://github.com/WebKit/WebKit/pull/45470 WebKit only returns actual
  162 |       // permission value, if the API has been accessed.
  163 |       await page.evaluate(() => navigator.geolocation.getCurrentPosition(() => { }));
  164 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  165 |     } else if (isBidi) {
  166 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  167 |     } else {
  168 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  169 |     }
  170 |     expect(await getPermission(otherPage, 'geolocation')).toBe('granted');
  171 | 
  172 |     await context.clearPermissions();
  173 |     if (browserName === 'webkit') {
  174 |       // Since https://github.com/WebKit/WebKit/pull/45470 WebKit returns the cached
  175 |       // permission value, if the geolocation API has been accessed.
  176 |       // TODO: We can probably reset the cached state in the Web Process when resetting
  177 |       // permissions.
  178 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  179 | 
  180 |       // Geolocation API in the new page in the same context has not been accessed yet,
  181 |       // so the permission status should be prompt.
  182 |       const page2 = await context.newPage();
  183 |       await page2.goto(server.EMPTY_PAGE);
  184 |       expect(await getPermission(page2, 'geolocation')).toBe('prompt');
  185 |       await page2.close();
  186 |     } else {
  187 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  188 |     }
  189 |     expect(await getPermission(otherPage, 'geolocation')).toBe('granted');
  190 |     await otherContext.close();
  191 |     await context.close();
  192 |   });
  193 | });
  194 | 
  195 | it('should support clipboard read', async ({ page, context, server, browserName, isWindows, isLinux, headless, isHeadlessShell }) => {
  196 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/27475' });
  197 |   it.fail(browserName === 'firefox', 'No such permissions (requires flag) in Firefox');
  198 |   it.fixme(browserName === 'webkit' && isWindows, 'WebPasteboardProxy::allPasteboardItemInfo not implemented for Windows.');
  199 |   it.fixme(browserName === 'webkit' && isLinux && headless, 'WebPasteboardProxy::allPasteboardItemInfo not implemented for WPE.');
  200 | 
  201 |   await page.goto(server.EMPTY_PAGE);
  202 |   // There is no 'clipboard-read' permission in WebKit Web API.
  203 |   if (browserName !== 'webkit')
  204 |     expect(await getPermission(page, 'clipboard-read')).toBe('prompt');
  205 | 
  206 |   if (isHeadlessShell) {
  207 |     // Chromium (but not headless-shell) shows a dialog and does not resolve the promise.
  208 |     const error = await page.evaluate(() => navigator.clipboard.readText()).catch(e => e);
  209 |     expect(error.toString()).toContain('denied');
  210 |   }
  211 | 
  212 |   await context.grantPermissions(['clipboard-read']);
  213 |   if (browserName !== 'webkit')
  214 |     expect(await getPermission(page, 'clipboard-read')).toBe('granted');
  215 |   // There is no 'clipboard-write' permission in WebKit Web API.
  216 |   if (browserName === 'chromium')
  217 |     await context.grantPermissions(['clipboard-write']);
  218 |   await page.evaluate(() => navigator.clipboard.writeText('test content'));
  219 |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe('test content');
  220 | });
  221 | 
  222 | it('storage access', {
  223 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/31227' }
  224 | }, async ({ page, context, server, browserName }) => {
  225 |   it.skip(browserName !== 'chromium', 'chromium-only api');
  226 | 
  227 |   await context.grantPermissions(['storage-access']);
  228 |   expect(await getPermission(page, 'storage-access')).toBe('granted');
  229 |   server.setRoute('/set-cookie.html', (req, res) => {
  230 |     res.setHeader('Set-Cookie', 'name=value; Path=/; SameSite=Strict; Secure');
  231 |     res.end();
  232 |   });
  233 |   server.setRoute('/my-frame.html', (req, res) => {
  234 |     res.setHeader('Content-type', 'text/html');
  235 |     res.end(`<iframe src="${server.CROSS_PROCESS_PREFIX + '/empty.html'}"></iframe>`);
  236 |   });
  237 | 
  238 |   // Navigate once to the domain as top level.
  239 |   await page.goto(server.CROSS_PROCESS_PREFIX + '/set-cookie.html');
  240 |   await page.goto(server.PREFIX + '/my-frame.html');
  241 | 
  242 |   const frame = page.frames()[1];
  243 |   expect(await getPermission(frame, 'storage-access')).toBe('granted');
  244 |   const access = await frame.evaluate(() => document.requestStorageAccess().then(() => true, () => false));
  245 |   expect(access).toBe(true);
  246 |   expect(await frame.evaluate(() => document.hasStorageAccess())).toBe(true);
  247 | });
  248 | 
```