# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-clearcookies.spec.ts >> should isolate cookies when clearing
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-clearcookies.spec.ts:34:3

# Error details

```
Error: browserContext.addCookies: Protocol error (Storage.setCookies): browserContextId is only allowed for Browser target
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2018 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { contextTest as it, expect } from '../config/browserTest';
  19  | 
  20  | it('should clear cookies', async ({ context, page, server }) => {
  21  |   await page.goto(server.EMPTY_PAGE);
  22  |   await context.addCookies([{
  23  |     url: server.EMPTY_PAGE,
  24  |     name: 'cookie1',
  25  |     value: '1'
  26  |   }]);
  27  |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1');
  28  |   await context.clearCookies();
  29  |   expect(await context.cookies()).toEqual([]);
  30  |   await page.reload();
  31  |   expect(await page.evaluate('document.cookie')).toBe('');
  32  | });
  33  | 
  34  | it('should isolate cookies when clearing', async ({ context, server, browser }) => {
  35  |   const anotherContext = await browser.newContext();
> 36  |   await context.addCookies([{ url: server.EMPTY_PAGE, name: 'page1cookie', value: 'page1value' }]);
      |                 ^ Error: browserContext.addCookies: Protocol error (Storage.setCookies): browserContextId is only allowed for Browser target
  37  |   await anotherContext.addCookies([{ url: server.EMPTY_PAGE, name: 'page2cookie', value: 'page2value' }]);
  38  | 
  39  |   expect((await context.cookies()).length).toBe(1);
  40  |   expect((await anotherContext.cookies()).length).toBe(1);
  41  | 
  42  |   await context.clearCookies();
  43  |   expect((await context.cookies()).length).toBe(0);
  44  |   expect((await anotherContext.cookies()).length).toBe(1);
  45  | 
  46  |   await anotherContext.clearCookies();
  47  |   expect((await context.cookies()).length).toBe(0);
  48  |   expect((await anotherContext.cookies()).length).toBe(0);
  49  |   await anotherContext.close();
  50  | });
  51  | 
  52  | it('should remove cookies by name', async ({ context, page, server }) => {
  53  |   await context.addCookies([{
  54  |     name: 'cookie1',
  55  |     value: '1',
  56  |     domain: new URL(server.PREFIX).hostname,
  57  |     path: '/',
  58  |   },
  59  |   {
  60  |     name: 'cookie2',
  61  |     value: '2',
  62  |     domain: new URL(server.PREFIX).hostname,
  63  |     path: '/',
  64  |   }
  65  |   ]);
  66  |   await page.goto(server.PREFIX);
  67  |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1; cookie2=2');
  68  |   await context.clearCookies({ name: 'cookie1' });
  69  |   expect(await page.evaluate('document.cookie')).toBe('cookie2=2');
  70  | });
  71  | 
  72  | it('should remove cookies by name regex', async ({ context, page, server }) => {
  73  |   await context.addCookies([{
  74  |     name: 'cookie1',
  75  |     value: '1',
  76  |     domain: new URL(server.PREFIX).hostname,
  77  |     path: '/',
  78  |   },
  79  |   {
  80  |     name: 'cookie2',
  81  |     value: '2',
  82  |     domain: new URL(server.PREFIX).hostname,
  83  |     path: '/',
  84  |   }
  85  |   ]);
  86  |   await page.goto(server.PREFIX);
  87  |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1; cookie2=2');
  88  |   await context.clearCookies({ name: /coo.*1/ });
  89  |   expect(await page.evaluate('document.cookie')).toBe('cookie2=2');
  90  | });
  91  | 
  92  | it('should remove cookies by domain', async ({ context, page, server }) => {
  93  |   await context.addCookies([{
  94  |     name: 'cookie1',
  95  |     value: '1',
  96  |     domain: new URL(server.PREFIX).hostname,
  97  |     path: '/',
  98  |   },
  99  |   {
  100 |     name: 'cookie2',
  101 |     value: '2',
  102 |     domain: new URL(server.CROSS_PROCESS_PREFIX).hostname,
  103 |     path: '/',
  104 |   }
  105 |   ]);
  106 |   await page.goto(server.PREFIX);
  107 |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1');
  108 |   await page.goto(server.CROSS_PROCESS_PREFIX);
  109 |   expect(await page.evaluate('document.cookie')).toBe('cookie2=2');
  110 |   await context.clearCookies({ domain: new URL(server.CROSS_PROCESS_PREFIX).hostname });
  111 |   expect(await page.evaluate('document.cookie')).toBe('');
  112 |   await page.goto(server.PREFIX);
  113 |   expect(await page.evaluate('document.cookie')).toBe('cookie1=1');
  114 | });
  115 | 
  116 | it('should remove cookies by path', async ({ context, page, server }) => {
  117 |   await context.addCookies([{
  118 |     name: 'cookie1',
  119 |     value: '1',
  120 |     domain: new URL(server.PREFIX).hostname,
  121 |     path: '/api/v1',
  122 |   },
  123 |   {
  124 |     name: 'cookie2',
  125 |     value: '2',
  126 |     domain: new URL(server.PREFIX).hostname,
  127 |     path: '/api/v2',
  128 |   },
  129 |   {
  130 |     name: 'cookie3',
  131 |     value: '3',
  132 |     domain: new URL(server.PREFIX).hostname,
  133 |     path: '/',
  134 |   }
  135 |   ]);
  136 |   await page.goto(server.PREFIX + '/api/v1');
```