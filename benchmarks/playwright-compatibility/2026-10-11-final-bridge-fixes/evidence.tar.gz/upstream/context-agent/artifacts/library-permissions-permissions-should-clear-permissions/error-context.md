# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/permissions.spec.ts >> permissions >> should clear permissions
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/permissions.spec.ts:87:5

# Error details

```
Error: browserContext.grantPermissions: Protocol error (Browser.grantPermissions): Failed to find browser context for id E7852B8CEF38144D282A0172F915039C
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2017 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { contextTest as it, expect } from '../config/browserTest';
  19  | 
  20  | function getPermission(page, name) {
  21  |   return page.evaluate(name => navigator.permissions.query({ name }).then(result => result.state), name);
  22  | }
  23  | 
  24  | it.describe('permissions', () => {
  25  |   it.fixme(({ browserName, isWindows }) => browserName === 'webkit' && isWindows, 'Permissions API is disabled on Windows WebKit');
  26  | 
  27  |   it('should be prompt by default', async ({ page, server }) => {
  28  |     await page.goto(server.EMPTY_PAGE);
  29  |     expect(await getPermission(page, 'geolocation')).toBe('prompt');
  30  |   });
  31  | 
  32  |   it('should deny permission when not listed', async ({ page, context, server, browserName, isBidi, isFrozenWebkit }) => {
  33  |     it.skip(isFrozenWebkit);
  34  | 
  35  |     await page.goto(server.EMPTY_PAGE);
  36  |     await context.grantPermissions([], { origin: server.EMPTY_PAGE });
  37  |     if (browserName === 'webkit') {
  38  |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  39  |       // Since https://github.com/WebKit/WebKit/pull/45470 WebKit only returns actual
  40  |       // permission value, if the API has been accessed.
  41  |       await page.evaluate(() => navigator.geolocation.getCurrentPosition(() => { }));
  42  |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  43  |     } else if (isBidi) {
  44  |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  45  |     } else {
  46  |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  47  |     }
  48  |   });
  49  | 
  50  |   it('should fail when bad permission is given', async ({ page, context, server, isBidi }) => {
  51  |     await page.goto(server.EMPTY_PAGE);
  52  |     let error: Error;
  53  |     await context.grantPermissions(['foo'], { origin: server.EMPTY_PAGE }).catch(e => error = e);
  54  |     if (isBidi)
  55  |       expect(error.message).toContain('Protocol error (permissions.setPermission): invalid argument');
  56  |     else
  57  |       expect(error.message).toContain('Unknown permission: foo');
  58  |   });
  59  | 
  60  |   it('should grant geolocation permission when origin is listed', async ({ page, context, server }) => {
  61  |     await page.goto(server.EMPTY_PAGE);
  62  |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  63  |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  64  |   });
  65  | 
  66  |   it('should prompt for geolocation permission when origin is not listed', async ({ page, context, server }) => {
  67  |     await page.goto(server.EMPTY_PAGE);
  68  |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  69  |     await page.goto(server.CROSS_PROCESS_PREFIX + '/empty.html');
  70  |     expect(await getPermission(page, 'geolocation')).toBe('prompt');
  71  |   });
  72  | 
  73  |   it('should grant notifications permission when listed', async ({ page, context, server }) => {
  74  |     await page.goto(server.EMPTY_PAGE);
  75  |     await context.grantPermissions(['notifications'], { origin: server.EMPTY_PAGE });
  76  |     expect(await getPermission(page, 'notifications')).toBe('granted');
  77  |   });
  78  | 
  79  |   it('should accumulate when adding', async ({ page, context, server }) => {
  80  |     await page.goto(server.EMPTY_PAGE);
  81  |     await context.grantPermissions(['geolocation']);
  82  |     await context.grantPermissions(['notifications']);
  83  |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  84  |     expect(await getPermission(page, 'notifications')).toBe('granted');
  85  |   });
  86  | 
  87  |   it('should clear permissions', async ({ page, context, server }) => {
  88  |     await page.goto(server.EMPTY_PAGE);
> 89  |     await context.grantPermissions(['geolocation']);
      |                   ^ Error: browserContext.grantPermissions: Protocol error (Browser.grantPermissions): Failed to find browser context for id E7852B8CEF38144D282A0172F915039C
  90  |     await context.clearPermissions();
  91  |     await context.grantPermissions(['notifications']);
  92  |     expect(await getPermission(page, 'geolocation')).not.toBe('granted');
  93  |     expect(await getPermission(page, 'notifications')).toBe('granted');
  94  |   });
  95  | 
  96  |   it('should grant permission when listed for all domains', async ({ page, context, server }) => {
  97  |     await page.goto(server.EMPTY_PAGE);
  98  |     await context.grantPermissions(['geolocation']);
  99  |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  100 |   });
  101 | 
  102 |   it('should grant permission when creating context', async ({ server, browser }) => {
  103 |     const context = await browser.newContext({ permissions: ['geolocation'] });
  104 |     const page = await context.newPage();
  105 |     await page.goto(server.EMPTY_PAGE);
  106 |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  107 |     await context.close();
  108 |   });
  109 | 
  110 |   it('should reset permissions', async ({ page, context, server }) => {
  111 |     await page.goto(server.EMPTY_PAGE);
  112 |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  113 |     expect(await getPermission(page, 'geolocation')).toBe('granted');
  114 |     await context.clearPermissions();
  115 |     expect(await getPermission(page, 'geolocation')).toBe('prompt');
  116 |   });
  117 | 
  118 |   it('should trigger permission onchange', async ({ page, context, server, browserName, isBidi }) => {
  119 |     it.fail(browserName === 'webkit');
  120 | 
  121 |     await page.goto(server.EMPTY_PAGE);
  122 |     await page.evaluate(() => {
  123 |       window['events'] = [];
  124 |       return navigator.permissions.query({ name: 'geolocation' }).then(function(result) {
  125 |         window['events'].push(result.state);
  126 |         result.onchange = function() {
  127 |           window['events'].push(result.state);
  128 |         };
  129 |       });
  130 |     });
  131 |     const expectedEvents = ['prompt'];
  132 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  133 |     await context.grantPermissions([], { origin: server.EMPTY_PAGE });
  134 |     if (!isBidi)
  135 |       expectedEvents.push('denied');
  136 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  137 |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  138 |     expectedEvents.push('granted');
  139 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  140 |     await context.clearPermissions();
  141 |     expectedEvents.push('prompt');
  142 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  143 |   });
  144 | 
  145 |   it('should isolate permissions between browser contexts', async ({ server, browser, browserName, isBidi, isFrozenWebkit }) => {
  146 |     it.skip(isFrozenWebkit);
  147 | 
  148 |     const context = await browser.newContext();
  149 |     const page = await context.newPage();
  150 |     await page.goto(server.EMPTY_PAGE);
  151 |     const otherContext = await browser.newContext();
  152 |     const otherPage = await otherContext.newPage();
  153 |     await otherPage.goto(server.EMPTY_PAGE);
  154 |     expect(await getPermission(page, 'geolocation')).toBe('prompt');
  155 |     expect(await getPermission(otherPage, 'geolocation')).toBe('prompt');
  156 | 
  157 |     await context.grantPermissions([], { origin: server.EMPTY_PAGE });
  158 |     await otherContext.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  159 |     if (browserName === 'webkit') {
  160 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  161 |       // Since https://github.com/WebKit/WebKit/pull/45470 WebKit only returns actual
  162 |       // permission value, if the API has been accessed.
  163 |       await page.evaluate(() => navigator.geolocation.getCurrentPosition(() => { }));
  164 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  165 |     } else if (isBidi) {
  166 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  167 |     } else {
  168 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  169 |     }
  170 |     expect(await getPermission(otherPage, 'geolocation')).toBe('granted');
  171 | 
  172 |     await context.clearPermissions();
  173 |     if (browserName === 'webkit') {
  174 |       // Since https://github.com/WebKit/WebKit/pull/45470 WebKit returns the cached
  175 |       // permission value, if the geolocation API has been accessed.
  176 |       // TODO: We can probably reset the cached state in the Web Process when resetting
  177 |       // permissions.
  178 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  179 | 
  180 |       // Geolocation API in the new page in the same context has not been accessed yet,
  181 |       // so the permission status should be prompt.
  182 |       const page2 = await context.newPage();
  183 |       await page2.goto(server.EMPTY_PAGE);
  184 |       expect(await getPermission(page2, 'geolocation')).toBe('prompt');
  185 |       await page2.close();
  186 |     } else {
  187 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  188 |     }
  189 |     expect(await getPermission(otherPage, 'geolocation')).toBe('granted');
```