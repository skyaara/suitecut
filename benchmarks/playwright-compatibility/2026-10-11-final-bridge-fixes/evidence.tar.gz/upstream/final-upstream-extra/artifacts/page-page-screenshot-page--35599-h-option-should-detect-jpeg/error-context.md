# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-screenshot.spec.ts >> page screenshot >> path option should detect jpeg
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-screenshot.spec.ts:446:5

# Error details

```
Error: expect(Buffer).toMatchSnapshot(expected) failed

  90000 pixels (ratio 1.00 of all image pixels) are different.

  Snapshot: white.jpg

```

# Test source

```ts
  351 |       }
  352 |     });
  353 |     expect(screenshot).toMatchSnapshot('screenshot-clip-odd-size.png');
  354 |   });
  355 | 
  356 |   it('should work for canvas', async ({ page, server }) => {
  357 |     await page.setViewportSize({ width: 500, height: 500 });
  358 |     await page.goto(server.PREFIX + '/screenshots/canvas.html');
  359 |     const screenshot = await page.screenshot();
  360 |     // Allow 4 corners to be rendered differently on various platforms/browsers.
  361 |     expect(screenshot).toMatchSnapshot('screenshot-canvas.png', { maxDiffPixels: 4 });
  362 |   });
  363 | 
  364 |   it('should capture canvas changes', async ({ page, isElectron }) => {
  365 |     it.skip(isElectron);
  366 |     await page.goto('data:text/html,<canvas></canvas>');
  367 |     await page.evaluate(() => {
  368 |       const canvas = document.querySelector('canvas');
  369 |       canvas.width = 600;
  370 |       canvas.height = 600;
  371 |     });
  372 | 
  373 |     async function addLine(step: number) {
  374 |       await page.evaluate(n => {
  375 |         const canvas = document.querySelector('canvas');
  376 |         const ctx = canvas.getContext('2d');
  377 |         ctx.lineWidth = 1;
  378 |         ctx.beginPath();
  379 |         ctx.moveTo(0, n * 100);
  380 |         ctx.lineTo(300, n * 100);
  381 |         ctx.stroke();
  382 |       }, step);
  383 |     }
  384 | 
  385 |     for (let i = 0; i < 3; i++) {
  386 |       await addLine(i);
  387 |       // With the slight delay WebKit stops reflecting changes in the screenshots on macOS.
  388 |       await new Promise(f => setTimeout(f, 100));
  389 |       const screenshot = await page.screenshot();
  390 |       expect(screenshot).toMatchSnapshot(`canvas-changes-${i}.png`);
  391 |     }
  392 |   });
  393 | 
  394 |   it('should work for webgl', async ({ page, server, browserName, platform, isElectron }) => {
  395 |     it.skip(browserName === 'webkit' && platform === 'darwin' && os.arch() === 'x64', 'WebGL is not available on Intel macOS - https://bugs.webkit.org/show_bug.cgi?id=278277');
  396 |     it.skip(isElectron, 'different rendering in electron');
  397 | 
  398 |     await page.setViewportSize({ width: 640, height: 480 });
  399 |     await page.goto(server.PREFIX + '/screenshots/webgl.html');
  400 |     const screenshot = await page.screenshot();
  401 |     expect(screenshot).toMatchSnapshot('screenshot-webgl.png');
  402 |   });
  403 | 
  404 |   it('should work for translateZ', async ({ page, server }) => {
  405 |     await page.setViewportSize({ width: 500, height: 500 });
  406 |     await page.goto(server.PREFIX + '/screenshots/translateZ.html');
  407 |     const screenshot = await page.screenshot();
  408 |     expect(screenshot).toMatchSnapshot('screenshot-translateZ.png');
  409 |   });
  410 | 
  411 |   it('should work while navigating', async ({ page, server }) => {
  412 |     await page.setViewportSize({ width: 500, height: 500 });
  413 |     await page.goto(server.PREFIX + '/redirectloop1.html');
  414 |     for (let i = 0; i < 10; i++) {
  415 |       const screenshot = await page.screenshot({ fullPage: true }).catch(e => {
  416 |         if (e.message.includes('Cannot take a screenshot while page is navigating'))
  417 |           return Buffer.from('');
  418 |         throw e;
  419 |       });
  420 |       expect(screenshot).toBeInstanceOf(Buffer);
  421 |     }
  422 |   });
  423 | 
  424 |   it('should work with iframe in shadow', async ({ page, server }) => {
  425 |     await page.setViewportSize({ width: 500, height: 500 });
  426 |     await page.goto(server.PREFIX + '/grid-iframe-in-shadow.html');
  427 |     expect(await page.screenshot()).toMatchSnapshot('screenshot-iframe.png');
  428 |   });
  429 | 
  430 |   it('path option should work', async ({ page, server }, testInfo) => {
  431 |     await page.setViewportSize({ width: 500, height: 500 });
  432 |     await page.goto(server.PREFIX + '/grid.html');
  433 |     const outputPath = testInfo.outputPath('screenshot.png');
  434 |     await page.screenshot({ path: outputPath });
  435 |     expect(await fs.promises.readFile(outputPath)).toMatchSnapshot('screenshot-sanity.png');
  436 |   });
  437 | 
  438 |   it('path option should create subdirectories', async ({ page, server }, testInfo) => {
  439 |     await page.setViewportSize({ width: 500, height: 500 });
  440 |     await page.goto(server.PREFIX + '/grid.html');
  441 |     const outputPath = testInfo.outputPath(path.join('these', 'are', 'directories', 'screenshot.png'));
  442 |     await page.screenshot({ path: outputPath });
  443 |     expect(await fs.promises.readFile(outputPath)).toMatchSnapshot('screenshot-sanity.png');
  444 |   });
  445 | 
  446 |   it('path option should detect jpeg', async ({ page, server, isElectron }, testInfo) => {
  447 |     await page.setViewportSize({ width: 300, height: 300 });
  448 |     await page.goto(server.EMPTY_PAGE);
  449 |     const outputPath = testInfo.outputPath('screenshot.jpg');
  450 |     const screenshot = await page.screenshot({ omitBackground: true, path: outputPath });
> 451 |     expect(await fs.promises.readFile(outputPath)).toMatchSnapshot('white.jpg');
      |                                                    ^ Error: expect(Buffer).toMatchSnapshot(expected) failed
  452 |     expect(screenshot).toMatchSnapshot('white.jpg');
  453 |   });
  454 | 
  455 |   it('path option should throw for unsupported mime type', async ({ page }) => {
  456 |     const error = await page.screenshot({ path: 'file.txt' }).catch(e => e);
  457 |     expect(error.message).toContain('path: unsupported mime type "text/plain"');
  458 |   });
  459 | 
  460 |   it('quality option should throw for png', async ({ page }) => {
  461 |     const error = await page.screenshot({ quality: 10 }).catch(e => e);
  462 |     expect(error.message).toContain('options.quality is unsupported for the png');
  463 |   });
  464 | 
  465 |   it('zero quality option should throw for png', async ({ page }) => {
  466 |     const error = await page.screenshot({ quality: 0, type: 'png' }).catch(e => e);
  467 |     expect(error.message).toContain('options.quality is unsupported for the png');
  468 |   });
  469 | 
  470 |   it('quality option should work for jpeg', async ({ page, server }) => {
  471 |     await page.goto(server.PREFIX + '/grid.html');
  472 |     const zeroQuality = await page.screenshot({ type: 'jpeg', quality: 0 });
  473 |     const highQuality = await page.screenshot({ type: 'jpeg', quality: 100 });
  474 |     expect(zeroQuality.byteLength).toBeLessThan(highQuality.byteLength);
  475 |   });
  476 | 
  477 |   it('should prefer type over extension', async ({ page }, testInfo) => {
  478 |     const outputPath = testInfo.outputPath('file.png');
  479 |     const buffer = await page.screenshot({ path: outputPath, type: 'jpeg' });
  480 |     expect([buffer[0], buffer[1], buffer[2]]).toEqual([0xFF, 0xD8, 0xFF]);
  481 |   });
  482 | 
  483 |   it('should not issue resize event', async ({ page, server }) => {
  484 |     await page.goto(server.PREFIX + '/grid.html');
  485 |     let resizeTriggered = false;
  486 |     await page.exposeFunction('resize', () => {
  487 |       resizeTriggered = true;
  488 |     });
  489 |     await page.evaluate(() => {
  490 |       window.addEventListener('resize', () => (window as any).resize());
  491 |     });
  492 |     await page.screenshot();
  493 |     expect(resizeTriggered).toBeFalsy();
  494 |   });
  495 | 
  496 |   it('should work with Array deleted', async ({ page, server }) => {
  497 |     await page.setViewportSize({ width: 500, height: 500 });
  498 |     await page.goto(server.PREFIX + '/grid.html');
  499 |     await page.evaluate(() => delete window.Array);
  500 |     const screenshot = await page.screenshot({ fullPage: true });
  501 |     expect(screenshot).toMatchSnapshot('screenshot-grid-fullpage.png');
  502 |   });
  503 | 
  504 |   it('should take fullPage screenshots during navigation', async ({ page, server }) => {
  505 |     it.slow();
  506 | 
  507 |     await page.setViewportSize({ width: 500, height: 500 });
  508 |     await page.goto(server.PREFIX + '/grid.html');
  509 |     const reloadSeveralTimes = async () => {
  510 |       for (let i = 0; i < 5; ++i)
  511 |         await page.reload();
  512 |     };
  513 |     const screenshotSeveralTimes = async () => {
  514 |       for (let i = 0; i < 5; ++i)
  515 |         await page.screenshot({ fullPage: true });
  516 |     };
  517 |     await Promise.all([
  518 |       reloadSeveralTimes(),
  519 |       screenshotSeveralTimes()
  520 |     ]);
  521 |   });
  522 | 
  523 |   it.describe('mask option', () => {
  524 |     it('should work', async ({ page, server }) => {
  525 |       await page.setViewportSize({ width: 500, height: 500 });
  526 |       await page.goto(server.PREFIX + '/grid.html');
  527 |       expect(await page.screenshot({
  528 |         mask: [page.locator('div').nth(5)],
  529 |       })).toMatchSnapshot('mask-should-work.png');
  530 |     });
  531 | 
  532 |     it('should work with locator', async ({ page, server }) => {
  533 |       await page.setViewportSize({ width: 500, height: 500 });
  534 |       await page.goto(server.PREFIX + '/grid.html');
  535 |       const bodyLocator = page.locator('body');
  536 |       expect(await bodyLocator.screenshot({
  537 |         mask: [page.locator('div').nth(5)],
  538 |       })).toMatchSnapshot('mask-should-work-with-locator.png');
  539 |     });
  540 | 
  541 |     it('should work with elementhandle', async ({ page, server }) => {
  542 |       await page.setViewportSize({ width: 500, height: 500 });
  543 |       await page.goto(server.PREFIX + '/grid.html');
  544 |       const bodyHandle = await page.$('body');
  545 |       expect(await bodyHandle.screenshot({
  546 |         mask: [page.locator('div').nth(5)],
  547 |       })).toMatchSnapshot('mask-should-work-with-elementhandle.png');
  548 |     });
  549 | 
  550 |     it('should mask multiple elements', async ({ page, server }) => {
  551 |       await page.setViewportSize({ width: 500, height: 500 });
```