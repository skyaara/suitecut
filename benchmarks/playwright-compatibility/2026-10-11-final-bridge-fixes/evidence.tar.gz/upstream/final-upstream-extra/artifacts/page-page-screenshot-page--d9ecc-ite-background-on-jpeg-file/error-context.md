# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-screenshot.spec.ts >> page screenshot >> should render white background on jpeg file
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-screenshot.spec.ts:275:5

# Error details

```
Error: expect(Buffer).toMatchSnapshot(expected) failed

  90000 pixels (ratio 1.00 of all image pixels) are different.

  Snapshot: white.jpg

```

# Test source

```ts
  179 |       }
  180 |     });
  181 |     expect(screenshot).toMatchSnapshot('screenshot-offscreen-clip.png');
  182 |   });
  183 | 
  184 |   it('should throw on clip outside the viewport', async ({ page, server }) => {
  185 |     await page.setViewportSize({ width: 500, height: 500 });
  186 |     await page.goto(server.PREFIX + '/grid.html');
  187 |     const screenshotError = await page.screenshot({
  188 |       clip: {
  189 |         x: 50,
  190 |         y: 650,
  191 |         width: 100,
  192 |         height: 100
  193 |       }
  194 |     }).catch(error => error);
  195 |     expect(screenshotError.message).toContain('Clipped area is either empty or outside the resulting image');
  196 |   });
  197 | 
  198 |   it('should throw on a negative clip size', async ({ page, server }) => {
  199 |     await page.setViewportSize({ width: 500, height: 500 });
  200 |     await page.goto(server.PREFIX + '/grid.html');
  201 |     const screenshotError = await page.screenshot({
  202 |       clip: {
  203 |         x: 50,
  204 |         y: 50,
  205 |         width: -100,
  206 |         height: 100
  207 |       }
  208 |     }).catch(error => error);
  209 |     expect(screenshotError.message).toContain('Expected options.clip.width to be greater than 0');
  210 |   });
  211 | 
  212 |   it('should run in parallel', async ({ page, server }) => {
  213 |     await page.setViewportSize({ width: 500, height: 500 });
  214 |     await page.goto(server.PREFIX + '/grid.html');
  215 |     const promises = [];
  216 |     for (let i = 0; i < 3; ++i) {
  217 |       promises.push(page.screenshot({
  218 |         clip: {
  219 |           x: 50 * i,
  220 |           y: 0,
  221 |           width: 50,
  222 |           height: 50
  223 |         }
  224 |       }));
  225 |     }
  226 |     const screenshots = await Promise.all(promises);
  227 |     expect(screenshots[1]).toMatchSnapshot('grid-cell-1.png');
  228 |   });
  229 | 
  230 |   it('should take fullPage screenshots', async ({ page, server }) => {
  231 |     await page.setViewportSize({ width: 500, height: 500 });
  232 |     await page.goto(server.PREFIX + '/grid.html');
  233 |     const screenshot = await page.screenshot({
  234 |       fullPage: true
  235 |     });
  236 |     expect(screenshot).toMatchSnapshot('screenshot-grid-fullpage.png');
  237 |   });
  238 | 
  239 |   it('should take fullPage screenshots and mask elements outside of it', async ({ page, server }) => {
  240 |     it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/30770' });
  241 |     await page.setViewportSize({ width: 500, height: 500 });
  242 |     await page.goto(server.PREFIX + '/grid.html');
  243 |     const screenshot = await page.screenshot({
  244 |       fullPage: true,
  245 |       mask: [page.locator('.box').nth(144)],
  246 |     });
  247 |     expect(screenshot).toMatchSnapshot('screenshot-grid-fullpage-mask-outside-viewport.png');
  248 |   });
  249 | 
  250 |   it('should restore viewport after fullPage screenshot', async ({ page, server }) => {
  251 |     await page.setViewportSize({ width: 500, height: 500 });
  252 |     await page.goto(server.PREFIX + '/grid.html');
  253 |     const screenshot = await page.screenshot({ fullPage: true });
  254 |     expect(screenshot).toBeInstanceOf(Buffer);
  255 |     await verifyViewport(page, 500, 500);
  256 |   });
  257 | 
  258 |   it('should allow transparency', async ({ page, browserName, isBidi }) => {
  259 |     it.fail(browserName === 'firefox' || isBidi);
  260 | 
  261 |     await page.setViewportSize({ width: 300, height: 300 });
  262 |     await page.setContent(`
  263 |       <style>
  264 |         body { margin: 0 }
  265 |         div { width: 300px; height: 100px; }
  266 |       </style>
  267 |       <div style="background:black"></div>
  268 |       <div style="background:white"></div>
  269 |       <div style="background:transparent"></div>
  270 |     `);
  271 |     const screenshot = await page.screenshot({ omitBackground: true });
  272 |     expect(screenshot).toMatchSnapshot('transparent.png');
  273 |   });
  274 | 
  275 |   it('should render white background on jpeg file', async ({ page, server, isElectron }) => {
  276 |     await page.setViewportSize({ width: 300, height: 300 });
  277 |     await page.goto(server.EMPTY_PAGE);
  278 |     const screenshot = await page.screenshot({ omitBackground: true, type: 'jpeg' });
> 279 |     expect(screenshot).toMatchSnapshot('white.jpg');
      |                        ^ Error: expect(Buffer).toMatchSnapshot(expected) failed
  280 |   });
  281 | 
  282 |   it('should produce a valid webp screenshot', async ({ page, server }) => {
  283 |     await page.setViewportSize({ width: 300, height: 300 });
  284 |     await page.goto(server.EMPTY_PAGE);
  285 |     await page.evaluate(() => (document.body.style.background = 'rgb(255, 0, 0)'));
  286 |     const screenshot = await page.screenshot({ type: 'webp' });
  287 |     expect(screenshot).toMatchSnapshot('red.webp');
  288 |   });
  289 | 
  290 |   it('path option should detect webp', async ({ page, server }, testInfo) => {
  291 |     await page.setViewportSize({ width: 300, height: 300 });
  292 |     await page.goto(server.EMPTY_PAGE);
  293 |     await page.evaluate(() => (document.body.style.background = 'rgb(255, 0, 0)'));
  294 |     const outputPath = testInfo.outputPath('screenshot.webp');
  295 |     const screenshot = await page.screenshot({ path: outputPath });
  296 |     expect(await fs.promises.readFile(outputPath)).toMatchSnapshot('red.webp');
  297 |     expect(screenshot).toMatchSnapshot('red.webp');
  298 |   });
  299 | 
  300 |   it('quality option should work for webp', async ({ page, server }) => {
  301 |     await page.goto(server.PREFIX + '/grid.html');
  302 |     const lowQuality = await page.screenshot({ type: 'webp', quality: 0 });
  303 |     const highQuality = await page.screenshot({ type: 'webp', quality: 100 });
  304 |     expect(lowQuality.byteLength).toBeLessThan(highQuality.byteLength);
  305 |   });
  306 | 
  307 |   it('webp screenshots should be lossless by default', async ({ page, server }) => {
  308 |     await page.goto(server.PREFIX + '/grid.html');
  309 |     expect(utils.isLosslessWebp(await page.screenshot({ type: 'webp' }))).toBe(true);
  310 |     expect(utils.isLosslessWebp(await page.screenshot({ type: 'webp', quality: 80 }))).toBe(false);
  311 |   });
  312 | 
  313 |   it('should allow transparency with webp', async ({ page, browserName, isBidi }) => {
  314 |     it.skip(isBidi, 'transparency is not supported via WebDriver BiDi');
  315 |     it.fail(browserName === 'firefox');
  316 | 
  317 |     await page.setViewportSize({ width: 300, height: 300 });
  318 |     await page.setContent(`
  319 |       <style>
  320 |         body { margin: 0 }
  321 |         div { width: 300px; height: 100px; }
  322 |       </style>
  323 |       <div style="background:black"></div>
  324 |       <div style="background:white"></div>
  325 |       <div style="background:transparent"></div>
  326 |     `);
  327 |     const screenshot = await page.screenshot({ omitBackground: true, type: 'webp' });
  328 |     const { width, height, data } = utils.decodeWebp(screenshot);
  329 |     expect(width).toBe(300);
  330 |     expect(height).toBe(300);
  331 |     const pixel = (x: number, y: number) => [...data.subarray((y * width + x) * 4, (y * width + x) * 4 + 4)];
  332 |     expect(pixel(150, 50)).toEqual([0, 0, 0, 255]);
  333 |     expect(pixel(150, 150)).toEqual([255, 255, 255, 255]);
  334 |     expect(pixel(150, 250)[3]).toBe(0);
  335 |   });
  336 | 
  337 |   it('quality option should throw for webp when out of range', async ({ page }) => {
  338 |     const error = await page.screenshot({ type: 'webp', quality: 101 }).catch(e => e);
  339 |     expect(error.message).toContain('Expected options.quality to be between 0 and 100');
  340 |   });
  341 | 
  342 |   it('should work with odd clip size on Retina displays', async ({ page, isElectron }) => {
  343 |     it.skip(isElectron, 'electron does not set device scale factor to 1');
  344 | 
  345 |     const screenshot = await page.screenshot({
  346 |       clip: {
  347 |         x: 0,
  348 |         y: 0,
  349 |         width: 11,
  350 |         height: 11,
  351 |       }
  352 |     });
  353 |     expect(screenshot).toMatchSnapshot('screenshot-clip-odd-size.png');
  354 |   });
  355 | 
  356 |   it('should work for canvas', async ({ page, server }) => {
  357 |     await page.setViewportSize({ width: 500, height: 500 });
  358 |     await page.goto(server.PREFIX + '/screenshots/canvas.html');
  359 |     const screenshot = await page.screenshot();
  360 |     // Allow 4 corners to be rendered differently on various platforms/browsers.
  361 |     expect(screenshot).toMatchSnapshot('screenshot-canvas.png', { maxDiffPixels: 4 });
  362 |   });
  363 | 
  364 |   it('should capture canvas changes', async ({ page, isElectron }) => {
  365 |     it.skip(isElectron);
  366 |     await page.goto('data:text/html,<canvas></canvas>');
  367 |     await page.evaluate(() => {
  368 |       const canvas = document.querySelector('canvas');
  369 |       canvas.width = 600;
  370 |       canvas.height = 600;
  371 |     });
  372 | 
  373 |     async function addLine(step: number) {
  374 |       await page.evaluate(n => {
  375 |         const canvas = document.querySelector('canvas');
  376 |         const ctx = canvas.getContext('2d');
  377 |         ctx.lineWidth = 1;
  378 |         ctx.beginPath();
  379 |         ctx.moveTo(0, n * 100);
```