# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/heap.spec.ts >> should not leak dispatchers after closing page
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/heap.spec.ts:191:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 5
Received: 6
```

# Test source

```ts
  105 |       const type = edgeTypes[edges[base + edgeTypeOff]];
  106 |       if (type === 'weak')
  107 |         continue; // Weak references do not retain.
  108 |       const to = edges[base + edgeToOff] / nf;
  109 |       if (visited[to])
  110 |         continue;
  111 |       visited[to] = 1;
  112 |       parent[to] = from;
  113 |       const rawName = edges[base + edgeNameOff];
  114 |       parentEdgeName[to] = (type === 'element' || type === 'hidden') ? `[${rawName}]` : strings[rawName];
  115 |       queue.push(to);
  116 |     }
  117 |   }
  118 | 
  119 |   const targets: number[] = [];
  120 |   for (let i = 0; i < nodeCount && targets.length < maxPaths; ++i) {
  121 |     if (nodeTypeName(i) === 'object' && nodeName(i) === constructorName)
  122 |       targets.push(i);
  123 |   }
  124 |   console.log(`\n===== retainer paths for ${constructorName} (showing ${targets.length}) =====`);
  125 |   for (const target of targets) {
  126 |     const path: string[] = [];
  127 |     let cur = target;
  128 |     while (cur !== -1) {
  129 |       const label = `${nodeName(cur)} (${nodeTypeName(cur)} @${nodes[cur * nf + nodeIdOff]})`;
  130 |       path.push(parent[cur] === -1 ? label : `${label}  <--[${parentEdgeName[cur]}]--`);
  131 |       cur = parent[cur];
  132 |     }
  133 |     console.log('  ' + path.join('\n    '));
  134 |     console.log('  ----');
  135 |   }
  136 | }
  137 | 
  138 | const clientClass = {
  139 |   Page: null as Function,
  140 |   BrowserContext: null as Function,
  141 |   Browser: null as Function,
  142 |   Request: null as Function,
  143 |   Response: null as Function,
  144 | };
  145 | 
  146 | test.beforeAll(async ({ browser, server }) => {
  147 |   const context = await browser.newContext();
  148 |   const page = await context.newPage();
  149 |   clientClass.Page = page.constructor;
  150 |   clientClass.BrowserContext = context.constructor;
  151 |   clientClass.Browser = browser.constructor;
  152 |   const [request, response] = await Promise.all([
  153 |     page.waitForRequest(() => true),
  154 |     page.waitForResponse(() => true),
  155 |     page.goto(server.EMPTY_PAGE),
  156 |   ]);
  157 |   clientClass.Request = request.constructor;
  158 |   clientClass.Response = response.constructor;
  159 |   await context.close();
  160 | });
  161 | 
  162 | for (let i = 0; i < 3; ++i) {
  163 |   test(`test #${i} to request page and context`, async ({ page, context }) => {
  164 |     // This test is here to create page instance
  165 |   });
  166 | }
  167 | 
  168 | test('test to request page and context', async ({ page, context }) => {
  169 |   // This test is here to create page instance
  170 | });
  171 | 
  172 | test('should not leak fixtures w/ page', async ({ page }) => {
  173 |   expect(await queryObjectCount(clientClass.Page)).toBe(1);
  174 |   expect(await queryObjectCount(clientClass.BrowserContext)).toBe(1);
  175 |   expect(await queryObjectCount(clientClass.Browser)).toBe(1);
  176 | });
  177 | 
  178 | test('should not leak fixtures w/o page', async ({}) => {
  179 |   expect(await queryObjectCount(clientClass.Page)).toBe(0);
  180 |   expect(await queryObjectCount(clientClass.BrowserContext)).toBe(0);
  181 |   expect(await queryObjectCount(clientClass.Browser)).toBe(1);
  182 | });
  183 | 
  184 | test('should not leak server-side objects', async ({ page }) => {
  185 |   expect(await queryObjectCount(coreServer.Page)).toBe(1);
  186 |   // 6 is because v8 heap creates objects for descendant classes, so WKContext, CRContext, FFContext, WVBrowserContext, BidiBrowserContext and our context instance.
  187 |   expect(await queryObjectCount(coreServer.BrowserContext)).toBe(6);
  188 |   expect(await queryObjectCount(coreServer.Browser)).toBe(6);
  189 | });
  190 | 
  191 | test('should not leak dispatchers after closing page', async ({ context, server }) => {
  192 |   const pages = [];
  193 |   const COUNT = 5;
  194 |   for (let i = 0; i < COUNT; ++i) {
  195 |     const page = await context.newPage();
  196 |     // ensure listeners are registered
  197 |     page.on('console', () => {});
  198 |     await page.goto(server.PREFIX + '/title.html');
  199 |     await page.evaluate(async i => {
  200 |       console.log('message', i);
  201 |     }, i);
  202 |     pages.push(page);
  203 |   }
  204 | 
> 205 |   expect(await queryObjectCount(coreServer.Page)).toBe(COUNT);
      |                                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  206 |   expect(await queryObjectCount(coreServer.RequestDispatcher)).toBe(COUNT);
  207 |   expect(await queryObjectCount(coreServer.ResponseDispatcher)).toBe(COUNT);
  208 | 
  209 |   for (const page of pages)
  210 |     await page.close();
  211 |   pages.length = 0;
  212 | 
  213 |   expect(await queryObjectCount(coreServer.Page)).toBe(0);
  214 |   expect(await queryObjectCount(coreServer.RequestDispatcher)).toBe(0);
  215 |   expect(await queryObjectCount(coreServer.ResponseDispatcher)).toBe(0);
  216 | 
  217 |   expect(await queryObjectCount(clientClass.Page)).toBeLessThan(COUNT);
  218 |   expect(await queryObjectCount(coreServer.Page)).toBe(0);
  219 |   expect(await queryObjectCount(clientClass.Request)).toBe(0);
  220 |   expect(await queryObjectCount(clientClass.Response)).toBe(0);
  221 | });
  222 | 
  223 | test('should not leak workers', async ({ page }) => {
  224 |   const before = await queryObjectCount(coreServer.Worker);
  225 |   for (let i = 0; i < 5; ++i) {
  226 |     const [workerHandle, workerObj] = await Promise.all([
  227 |       page.evaluateHandle(index => new Worker(URL.createObjectURL(new Blob([String(index)], { type: 'application/javascript' }))), i),
  228 |       page.waitForEvent('worker'),
  229 |     ]);
  230 |     await Promise.all([
  231 |       workerObj.waitForEvent('close'),
  232 |       workerHandle.evaluate(workerObj => workerObj.terminate()),
  233 |     ]);
  234 |   }
  235 |   expect.soft(await queryObjectCount(coreServer.Worker)).toBe(before);
  236 |   expect.soft(await queryObjectCount(coreServer.WorkerDispatcher)).toBe(0);
  237 | });
  238 | 
  239 | test.describe(() => {
  240 |   test.beforeEach(() => {
  241 |     coreServer.setMaxDispatchersForTest(100);
  242 |   });
  243 | 
  244 |   test('should collect stale handles', async ({ page, server }) => {
  245 |     page.on('request', () => {});
  246 |     const response = await page.goto(server.PREFIX + '/title.html');
  247 |     for (let i = 0; i < 200; ++i) {
  248 |       await page.evaluate(async () => {
  249 |         const response = await fetch('/');
  250 |         await response.text();
  251 |       });
  252 |     }
  253 |     const e = await response.allHeaders().catch(e => e);
  254 |     expect(e.message).toContain('The object has been collected to prevent unbounded heap growth.');
  255 | 
  256 |     const counts = [
  257 |       { count: await queryObjectCount(clientClass.Request), message: 'client.Request' },
  258 |       { count: await queryObjectCount(clientClass.Response), message: 'client.Response' },
  259 |       { count: await queryObjectCount(coreServer.Request), message: 'server.Request' },
  260 |       { count: await queryObjectCount(coreServer.Response), message: 'server.Response' },
  261 |       { count: await queryObjectCount(coreServer.RequestDispatcher), message: 'dispatchers.RequestDispatcher' },
  262 |       { count: await queryObjectCount(coreServer.ResponseDispatcher), message: 'dispatchers.ResponseDispatcher' },
  263 |     ];
  264 |     for (const { count, message } of counts) {
  265 |       expect(count, { message }).toBeGreaterThan(50);
  266 |       expect(count, { message }).toBeLessThan(150);
  267 |     }
  268 |   });
  269 | 
  270 |   test('should collect frames', async ({ page, server }) => {
  271 |     test.slow();
  272 | 
  273 |     const kFrameCount = 310;
  274 | 
  275 |     await page.goto(server.EMPTY_PAGE);
  276 |     let cb;
  277 |     const promise = new Promise(f => cb = f);
  278 |     let counter = 0;
  279 |     page.on('frameattached', async () => {
  280 |       // Make sure we can access page.
  281 |       await page.title();
  282 |       if (++counter === kFrameCount)
  283 |         cb();
  284 |     });
  285 | 
  286 |     page.evaluate(async ({ url, count }) => {
  287 |       for (let i = 0; i < count; i++) {
  288 |         const frame = document.createElement('iframe');
  289 |         frame.src = url;
  290 |         document.body.appendChild(frame);
  291 |         await new Promise(f => window.builtins.setTimeout(f, 10));
  292 |         frame.remove();
  293 |       }
  294 |     }, { url: server.PREFIX + '/one-style.html', count: kFrameCount }).catch(() => {});
  295 |     await promise;
  296 |     await page.waitForTimeout(500);
  297 |   });
  298 | 
  299 |   test.afterEach(() => {
  300 |     coreServer.setMaxDispatchersForTest(null);
  301 |   });
  302 | });
  303 | 
  304 | test('cycle handles', async ({ page, server, trace }) => {
  305 |   test.slow();
```