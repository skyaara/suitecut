import urllib.request,base64,pathlib,concurrent.futures,json
base=pathlib.Path('/tmp/suitecut-deep-audit/implementation');base.mkdir(exist_ok=True)
urls={
 'chromium-file-select-helper.cc':'https://chromium.googlesource.com/chromium/src/+/152.0.7977.83/chrome/browser/file_select_helper.cc?format=TEXT',
 'cef-file-dialog-manager.cc':'https://raw.githubusercontent.com/chromiumembedded/cef/708dc14/libcef/browser/file_dialog_manager.cc',
 'cef-permission-prompt.cc':'https://raw.githubusercontent.com/chromiumembedded/cef/708dc14/libcef/browser/permission_prompt.cc',
}
def get(pair):
 name,url=pair
 try:
  data=urllib.request.urlopen(url,timeout=20).read()
  if '?format=TEXT' in url:data=base64.b64decode(data)
  (base/name).write_bytes(data);return {'file':name,'url':url,'bytes':len(data)}
 except Exception as e:return {'file':name,'url':url,'error':str(e)}
rows=list(concurrent.futures.ThreadPoolExecutor(3).map(get,urls.items()));(base/'sources.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows))
