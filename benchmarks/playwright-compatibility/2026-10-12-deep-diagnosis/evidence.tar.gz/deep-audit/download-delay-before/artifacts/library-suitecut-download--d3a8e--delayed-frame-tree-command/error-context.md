# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/suitecut-download-delay.spec.ts >> popup download survives a delayed frame-tree command
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/suitecut-download-delay.spec.ts:6:5

# Error details

```
TimeoutError: page.waitForEvent: Timeout 3000ms exceeded while waiting for event "download"
=========================== logs ===========================
waiting for event "download"
============================================================
```

# Test source

```ts
  1  | import {contextTest as test,expect} from '../config/browserTest';
  2  | import {launchNativeBrowser} from '/workspace/suitecut/src/native-browser';
  3  | import {connectCEF} from '/workspace/suitecut/src/engine';
  4  | import fs from 'node:fs';
  5  | import {setTimeout as delay} from 'node:timers/promises';
  6  | test('popup download survives a delayed frame-tree command',async({server})=>{
  7  |  server.setRoute('/delayed-download',(req,res)=>{res.setHeader('Content-Disposition','attachment;filename=test.txt');res.end('download body');});
  8  |  const source=await launchNativeBrowser({executablePath:process.env.SUITECUT_DIRECT_EXECUTABLE!,width:640,height:360,framesPerSecond:30,pixelFormat:'i420'});
  9  |  let hold=false;
  10 |  const wrapped={...source,command:async(name,fields)=>{const message=fields?.message;if(hold && name==='cdp' && message?.method==='Page.getFrameTree')await delay(300);return await source.command!(name,fields);}};
  11 |  const browser=await connectCEF(wrapped);
  12 |  try{
  13 |   const page=await browser.newPage();await page.goto(server.EMPTY_PAGE);await page.setContent(`<a target=_blank href="${server.PREFIX}/delayed-download">download</a>`);
> 14 |   hold=true;const downloaded=page.waitForEvent('download',{timeout:3000});void downloaded.catch(()=>{});await page.click('a');const download=await downloaded;expect(fs.readFileSync((await download.path())!,'utf8')).toBe('download body');
     |                                   ^ TimeoutError: page.waitForEvent: Timeout 3000ms exceeded while waiting for event "download"
  15 |  }finally{await browser.close();await source.close();}
  16 | });
  17 | 
```