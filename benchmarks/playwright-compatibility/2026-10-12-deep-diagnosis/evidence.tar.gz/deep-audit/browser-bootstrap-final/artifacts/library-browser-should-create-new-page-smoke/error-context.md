# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browser.spec.ts >> should create new page @smoke
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browser.spec.ts:24:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 2
```

# Test source

```ts
  1  | /**
  2  |  * Copyright 2020 Microsoft Corporation. All rights reserved.
  3  |  *
  4  |  * Licensed under the Apache License, Version 2.0 (the "License");
  5  |  * you may not use this file except in compliance with the License.
  6  |  * You may obtain a copy of the License at
  7  |  *
  8  |  *     http://www.apache.org/licenses/LICENSE-2.0
  9  |  *
  10 |  * Unless required by applicable law or agreed to in writing, software
  11 |  * distributed under the License is distributed on an "AS IS" BASIS,
  12 |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13 |  * See the License for the specific language governing permissions and
  14 |  * limitations under the License.
  15 |  */
  16 | 
  17 | import { kTargetClosedErrorMessage } from '../config/errors';
  18 | import { browserTest as test, expect } from '../config/browserTest';
  19 | 
  20 | test('should return browserType', function({ browser, browserType }) {
  21 |   expect(browser.browserType()).toBe(browserType);
  22 | });
  23 | 
  24 | test('should create new page @smoke', async function({ browser }) {
  25 |   const page1 = await browser.newPage();
> 26 |   expect(browser.contexts().length).toBe(1);
     |                                     ^ Error: expect(received).toBe(expected) // Object.is equality
  27 | 
  28 |   const page2 = await browser.newPage();
  29 |   expect(browser.contexts().length).toBe(2);
  30 | 
  31 |   await page1.close();
  32 |   expect(browser.contexts().length).toBe(1);
  33 | 
  34 |   await page2.close();
  35 |   expect(browser.contexts().length).toBe(0);
  36 | });
  37 | 
  38 | test('should throw upon second create new page', async function({ browser }) {
  39 |   const page = await browser.newPage();
  40 |   let error: Error;
  41 |   await page.context().newPage().catch(e => error = e);
  42 |   await page.close();
  43 |   expect(error!.message).toContain('Please use browser.newContext()');
  44 | });
  45 | 
  46 | test('version should work', async function({ browser, browserName }) {
  47 |   const version = browser.version();
  48 |   if (browserName === 'chromium')
  49 |     expect(version.match(/^\d+\.\d+\.\d+\.\d+$/)).toBeTruthy();
  50 |   else
  51 |     expect(version.match(/^\d+\.\d+/)).toBeTruthy();
  52 | });
  53 | 
  54 | test('should dispatch page.on(close) upon browser.close and reject evaluate', async ({ browserType }) => {
  55 |   const browser = await browserType.launch();
  56 |   const page = await browser.newPage();
  57 |   let closed = false;
  58 |   page.on('close', () => closed = true);
  59 |   const promise = page.evaluate(() => new Promise<void>(() => {})).catch(e => e);
  60 |   await browser.close();
  61 |   expect(closed).toBe(true);
  62 |   const error = await promise;
  63 |   expect(error.message).toContain(kTargetClosedErrorMessage);
  64 | });
  65 | 
  66 | test('should fire context event on newContext', async ({ browser }) => {
  67 |   const events = [];
  68 |   browser.on('context', ctx => events.push(ctx));
  69 |   const context = await browser.newContext();
  70 |   expect(events).toEqual([context]);
  71 |   await context.close();
  72 | });
  73 | 
  74 | test('newContext should not leave a context upon failure', async ({ browser, toImpl }) => {
  75 |   const error = await browser.newContext({
  76 |     __testHookBeforeSetStorageState: () => Promise.reject(new Error('Oh my')),
  77 |   } as any).catch(e => e);
  78 |   expect(error.message).toContain('Oh my');
  79 |   await expect.poll(() => toImpl(browser).contexts().length).toBe(0);
  80 | });
  81 | 
```