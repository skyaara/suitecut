# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-page-event.spec.ts >> should work with Shift-clicking
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-page-event.spec.ts:160:3

# Error details

```
Test timeout of 30000ms exceeded.
```