# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/locator-misc-2.spec.ts >> Locator.locator() and FrameLocator.locator() should accept locator
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/locator-misc-2.spec.ts:171:3

# Error details

```
Error: page.setContent: Target page, context or browser has been closed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  72  |   await expect(page.locator('#lazyload')).toHaveText('LAZY LOADED CONTENT');
  73  |   expect(await page.locator('#lazyload').boundingBox()).toEqual({ x: 0, y: 720, width: 1280, height: 20 });
  74  | });
  75  | 
  76  | it('should select textarea', async ({ page, server, browserName }) => {
  77  |   await page.goto(server.PREFIX + '/input/textarea.html');
  78  |   const textarea = page.locator('textarea');
  79  |   await textarea.evaluate(textarea => (textarea as HTMLTextAreaElement).value = 'some value');
  80  |   await textarea.selectText();
  81  |   expect(await page.evaluate(() => window.getSelection().toString())).toBe('some value');
  82  | });
  83  | 
  84  | it('should type', async ({ page }) => {
  85  |   await page.setContent(`<input type='text' />`);
  86  |   await page.locator('input').type('hello');
  87  |   expect(await page.$eval('input', input => input.value)).toBe('hello');
  88  | });
  89  | 
  90  | it('should pressSequentially', async ({ page }) => {
  91  |   await page.setContent(`<input type='text' />`);
  92  |   await page.locator('input').pressSequentially('hello');
  93  |   expect(await page.$eval('input', input => input.value)).toBe('hello');
  94  | });
  95  | 
  96  | it('should take screenshot', async ({ page, server, browserName, headless, isAndroid, mode }) => {
  97  |   it.skip(browserName === 'firefox' && !headless);
  98  |   it.skip(isAndroid, 'Different dpr. Remove after using 1x scale for screenshots.');
  99  |   await page.setViewportSize({ width: 500, height: 500 });
  100 |   await page.goto(server.PREFIX + '/grid.html');
  101 |   await page.evaluate(() => window.scrollBy(50, 100));
  102 |   const element = page.locator('.box:nth-of-type(3)');
  103 |   const screenshot = await element.screenshot();
  104 |   expect(screenshot).toMatchSnapshot('screenshot-element-bounding-box.png');
  105 | });
  106 | 
  107 | it('should return bounding box', async ({ page, server, browserName, headless, isAndroid, isLinux }) => {
  108 |   it.skip(isAndroid);
  109 | 
  110 |   await page.setViewportSize({ width: 500, height: 500 });
  111 |   await page.goto(server.PREFIX + '/grid.html');
  112 |   const element = page.locator('.box:nth-of-type(13)');
  113 |   const box = await element.boundingBox();
  114 |   expect(box).toEqual({ x: 100, y: 50, width: 50, height: 50 });
  115 | });
  116 | 
  117 | it('should waitFor', async ({ page }) => {
  118 |   await page.setContent(`<div></div>`);
  119 |   const locator = page.locator('span');
  120 |   const promise = locator.waitFor();
  121 |   await page.$eval('div', div => div.innerHTML = '<span>target</span>');
  122 |   await promise;
  123 |   await expect(locator).toHaveText('target');
  124 | });
  125 | 
  126 | it('should waitFor hidden', async ({ page }) => {
  127 |   await page.setContent(`<div><span>target</span></div>`);
  128 |   const locator = page.locator('span');
  129 |   const promise = locator.waitFor({ state: 'hidden' });
  130 |   await page.$eval('div', div => div.innerHTML = '');
  131 |   await promise;
  132 | });
  133 | 
  134 | it('should combine visible with other selectors', async ({ page }) => {
  135 |   await page.setContent(`<div>
  136 |   <div class="item" style="display: none">Hidden data0</div>
  137 |   <div class="item">visible data1</div>
  138 |   <div class="item" style="display: none">Hidden data1</div>
  139 |   <div class="item">visible data2</div>
  140 |   <div class="item" style="display: none">Hidden data1</div>
  141 |   <div class="item">visible data3</div>
  142 |   </div>`);
  143 |   const locator = page.locator('.item >> visible=true').nth(1);
  144 |   await expect(locator).toHaveText('visible data2');
  145 |   await expect(page.locator('.item >> visible=true >> text=data3')).toHaveText('visible data3');
  146 | });
  147 | 
  148 | it('should support filter(visible)', async ({ page }) => {
  149 |   await page.setContent(`<div>
  150 |     <div class="item" style="display: none">Hidden data0</div>
  151 |     <div class="item">visible data1</div>
  152 |     <div class="item" style="display: none">Hidden data1</div>
  153 |     <div class="item">visible data2</div>
  154 |     <div class="item" style="display: none">Hidden data2</div>
  155 |     <div class="item">visible data3</div>
  156 |     </div>
  157 |   `);
  158 |   const locator = page.locator('.item').filter({ visible: true }).nth(1);
  159 |   await expect(locator).toHaveText('visible data2');
  160 |   await expect(page.locator('.item').filter({ visible: true }).getByText('data3')).toHaveText('visible data3');
  161 |   await expect(page.locator('.item').filter({ visible: false }).getByText('data1')).toHaveText('Hidden data1');
  162 | });
  163 | 
  164 | it('locator.count should work with deleted Map in main world', async ({ page }) => {
  165 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/11254' });
  166 |   await page.evaluate('Map = 1');
  167 |   await page.locator('#searchResultTableDiv .x-grid3-row').count();
  168 |   await expect(page.locator('#searchResultTableDiv .x-grid3-row')).toHaveCount(0);
  169 | });
  170 | 
  171 | it('Locator.locator() and FrameLocator.locator() should accept locator', async ({ page }) => {
> 172 |   await page.setContent(`
      |              ^ Error: page.setContent: Target page, context or browser has been closed
  173 |     <div><input value=outer></div>
  174 |     <iframe srcdoc="<div><input value=inner></div>"></iframe>
  175 |   `);
  176 | 
  177 |   const inputLocator = page.locator('input');
  178 |   expect(await inputLocator.inputValue()).toBe('outer');
  179 |   expect(await page.locator('div').locator(inputLocator).inputValue()).toBe('outer');
  180 |   expect(await page.frameLocator('iframe').locator(inputLocator).inputValue()).toBe('inner');
  181 |   expect(await page.frameLocator('iframe').locator('div').locator(inputLocator).inputValue()).toBe('inner');
  182 | 
  183 |   const divLocator = page.locator('div');
  184 |   expect(await divLocator.locator('input').inputValue()).toBe('outer');
  185 |   expect(await page.frameLocator('iframe').locator(divLocator).locator('input').inputValue()).toBe('inner');
  186 | });
  187 | 
  188 | it('should fill programmatically enabled textarea', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36307' } }, async ({ page }) => {
  189 |   await page.setContent(`
  190 |     <button>Enable</button>
  191 |     <form>
  192 |       <textarea id="text" disabled></textarea>
  193 |     </form>
  194 |     <script>
  195 |       document.querySelector('button').addEventListener('click', () => {
  196 |         document.querySelector('#text').disabled = false;
  197 |       });
  198 |     </script>
  199 |   `);
  200 |   await page.locator('button').click();
  201 |   await page.locator('#text').fill('Hello');
  202 |   await expect(page.locator('#text')).toHaveValue('Hello');
  203 | });
  204 | 
  205 | it('press should throw on unknown keys', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36697' } }, async ({ page, server }) => {
  206 |   await page.setContent(`<input type='text' value='hello' />`);
  207 |   const locator = page.getByRole('textbox');
  208 |   await expect(locator.press('NotARealKey')).rejects.toThrowError(/Unknown key: "NotARealKey"/);
  209 |   await expect(locator.press('ё')).rejects.toThrowError(/Unknown key: "ё"/);
  210 |   await expect(locator.press('😊')).rejects.toThrowError(/Unknown key: "😊"/);
  211 | });
  212 | 
```