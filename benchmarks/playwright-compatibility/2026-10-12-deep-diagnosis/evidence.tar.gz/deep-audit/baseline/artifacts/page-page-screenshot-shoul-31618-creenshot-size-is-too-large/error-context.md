# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-screenshot.spec.ts >> should throw if screenshot size is too large
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-screenshot.spec.ts:969:3

# Error details

```
Error: page.screenshot: Protocol error (Page.captureScreenshot): CEF screenshot exceeds the 8,294,400-pixel or 16,384-axis limit
Call log:
  - taking page screenshot
  - waiting for fonts to load...
  - fonts loaded

```

# Test source

```ts
  874  |       const animation = el.getAnimations()[0];
  875  |       animation.oncancel = () => window._EVENTS.push('oncancel');
  876  |       animation.onfinish = () => window._EVENTS.push('onfinish');
  877  |       animation.onremove = () => window._EVENTS.push('onremove');
  878  |       await animation.ready;
  879  |     });
  880  |     await Promise.all([
  881  |       page.screenshot({ animations: 'disabled' }),
  882  |       page.waitForEvent('console', msg => msg.text() === 'transitionend'),
  883  |     ]);
  884  |     expect(await page.evaluate(() => window._EVENTS)).toEqual([
  885  |       'onfinish', 'transitionend'
  886  |     ]);
  887  |   });
  888  | 
  889  |   it('should trigger particular events for INfinite css animation', async ({ page, server }) => {
  890  |     await page.goto(server.PREFIX + '/rotate-z.html');
  891  |     const div = page.locator('div');
  892  |     await div.evaluate(async el => {
  893  |       window._EVENTS = [];
  894  |       el.addEventListener('animationcancel', () => {
  895  |         window._EVENTS.push('animationcancel');
  896  |         console.log('animationcancel');
  897  |       }, false);
  898  |       const animation = el.getAnimations()[0];
  899  |       animation.oncancel = () => window._EVENTS.push('oncancel');
  900  |       animation.onfinish = () => window._EVENTS.push('onfinish');
  901  |       animation.onremove = () => window._EVENTS.push('onremove');
  902  |       await animation.ready;
  903  |     });
  904  |     await Promise.all([
  905  |       page.screenshot({ animations: 'disabled' }),
  906  |       page.waitForEvent('console', msg => msg.text() === 'animationcancel'),
  907  |     ]);
  908  |     expect(await page.evaluate(() => window._EVENTS)).toEqual([
  909  |       'oncancel', 'animationcancel'
  910  |     ]);
  911  |   });
  912  | 
  913  |   it('should trigger particular events for finite css animation', async ({ page, server }) => {
  914  |     await page.goto(server.PREFIX + '/rotate-z.html');
  915  |     const div = page.locator('div');
  916  |     await div.evaluate(async el => {
  917  |       window._EVENTS = [];
  918  |       // Make CSS animation to be finite.
  919  |       el.style.setProperty('animation-iteration-count', '1000');
  920  |       el.addEventListener('animationend', () => {
  921  |         window._EVENTS.push('animationend');
  922  |         console.log('animationend');
  923  |       }, false);
  924  |       const animation = el.getAnimations()[0];
  925  |       animation.oncancel = () => window._EVENTS.push('oncancel');
  926  |       animation.onfinish = () => window._EVENTS.push('onfinish');
  927  |       animation.onremove = () => window._EVENTS.push('onremove');
  928  |       await animation.ready;
  929  |     });
  930  |     // Ensure CSS animation is finite.
  931  |     expect(await div.evaluate(async el => Number.isFinite(el.getAnimations()[0].effect.getComputedTiming().endTime))).toBe(true);
  932  |     await Promise.all([
  933  |       page.waitForEvent('console', msg => msg.text() === 'animationend'),
  934  |       page.screenshot({ animations: 'disabled' }),
  935  |     ]);
  936  |     expect(await page.evaluate(() => window._EVENTS)).toEqual([
  937  |       'onfinish', 'animationend'
  938  |     ]);
  939  |   });
  940  | 
  941  |   it('should wait for fonts to load', async ({ page, server, isWindows, isAndroid }) => {
  942  |     it.fixme(isWindows, 'This requires a windows-specific test expectations. https://github.com/microsoft/playwright/issues/12707');
  943  |     it.skip(isAndroid, 'Different viewport');
  944  |     await page.setViewportSize({ width: 500, height: 500 });
  945  |     const fontRequestPromise = new Promise<any>(resolve => {
  946  |       // Stall font loading.
  947  |       server.setRoute('/webfont/iconfont.woff2', (request, response) => {
  948  |         resolve({ request, response });
  949  |       });
  950  |     });
  951  |     await page.goto(server.PREFIX + '/webfont/webfont.html', {
  952  |       waitUntil: 'domcontentloaded', // 'load' will not happen if webfont is pending
  953  |     });
  954  | 
  955  |     // Make sure screenshot times out while webfont is stalled.
  956  |     const error = await page.screenshot({ timeout: 200, }).catch(e => e);
  957  |     expect(error.message).toContain('waiting for fonts to load...');
  958  |     expect(error.message).toContain('Timeout 200ms exceeded');
  959  | 
  960  |     const fontRequest = await fontRequestPromise;
  961  |     server.serveFile(fontRequest.request, fontRequest.response);
  962  |     const iconsScreenshot = await page.screenshot();
  963  |     expect(iconsScreenshot).toMatchSnapshot('screenshot-web-font.png', {
  964  |       maxDiffPixels: 50,
  965  |     });
  966  |   });
  967  | });
  968  | 
  969  | it('should throw if screenshot size is too large', async ({ page, browserName, isMac, isBidi }) => {
  970  |   const maxSize = browserName === 'firefox' && isBidi ? 65535 : 32767;
  971  |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/16727' });
  972  |   {
  973  |     await page.setContent(`<style>body {margin: 0; padding: 0;}</style><div style='min-height: ${maxSize}px; background: red;'></div>`);
> 974  |     const result = await page.screenshot({ fullPage: true });
       |                               ^ Error: page.screenshot: Protocol error (Page.captureScreenshot): CEF screenshot exceeds the 8,294,400-pixel or 16,384-axis limit
  975  |     expect(result).toBeTruthy();
  976  |   }
  977  |   {
  978  |     await page.setContent(`<style>body {margin: 0; padding: 0;}</style><div style='min-height: ${maxSize + 1}px; background: red;'></div>`);
  979  |     const exception = await page.screenshot({ fullPage: true }).catch(e => e);
  980  |     if ((browserName === 'firefox' && !isBidi) || (browserName === 'webkit' && !isMac))
  981  |       expect(exception.message).toContain('Cannot take screenshot larger than 32767');
  982  |     else if (browserName === 'firefox' && isBidi)
  983  |       expect(exception.message).toContain('65536 exceeds the maximum allowed screenshot height of 65535 pixels');
  984  |   }
  985  | });
  986  | 
  987  | it('page screenshot should capture css transform', async function({ page, browserName, isElectron, isAndroid }) {
  988  |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/26447' });
  989  |   it.fixme(browserName === 'webkit');
  990  |   it.skip(isElectron || isAndroid, 'Returns screenshot of a different size.');
  991  |   await page.setContent(`
  992  |     <style>
  993  |     .container {
  994  |       width: 150px;
  995  |       height: 150px;
  996  |       margin: 75px 0 0 75px;
  997  |       border: none;
  998  |     }
  999  | 
  1000 |     .cube {
  1001 |       width: 100%;
  1002 |       height: 100%;
  1003 |       perspective: 550px;
  1004 |       perspective-origin: 150% 150%;
  1005 |     }
  1006 | 
  1007 |     .face {
  1008 |       display: block;
  1009 |       position: absolute;
  1010 |       width: 100px;
  1011 |       height: 100px;
  1012 |       border: none;
  1013 |     }
  1014 | 
  1015 |     .right {
  1016 |       background: rgba(196, 0, 0, 0.7);
  1017 |       transform: rotateY(70deg);
  1018 |     }
  1019 | 
  1020 |     </style>
  1021 |     <div class="container">
  1022 |       <div class="cube showbf">
  1023 |         <div class="face right"></div>
  1024 |       </div>
  1025 |     </div>
  1026 |   `);
  1027 | 
  1028 |   await expect(page).toHaveScreenshot();
  1029 | });
  1030 | 
  1031 | it('should capture css box-shadow', async ({ page, isElectron, isAndroid }) => {
  1032 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/21620' });
  1033 |   it.skip(isElectron || isAndroid, 'Returns screenshot of a different size.');
  1034 |   await page.setContent(`<div style="box-shadow: red 10px 10px 10px; width: 50px; height: 50px;"></div>`);
  1035 |   await expect(page).toHaveScreenshot();
  1036 | });
  1037 | 
```