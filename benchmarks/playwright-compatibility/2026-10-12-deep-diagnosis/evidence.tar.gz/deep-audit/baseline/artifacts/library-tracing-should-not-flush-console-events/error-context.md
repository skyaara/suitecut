# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/tracing.spec.ts >> should not flush console events
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/tracing.spec.ts:716:5

# Error details

```
Error: ENOENT: no such file or directory, scandir '/tmp/suitecut-deep-audit/baseline/artifacts/.playwright-artifacts-45/traces'

Call Log:
- Test timeout of 30000ms exceeded
```

# Test source

```ts
  644 |     url
  645 |   }));
  646 |   expect(actions[0].snapshot.response).toEqual(expect.objectContaining({
  647 |     status: 200,
  648 |     statusText: 'OK',
  649 |     headers: expect.arrayContaining([
  650 |       expect.objectContaining({
  651 |         'name': 'Content-Length',
  652 |         'value': '15'
  653 |       })
  654 |     ])
  655 |   }));
  656 | });
  657 | 
  658 | test('should store global request traces separately', async ({ request, server, playwright, browserName, mode }, testInfo) => {
  659 |   const request2 = await playwright.request.newContext();
  660 |   await Promise.all([
  661 |     request.tracing.start({ snapshots: true }),
  662 |     request2.tracing.start({ snapshots: true })
  663 |   ]);
  664 |   const url = server.PREFIX + '/simple.json';
  665 |   await Promise.all([
  666 |     request.get(url),
  667 |     request2.post(url)
  668 |   ]);
  669 |   const tracePath = testInfo.outputPath('trace.zip');
  670 |   const trace2Path = testInfo.outputPath('trace2.zip');
  671 |   await Promise.all([
  672 |     request.tracing.stop({ path: tracePath }),
  673 |     request2.tracing.stop({ path: trace2Path })
  674 |   ]);
  675 |   {
  676 |     const trace = await parseTraceRaw(tracePath);
  677 |     const actions = trace.events.filter(e => e.type === 'resource-snapshot');
  678 |     expect(actions).toHaveLength(1);
  679 |     expect(actions[0].snapshot.request).toEqual(expect.objectContaining({
  680 |       method: 'GET',
  681 |       url
  682 |     }));
  683 |   }
  684 |   {
  685 |     const trace = await parseTraceRaw(trace2Path);
  686 |     const actions = trace.events.filter(e => e.type === 'resource-snapshot');
  687 |     expect(actions).toHaveLength(1);
  688 |     expect(actions[0].snapshot.request).toEqual(expect.objectContaining({
  689 |       method: 'POST',
  690 |       url
  691 |     }));
  692 |   }
  693 | });
  694 | 
  695 | test('should store postData for global request', async ({ request, server }, testInfo) => {
  696 |   testInfo.annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/15031' });
  697 |   await request.tracing.start({ snapshots: true });
  698 |   const url = server.PREFIX + '/simple.json';
  699 |   await request.post(url, {
  700 |     data: 'test'
  701 |   });
  702 |   const tracePath = testInfo.outputPath('trace.zip');
  703 |   await request.tracing.stop({ path: tracePath });
  704 | 
  705 |   const trace = await parseTraceRaw(tracePath);
  706 |   const actions = trace.events.filter(e => e.type === 'resource-snapshot');
  707 |   expect(actions).toHaveLength(1);
  708 |   const req = actions[0].snapshot.request;
  709 |   expect(req.postData?._sha1).toBeTruthy();
  710 |   expect(req).toEqual(expect.objectContaining({
  711 |     method: 'POST',
  712 |     url
  713 |   }));
  714 | });
  715 | 
  716 | test('should not flush console events', async ({ context, page, mode }, testInfo) => {
  717 |   const testId = test.info().testId;
  718 |   await context.tracing.start({ name: testId });
  719 |   const promise = new Promise<void>(f => {
  720 |     let counter = 0;
  721 |     page.on('console', () => {
  722 |       if (++counter === 100)
  723 |         f();
  724 |     });
  725 |   });
  726 | 
  727 |   await page.evaluate(() => {
  728 |     window.builtins.setTimeout(() => {
  729 |       for (let i = 0; i < 100; ++i)
  730 |         console.log('hello ' + i);
  731 |     }, 10);
  732 |     return 31415926;
  733 |   });
  734 | 
  735 |   await promise;
  736 | 
  737 |   const dir = path.join(testInfo.project.outputDir, artifactsFolderName(testInfo.workerIndex), 'traces');
  738 | 
  739 |   let content: string;
  740 |   await expect(async () => {
  741 |     const traceName = fs.readdirSync(dir).find(name => name.endsWith(testId + '.trace'));
  742 |     content = await fs.promises.readFile(path.join(dir, traceName), 'utf8');
  743 |     expect(content).toContain('31415926');
> 744 |   }).toPass();
      |      ^ Error: ENOENT: no such file or directory, scandir '/tmp/suitecut-deep-audit/baseline/artifacts/.playwright-artifacts-45/traces'
  745 |   expect(content).not.toContain('hello 0');
  746 | 
  747 |   await page.evaluate(() => 42);
  748 | 
  749 |   await expect(async () => {
  750 |     const traceName = fs.readdirSync(dir).find(name => name.endsWith(testId + '.trace'));
  751 |     const content = await fs.promises.readFile(path.join(dir, traceName), 'utf8');
  752 |     expect(content).toContain('hello 0');
  753 |     expect(content).toContain('hello 99');
  754 |   }).toPass();
  755 | });
  756 | 
  757 | test('should flush console events on tracing stop', async ({ context, page }, testInfo) => {
  758 |   await context.tracing.start();
  759 |   const promise = new Promise<void>(f => {
  760 |     let counter = 0;
  761 |     page.on('console', () => {
  762 |       if (++counter === 100)
  763 |         f();
  764 |     });
  765 |   });
  766 |   await page.evaluate(() => {
  767 |     window.builtins.setTimeout(() => {
  768 |       for (let i = 0; i < 100; ++i)
  769 |         console.log('hello ' + i);
  770 |     });
  771 |   });
  772 |   await promise;
  773 |   const tracePath = testInfo.outputPath('trace.zip');
  774 |   await context.tracing.stop({ path: tracePath });
  775 |   const trace = await parseTraceRaw(tracePath);
  776 |   const events = trace.events.filter(e => e.type === 'console');
  777 |   expect(events).toHaveLength(100);
  778 | });
  779 | 
  780 | test('should not emit after w/o before', async ({ browserType, mode }, testInfo) => {
  781 |   const tracesDir = testInfo.outputPath('traces');
  782 |   const browser = await browserType.launch({ tracesDir });
  783 |   const context = await browser.newContext();
  784 |   const page = await context.newPage();
  785 | 
  786 |   await context.tracing.start({ name: 'name1', snapshots: true });
  787 |   const evaluatePromise = page.evaluate(() => {
  788 |     console.log('started');
  789 |     return new Promise(f => (window as any).callback = f);
  790 |   }).catch(() => {});
  791 |   await page.waitForEvent('console');
  792 |   await context.tracing.stopChunk({ path: testInfo.outputPath('trace1.zip') });
  793 |   expect(fs.existsSync(path.join(tracesDir, 'name1.trace'))).toBe(true);
  794 | 
  795 |   await context.tracing.startChunk({ name: 'name2' });
  796 |   await page.evaluateHandle(() => (window as any).callback());
  797 |   await evaluatePromise;
  798 |   await context.tracing.stop({ path: testInfo.outputPath('trace2.zip') });
  799 |   expect(fs.existsSync(path.join(tracesDir, 'name2.trace'))).toBe(true);
  800 | 
  801 |   await browser.close();
  802 |   let minCallId = 100000;
  803 |   const sanitize = (e: any) => {
  804 |     if (e.type === 'after' || e.type === 'before') {
  805 |       minCallId = Math.min(minCallId, +e.callId.split('@')[1]);
  806 |       return {
  807 |         type: e.type,
  808 |         callId: +e.callId.split('@')[1] - minCallId,
  809 |         title: e.title,
  810 |       };
  811 |     }
  812 |   };
  813 | 
  814 |   let call1: number;
  815 |   {
  816 |     const { events } = await parseTraceRaw(testInfo.outputPath('trace1.zip'));
  817 |     const sanitized = events.map(sanitize).filter(Boolean);
  818 |     expect(sanitized).toEqual([
  819 |       {
  820 |         type: 'before',
  821 |         callId: expect.any(Number),
  822 |       },
  823 |       {
  824 |         type: 'before',
  825 |         callId: expect.any(Number),
  826 |         title: 'Wait for event "console"',
  827 |       },
  828 |       {
  829 |         type: 'after',
  830 |         callId: expect.any(Number),
  831 |       },
  832 |     ]);
  833 |     call1 = sanitized[0].callId;
  834 |     expect(sanitized[1].callId).toBe(sanitized[2].callId);
  835 |   }
  836 | 
  837 |   let call2before: number;
  838 |   let call2after: number;
  839 |   {
  840 |     const { events } = await parseTraceRaw(testInfo.outputPath('trace2.zip'));
  841 |     const sanitized = events.map(sanitize).filter(Boolean);
  842 |     expect(sanitized).toEqual([
  843 |       {
  844 |         type: 'before',
```