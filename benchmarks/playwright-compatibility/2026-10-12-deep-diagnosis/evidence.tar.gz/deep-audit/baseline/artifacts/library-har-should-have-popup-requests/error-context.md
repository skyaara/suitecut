# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/har.spec.ts >> should have popup requests
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/har.spec.ts:588:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 2
Received: 0
```

# Test source

```ts
  502 | 
  503 | it('should record failed request headers', async ({ contextFactory, server }, testInfo) => {
  504 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  505 |   server.setRoute('/har.html', (req, res) => {
  506 |     res.socket!.destroy();
  507 |   });
  508 |   await page.goto(server.PREFIX + '/har.html').catch(() => {});
  509 |   const log = await getLog();
  510 |   expect(log.entries[0].response._failureText).toBeTruthy();
  511 |   const request = log.entries[0].request;
  512 |   expect(request.url.endsWith('/har.html')).toBe(true);
  513 |   expect(request.method).toBe('GET');
  514 |   expect(request.headers).toContainEqual(expect.objectContaining({ name: 'User-Agent' }));
  515 | });
  516 | 
  517 | it('should record failed request overrides', async ({ contextFactory, server }, testInfo) => {
  518 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  519 |   server.setRoute('/empty.html', (req, res) => {
  520 |     res.socket!.destroy();
  521 |   });
  522 |   await page.route('**/foo', route => {
  523 |     void route.fallback({
  524 |       url: server.EMPTY_PAGE,
  525 |       method: 'POST',
  526 |       headers: {
  527 |         ...route.request().headers(),
  528 |         'content-type': 'text/plain',
  529 |         'cookie': 'foo=bar',
  530 |         'custom': 'value'
  531 |       },
  532 |       postData: 'Hi!'
  533 |     });
  534 |   });
  535 |   await page.goto(server.PREFIX + '/foo').catch(() => {});
  536 |   const log = await getLog();
  537 |   expect(log.entries[0].response._failureText).toBeTruthy();
  538 |   const request = log.entries[0].request;
  539 |   expect(request.url).toBe(server.EMPTY_PAGE);
  540 |   expect(request.method).toBe('POST');
  541 |   expect(request.headers).toContainEqual({ name: 'custom', value: 'value' });
  542 |   expect(request.cookies).toEqual([]);
  543 |   expect(request.postData).toEqual({ 'mimeType': 'text/plain', 'params': [], 'text': 'Hi!' });
  544 | });
  545 | 
  546 | it('should report the correct request body size', async ({ contextFactory, server }, testInfo) => {
  547 |   server.setRoute('/api', (req, res) => res.end());
  548 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  549 |   await page.goto(server.EMPTY_PAGE);
  550 |   await Promise.all([
  551 |     page.waitForResponse(server.PREFIX + '/api1'),
  552 |     page.evaluate(() => {
  553 |       void fetch('/api1', {
  554 |         method: 'POST',
  555 |         body: 'abc123'
  556 |       });
  557 |     })
  558 |   ]);
  559 |   const log = await getLog();
  560 |   expect(log.entries[1].request.bodySize).toBe(6);
  561 | });
  562 | 
  563 | it('should report the correct request body size when the bodySize is 0', async ({ contextFactory, server }, testInfo) => {
  564 |   server.setRoute('/api', (req, res) => res.end());
  565 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  566 |   await page.goto(server.EMPTY_PAGE);
  567 |   await Promise.all([
  568 |     page.waitForResponse(server.PREFIX + '/api2'),
  569 |     page.evaluate(() => {
  570 |       void fetch('/api2', {
  571 |         method: 'POST',
  572 |         body: ''
  573 |       });
  574 |     })
  575 |   ]);
  576 |   const log = await getLog();
  577 |   expect(log.entries[1].request.bodySize).toBe(0);
  578 | });
  579 | 
  580 | it('should report the correct response body size when the bodySize is 0', async ({ contextFactory, server }, testInfo) => {
  581 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  582 |   const response = await page.goto(server.EMPTY_PAGE);
  583 |   await response!.finished();
  584 |   const log = await getLog();
  585 |   expect(log.entries[0].response.bodySize).toBe(0);
  586 | });
  587 | 
  588 | it('should have popup requests', async ({ contextFactory, server }, testInfo) => {
  589 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  590 |   await page.goto(server.EMPTY_PAGE);
  591 |   await page.setContent('<a target=_blank rel=noopener href="/one-style.html">yo</a>');
  592 |   const [popup] = await Promise.all([
  593 |     page.waitForEvent('popup'),
  594 |     page.click('a'),
  595 |   ]);
  596 |   await popup.waitForLoadState();
  597 |   const log = await getLog();
  598 | 
  599 |   expect(log.pages!.length).toBe(2);
  600 | 
  601 |   const entries = log.entries.filter(entry => entry.pageref === log.pages![1].id);
> 602 |   expect(entries.length).toBe(2);
      |                          ^ Error: expect(received).toBe(expected) // Object.is equality
  603 |   expect(entries[0].request.url).toBe(server.PREFIX + '/one-style.html');
  604 |   expect(entries[0].response.status).toBe(200);
  605 |   expect(entries[1].request.url).toBe(server.PREFIX + '/one-style.css');
  606 |   expect(entries[1].response.status).toBe(200);
  607 | });
  608 | 
  609 | it('should not contain internal pages', async ({ browserName, contextFactory, server }, testInfo) => {
  610 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/6743' });
  611 | 
  612 |   server.setRoute('/empty.html', (req, res) => {
  613 |     res.setHeader('Set-Cookie', 'name=value');
  614 |     res.end();
  615 |   });
  616 | 
  617 |   const { page, context, getLog } = await pageWithHar(contextFactory, testInfo);
  618 |   await page.goto(server.EMPTY_PAGE);
  619 | 
  620 |   const cookies = await context.cookies();
  621 |   expect(cookies.length).toBe(1);
  622 |   // Get storage state, this create internal page.
  623 |   await context.storageState();
  624 | 
  625 |   const log = await getLog();
  626 |   expect(log.pages!.length).toBe(1);
  627 | });
  628 | 
  629 | it('should have connection details', async ({ contextFactory, server, browserName, platform, mode }, testInfo) => {
  630 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  631 |   await page.goto(server.EMPTY_PAGE);
  632 |   const log = await getLog();
  633 |   const { serverIPAddress, _serverPort: port, _securityDetails: securityDetails } = log.entries[0];
  634 |   expect(serverIPAddress).toMatch(/^127\.0\.0\.1|\[::1\]/);
  635 |   expect(port).toBe(server.PORT);
  636 |   expect(securityDetails).toEqual({});
  637 | });
  638 | 
  639 | it('should have security details', async ({ contextFactory, httpsServer, browserName, platform, mode, channel, isFrozenWebkit }, testInfo) => {
  640 |   it.fail(browserName === 'webkit' && platform === 'win32' && channel !== 'webkit-wsl');
  641 |   it.skip(isFrozenWebkit);
  642 | 
  643 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  644 |   await page.goto(httpsServer.EMPTY_PAGE);
  645 |   await page.request.get(httpsServer.EMPTY_PAGE);
  646 |   const log = await getLog();
  647 |   const { serverIPAddress, _serverPort: port, _securityDetails: securityDetails } = log.entries[0];
  648 |   expect(serverIPAddress).toMatch(/^127\.0\.0\.1|\[::1\]/);
  649 |   expect(port).toBe(httpsServer.PORT);
  650 |   if (browserName === 'webkit')
  651 |     expect(securityDetails).toEqual({ protocol: 'TLS 1.3', subjectName: 'playwright-test', validFrom: 1691708270, validTo: 2007068270 });
  652 |   else
  653 |     expect(securityDetails).toEqual({ issuer: 'playwright-test', protocol: 'TLS 1.3', subjectName: 'playwright-test', validFrom: 1691708270, validTo: 2007068270 });
  654 | 
  655 |   expect(log.entries[1]._securityDetails).toEqual({ issuer: 'playwright-test', protocol: 'TLSv1.3', subjectName: 'playwright-test', validFrom: 1691708270, validTo: 2007068270 });
  656 | });
  657 | 
  658 | it('should have connection details for redirects', async ({ contextFactory, server, browserName, mode }, testInfo) => {
  659 |   server.setRedirect('/foo.html', '/empty.html');
  660 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  661 |   await page.goto(server.PREFIX + '/foo.html');
  662 |   const log = await getLog();
  663 |   expect(log.entries.length).toBe(2);
  664 | 
  665 |   const detailsFoo = log.entries[0];
  666 | 
  667 |   if (browserName === 'webkit') {
  668 |     expect(detailsFoo.serverIPAddress).toBeUndefined();
  669 |     expect(detailsFoo._serverPort).toBeUndefined();
  670 |   } else {
  671 |     expect(detailsFoo.serverIPAddress).toMatch(/^127\.0\.0\.1|\[::1\]/);
  672 |     expect(detailsFoo._serverPort).toBe(server.PORT);
  673 |   }
  674 | 
  675 |   const detailsEmpty = log.entries[1];
  676 |   expect(detailsEmpty.serverIPAddress).toMatch(/^127\.0\.0\.1|\[::1\]/);
  677 |   expect(detailsEmpty._serverPort).toBe(server.PORT);
  678 | });
  679 | 
  680 | it('should have connection details for failed requests', async ({ contextFactory, server, browserName, platform, mode }, testInfo) => {
  681 |   server.setRoute('/one-style.css', (_, res) => {
  682 |     res.setHeader('Content-Type', 'text/css');
  683 |     res.socket!.destroy();
  684 |   });
  685 |   const { page, getLog } = await pageWithHar(contextFactory, testInfo);
  686 |   await page.goto(server.PREFIX + '/one-style.html');
  687 |   const log = await getLog();
  688 |   const { serverIPAddress, _serverPort: port } = log.entries[0];
  689 |   expect(serverIPAddress).toMatch(/^127\.0\.0\.1|\[::1\]/);
  690 |   expect(port).toBe(server.PORT);
  691 | });
  692 | 
  693 | it('should return server address directly from response', async ({ page, server, mode }) => {
  694 |   const response = await page.goto(server.EMPTY_PAGE);
  695 |   const { ipAddress, port } = (await response!.serverAddr())!;
  696 |   expect(ipAddress).toMatch(/^127\.0\.0\.1|\[::1\]/);
  697 |   expect(port).toBe(server.PORT);
  698 | });
  699 | 
  700 | it('should return security details directly from response', async ({ contextFactory, httpsServer, browserName, platform, channel, isFrozenWebkit }) => {
  701 |   it.skip(isFrozenWebkit);
  702 | 
```