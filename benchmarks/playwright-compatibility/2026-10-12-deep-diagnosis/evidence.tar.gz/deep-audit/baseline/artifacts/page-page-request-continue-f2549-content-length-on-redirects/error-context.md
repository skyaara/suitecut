# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-request-continue.spec.ts >> continue should drop content-length on redirects
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-request-continue.spec.ts:590:3

# Error details

```
Error: expect(received).toBeUndefined()

Received: "text/plain;charset=UTF-8"
```

# Test source

```ts
  510 | }, async ({ page, server }) => {
  511 |   server.setRoute('/set-cookie', (request, response) => {
  512 |     response.writeHead(200, { 'Set-Cookie': 'foo=v1;' });
  513 |     response.end();
  514 |   });
  515 |   await page.goto(server.PREFIX + '/set-cookie');
  516 |   expect(await page.evaluate(() => document.cookie)).toBe('foo=v1');
  517 | 
  518 |   // The redirect updates the cookie before bouncing to the final destination.
  519 |   server.setRoute('/redirect', (request, response) => {
  520 |     response.writeHead(302, { 'Set-Cookie': 'foo=v2;', 'location': server.PREFIX + '/empty.html' });
  521 |     response.end();
  522 |   });
  523 | 
  524 |   await page.route('**/redirect', route => {
  525 |     void route.continue({ headers: route.request().headers() });
  526 |   });
  527 | 
  528 |   const [serverRequest] = await Promise.all([
  529 |     server.waitForRequest('/empty.html'),
  530 |     page.goto(server.PREFIX + '/redirect')
  531 |   ]);
  532 |   // The redirected request should carry the cookie updated by the redirect, not the stale captured value.
  533 |   expect(serverRequest.headers['cookie']).toBe('foo=v2');
  534 | });
  535 | 
  536 | it('redirect after continue should be able to delete cookie', {
  537 |   annotation: [
  538 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/35168' },
  539 |   ]
  540 | }, async ({ page, server }) => {
  541 |   server.setRoute('/set-cookie', (request, response) => {
  542 |     response.writeHead(200, { 'Set-Cookie': 'foo=bar;' });
  543 |     response.end();
  544 |   });
  545 |   await page.goto(server.PREFIX + '/set-cookie');
  546 |   expect(await page.evaluate(() => document.cookie)).toBe('foo=bar');
  547 | 
  548 |   server.setRoute('/delete-cookie', (request, response) => {
  549 |     response.writeHead(200, { 'Set-Cookie': 'foo=bar; expires=Thu, 01 Jan 1970 00:00:00 GMT' });
  550 |     response.end();
  551 |   });
  552 |   server.setRedirect('/redirect', '/delete-cookie');
  553 |   await page.route('**/redirect', route => {
  554 |     void route.continue({
  555 |       headers: {
  556 |         ...route.request().headers(),
  557 |       }
  558 |     });
  559 |   });
  560 |   await page.goto(server.PREFIX + '/redirect');
  561 |   const [serverRequest] = await Promise.all([
  562 |     server.waitForRequest('/empty.html'),
  563 |     page.goto(server.EMPTY_PAGE)
  564 |   ]);
  565 |   expect(serverRequest.headers['cookie']).toBeFalsy();
  566 | });
  567 | 
  568 | it('continue should propagate headers to redirects', {
  569 |   annotation: [
  570 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/28758' },
  571 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/32045' },
  572 |   ]
  573 | }, async ({ page, server }) => {
  574 |   await server.setRedirect('/redirect', '/empty.html');
  575 |   await page.route('**/redirect', route => {
  576 |     void route.continue({
  577 |       headers: {
  578 |         ...route.request().headers(),
  579 |         custom: 'value'
  580 |       }
  581 |     });
  582 |   });
  583 |   const [serverRequest] = await Promise.all([
  584 |     server.waitForRequest('/empty.html'),
  585 |     page.goto(server.PREFIX + '/redirect')
  586 |   ]);
  587 |   expect(serverRequest.headers['custom']).toBe('value');
  588 | });
  589 | 
  590 | it('continue should drop content-length on redirects', {
  591 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36029' }
  592 | }, async ({ page, server }) => {
  593 |   await page.goto(server.EMPTY_PAGE);
  594 | 
  595 |   await server.setRedirect('/redirect', '/empty.html');
  596 |   await page.route('**/redirect', route => {
  597 |     void route.continue({
  598 |       headers: {
  599 |         ...route.request().headers(),
  600 |         custom: 'value'
  601 |       }
  602 |     });
  603 |   });
  604 |   const [serverRequest] = await Promise.all([
  605 |     server.waitForRequest('/empty.html'),
  606 |     page.evaluate(url => fetch(url, { method: 'POST', body: 'foo' }), server.PREFIX + '/redirect')
  607 |   ]);
  608 |   expect.soft(serverRequest.method).toBe('GET');
  609 |   expect.soft(serverRequest.headers['content-length']).toBeUndefined();
> 610 |   expect.soft(serverRequest.headers['content-type']).toBeUndefined();
      |                                                      ^ Error: expect(received).toBeUndefined()
  611 |   expect.soft(serverRequest.headers['custom']).toBe('value');
  612 | });
  613 | 
  614 | it('redirected requests should report overridden headers', {
  615 |   annotation: [
  616 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/31351' },
  617 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/32045' },
  618 |   ]
  619 | }, async ({ page, server }) => {
  620 |   await server.setRedirect('/redirect', '/empty.html');
  621 |   await page.route('**/redirect', route => {
  622 |     const headers = route.request().headers();
  623 |     headers['custom'] = 'value';
  624 |     void route.fallback({ headers });
  625 |   });
  626 | 
  627 |   const [serverRequest, response] = await Promise.all([
  628 |     server.waitForRequest('/empty.html'),
  629 |     page.goto(server.PREFIX + '/redirect')
  630 |   ]);
  631 |   expect(serverRequest.headers['custom']).toBe('value');
  632 |   expect(response.request().url()).toBe(server.EMPTY_PAGE);
  633 |   expect(response.request().headers()['custom']).toBe('value');
  634 |   expect((await response.request().allHeaders())['custom']).toBe('value');
  635 | });
  636 | 
  637 | it('continue should delete headers on redirects', {
  638 |   annotation: [
  639 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/13106' },
  640 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/32045' },
  641 |   ]
  642 | }, async ({ page, server }) => {
  643 |   await page.goto(server.PREFIX + '/empty.html');
  644 |   server.setRoute('/something', (request, response) => {
  645 |     response.writeHead(200, { 'Access-Control-Allow-Origin': '*' });
  646 |     response.end('done');
  647 |   });
  648 |   await server.setRedirect('/redirect', '/something');
  649 |   await page.route('**/redirect', route => {
  650 |     void route.continue({
  651 |       headers: {
  652 |         ...route.request().headers(),
  653 |         foo: undefined
  654 |       }
  655 |     });
  656 |   });
  657 |   const [text, serverRequest] = await Promise.all([
  658 |     page.evaluate(async url => {
  659 |       const data = await fetch(url, {
  660 |         headers: {
  661 |           foo: 'a',
  662 |         }
  663 |       });
  664 |       return data.text();
  665 |     }, server.PREFIX + '/redirect'),
  666 |     server.waitForRequest('/something')
  667 |   ]);
  668 |   expect(text).toBe('done');
  669 |   expect(serverRequest.headers.foo).toBeFalsy();
  670 | });
  671 | 
  672 | it('propagate headers same origin redirect', {
  673 |   annotation: [
  674 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/13106' },
  675 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/32045' },
  676 |     { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/35154' },
  677 |   ]
  678 | }, async ({ page, server }) => {
  679 |   await page.goto(server.PREFIX + '/empty.html');
  680 |   let resolve;
  681 |   const serverRequestPromise = new Promise<http.IncomingMessage>(f => resolve = f);
  682 |   server.setRoute('/something', (request, response) => {
  683 |     if (request.method === 'OPTIONS') {
  684 |       response.writeHead(204, {
  685 |         'Access-Control-Allow-Origin': server.PREFIX,
  686 |         'Access-Control-Allow-Credentials': 'true',
  687 |         'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, DELETE',
  688 |         'Access-Control-Allow-Headers': 'authorization,cookie,custom',
  689 |       });
  690 |       response.end();
  691 |       return;
  692 |     }
  693 |     resolve(request);
  694 |     response.writeHead(200, { });
  695 |     response.end('done');
  696 |   });
  697 |   await server.setRedirect('/redirect', '/something');
  698 |   await page.evaluate(() => document.cookie = 'a=b');
  699 |   const text = await page.evaluate(async url => {
  700 |     const data = await fetch(url, {
  701 |       headers: {
  702 |         authorization: 'credentials',
  703 |         custom: 'foo'
  704 |       },
  705 |       credentials: 'include',
  706 |     });
  707 |     return data.text();
  708 |   }, server.PREFIX + '/redirect');
  709 |   expect(text).toBe('done');
  710 |   const serverRequest = await serverRequestPromise;
```