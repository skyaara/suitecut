# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-event-request.spec.ts >> should fire requestfailed when intercepting race
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-event-request.spec.ts:198:3

# Error details

```
Error: page.setContent: Target page, context or browser has been closed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  123 |   it.fixme(isAndroid);
  124 | 
  125 |   await page.goto(server.PREFIX + '/serviceworkers/stub/sw.html');
  126 |   await page.evaluate(() => window['activationPromise']);
  127 | 
  128 |   const reloadResponse = await page.reload();
  129 |   expect(await page.evaluate('window.fromSW')).toBe(true);
  130 |   expect(reloadResponse.url()).toBe(server.PREFIX + '/serviceworkers/stub/sw.html');
  131 |   await page.evaluate(() => window['activationPromise']);
  132 | 
  133 |   if (browserName !== 'firefox') {
  134 |     // When SW fetch throws, Firefox does not fail the navigation,
  135 |     // but rather falls back to the real network.
  136 | 
  137 |     const [, failedRequest] = await Promise.all([
  138 |       page.evaluate(() => {
  139 |         window.location.href = '/serviceworkers/stub/error.html';
  140 |       }),
  141 |       page.waitForEvent('requestfailed'),
  142 |     ]);
  143 |     expect(failedRequest.url()).toBe(server.PREFIX + '/serviceworkers/stub/error.html');
  144 |     expect(failedRequest.failure().errorText).toContain(browserName === 'chromium' ? 'net::ERR_FAILED' : 'uh oh');
  145 |     expect(failedRequest.serviceWorker()).toBe(null);
  146 |     expect(await failedRequest.response()).toBe(null);
  147 |   }
  148 | });
  149 | 
  150 | it('should report navigation requests and responses handled by service worker with routing', async ({ page, server, isAndroid, browserName }) => {
  151 |   it.fixme(isAndroid);
  152 | 
  153 |   await page.route('**/*', route => route.continue());
  154 |   await page.goto(server.PREFIX + '/serviceworkers/stub/sw.html');
  155 |   await page.evaluate(() => window['activationPromise']);
  156 | 
  157 |   const reloadResponse = await page.reload();
  158 |   expect(await page.evaluate('window.fromSW')).toBe(true);
  159 |   expect(reloadResponse.url()).toBe(server.PREFIX + '/serviceworkers/stub/sw.html');
  160 |   await page.evaluate(() => window['activationPromise']);
  161 | 
  162 |   if (browserName !== 'firefox') {
  163 |     // When SW fetch throws, Firefox does not fail the navigation,
  164 |     // but rather falls back to the real network.
  165 | 
  166 |     const [, failedRequest] = await Promise.all([
  167 |       page.evaluate(() => {
  168 |         window.location.href = '/serviceworkers/stub/error.html';
  169 |         // eslint-disable-next-line
  170 |         undefined
  171 |       }),
  172 |       page.waitForEvent('requestfailed'),
  173 |     ]);
  174 |     expect(failedRequest.url()).toBe(server.PREFIX + '/serviceworkers/stub/error.html');
  175 |     expect(failedRequest.failure().errorText).toContain(browserName === 'chromium' ? 'net::ERR_FAILED' : 'uh oh');
  176 |     expect(failedRequest.serviceWorker()).toBe(null);
  177 |     expect(await failedRequest.response()).toBe(null);
  178 |   }
  179 | });
  180 | 
  181 | it('should return response body when Cross-Origin-Opener-Policy is set', async ({ page, server, browserName }) => {
  182 |   server.setRoute('/empty.html', (req, res) => {
  183 |     res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  184 |     // Note: without 'onload', Firefox sometimes does not fire the load event
  185 |     // over the protocol. The reason is unclear.
  186 |     res.end(`
  187 |       <div>Hello there!</div>
  188 |       <script>window.onload = () => console.log('onload')</script>
  189 |     `);
  190 |   });
  191 |   const response = await page.goto(server.EMPTY_PAGE);
  192 |   expect(page.url()).toBe(server.EMPTY_PAGE);
  193 |   await response.finished();
  194 |   expect(response.request().failure()).toBeNull();
  195 |   expect(await response.text()).toContain('Hello there!');
  196 | });
  197 | 
  198 | it('should fire requestfailed when intercepting race', async ({ page, server, browserName }) => {
  199 |   it.skip(browserName !== 'chromium', 'This test is specifically testing Chromium race');
  200 | 
  201 |   const promise = new Promise<void>(resolve => {
  202 |     let counter = 0;
  203 |     const failures = new Set();
  204 |     const alive = new Set();
  205 |     page.on('request', request => {
  206 |       expect(alive.has(request)).toBe(false);
  207 |       expect(failures.has(request)).toBe(false);
  208 |       alive.add(request);
  209 |     });
  210 |     page.on('requestfailed', request => {
  211 |       expect(failures.has(request)).toBe(false);
  212 |       expect(alive.has(request)).toBe(true);
  213 |       alive.delete(request);
  214 |       failures.add(request);
  215 |       if (++counter === 10)
  216 |         resolve();
  217 |     });
  218 |   });
  219 | 
  220 |   // Stall requests to make sure we don't get requestfinished.
  221 |   await page.route('**', route => {});
  222 | 
> 223 |   await page.setContent(`
      |              ^ Error: page.setContent: Target page, context or browser has been closed
  224 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  225 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  226 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  227 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  228 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  229 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  230 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  231 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  232 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  233 |     <iframe src="${server.EMPTY_PAGE}"></iframe>
  234 |     <script>
  235 |       function abortAll() {
  236 |         const frames = document.querySelectorAll("iframe");
  237 |         for (const frame of frames)
  238 |           frame.src = "about:blank";
  239 |       }
  240 |       abortAll();
  241 |     </script>
  242 |   `);
  243 | 
  244 |   await promise;
  245 | });
  246 | 
  247 | it('main resource xhr should have type xhr', async ({ page, server }) => {
  248 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/22812' });
  249 |   await page.goto(server.EMPTY_PAGE);
  250 |   const [request] = await Promise.all([
  251 |     page.waitForEvent('request'),
  252 |     page.evaluate(() => {
  253 |       const x = new XMLHttpRequest();
  254 |       x.open('GET', location.href, false);
  255 |       x.send();
  256 |     })
  257 |   ]);
  258 |   expect(request.isNavigationRequest()).toBe(false);
  259 |   expect(request.resourceType()).toBe('xhr');
  260 | });
  261 | 
  262 | it('should finish 204 request', {
  263 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/32752' }
  264 | }, async ({ page, server, browserName }) => {
  265 |   it.fixme(browserName === 'chromium');
  266 |   server.setRoute('/204', (req, res) => {
  267 |     res.writeHead(204, { 'Content-type': 'text/plain' });
  268 |     res.end();
  269 |   });
  270 |   await page.goto(server.EMPTY_PAGE);
  271 |   const reqPromise = Promise.race([
  272 |     page.waitForEvent('requestfailed', r => r.url().endsWith('/204')).then(() => 'requestfailed'),
  273 |     page.waitForEvent('requestfinished', r => r.url().endsWith('/204')).then(() => 'requestfinished'),
  274 |   ]);
  275 |   page.evaluate(async url => { await fetch(url); }, server.PREFIX + '/204').catch(() => {});
  276 |   expect(await reqPromise).toBe('requestfinished');
  277 | });
  278 | 
  279 | it('<picture> resource should have type image', async ({ page }) => {
  280 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/33148' });
  281 |   const [request] = await Promise.all([
  282 |     page.waitForEvent('request'),
  283 |     page.setContent(`
  284 |       <picture>
  285 |         <source>
  286 |           <img src="https://www.wikipedia.org/portal/wikipedia.org/assets/img/Wikipedia-logo-v2@2x.png">
  287 |         </source>
  288 |       </picture>
  289 |     `)
  290 |   ]);
  291 |   expect(request.resourceType()).toBe('image');
  292 | });
  293 | 
  294 | // Chromium: requestWillBeSentEvent.frameId is undefined for OPTIONS.
  295 | // WebKit: no requestWillBeSent event in the protocol for OPTIONS (at least on Mac).
  296 | // Firefox: OPTIONS request can be dispatched.
  297 | it('should not expose preflight OPTIONS request', {
  298 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36311' }
  299 | }, async ({ page, server, browserName }) => {
  300 |   const serverRequests = [];
  301 |   server.setRoute('/cors', (req, res) => {
  302 |     serverRequests.push(`${req.method} ${req.url}`);
  303 |     if (req.method === 'OPTIONS') {
  304 |       res.writeHead(204, {
  305 |         'Access-Control-Allow-Origin': '*',
  306 |         'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
  307 |         'Access-Control-Allow-Headers': '*',
  308 |       });
  309 |       res.end();
  310 |       return;
  311 |     }
  312 |     res.writeHead(200, { 'Content-type': 'text/plain', 'Access-Control-Allow-Origin': '*' });
  313 |     res.end('Hello there!');
  314 |   });
  315 |   const clientRequests = [];
  316 |   page.on('request', request => {
  317 |     clientRequests.push(`${request.method()} ${request.url()}`);
  318 |   });
  319 |   const response = await page.evaluate(async url => {
  320 |     const response = await fetch(url, {
  321 |       method: 'POST',
  322 |       body: '',
  323 |       headers: {
```