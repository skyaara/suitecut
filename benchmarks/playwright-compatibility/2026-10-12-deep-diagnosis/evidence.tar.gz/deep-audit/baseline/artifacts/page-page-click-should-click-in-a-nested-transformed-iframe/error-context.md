# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-click.spec.ts >> should click in a nested transformed iframe
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-click.spec.ts:1112:3

# Error details

```
Error: page.setContent: Target page, context or browser has been closed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  1013 |     </style>
  1014 |     <iframe srcdoc="
  1015 |       <style>
  1016 |         body, html { margin: 0; padding: 0; }
  1017 |         div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  1018 |       </style>
  1019 |       <div>Target</div>
  1020 |       <script>
  1021 |         document.querySelector('div').addEventListener('click', () => window.top._clicked = true);
  1022 |       </script>
  1023 |     "></iframe>
  1024 |   `);
  1025 |   const locator = page.frameLocator('iframe').locator('div');
  1026 |   await locator.click();
  1027 |   expect(await page.evaluate('window._clicked')).toBe(true);
  1028 | });
  1029 | 
  1030 | it('should click in a transformed iframe', async ({ page }) => {
  1031 |   await page.setContent(`
  1032 |     <style>
  1033 |       body, html, iframe { margin: 0; padding: 0; border: none; }
  1034 |       iframe {
  1035 |         border: 4px solid black;
  1036 |         background: gray;
  1037 |         margin-left: 33px;
  1038 |         margin-top: 24px;
  1039 |         width: 400px;
  1040 |         height: 400px;
  1041 |         transform: translate(100px, 100px) scale(1.2) rotate3d(1, 1, 1, 25deg);
  1042 |       }
  1043 |     </style>
  1044 |     <iframe srcdoc="
  1045 |       <style>
  1046 |         body, html { margin: 0; padding: 0; }
  1047 |         div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  1048 |       </style>
  1049 |       <div>Target</div>
  1050 |       <script>
  1051 |         document.querySelector('div').addEventListener('click', () => window.top._clicked = true);
  1052 |       </script>
  1053 |     "></iframe>
  1054 |   `);
  1055 |   const locator = page.frameLocator('iframe').locator('div');
  1056 |   await locator.click();
  1057 |   expect(await page.evaluate('window._clicked')).toBe(true);
  1058 | });
  1059 | 
  1060 | it('should click a button that is overlaid by a permission popup', async ({ page, server }) => {
  1061 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/23280' });
  1062 |   await page.setViewportSize({ width: 500, height: 500 });
  1063 |   await page.goto(server.EMPTY_PAGE);
  1064 |   await page.setContent(`
  1065 |     <style>body, html { padding: 0; margin: 0; }</style>
  1066 |     <script type='text/javascript'>
  1067 |       window.addEventListener('DOMContentLoaded', () => {
  1068 |         // Viewport filled with buttons.
  1069 |         for (let i = 0; i < 100; ++i) {
  1070 |           const button = document.createElement('button');
  1071 |           button.textContent = i;
  1072 |           button.style.setProperty('width', '50px');
  1073 |           button.style.setProperty('height', '50px');
  1074 |           document.body.append(button);
  1075 |         }
  1076 |       }, false);
  1077 |     </script>
  1078 |   `);
  1079 |   // Issue a geolocation request. This should show a browser popup.
  1080 |   // NOTE: this is a bit racy since we can't wait for the geolocation
  1081 |   // popup to be shown.
  1082 |   await page.evaluate(() => {
  1083 |     navigator.geolocation.getCurrentPosition(position => { });
  1084 |   });
  1085 |   // If popup blocks the click, then some of the `page.click` calls below will hang.
  1086 |   for (let i = 0; i < 30; ++i)
  1087 |     await page.click(`text=${i}`);
  1088 | });
  1089 | 
  1090 | it('should click in a transformed iframe with force', async ({ page }) => {
  1091 |   await page.setContent(`
  1092 |     <style>
  1093 |       body, html, iframe { margin: 0; padding: 0; border: none; }
  1094 |       iframe { background: gray; margin-left: 33px; margin-top: 24px; width: 400px; height: 400px; transform: translate(-40px, -40px) scale(0.8); }
  1095 |     </style>
  1096 |     <iframe srcdoc="
  1097 |       <style>
  1098 |         body, html { margin: 0; padding: 0; }
  1099 |         div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  1100 |       </style>
  1101 |       <div>Target</div>
  1102 |       <script>
  1103 |         document.querySelector('div').addEventListener('click', () => window.top._clicked = true);
  1104 |       </script>
  1105 |     "></iframe>
  1106 |   `);
  1107 |   const locator = page.frameLocator('iframe').locator('div');
  1108 |   await locator.click({ force: true });
  1109 |   expect(await page.evaluate('window._clicked')).toBe(true);
  1110 | });
  1111 | 
  1112 | it('should click in a nested transformed iframe', async ({ page }) => {
> 1113 |   await page.setContent(`
       |              ^ Error: page.setContent: Target page, context or browser has been closed
  1114 |     <style>
  1115 |       body, html, iframe { margin: 0; padding: 0; box-sizing: border-box; }
  1116 |       iframe { border: 1px solid black; background: gray; margin-left: 33px; margin-top: 24px; width: 400px; height: 400px; transform: scale(0.8); }
  1117 |     </style>
  1118 |     <iframe srcdoc="
  1119 |       <style>
  1120 |         body, html, iframe { margin: 0; padding: 0; box-sizing: border-box; }
  1121 |         iframe { border: 3px solid black; background: gray; margin-left: 18px; margin-top: 14px; width: 200px; height: 200px; transform: scale(0.7); }
  1122 |       </style>
  1123 |       <iframe srcdoc='
  1124 |         <style>
  1125 |           div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  1126 |         </style>
  1127 |         <div>Target</div>
  1128 |       '></iframe>
  1129 |     "></iframe>
  1130 |   `);
  1131 |   const locator = page.frameLocator('iframe').frameLocator('iframe').locator('div');
  1132 |   await locator.evaluate(div => {
  1133 |     div.addEventListener('click', () => window.top['_clicked'] = true);
  1134 |   });
  1135 |   await locator.click();
  1136 |   expect(await page.evaluate('window._clicked')).toBe(true);
  1137 | });
  1138 | 
  1139 | it('ensure events are dispatched in the individual tasks', async ({ page, browserName }) => {
  1140 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/19685' });
  1141 |   await page.setContent(`
  1142 |     <div id="outer" style="background: #d4d4d4; width: 60px; height: 60px;">
  1143 |       <div id="inner" style="background: #adadad; width: 46px; height: 46px;"></div>
  1144 |     </div>
  1145 |   `);
  1146 | 
  1147 |   await page.evaluate(() => {
  1148 |     function onClick(name) {
  1149 |       console.log(`click ${name}`);
  1150 | 
  1151 |       window.builtins.setTimeout(function() {
  1152 |         console.log(`timeout ${name}`);
  1153 |       }, 0);
  1154 | 
  1155 |       void Promise.resolve().then(function() {
  1156 |         console.log(`promise ${name}`);
  1157 |       });
  1158 |     }
  1159 | 
  1160 |     document.getElementById('inner').addEventListener('click', () => onClick('inner'));
  1161 |     document.getElementById('outer').addEventListener('click', () => onClick('outer'));
  1162 |   });
  1163 | 
  1164 |   // Capture console messages
  1165 |   const messages: Array<string> = [];
  1166 |   page.on('console', msg => messages.push(msg.text()));
  1167 | 
  1168 |   // Click on the inner div element
  1169 |   await page.locator('#inner').click();
  1170 | 
  1171 |   await expect.poll(() => messages).toEqual([
  1172 |     'click inner',
  1173 |     'promise inner',
  1174 |     'click outer',
  1175 |     'promise outer',
  1176 |     'timeout inner',
  1177 |     'timeout outer',
  1178 |   ]);
  1179 | });
  1180 | 
  1181 | it('should click if opened select covers the button', async ({ page }) => {
  1182 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/23618' });
  1183 |   await page.setContent(`
  1184 |     <div>
  1185 |       <select>
  1186 |         <option>very long text #1</option>
  1187 |         <option>very long text #2</option>
  1188 |         <option>very long text #3</option>
  1189 |         <option>very long text #4</option>
  1190 |         <option>very long text #5</option>
  1191 |         <option>very long text #6</option>
  1192 |       </select>
  1193 |     </div>
  1194 |     <div>
  1195 |       <button onclick="window.__CLICKED=42">clickme</button>
  1196 |     </div>
  1197 |   `);
  1198 |   await page.click('select');
  1199 |   await page.click('button');
  1200 |   expect(await page.evaluate('window.__CLICKED')).toBe(42);
  1201 | });
  1202 | 
  1203 | it('should fire contextmenu event on right click in correct order', async ({ page, server, browserName, isWindows }) => {
  1204 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/26515' });
  1205 |   await page.goto(server.EMPTY_PAGE);
  1206 |   await page.setContent(`
  1207 |     <button id="target">Click me</button>
  1208 |   `);
  1209 |   await page.evaluate(() => {
  1210 |     const logEvent = e => console.log(e.type);
  1211 |     document.addEventListener('mousedown', logEvent);
  1212 |     document.addEventListener('mouseup', logEvent);
  1213 |     document.addEventListener('contextmenu', logEvent);
```