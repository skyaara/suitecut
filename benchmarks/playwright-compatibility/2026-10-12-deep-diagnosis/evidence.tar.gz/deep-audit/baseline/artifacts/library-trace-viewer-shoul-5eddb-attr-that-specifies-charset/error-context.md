# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/trace-viewer.spec.ts >> should replace meta content attr that specifies charset
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/trace-viewer.spec.ts:2435:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "<meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\">"
Received: "<meta content=\"text/html; charset=utf-8\" http-equiv=\"content-type\">"

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Test source

```ts
  2341 | });
  2342 | 
  2343 | test('should not navigate on anchor clicks', async ({ runAndTrace, page, server }) => {
  2344 |   const url = server.EMPTY_PAGE;
  2345 |   const traceViewer = await runAndTrace(async () => {
  2346 |     await page.setContent(`
  2347 |       <a href="${url}">link1</a>
  2348 |       <a href="${url}" target="_blank">link2</a>
  2349 |       <a href="${url}" target="_top">link3</a>
  2350 |     `);
  2351 |   });
  2352 |   const snapshot = await traceViewer.snapshotFrame('Set content');
  2353 |   const frame = await snapshot.owner().elementHandle().then(handle => handle.contentFrame());
  2354 | 
  2355 |   const checkLink = async (name: string) => {
  2356 |     let newPageOpened = false;
  2357 |     traceViewer.page.context().on('page', () => {
  2358 |       newPageOpened = true;
  2359 |     });
  2360 |     await snapshot.getByRole('link', { name }).click();
  2361 |     await traceViewer.page.waitForTimeout(500);
  2362 |     await expect(traceViewer.page).not.toHaveURL(url, { timeout: 500 });
  2363 |     expect(frame.url()).not.toBe(url);
  2364 |     expect(newPageOpened).toBe(false);
  2365 |   };
  2366 | 
  2367 |   await checkLink('link1');
  2368 |   await checkLink('link2');
  2369 |   await checkLink('link3');
  2370 | });
  2371 | 
  2372 | test('should respect CSSOM changes', async ({ runAndTrace, page, server }) => {
  2373 |   const traceViewer = await runAndTrace(async () => {
  2374 |     await page.setContent('<style>button { color: red; }</style><button>Hello</button>');
  2375 |     await page.evaluate(() => { (document.styleSheets[0].cssRules[0] as any).style.color = 'blue'; });
  2376 | 
  2377 |     await page.setContent('<style>@media { button { color: red; } }</style><button>Hello</button>');
  2378 |     await page.evaluate(() => {
  2379 |       window['rule'] = document.styleSheets[0].cssRules[0];
  2380 |       void 0;
  2381 |     });
  2382 |     await page.evaluate(() => { window['rule'].cssRules[0].style.color = 'black'; });
  2383 |     await page.evaluate(() => { window['rule'].insertRule('button:not(.disabled) { color: green; }', 1); });
  2384 | 
  2385 |     await page.route('**/style.css', route => {
  2386 |       route.fulfill({ body: 'button { color: red; }', }).catch(() => {});
  2387 |     });
  2388 |     await page.goto(server.EMPTY_PAGE);
  2389 |     await page.setContent('<link rel="stylesheet" href="style.css"><button>Hello</button>');
  2390 |     await page.evaluate(() => { (document.styleSheets[0].cssRules[0] as any).style.color = 'blue'; });
  2391 |     await page.evaluate(() => '1 + 1');
  2392 |     await page.evaluate(() => { document.styleSheets[0].disabled = true; });
  2393 |   });
  2394 | 
  2395 |   const frame1 = await traceViewer.snapshotFrame('Set content', 0);
  2396 |   await expect(frame1.locator('button')).toHaveCSS('color', 'rgb(255, 0, 0)');
  2397 |   const frame2 = await traceViewer.snapshotFrame('Evaluate', 0);
  2398 |   await expect(frame2.locator('button')).toHaveCSS('color', 'rgb(0, 0, 255)');
  2399 | 
  2400 |   const frame3 = await traceViewer.snapshotFrame('Set content', 1);
  2401 |   await expect(frame3.locator('button')).toHaveCSS('color', 'rgb(255, 0, 0)');
  2402 |   const frame4 = await traceViewer.snapshotFrame('Evaluate', 2);
  2403 |   await expect(frame4.locator('button')).toHaveCSS('color', 'rgb(0, 0, 0)');
  2404 |   const frame5 = await traceViewer.snapshotFrame('Evaluate', 3);
  2405 |   await expect(frame5.locator('button')).toHaveCSS('color', 'rgb(0, 128, 0)');
  2406 | 
  2407 |   const frame6 = await traceViewer.snapshotFrame('Set content', 2);
  2408 |   await expect(frame6.locator('button')).toHaveCSS('color', 'rgb(255, 0, 0)');
  2409 |   const frame7 = await traceViewer.snapshotFrame('Evaluate', 4);
  2410 |   await expect(frame7.locator('button')).toHaveCSS('color', 'rgb(0, 0, 255)');
  2411 |   const frame8 = await traceViewer.snapshotFrame('Evaluate', 5);
  2412 |   await traceViewer.page.waitForTimeout(1000); // give it time to render wrong color
  2413 |   await expect(frame8.locator('button')).toHaveCSS('color', 'rgb(0, 0, 255)');
  2414 |   const frame9 = await traceViewer.snapshotFrame('Evaluate', 6);
  2415 |   await expect(frame9.locator('button')).toHaveCSS('color', 'rgb(0, 0, 0)');
  2416 | });
  2417 | 
  2418 | test('should preserve custom doctype', async ({ runAndTrace, page }) => {
  2419 |   const traceViewer = await runAndTrace(async () => {
  2420 |     await page.setContent('<!DOCTYPE foo><body>hi</body>');
  2421 |   });
  2422 |   const frame = await traceViewer.snapshotFrame('Set content');
  2423 |   await expect.poll(() => frame.locator('body').evaluate(() => document.doctype.name)).toBe('foo');
  2424 | });
  2425 | 
  2426 | test('should replace meta charset attr that specifies charset', async ({ runAndTrace, page, server }) => {
  2427 |   const traceViewer = await runAndTrace(async () => {
  2428 |     await page.goto(server.EMPTY_PAGE);
  2429 |     await page.setContent('<meta charset="shift-jis" />');
  2430 |   });
  2431 |   const frame = await traceViewer.snapshotFrame('Set content');
  2432 |   await expect.poll(() => frame.locator('body').evaluate(() => document.querySelector('meta')?.outerHTML.toLowerCase())).toBe('<meta charset="utf-8">');
  2433 | });
  2434 | 
  2435 | test('should replace meta content attr that specifies charset', async ({ runAndTrace, page, server }) => {
  2436 |   const traceViewer = await runAndTrace(async () => {
  2437 |     await page.goto(server.EMPTY_PAGE);
  2438 |     await page.setContent('<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">');
  2439 |   });
  2440 |   const frame = await traceViewer.snapshotFrame('Set content');
> 2441 |   await expect.poll(() => frame.locator('body').evaluate(() => document.querySelector('meta')?.outerHTML.toLowerCase())).toBe('<meta http-equiv="content-type" content="text/html; charset=utf-8">');
       |                                                                                                                          ^ Error: expect(received).toBe(expected) // Object.is equality
  2442 | });
  2443 | 
  2444 | test('should drop meta http-equiv refresh during recording', async ({ runAndTrace, page, server }) => {
  2445 |   const traceViewer = await runAndTrace(async () => {
  2446 |     await page.goto(server.EMPTY_PAGE);
  2447 |     // Use a very large delay so the recorded page does not actually navigate before the snapshot is taken.
  2448 |     await page.setContent(`
  2449 |       <head>
  2450 |         <meta http-equiv="refresh" content="999999; url=https://example.com/evil">
  2451 |       </head>
  2452 |       <body><div>safe</div></body>
  2453 |     `);
  2454 |   });
  2455 |   const frame = await traceViewer.snapshotFrame('Set content');
  2456 |   await expect(frame.locator('div')).toHaveText('safe');
  2457 |   // Refresh META must be stripped from the snapshot, so the iframe is not navigated.
  2458 |   await expect.poll(() => frame.locator('head').evaluate(head => head.querySelector('meta[http-equiv]')?.outerHTML.toLowerCase() ?? '')).toBe('');
  2459 |   // The trace viewer top-level title and body must remain untouched.
  2460 |   await expect(traceViewer.page).toHaveTitle(/Playwright Trace Viewer/);
  2461 |   await expect(traceViewer.page.locator('body')).not.toHaveAttribute('data-pwned', /.*/);
  2462 | });
  2463 | 
  2464 | test('should neutralize meta http-equiv refresh during rendering', async ({ runAndTrace, page, server }) => {
  2465 |   // Inject a META refresh directly via DOM manipulation that bypasses the
  2466 |   // recording-time strip (so this test specifically validates the renderer-side defense).
  2467 |   const traceViewer = await runAndTrace(async () => {
  2468 |     await page.goto(server.EMPTY_PAGE);
  2469 |     await page.evaluate(() => {
  2470 |       const meta = document.createElement('meta');
  2471 |       meta.setAttribute('http-equiv', 'refresh');
  2472 |       meta.setAttribute('content', '999999; url=https://example.com/evil');
  2473 |       document.head.appendChild(meta);
  2474 |       const div = document.createElement('div');
  2475 |       div.textContent = 'safe';
  2476 |       document.body.appendChild(div);
  2477 |     });
  2478 |   });
  2479 |   const frame = await traceViewer.snapshotFrame('Evaluate');
  2480 |   await expect(frame.locator('div')).toHaveText('safe');
  2481 |   // Even if a META refresh is in the recorded snapshot, the renderer must
  2482 |   // neutralize the http-equiv and content attributes so it has no effect.
  2483 |   await expect.poll(() => frame.locator('head').evaluate(head => !!head.querySelector('meta[http-equiv="refresh"]'))).toBe(false);
  2484 |   await expect(traceViewer.page).toHaveTitle(/Playwright Trace Viewer/);
  2485 | });
  2486 | 
  2487 | test('snapshot iframes should be sandboxed', async ({ runAndTrace, page, server }) => {
  2488 |   const traceViewer = await runAndTrace(async () => {
  2489 |     await page.goto(server.EMPTY_PAGE);
  2490 |     await page.setContent('<div>hello</div>');
  2491 |   });
  2492 |   await traceViewer.snapshotFrame('Set content');
  2493 |   const sandboxValues = await traceViewer.page.locator('iframe[name=snapshot]').evaluateAll(frames => frames.map(f => f.getAttribute('sandbox')));
  2494 |   for (const value of sandboxValues) {
  2495 |     expect(value).toBeTruthy();
  2496 |     expect(value).toContain('allow-same-origin');
  2497 |     expect(value).toContain('allow-scripts');
  2498 |   }
  2499 | });
  2500 | 
  2501 | test('should capture iframe with srcdoc', async ({ page, server, runAndTrace }) => {
  2502 |   await page.route('**/empty.html', route => {
  2503 |     void route.fulfill({
  2504 |       body: `<iframe srcdoc="<button>Hello iframe</button>"></iframe>`,
  2505 |       contentType: 'text/html'
  2506 |     }).catch(() => {});
  2507 |   });
  2508 | 
  2509 |   const traceViewer = await runAndTrace(async () => {
  2510 |     await page.goto(server.EMPTY_PAGE);
  2511 |     await expect(page.frameLocator('iframe').locator('button')).toHaveText('Hello iframe');
  2512 |     await page.evaluate('2+2');
  2513 |   });
  2514 | 
  2515 |   const frame = await traceViewer.snapshotFrame('Evaluate');
  2516 |   await expect(frame.frameLocator('iframe').getByRole('button')).toHaveText('Hello iframe');
  2517 | });
  2518 | 
  2519 | test('should render snapshots from the second chunk', async ({ context, page, server, showTraceViewer }, testInfo) => {
  2520 |   await context.tracing.start({ screenshots: true, snapshots: true });
  2521 |   await page.goto(server.EMPTY_PAGE);
  2522 |   await page.setContent('<button>Click</button>');
  2523 | 
  2524 |   await context.tracing.startChunk();
  2525 |   await page.click('"Click"');
  2526 |   await context.tracing.stopChunk({ path: testInfo.outputPath('trace1.zip') });
  2527 | 
  2528 |   await context.tracing.startChunk();
  2529 |   await page.hover('"Click"');
  2530 |   await context.tracing.stopChunk({ path: testInfo.outputPath('trace2.zip') });
  2531 | 
  2532 |   // Snapshots in the second chunk must be self-contained and not reference
  2533 |   // snapshot state from the first chunk.
  2534 |   const traceViewer = await showTraceViewer(testInfo.outputPath('trace2.zip'));
  2535 |   const frame = await traceViewer.snapshotFrame('Hover');
  2536 |   await expect(frame.locator('button')).toHaveText('Click');
  2537 | });
  2538 | 
  2539 | test('take trace paths via stdin', async ({ showTraceViewer }) => {
  2540 |   const traceViewer = await showTraceViewer(undefined, { stdin: true });
  2541 |   await expect(traceViewer.page).toHaveTitle('Playwright Trace Viewer');
```