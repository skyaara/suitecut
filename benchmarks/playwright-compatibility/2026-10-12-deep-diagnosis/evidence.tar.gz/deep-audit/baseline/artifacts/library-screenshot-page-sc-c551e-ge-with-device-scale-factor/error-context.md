# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/screenshot.spec.ts >> page screenshot >> should throw if screenshot size is too large with device scale factor
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/screenshot.spec.ts:123:14

# Error details

```
Error: page.screenshot: Protocol error (Page.captureScreenshot): CEF screenshot exceeds the 8,294,400-pixel or 16,384-axis limit
Call log:
  - taking page screenshot
  - waiting for fonts to load...
  - fonts loaded

```

# Test source

```ts
  29  |       const page = await context.newPage();
  30  |       await page.goto(server.PREFIX + '/grid.html');
  31  |       return page;
  32  |     }));
  33  |     const promises = [];
  34  |     for (let i = 0; i < N; ++i)
  35  |       promises.push(pages[i].screenshot({ clip: { x: 50 * (i % 2), y: 0, width: 50, height: 50 } }));
  36  |     const screenshots = await Promise.all(promises);
  37  |     for (let i = 0; i < N; ++i)
  38  |       expect(screenshots[i]).toMatchSnapshot(`grid-cell-${i % 2}.png`);
  39  |     await Promise.all(pages.map(page => page.close()));
  40  |   });
  41  | 
  42  |   browserTest('should work with a mobile viewport', async ({ browser, server, browserName }) => {
  43  |     browserTest.skip(browserName === 'firefox');
  44  | 
  45  |     const context = await browser.newContext({ viewport: { width: 320, height: 480 }, isMobile: true });
  46  |     const page = await context.newPage();
  47  |     await page.goto(server.PREFIX + '/overflow.html');
  48  |     const screenshot = await page.screenshot();
  49  |     expect(screenshot).toMatchSnapshot('screenshot-mobile.png');
  50  |     await context.close();
  51  |   });
  52  | 
  53  |   browserTest('should work with a mobile viewport and clip', async ({ browser, server, browserName }) => {
  54  |     browserTest.skip(browserName === 'firefox');
  55  | 
  56  |     const context = await browser.newContext({ viewport: { width: 320, height: 480 }, isMobile: true });
  57  |     const page = await context.newPage();
  58  |     await page.goto(server.PREFIX + '/overflow.html');
  59  |     const screenshot = await page.screenshot({ clip: { x: 10, y: 10, width: 100, height: 150 } });
  60  |     expect(screenshot).toMatchSnapshot('screenshot-mobile-clip.png');
  61  |     await context.close();
  62  |   });
  63  | 
  64  |   browserTest('should work with a mobile viewport and fullPage', async ({ browser, server, browserName }) => {
  65  |     browserTest.skip(browserName === 'firefox');
  66  | 
  67  |     const context = await browser.newContext({ viewport: { width: 320, height: 480 }, isMobile: true });
  68  |     const page = await context.newPage();
  69  |     await page.goto(server.PREFIX + '/overflow-large.html');
  70  |     const screenshot = await page.screenshot({ fullPage: true });
  71  |     expect(screenshot).toMatchSnapshot('screenshot-mobile-fullpage.png');
  72  |     await context.close();
  73  |   });
  74  | 
  75  |   browserTest('should work with device scale factor', async ({ browser, server, isMac, browserName }) => {
  76  |     const context = await browser.newContext({ viewport: { width: 320, height: 480 }, deviceScaleFactor: 2 });
  77  |     const page = await context.newPage();
  78  |     await page.goto(server.PREFIX + '/grid.html');
  79  |     const screenshot = await page.screenshot();
  80  |     expect(screenshot).toMatchSnapshot('screenshot-device-scale-factor.png');
  81  |     await context.close();
  82  |   });
  83  | 
  84  |   browserTest('should work with device scale factor and clip', async ({ browser, server }) => {
  85  |     const context = await browser.newContext({ viewport: { width: 500, height: 500 }, deviceScaleFactor: 3 });
  86  |     const page = await context.newPage();
  87  |     await page.goto(server.PREFIX + '/grid.html');
  88  |     const screenshot = await page.screenshot({ clip: { x: 50, y: 100, width: 150, height: 100 } });
  89  |     expect(screenshot).toMatchSnapshot('screenshot-device-scale-factor-clip.png');
  90  |     await context.close();
  91  |   });
  92  | 
  93  |   browserTest('should work with device scale factor and scale:css', async ({ browser, server }) => {
  94  |     const context = await browser.newContext({ viewport: { width: 320, height: 480 }, deviceScaleFactor: 2 });
  95  |     const page = await context.newPage();
  96  |     await page.goto(server.PREFIX + '/grid.html');
  97  |     const screenshot = await page.screenshot({ scale: 'css' });
  98  |     expect(screenshot).toMatchSnapshot('screenshot-device-scale-factor-css-size.png');
  99  |     await context.close();
  100 |   });
  101 | 
  102 |   browserTest('should produce screenshot of correct size with scale:css and null viewport', async ({ browser, server }) => {
  103 |     const context = await browser.newContext({ viewport: null });
  104 |     const page = await context.newPage();
  105 |     await page.goto(server.PREFIX + '/grid.html');
  106 |     const [innerWidth, innerHeight] = await page.evaluate(() => [window.innerWidth, window.innerHeight]);
  107 |     const screenshot = await page.screenshot({ scale: 'css' });
  108 |     const decoded = PNG.sync.read(screenshot);
  109 |     expect(decoded.width).toBe(innerWidth);
  110 |     expect(decoded.height).toBe(innerHeight);
  111 |     await context.close();
  112 |   });
  113 | 
  114 |   browserTest('should work with device scale factor, clip and scale:css', async ({ browser, server }) => {
  115 |     const context = await browser.newContext({ viewport: { width: 500, height: 500 }, deviceScaleFactor: 3 });
  116 |     const page = await context.newPage();
  117 |     await page.goto(server.PREFIX + '/grid.html');
  118 |     const screenshot = await page.screenshot({ clip: { x: 50, y: 100, width: 150, height: 100 }, scale: 'css' });
  119 |     expect(screenshot).toMatchSnapshot('screenshot-device-scale-factor-clip-css-size.png');
  120 |     await context.close();
  121 |   });
  122 | 
  123 |   browserTest('should throw if screenshot size is too large with device scale factor', async ({ browser, browserName, isMac, isBidi }) => {
  124 |     browserTest.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/16727' });
  125 |     const context = await browser.newContext({ viewport: { width: 500, height: 500 }, deviceScaleFactor: 2 });
  126 |     const page = await context.newPage();
  127 |     {
  128 |       await page.setContent(`<style>body {margin: 0; padding: 0;}</style><div style='min-height: 16383px; background: red;'></div>`);
> 129 |       const result = await page.screenshot({ fullPage: true });
      |                                 ^ Error: page.screenshot: Protocol error (Page.captureScreenshot): CEF screenshot exceeds the 8,294,400-pixel or 16,384-axis limit
  130 |       expect(result).toBeTruthy();
  131 |     }
  132 |     {
  133 |       await page.setContent(`<style>body {margin: 0; padding: 0;}</style><div style='min-height: 16384px; background: red;'></div>`);
  134 |       const exception = await page.screenshot({ fullPage: true }).catch(e => e);
  135 |       if ((browserName === 'firefox' && !isBidi) || (browserName === 'webkit' && !isMac))
  136 |         expect(exception.message).toContain('Cannot take screenshot larger than 32767');
  137 | 
  138 |       const image = await page.screenshot({ fullPage: true, scale: 'css' });
  139 |       expect(image).toBeTruthy();
  140 |     }
  141 |     await context.close();
  142 |   });
  143 | 
  144 |   browserTest('should work with large size', {
  145 |     annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/4038' },
  146 |   }, async ({ browserName, headless, platform, contextFactory, channel }) => {
  147 |     browserTest.fixme(browserName === 'chromium' && !headless && platform === 'linux', 'Chromium has gpu problems on linux with large screenshots');
  148 |     browserTest.slow(true, 'Large screenshot is slow');
  149 | 
  150 |     const context = await contextFactory();
  151 |     const page = await context.newPage();
  152 | 
  153 |     await page.setViewportSize({ width: 1280, height: 800 });
  154 |     await page.evaluate(() => {
  155 |       document.body.style.margin = '0';
  156 |       document.body.style.padding = '0';
  157 |       document.documentElement.style.margin = '0';
  158 |       document.documentElement.style.padding = '0';
  159 |       const div = document.createElement('div');
  160 |       div.style.width = '1250px';
  161 |       div.style.height = '8440px';
  162 |       div.style.background = 'linear-gradient(red, blue)';
  163 |       document.body.appendChild(div);
  164 |     });
  165 |     const buffer = await page.screenshot({ fullPage: true });
  166 |     const decoded = PNG.sync.read(buffer);
  167 | 
  168 |     const pixel = (x: number, y: number) => {
  169 |       const dst = new PNG({ width: 1, height: 1 });
  170 |       PNG.bitblt(decoded, dst, x, y, 1, 1);
  171 |       const pixels = dst.data;
  172 |       return { r: pixels[0], g: pixels[1], b: pixels[2], a: pixels[3] };
  173 |     };
  174 | 
  175 |     expect(pixel(0, 0).r).toBeGreaterThan(128);
  176 |     expect(pixel(0, 0).b).toBeLessThan(128);
  177 |     expect(pixel(0, 8339).r).toBeLessThan(128);
  178 |     expect(pixel(0, 8339).b).toBeGreaterThan(128);
  179 |   });
  180 | 
  181 |   browserTest('should handle vh units ', async ({ contextFactory }) => {
  182 |     const context = await contextFactory();
  183 |     const page = await context.newPage();
  184 | 
  185 |     await page.setViewportSize({ width: 800, height: 500 });
  186 |     await page.evaluate(() => {
  187 |       document.body.style.margin = '0';
  188 |       document.body.style.padding = '0';
  189 |       document.documentElement.style.margin = '0';
  190 |       document.documentElement.style.padding = '0';
  191 |       const div = document.createElement('div');
  192 |       div.style.width = '100%';
  193 |       div.style.borderTop = '100vh solid red';
  194 |       div.style.borderBottom = '100vh solid blue';
  195 |       document.body.appendChild(div);
  196 |     });
  197 |     const buffer = await page.screenshot({ fullPage: true });
  198 |     const decoded = PNG.sync.read(buffer);
  199 | 
  200 |     const pixel = (x: number, y: number) => {
  201 |       const dst = new PNG({ width: 1, height: 1 });
  202 |       PNG.bitblt(decoded, dst, x, y, 1, 1);
  203 |       const pixels = dst.data;
  204 |       return { r: pixels[0], g: pixels[1], b: pixels[2], a: pixels[3] };
  205 |     };
  206 | 
  207 |     expect(pixel(0, 0).r).toBeGreaterThan(128);
  208 |     expect(pixel(0, 0).b).toBeLessThan(128);
  209 |     expect(pixel(0, 999).r).toBeLessThan(128);
  210 |     expect(pixel(0, 999).b).toBeGreaterThan(128);
  211 |   });
  212 | 
  213 |   browserTest('should not hang when event loop is blocked', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36702' } }, async ({ page, trace, mode }) => {
  214 |     browserTest.skip(trace === 'on', 'taking a snapshot hangs when the page is blocked');
  215 |     browserTest.skip(mode === 'driver', 'test hooks are not available in driver mode');
  216 |     browserTest.setTimeout(5000);
  217 |     const __testHookBeforeScreenshot = async () => {
  218 |       page.evaluate(() => {
  219 |         console.log('blocked');
  220 |         while (true) {}
  221 |       }).catch(() => {});
  222 |       await page.waitForEvent('console', e => e.text() === 'blocked');
  223 |     };
  224 |     await expect(page.screenshot({ fullPage: true, timeout: 200, __testHookBeforeScreenshot } as any)).rejects.toThrow(/page.screenshot: Timeout 200ms exceeded/);
  225 |   });
  226 | });
  227 | 
  228 | browserTest.describe('element screenshot', () => {
  229 |   browserTest.skip(({ browserName, headless }) => browserName === 'firefox' && !headless);
```