# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/expect-boolean.spec.ts >> toBeVisible >> with frameLocator 2
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/expect-boolean.spec.ts:391:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('iframe').contentFrame().locator('input')
Expected: visible
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('iframe').contentFrame().locator('input')
  - Target page, context or browser has been closed

```

```yaml
- iframe
```

# Test source

```ts
  295 |   await page.setContent('<input type=checkbox hidden="of course"></input>');
  296 |   const locator = page.locator('input');
  297 |   await expect(locator).toBeHidden();
  298 | });
  299 | 
  300 | test('not.toBeDisabled div', async ({ page }) => {
  301 |   await page.setContent('<div disabled="yes"></div>');
  302 |   const locator = page.locator('div');
  303 |   await expect(locator).not.toBeDisabled();
  304 | });
  305 | 
  306 | test.describe('toBeVisible', () => {
  307 |   test('default', async ({ page }) => {
  308 |     await page.setContent('<input></input>');
  309 |     const locator = page.locator('input');
  310 |     await expect(locator).toBeVisible();
  311 |   });
  312 | 
  313 |   test('with not', async ({ page }) => {
  314 |     await page.setContent('<button style="display: none">hello</button>');
  315 |     const locator = page.locator('button');
  316 |     await expect(locator).not.toBeVisible();
  317 |   });
  318 | 
  319 |   test('with visible:true', async ({ page }) => {
  320 |     await page.setContent('<button>hello</button>');
  321 |     const locator = page.locator('button');
  322 |     await expect(locator).toBeVisible({ visible: true });
  323 |   });
  324 | 
  325 |   test('with visible:false', async ({ page }) => {
  326 |     await page.setContent('<button hidden>hello</button>');
  327 |     const locator = page.locator('button');
  328 |     await expect(locator).toBeVisible({ visible: false });
  329 |   });
  330 | 
  331 |   test('with not and visible:false', async ({ page }) => {
  332 |     await page.setContent('<button>hello</button>');
  333 |     const locator = page.locator('button');
  334 |     await expect(locator).not.toBeVisible({ visible: false });
  335 |   });
  336 | 
  337 |   test('eventually', async ({ page }) => {
  338 |     await page.setContent('<div></div>');
  339 |     const locator = page.locator('span');
  340 |     setTimeout(() => {
  341 |       page.$eval('div', div => div.innerHTML = '<span>Hello</span>').catch(() => {});
  342 |     }, 0);
  343 |     await expect(locator).toBeVisible();
  344 |   });
  345 | 
  346 |   test('eventually with not', async ({ page }) => {
  347 |     await page.setContent('<div><span>Hello</span></div>');
  348 |     const locator = page.locator('span');
  349 |     setTimeout(() => {
  350 |       page.$eval('span', span => span.textContent = '').catch(() => {});
  351 |     }, 0);
  352 |     await expect(locator).not.toBeVisible();
  353 |   });
  354 | 
  355 |   test('fail', async ({ page }) => {
  356 |     await page.setContent('<button style="display: none"></button>');
  357 |     const locator = page.locator('button');
  358 |     const error = await expect(locator).toBeVisible({ timeout: 1000 }).catch(e => e);
  359 |     expect(error.message).toContain(`locator resolved to <button></button>`);
  360 |   });
  361 | 
  362 |   test('fail with not', async ({ page }) => {
  363 |     await page.setContent('<input></input>');
  364 |     const locator = page.locator('input');
  365 |     const error = await expect(locator).not.toBeVisible({ timeout: 1000 }).catch(e => e);
  366 |     expect(error.message).toContain(`locator resolved to <input/>`);
  367 |   });
  368 | 
  369 |   test('with impossible timeout', async ({ page }) => {
  370 |     await page.setContent('<div id=node>Text content</div>');
  371 |     await expect(page.locator('#node')).toBeVisible({ timeout: 1 });
  372 |   });
  373 | 
  374 |   test('with impossible timeout .not', async ({ page }) => {
  375 |     await page.setContent('<div id=node>Text content</div>');
  376 |     await expect(page.locator('no-such-thing')).not.toBeVisible({ timeout: 1 });
  377 |   });
  378 | 
  379 |   test('with frameLocator', async ({ page }) => {
  380 |     await page.setContent('<div></div>');
  381 |     const locator = page.frameLocator('iframe').locator('input');
  382 |     let done = false;
  383 |     const promise = expect(locator).toBeVisible().then(() => done = true);
  384 |     await page.waitForTimeout(1000);
  385 |     expect(done).toBe(false);
  386 |     await page.setContent('<iframe srcdoc="<input>"></iframe>');
  387 |     await promise;
  388 |     expect(done).toBe(true);
  389 |   });
  390 | 
  391 |   test('with frameLocator 2', async ({ page }) => {
  392 |     await page.setContent('<iframe></iframe>');
  393 |     const locator = page.frameLocator('iframe').locator('input');
  394 |     let done = false;
> 395 |     const promise = expect(locator).toBeVisible().then(() => done = true);
      |                                     ^ Error: expect(locator).toBeVisible() failed
  396 |     await page.waitForTimeout(1000);
  397 |     expect(done).toBe(false);
  398 |     await page.setContent('<iframe srcdoc="<input>"></iframe>');
  399 |     await promise;
  400 |     expect(done).toBe(true);
  401 |   });
  402 | 
  403 |   test('over navigation', async ({ page, server }) => {
  404 |     await page.goto(server.EMPTY_PAGE);
  405 |     let done = false;
  406 |     const promise = expect(page.locator('input')).toBeVisible().then(() => done = true);
  407 |     await page.waitForTimeout(1000);
  408 |     expect(done).toBe(false);
  409 |     await page.goto(server.PREFIX + '/input/checkbox.html');
  410 |     await promise;
  411 |     expect(done).toBe(true);
  412 |   });
  413 | });
  414 | 
  415 | test.describe('toBeHidden', () => {
  416 |   test('default', async ({ page }) => {
  417 |     await page.setContent('<button style="display: none"></button>');
  418 |     const locator = page.locator('button');
  419 |     await expect(locator).toBeHidden();
  420 |   });
  421 | 
  422 |   test('when nothing matches', async ({ page }) => {
  423 |     await page.setContent('<div></div>');
  424 |     const locator = page.locator('button');
  425 |     await expect(locator).toBeHidden();
  426 |   });
  427 | 
  428 |   test('with not', async ({ page }) => {
  429 |     await page.setContent('<input></input>');
  430 |     const locator = page.locator('input');
  431 |     await expect(locator).not.toBeHidden();
  432 |   });
  433 | 
  434 |   test('eventually with not', async ({ page }) => {
  435 |     await page.setContent('<div></div>');
  436 |     const locator = page.locator('span');
  437 |     setTimeout(() => {
  438 |       page.$eval('div', div => div.innerHTML = '<span>Hello</span>').catch(() => {});
  439 |     }, 0);
  440 |     await expect(locator).not.toBeHidden();
  441 |   });
  442 | 
  443 |   test('eventually', async ({ page }) => {
  444 |     await page.setContent('<div><span>Hello</span></div>');
  445 |     const locator = page.locator('span');
  446 |     setTimeout(() => {
  447 |       page.$eval('span', span => span.textContent = '').catch(() => {});
  448 |     }, 0);
  449 |     await expect(locator).toBeHidden();
  450 |   });
  451 | 
  452 |   test('fail', async ({ page }) => {
  453 |     await page.setContent('<input></input>');
  454 |     const locator = page.locator('input');
  455 |     const error = await expect(locator).toBeHidden({ timeout: 3000 }).catch(e => e);
  456 |     expect(error.message).toContain(`locator resolved to <input/>`);
  457 |   });
  458 | 
  459 |   test('fail with not', async ({ page }) => {
  460 |     await page.setContent('<button style="display: none"></button>');
  461 |     const locator = page.locator('button');
  462 |     const error = await expect(locator).not.toBeHidden({ timeout: 3000 }).catch(e => e);
  463 |     expect(error.message).toContain(`locator resolved to <button></button>`);
  464 |   });
  465 | 
  466 |   test('fail with not when nothing matching', async ({ page }) => {
  467 |     await page.setContent('<div></div>');
  468 |     const locator = page.locator('button');
  469 |     const error = await expect(locator).not.toBeHidden({ timeout: 1000 }).catch(e => e);
  470 |     expect(stripAnsi(error.message)).toContain(`expect(locator).not.toBeHidden() failed
  471 | 
  472 | Locator: locator('button')
  473 | Expected: not hidden
  474 | Timeout: 1000ms
  475 | Error: element(s) not found
  476 | 
  477 | Call log:
  478 |   - Expect "not toBeHidden" with timeout 1000ms
  479 | `);
  480 |   });
  481 | 
  482 |   test('with impossible timeout .not', async ({ page }) => {
  483 |     await page.setContent('<div id=node>Text content</div>');
  484 |     await expect(page.locator('#node')).not.toBeHidden({ timeout: 1 });
  485 |   });
  486 | 
  487 |   test('with impossible timeout', async ({ page }) => {
  488 |     await page.setContent('<div id=node>Text content</div>');
  489 |     await expect(page.locator('no-such-thing')).toBeHidden({ timeout: 1 });
  490 |   });
  491 | });
  492 | 
  493 | test('toBeFocused', async ({ page }) => {
  494 |   await page.setContent('<input></input>');
  495 |   const locator = page.locator('input');
```