# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-set-input-files.spec.ts >> should upload a folder
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-set-input-files.spec.ts:38:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.evaluate: Target page, context or browser has been closed
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - button "Choose File" [ref=e3]
  - button "Submit" [ref=e4]
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2017 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { test, expect } from './pageTest';
  19  | 
  20  | import path from 'path';
  21  | import fs from 'fs';
  22  | import formidable from 'formidable';
  23  | 
  24  | test('should upload the file', async ({ page, server, asset }) => {
  25  |   await page.goto(server.PREFIX + '/input/fileupload.html');
  26  |   const filePath = path.relative(process.cwd(), asset('file-to-upload.txt'));
  27  |   const input = await page.$('input');
  28  |   await input.setInputFiles(filePath);
  29  |   expect(await page.evaluate(e => e.files[0].name, input)).toBe('file-to-upload.txt');
  30  |   expect(await page.evaluate(e => {
  31  |     const reader = new FileReader();
  32  |     const promise = new Promise(fulfill => reader.onload = fulfill);
  33  |     reader.readAsText(e.files[0]);
  34  |     return promise.then(() => reader.result);
  35  |   }, input)).toBe('contents of the file');
  36  | });
  37  | 
  38  | test('should upload a folder', async ({ page, server, isFrozenWebkit, isAndroid }) => {
  39  |   test.skip(isAndroid);
  40  |   test.skip(isFrozenWebkit);
  41  | 
  42  |   await page.goto(server.PREFIX + '/input/folderupload.html');
  43  |   const input = await page.$('input');
  44  |   const dir = path.join(test.info().outputDir, 'file-upload-test');
  45  |   {
  46  |     await fs.promises.mkdir(dir, { recursive: true });
  47  |     await fs.promises.writeFile(path.join(dir, 'file1.txt'), 'file1 content');
  48  |     await fs.promises.writeFile(path.join(dir, 'file2'), 'file2 content');
  49  |     await fs.promises.mkdir(path.join(dir, 'sub-dir'));
  50  |     await fs.promises.writeFile(path.join(dir, 'sub-dir', 'really.txt'), 'sub-dir file content');
  51  |   }
  52  |   await input.setInputFiles(dir);
> 53  |   expect(new Set(await page.evaluate(e => [...e.files].map(f => f.webkitRelativePath), input))).toEqual(new Set([
      |                             ^ Error: page.evaluate: Target page, context or browser has been closed
  54  |     // Note: this did not work before Chrome 127, see https://issues.chromium.org/issues/345393164.
  55  |     'file-upload-test/sub-dir/really.txt',
  56  |     'file-upload-test/file1.txt',
  57  |     'file-upload-test/file2',
  58  |   ]));
  59  |   const webkitRelativePaths = await page.evaluate(e => [...e.files].map(f => f.webkitRelativePath), input);
  60  |   for (let i = 0; i < webkitRelativePaths.length; i++) {
  61  |     const content = await input.evaluate((e, i) => {
  62  |       const reader = new FileReader();
  63  |       const promise = new Promise(fulfill => reader.onload = fulfill);
  64  |       reader.readAsText(e.files[i]);
  65  |       return promise.then(() => reader.result);
  66  |     }, i);
  67  |     expect(content).toEqual(fs.readFileSync(path.join(dir, '..', webkitRelativePaths[i])).toString());
  68  |   }
  69  | });
  70  | 
  71  | test('should upload a folder and throw for multiple directories', async ({ page, server, isAndroid, isFrozenWebkit }) => {
  72  |   test.skip(isAndroid);
  73  |   test.skip(isFrozenWebkit);
  74  | 
  75  |   await page.goto(server.PREFIX + '/input/folderupload.html');
  76  |   const input = await page.$('input');
  77  |   const dir = path.join(test.info().outputDir, 'file-upload-test');
  78  |   {
  79  |     await fs.promises.mkdir(path.join(dir, 'folder1'), { recursive: true });
  80  |     await fs.promises.writeFile(path.join(dir, 'folder1', 'file1.txt'), 'file1 content');
  81  |     await fs.promises.mkdir(path.join(dir, 'folder2'), { recursive: true });
  82  |     await fs.promises.writeFile(path.join(dir, 'folder2', 'file2.txt'), 'file2 content');
  83  |   }
  84  |   await expect(input.setInputFiles([
  85  |     path.join(dir, 'folder1'),
  86  |     path.join(dir, 'folder2'),
  87  |   ])).rejects.toThrow('Multiple directories are not supported');
  88  | });
  89  | 
  90  | test('should throw if a directory and files are passed', async ({ page, server, isAndroid, isFrozenWebkit }) => {
  91  |   test.skip(isAndroid);
  92  |   test.skip(isFrozenWebkit);
  93  | 
  94  |   await page.goto(server.PREFIX + '/input/folderupload.html');
  95  |   const input = await page.$('input');
  96  |   const dir = path.join(test.info().outputDir, 'file-upload-test');
  97  |   {
  98  |     await fs.promises.mkdir(path.join(dir, 'folder1'), { recursive: true });
  99  |     await fs.promises.writeFile(path.join(dir, 'folder1', 'file1.txt'), 'file1 content');
  100 |   }
  101 |   await expect(input.setInputFiles([
  102 |     path.join(dir, 'folder1'),
  103 |     path.join(dir, 'folder1', 'file1.txt'),
  104 |   ])).rejects.toThrow('File paths must be all files or a single directory');
  105 | });
  106 | 
  107 | test('should throw when uploading a folder in a normal file upload input', async ({ page, server, isAndroid, isFrozenWebkit }) => {
  108 |   test.skip(isAndroid);
  109 |   test.skip(isFrozenWebkit);
  110 | 
  111 |   await page.goto(server.PREFIX + '/input/fileupload.html');
  112 |   const input = await page.$('input');
  113 |   const dir = path.join(test.info().outputDir, 'file-upload-test');
  114 |   {
  115 |     await fs.promises.mkdir(path.join(dir), { recursive: true });
  116 |     await fs.promises.writeFile(path.join(dir, 'file1.txt'), 'file1 content');
  117 |   }
  118 |   await expect(input.setInputFiles(dir)).rejects.toThrow('File input does not support directories, pass individual files instead');
  119 | });
  120 | 
  121 | test('should throw when uploading a file in a directory upload input', async ({ page, server, isAndroid, asset, isFrozenWebkit }) => {
  122 |   test.skip(isAndroid);
  123 |   test.skip(isFrozenWebkit);
  124 | 
  125 |   await page.goto(server.PREFIX + '/input/folderupload.html');
  126 |   const input = await page.$('input');
  127 |   await expect(input.setInputFiles(asset('file to upload.txt'))).rejects.toThrow('[webkitdirectory] input requires passing a path to a directory');
  128 | });
  129 | 
  130 | test('should upload a file after popup', async ({ page, server, asset }) => {
  131 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/29923' });
  132 |   await page.goto(server.PREFIX + '/input/fileupload.html');
  133 |   {
  134 |     const [popup] = await Promise.all([
  135 |       page.waitForEvent('popup'),
  136 |       page.evaluate(() => window['__popup'] = window.open('about:blank')),
  137 |     ]);
  138 |     await popup.close();
  139 |   }
  140 |   const filePath = path.relative(process.cwd(), asset('file-to-upload.txt'));
  141 |   const input = await page.$('input');
  142 |   await input.setInputFiles(filePath);
  143 |   expect(await page.evaluate(e => e.files[0].name, input)).toBe('file-to-upload.txt');
  144 | });
  145 | 
  146 | test('should upload large file', async ({ page, server, isAndroid, mode }, testInfo) => {
  147 |   test.skip(isAndroid);
  148 |   test.slow();
  149 | 
  150 |   await page.goto(server.PREFIX + '/input/fileupload.html');
  151 |   const uploadFile = testInfo.outputPath('200MB.zip');
  152 |   const str = 'A'.repeat(4 * 1024);
  153 |   const stream = fs.createWriteStream(uploadFile);
```