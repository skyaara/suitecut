# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/popup.spec.ts >> should respect routes from browser context
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/popup.spec.ts:42:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1   | /**
  2   |  * Copyright (c) Microsoft Corporation.
  3   |  *
  4   |  * Licensed under the Apache License, Version 2.0 (the "License");
  5   |  * you may not use this file except in compliance with the License.
  6   |  * You may obtain a copy of the License at
  7   |  *
  8   |  * http://www.apache.org/licenses/LICENSE-2.0
  9   |  *
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import { browserTest as it, expect } from '../config/browserTest';
  18  | import type { Page } from 'playwright-core';
  19  | 
  20  | it('should inherit user agent from browser context @smoke', async function({ browser, server, isFrozenWebkit }) {
  21  |   it.skip(isFrozenWebkit);
  22  | 
  23  |   const context = await browser.newContext({
  24  |     userAgent: 'hey'
  25  |   });
  26  |   const page = await context.newPage();
  27  |   await page.goto(server.EMPTY_PAGE);
  28  |   await page.setContent('<a target=_blank rel=noopener href="/popup/popup.html">link</a>');
  29  |   const requestPromise = server.waitForRequest('/popup/popup.html');
  30  |   const [popup] = await Promise.all([
  31  |     context.waitForEvent('page'),
  32  |     page.click('a'),
  33  |   ]);
  34  |   await popup.waitForLoadState('domcontentloaded');
  35  |   const userAgent = await popup.evaluate(() => window['initialUserAgent']);
  36  |   const request = await requestPromise;
  37  |   await context.close();
  38  |   expect(userAgent).toBe('hey');
  39  |   expect(request.headers['user-agent']).toBe('hey');
  40  | });
  41  | 
  42  | it('should respect routes from browser context', async function({ browser, server }) {
  43  |   const context = await browser.newContext();
  44  |   const page = await context.newPage();
  45  |   await page.goto(server.EMPTY_PAGE);
  46  |   await page.setContent('<a target=_blank rel=noopener href="empty.html">link</a>');
  47  |   let intercepted = false;
  48  |   await context.route('**/empty.html', route => {
  49  |     void route.continue();
  50  |     intercepted = true;
  51  |   });
  52  |   await Promise.all([
  53  |     context.waitForEvent('page'),
  54  |     page.click('a'),
  55  |   ]);
  56  |   await context.close();
> 57  |   expect(intercepted).toBe(true);
      |                       ^ Error: expect(received).toBe(expected) // Object.is equality
  58  | });
  59  | 
  60  | it('should inherit extra headers from browser context', async function({ browser, server }) {
  61  |   const context = await browser.newContext({
  62  |     extraHTTPHeaders: { 'foo': 'bar' },
  63  |   });
  64  |   const page = await context.newPage();
  65  |   await page.goto(server.EMPTY_PAGE);
  66  |   const requestPromise = server.waitForRequest('/dummy.html');
  67  |   await page.evaluate(url => window['_popup'] = window.open(url), server.PREFIX + '/dummy.html');
  68  |   const request = await requestPromise;
  69  |   await context.close();
  70  |   expect(request.headers['foo']).toBe('bar');
  71  | });
  72  | 
  73  | it('should inherit offline from browser context', async function({ browser, server }) {
  74  |   const context = await browser.newContext();
  75  |   const page = await context.newPage();
  76  |   await page.goto(server.EMPTY_PAGE);
  77  |   await context.setOffline(true);
  78  |   const online = await page.evaluate(url => {
  79  |     const win = window.open(url);
  80  |     return win.navigator.onLine;
  81  |   }, server.PREFIX + '/dummy.html');
  82  |   await context.close();
  83  |   expect(online).toBe(false);
  84  | });
  85  | 
  86  | it('should inherit http credentials from browser context', async function({ browser, server }) {
  87  |   server.setAuth('/title.html', 'user', 'pass');
  88  |   const context = await browser.newContext({
  89  |     httpCredentials: { username: 'user', password: 'pass' }
  90  |   });
  91  |   const page = await context.newPage();
  92  |   await page.goto(server.EMPTY_PAGE);
  93  |   const [popup] = await Promise.all([
  94  |     page.waitForEvent('popup'),
  95  |     page.evaluate(url => window['_popup'] = window.open(url), server.PREFIX + '/title.html'),
  96  |   ]);
  97  |   await popup.waitForLoadState('domcontentloaded');
  98  |   expect(await popup.title()).toBe('Woof-Woof');
  99  |   await context.close();
  100 | });
  101 | 
  102 | it('should inherit touch support from browser context', async function({ browser, server }) {
  103 |   const context = await browser.newContext({
  104 |     viewport: { width: 400, height: 500 },
  105 |     hasTouch: true
  106 |   });
  107 |   const page = await context.newPage();
  108 |   await page.goto(server.EMPTY_PAGE);
  109 |   const hasTouch = await page.evaluate(() => {
  110 |     const win = window.open('');
  111 |     return 'ontouchstart' in win;
  112 |   });
  113 |   await context.close();
  114 |   expect(hasTouch).toBe(true);
  115 | });
  116 | 
  117 | it('should inherit viewport size from browser context', async function({ browser, server }) {
  118 |   const context = await browser.newContext({
  119 |     viewport: { width: 400, height: 500 }
  120 |   });
  121 |   const page = await context.newPage();
  122 |   await page.goto(server.EMPTY_PAGE);
  123 |   const size = await page.evaluate(() => {
  124 |     const win = window.open('about:blank');
  125 |     return { width: win.innerWidth, height: win.innerHeight };
  126 |   });
  127 |   await context.close();
  128 |   expect(size).toEqual({ width: 400, height: 500 });
  129 | });
  130 | 
  131 | it('should use viewport size from window features', async function({ browser, server, browserName }) {
  132 |   const context = await browser.newContext({
  133 |     viewport: { width: 700, height: 700 }
  134 |   });
  135 |   const page = await context.newPage();
  136 |   await page.goto(server.EMPTY_PAGE);
  137 |   const [size, popup] = await Promise.all([
  138 |     page.evaluate(async () => {
  139 |       const win = window.open(window.location.href, 'Title', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=300,top=0,left=0');
  140 |       await new Promise<void>(resolve => {
  141 |         const interval = window.builtins.setInterval(() => {
  142 |           if (win.innerWidth === 600 && win.innerHeight === 300) {
  143 |             window.builtins.clearInterval(interval);
  144 |             resolve();
  145 |           }
  146 |         }, 10);
  147 |       });
  148 |       return { width: win.innerWidth, height: win.innerHeight };
  149 |     }),
  150 |     page.waitForEvent('popup'),
  151 |   ]);
  152 |   await popup.setViewportSize({ width: 500, height: 400 });
  153 |   await popup.waitForLoadState();
  154 |   const resized = await popup.evaluate(() => ({ width: window.innerWidth, height: window.innerHeight }));
  155 |   await context.close();
  156 |   expect(size).toEqual({ width: 600, height: 300 });
  157 |   expect(resized).toEqual({ width: 500, height: 400 });
```