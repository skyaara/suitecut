# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/page-event-crash.spec.ts >> should emit crash event when page crashes
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/page-event-crash.spec.ts:42:1

# Error details

```
Test timeout of 30000ms exceeded.
```