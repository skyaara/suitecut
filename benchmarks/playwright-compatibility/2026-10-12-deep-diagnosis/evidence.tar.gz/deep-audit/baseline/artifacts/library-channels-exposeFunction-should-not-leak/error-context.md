# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/channels.spec.ts >> exposeFunction should not leak
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/channels.spec.ts:252:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  -  0
+ Received  + 26

@@ -28,10 +28,36 @@
                  },
                  Object {
                    "_guid": "page",
                    "objects": Array [
                      Object {
+                       "_guid": "frame",
+                       "objects": Array [],
+                     },
+                   ],
+                 },
+                 Object {
+                   "_guid": "request-context",
+                   "objects": Array [],
+                 },
+                 Object {
+                   "_guid": "tracing",
+                   "objects": Array [],
+                 },
+               ],
+             },
+             Object {
+               "_guid": "browser-context",
+               "objects": Array [
+                 Object {
+                   "_guid": "debugger",
+                   "objects": Array [],
+                 },
+                 Object {
+                   "_guid": "page",
+                   "objects": Array [
+                     Object {
                        "_guid": "disposable",
                        "objects": Array [],
                      },
                      Object {
                        "_guid": "frame",
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2017 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import domain from 'domain';
  19  | import { playwrightTest, expect } from '../config/browserTest';
  20  | 
  21  | // Use something worker-scoped (e.g. expectScopeState) forces a new worker for this file.
  22  | // Otherwise, a browser launched for other tests in this worker will affect the expectations.
  23  | const it = playwrightTest.extend<{}, { expectScopeState: (object: any, golden: any) => void }>({
  24  |   expectScopeState: [async ({ toImplInWorkerScope }, use) => {
  25  |     await use((object, golden) => {
  26  |       golden = trimGuids(golden);
  27  |       const remoteRoot = toImplInWorkerScope();
  28  |       const remoteState = trimGuids(remoteRoot._debugScopeState());
  29  |       const localRoot = object._connection._rootObject;
  30  |       const localState = trimGuids(localRoot._debugScopeState());
> 31  |       expect(localState).toEqual(golden);
      |                          ^ Error: expect(received).toEqual(expected) // deep equality
  32  |       expect(remoteState).toEqual(golden);
  33  |     });
  34  |   }, { scope: 'worker' }],
  35  | });
  36  | 
  37  | it.skip(({ mode }) => mode !== 'default');
  38  | it.skip(({ video }) => video === 'on', 'Extra video artifacts in the objects list');
  39  | 
  40  | it('should scope context handles', async ({ browserType, server, expectScopeState }) => {
  41  |   const browser = await browserType.launch();
  42  |   const GOLDEN_PRECONDITION = {
  43  |     _guid: '',
  44  |     objects: [
  45  |       { _guid: 'android', objects: [] },
  46  |       { _guid: 'browser-type', objects: [] },
  47  |       { _guid: 'browser-type', objects: [] },
  48  |       { _guid: 'browser-type', objects: [
  49  |         { _guid: 'browser', objects: [] }
  50  |       ] },
  51  |       { _guid: 'electron', objects: [] },
  52  |       { _guid: 'localUtils', objects: [] },
  53  |       { _guid: 'Playwright', objects: [] },
  54  |     ]
  55  |   };
  56  |   expectScopeState(browser, GOLDEN_PRECONDITION);
  57  | 
  58  |   const context = await browser.newContext();
  59  |   const page = await context.newPage();
  60  |   // Firefox Beta 96 yields a console warning for the pages that
  61  |   // don't use `<!DOCTYPE HTML> tag.
  62  |   await page.goto(server.PREFIX + '/empty-standard-mode.html');
  63  |   expectScopeState(browser, {
  64  |     _guid: '',
  65  |     objects: [
  66  |       { _guid: 'android', objects: [] },
  67  |       { _guid: 'browser-type', objects: [] },
  68  |       { _guid: 'browser-type', objects: [] },
  69  |       { _guid: 'browser-type', objects: [
  70  |         { _guid: 'browser', objects: [
  71  |           { _guid: 'browser-context', objects: [
  72  |             { _guid: 'page', objects: [
  73  |               { _guid: 'frame', objects: [] },
  74  |               { _guid: 'request', objects: [
  75  |                 { _guid: 'response', objects: [] },
  76  |               ] },
  77  |             ] },
  78  |             { _guid: 'debugger', objects: [] },
  79  |             { _guid: 'request-context', objects: [] },
  80  |             { _guid: 'tracing', objects: [] }
  81  |           ] },
  82  |         ] },
  83  |       ] },
  84  |       { _guid: 'electron', objects: [] },
  85  |       { _guid: 'localUtils', objects: [] },
  86  |       { _guid: 'Playwright', objects: [] },
  87  |     ]
  88  |   });
  89  | 
  90  |   await context.close();
  91  |   expectScopeState(browser, GOLDEN_PRECONDITION);
  92  |   await browser.close();
  93  | });
  94  | 
  95  | it('should scope CDPSession handles', async ({ browserType, browserName, expectScopeState }) => {
  96  |   it.skip(browserName !== 'chromium');
  97  | 
  98  |   const browser = await browserType.launch();
  99  |   const GOLDEN_PRECONDITION = {
  100 |     _guid: '',
  101 |     objects: [
  102 |       { _guid: 'android', objects: [] },
  103 |       { _guid: 'browser-type', objects: [] },
  104 |       { _guid: 'browser-type', objects: [] },
  105 |       { _guid: 'browser-type', objects: [
  106 |         { _guid: 'browser', objects: [] }
  107 |       ] },
  108 |       { _guid: 'electron', objects: [] },
  109 |       { _guid: 'localUtils', objects: [] },
  110 |       { _guid: 'Playwright', objects: [] },
  111 |     ]
  112 |   };
  113 |   expectScopeState(browserType, GOLDEN_PRECONDITION);
  114 | 
  115 |   const session = await browser.newBrowserCDPSession();
  116 |   expectScopeState(browserType, {
  117 |     _guid: '',
  118 |     objects: [
  119 |       { _guid: 'android', objects: [] },
  120 |       { _guid: 'browser-type', objects: [] },
  121 |       { _guid: 'browser-type', objects: [] },
  122 |       { _guid: 'browser-type', objects: [
  123 |         { _guid: 'browser', objects: [
  124 |           { _guid: 'cdp-session', objects: [] },
  125 |         ] },
  126 |       ] },
  127 |       { _guid: 'electron', objects: [] },
  128 |       { _guid: 'localUtils', objects: [] },
  129 |       { _guid: 'Playwright', objects: [] },
  130 |     ]
  131 |   });
```