# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/capabilities.spec.ts >> should support webgl @smoke
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/capabilities.spec.ts:105:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import url from 'url';
  18  | import { contextTest as it, expect } from '../config/browserTest';
  19  | 
  20  | it('SharedArrayBuffer should work @smoke', async function({ contextFactory, httpsServer }) {
  21  |   const context = await contextFactory({ ignoreHTTPSErrors: true });
  22  |   const page = await context.newPage();
  23  |   httpsServer.setRoute('/sharedarraybuffer', (req, res) => {
  24  |     res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  25  |     res.setHeader('Cross-Origin-Embedder-Policy', 'require-corp');
  26  |     // Note: without 'onload', Firefox sometimes does not fire the load event
  27  |     // over the protocol. The reason is unclear.
  28  |     res.end(`
  29  |       <div>Hello there!</div>
  30  |       <script>window.onload = () => console.log('onload')</script>
  31  |     `);
  32  |   });
  33  |   await page.goto(httpsServer.PREFIX + '/sharedarraybuffer');
  34  |   expect(await page.evaluate(() => typeof SharedArrayBuffer)).toBe('function');
  35  | });
  36  | 
  37  | it('Web Assembly should work @smoke', async ({ page, server }) => {
  38  |   await page.goto(server.PREFIX + '/wasm/table2.html');
  39  |   expect(await page.evaluate('loadTable()')).toBe('42, 83');
  40  | });
  41  | 
  42  | it('WebSocket should work @smoke', async ({ page, server }) => {
  43  |   server.sendOnWebSocketConnection('incoming');
  44  |   const value = await page.evaluate(host => {
  45  |     let cb;
  46  |     const result = new Promise(f => cb = f);
  47  |     const ws = new WebSocket('ws://' + host + '/ws');
  48  |     ws.addEventListener('message', data => { ws.close(); cb(data.data); });
  49  |     ws.addEventListener('error', error => cb('Error'));
  50  |     return result;
  51  |   }, server.HOST);
  52  |   expect(value).toBe('incoming');
  53  | });
  54  | 
  55  | it('should respect CSP @smoke', async ({ page, server }) => {
  56  |   server.setRoute('/empty.html', async (req, res) => {
  57  |     res.setHeader('Content-Security-Policy', `script-src 'unsafe-inline';`);
  58  |     res.end(`
  59  |       <script>
  60  |         window.testStatus = 'SUCCESS';
  61  |         window.testStatus = eval("'FAILED'");
  62  |       </script>`);
  63  |   });
  64  | 
  65  |   await page.goto(server.EMPTY_PAGE);
  66  |   expect(await page.evaluate(() => window['testStatus'])).toBe('SUCCESS');
  67  | });
  68  | 
  69  | it('should play video @smoke', async ({ page, asset, browserName, isWindows, isLinux, mode }) => {
  70  |   it.skip(browserName === 'webkit' && isWindows, 'passes locally but fails on GitHub Action bot, apparently due to a Media Pack issue in the Windows Server');
  71  | 
  72  |   // Safari only plays mp4 so we test WebKit with an .mp4 clip.
  73  |   const fileName = browserName === 'webkit' ? 'video_mp4.html' : 'video.html';
  74  |   const absolutePath = asset(fileName);
  75  |   // Our test server doesn't support range requests required to play on Mac,
  76  |   // so we load the page using a file url.
  77  |   await page.goto(url.pathToFileURL(absolutePath).href);
  78  |   await page.$eval('video', v => v.play());
  79  |   await page.$eval('video', v => v.pause());
  80  | });
  81  | 
  82  | it('should play webm video @smoke', async ({ page, asset, browserName, platform, macVersion, mode }) => {
  83  |   it.skip(browserName === 'webkit' && platform === 'win32', 'not supported');
  84  | 
  85  |   const absolutePath = asset('video_webm.html');
  86  |   // Our test server doesn't support range requests required to play on Mac,
  87  |   // so we load the page using a file url.
  88  |   await page.goto(url.pathToFileURL(absolutePath).href);
  89  |   await page.$eval('video', v => v.play());
  90  |   await page.$eval('video', v => v.pause());
  91  | });
  92  | 
  93  | it('should play audio @smoke', async ({ page, server, browserName, platform, macVersion }) => {
  94  |   it.fixme(browserName === 'webkit' && platform === 'win32', 'https://github.com/microsoft/playwright/issues/10892');
  95  |   it.skip(browserName === 'webkit' && platform === 'darwin' && macVersion === 15, 'audio output is unreliable on hosted macOS 15 runners');
  96  | 
  97  |   await page.goto(server.EMPTY_PAGE);
  98  |   await page.setContent(`<audio src="${server.PREFIX}/example.mp3"></audio>`);
  99  |   await page.$eval('audio', e => e.play());
  100 |   await page.waitForTimeout(3000);
  101 |   await page.$eval('audio', e => e.pause());
  102 |   expect(await page.$eval('audio', e => e.currentTime)).toBeGreaterThan(0.1);
  103 | });
  104 | 
  105 | it('should support webgl @smoke', async ({ page }) => {
  106 |   const hasWebGL = await page.evaluate(() => {
  107 |     const canvas = document.createElement('canvas');
  108 |     return !!canvas.getContext('webgl');
  109 |   });
> 110 |   expect(hasWebGL).toBe(true);
      |                    ^ Error: expect(received).toBe(expected) // Object.is equality
  111 | });
  112 | 
  113 | it('should support webgl 2 @smoke', async ({ page, browserName, isWindows }) => {
  114 |   it.fixme(browserName === 'firefox' && isWindows);
  115 | 
  116 |   const hasWebGL2 = await page.evaluate(() => {
  117 |     const canvas = document.createElement('canvas');
  118 |     return !!canvas.getContext('webgl2');
  119 |   });
  120 |   expect(hasWebGL2).toBe(true);
  121 | });
  122 | 
  123 | it('should not crash on page with mp4 @smoke', async ({ page, server, platform, browserName }) => {
  124 |   it.fixme(browserName === 'webkit' && platform === 'win32', 'https://github.com/microsoft/playwright/issues/11009, times out in setContent');
  125 |   await page.setContent(`<video><source src="${server.PREFIX}/movie.mp4"/></video>`);
  126 |   await page.waitForTimeout(1000);
  127 | });
  128 | 
  129 | it('should not crash on showDirectoryPicker', async ({ page, server, browserName, browserMajorVersion }) => {
  130 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/7339' });
  131 |   it.skip(browserName !== 'chromium', 'showDirectoryPicker is only available in Chromium');
  132 |   await page.goto(server.EMPTY_PAGE);
  133 |   // "User activation is required to show a file picker." - so we click first.
  134 |   await page.locator('body').click();
  135 |   page.evaluate(async () => {
  136 |     const dir = await (window as any).showDirectoryPicker();
  137 |     return dir.name;
  138 |     // In headless it throws (aborted), in headed it stalls (Test ended) and waits for the picker to be accepted.
  139 |   }).catch(e => expect(e.message).toMatch(/((DOMException|AbortError): .*The user aborted a request|Test ended)/));
  140 |   // The dialog will not be accepted, so we just wait for some time to
  141 |   // to give the browser a chance to crash.
  142 |   await page.waitForTimeout(3_000);
  143 | });
  144 | 
  145 | it('should not crash on storage.getDirectory()', async ({ page, server, browserName, isMac }) => {
  146 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/18235' });
  147 |   await page.goto(server.EMPTY_PAGE);
  148 |   const error = await page.evaluate(async () => {
  149 |     const dir = await navigator.storage.getDirectory();
  150 |     return dir.name;
  151 |   }).catch(e => e);
  152 |   if (browserName === 'webkit') {
  153 |     if (isMac)
  154 |       expect(error.message).toContain('UnknownError: The operation failed for an unknown transient reason');
  155 |     else
  156 |       expect(error.message).toContain('TypeError: undefined is not an object');
  157 |   } else {
  158 |     expect(error).toBeFalsy();
  159 |   }
  160 | });
  161 | 
  162 | it('navigator.clipboard should be present', async ({ page, server }) => {
  163 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/18901' });
  164 |   await page.goto(server.EMPTY_PAGE);
  165 |   expect(await page.evaluate(() => navigator.clipboard)).toBeTruthy();
  166 | });
  167 | 
  168 | it('should set CloseEvent.wasClean to false when the server terminates a WebSocket connection', async ({ page, server }) => {
  169 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/12353' });
  170 |   server.onceWebSocketConnection(socket => {
  171 |     socket.terminate();
  172 |   });
  173 |   const wasClean = await page.evaluate(port => new Promise<boolean>(resolve => {
  174 |     const ws = new WebSocket('ws://localhost:' + port + '/ws');
  175 |     ws.addEventListener('close', error => resolve(error.wasClean));
  176 |   }), server.PORT);
  177 |   expect(wasClean).toBe(false);
  178 | });
  179 | 
  180 | it('serviceWorker should intercept document request', async ({ page, server }) => {
  181 |   server.setRoute('/sw.js', (req, res) => {
  182 |     res.setHeader('Content-Type', 'application/javascript');
  183 |     res.end(`
  184 |       self.addEventListener('fetch', event => {
  185 |         event.respondWith(new Response('intercepted'));
  186 |       });
  187 |       self.addEventListener('activate', event => {
  188 |         event.waitUntil(clients.claim());
  189 |       });
  190 |     `);
  191 |   });
  192 |   await page.goto(server.EMPTY_PAGE);
  193 |   await page.evaluate(async () => {
  194 |     await navigator.serviceWorker.register('/sw.js');
  195 |     await new Promise(resolve => navigator.serviceWorker.oncontrollerchange = resolve);
  196 |   });
  197 |   await page.reload();
  198 |   expect(await page.textContent('body')).toBe('intercepted');
  199 | });
  200 | 
  201 | it('webkit should define window.safari', async ({ page, server, browserName }) => {
  202 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/21037' });
  203 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/29032' });
  204 |   it.skip(browserName !== 'webkit');
  205 |   await page.goto(server.EMPTY_PAGE);
  206 |   const defined = await page.evaluate(() => !!(window as any).safari);
  207 |   expect(defined).toBeTruthy();
  208 |   expect(await page.evaluate(() => typeof (window as any).safari.pushNotification)).toBe('object');
  209 |   expect(await page.evaluate(() => (window as any).safari.pushNotification.toString())).toBe('[object SafariRemoteNotification]');
  210 | });
```