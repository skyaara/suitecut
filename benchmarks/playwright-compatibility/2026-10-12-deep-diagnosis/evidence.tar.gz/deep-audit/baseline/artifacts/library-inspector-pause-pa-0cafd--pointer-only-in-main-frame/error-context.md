# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/inspector/pause.spec.ts >> pause >> should highlight pointer, only in main frame
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/inspector/pause.spec.ts:207:5

# Error details

```
Error: page.setContent: Target page, context or browser has been closed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  108 |       await page.goto(server.EMPTY_PAGE);
  109 |       // @ts-ignore
  110 |       await page.pause({ __testHookKeepTestTimeout: true });
  111 |     })();
  112 |     const recorderPage = await recorderPageGetter();
  113 |     await recorderPage.click('[title="Resume (F8)"]');
  114 |     await scriptPromise;
  115 |   });
  116 | 
  117 |   it('should show source', async ({ page, recorderPageGetter }) => {
  118 |     const scriptPromise = (async () => {
  119 |       // @ts-ignore
  120 |       await page.pause({ __testHookKeepTestTimeout: true });
  121 |       await pauseHelper(page);
  122 |     })();
  123 |     const recorderPage = await recorderPageGetter();
  124 |     await expect(recorderPage.getByRole('combobox', { name: 'Source chooser' })).toHaveValue(/pause\.spec\.ts/);
  125 |     await expect(recorderPage.locator('.source-line-paused')).toContainText('page.pause({ __testHookKeepTestTimeout: true })');
  126 | 
  127 |     await recorderPage.click('[title="Step over (F10)"]');
  128 |     await expect(recorderPage.getByRole('combobox', { name: 'Source chooser' })).toHaveValue(/pause-helper\.ts/);
  129 |     await expect(recorderPage.locator('.source-line-paused')).toContainText('page.setContent(\'<div>here we go</div>\')');
  130 | 
  131 |     await recorderPage.click('[title="Resume (F8)"]');
  132 |     await scriptPromise;
  133 |   });
  134 | 
  135 |   it('should pause on next pause', async ({ page, recorderPageGetter }) => {
  136 |     const scriptPromise = (async () => {
  137 |       // @ts-ignore
  138 |       await page.pause({ __testHookKeepTestTimeout: true });  // 1
  139 |       // @ts-ignore
  140 |       await page.pause({ __testHookKeepTestTimeout: true });  // 2
  141 |     })();
  142 |     const recorderPage = await recorderPageGetter();
  143 |     const source = await recorderPage.textContent('.source-line-paused');
  144 |     expect(source).toContain('page.pause({ __testHookKeepTestTimeout: true });  // 1');
  145 |     await recorderPage.click('[title="Resume (F8)"]');
  146 |     await recorderPage.waitForSelector('.source-line-paused:has-text("page.pause({ __testHookKeepTestTimeout: true });  // 2")');
  147 |     await recorderPage.click('[title="Resume (F8)"]');
  148 |     await scriptPromise;
  149 |   });
  150 | 
  151 |   it('should step', async ({ page, recorderPageGetter }) => {
  152 |     await page.setContent('<button>Submit</button>');
  153 |     const scriptPromise = (async () => {
  154 |       // @ts-ignore
  155 |       await page.pause({ __testHookKeepTestTimeout: true });
  156 |       await page.click('button');
  157 |     })();
  158 |     const recorderPage = await recorderPageGetter();
  159 |     const source = await recorderPage.textContent('.source-line-paused');
  160 |     expect(source).toContain('page.pause({ __testHookKeepTestTimeout: true });');
  161 | 
  162 |     await recorderPage.click('[title="Step over (F10)"]');
  163 |     await recorderPage.waitForSelector('.source-line-paused :has-text("page.click")');
  164 | 
  165 |     await recorderPage.click('[title="Resume (F8)"]');
  166 |     await scriptPromise;
  167 |   });
  168 | 
  169 |   it('should disable timeout on paused actions', async ({ page, recorderPageGetter }) => {
  170 |     await page.setContent('<button>Submit</button>');
  171 |     const scriptPromise = (async () => {
  172 |       // @ts-ignore
  173 |       await page.pause({ __testHookKeepTestTimeout: true });
  174 |       await page.click('button', { timeout: 1000 });
  175 |     })();
  176 |     const recorderPage = await recorderPageGetter();
  177 |     const source = await recorderPage.textContent('.source-line-paused');
  178 |     expect(source).toContain('page.pause({ __testHookKeepTestTimeout: true });');
  179 | 
  180 |     await recorderPage.click('[title="Step over (F10)"]');
  181 |     await recorderPage.waitForSelector('.source-line-paused :has-text("page.click")');
  182 |     await page.waitForTimeout(5000);
  183 | 
  184 |     await recorderPage.click('[title="Resume (F8)"]');
  185 |     await scriptPromise;
  186 |   });
  187 | 
  188 |   it('should step with keyboard shortcut', async ({ page, recorderPageGetter }) => {
  189 |     await page.setContent('<button>Submit</button>');
  190 |     const scriptPromise = (async () => {
  191 |       // @ts-ignore
  192 |       await page.pause({ __testHookKeepTestTimeout: true });
  193 |       await page.click('button');
  194 |     })();
  195 |     const recorderPage = await recorderPageGetter();
  196 |     const source = await recorderPage.textContent('.source-line-paused');
  197 |     expect(source).toContain('page.pause({ __testHookKeepTestTimeout: true });');
  198 | 
  199 |     await recorderPage.keyboard.press('F10');
  200 |     await recorderPage.waitForSelector('.source-line-paused :has-text("page.click")');
  201 |     await recorderPage.isEnabled('[title="Resume (F8)"]');
  202 | 
  203 |     await recorderPage.keyboard.press('F8');
  204 |     await scriptPromise;
  205 |   });
  206 | 
  207 |   it('should highlight pointer, only in main frame', async ({ page, recorderPageGetter }) => {
> 208 |     await page.setContent(`
      |                ^ Error: page.setContent: Target page, context or browser has been closed
  209 |       <iframe
  210 |         style="margin: 100px;"
  211 |         srcdoc="<button style='margin: 80px;'>Submit</button>">
  212 |       </iframe>
  213 |     `);
  214 |     const scriptPromise = (async () => {
  215 |       // @ts-ignore
  216 |       await page.pause({ __testHookKeepTestTimeout: true });
  217 |       await page.frameLocator('iframe').locator('button').click();
  218 |     })();
  219 |     const recorderPage = await recorderPageGetter();
  220 |     await recorderPage.click('[title="Step over (F10)"]');
  221 | 
  222 |     const { box1, box2 } = await (page as any)._wrapApiCall(async () => {
  223 |       const iframe = page.frames()[1];
  224 |       const button = await iframe.waitForSelector('button');
  225 |       const box1 = await button.boundingBox();
  226 | 
  227 |       const actionPoint = await page.waitForSelector('x-pw-action-point');
  228 |       const box2 = await actionPoint.boundingBox();
  229 | 
  230 |       const iframeActionPoint = await iframe.$('x-pw-action-point');
  231 |       expect(await iframeActionPoint?.isVisible()).toBeFalsy();
  232 | 
  233 |       return { box1, box2 };
  234 |     }, { internal: true });
  235 | 
  236 |     await recorderPage.click('[title="Resume (F8)"]');
  237 | 
  238 |     const x1 = box1!.x + box1!.width / 2;
  239 |     const y1 = box1!.y + box1!.height / 2;
  240 |     const x2 = box2!.x + box2!.width / 2;
  241 |     const y2 = box2!.y + box2!.height / 2;
  242 | 
  243 |     expect(Math.abs(x1 - x2) < 2).toBeTruthy();
  244 |     expect(Math.abs(y1 - y2) < 2).toBeTruthy();
  245 | 
  246 |     await scriptPromise;
  247 |   });
  248 | 
  249 |   it('should skip input when resuming', async ({ page, recorderPageGetter }) => {
  250 |     await page.setContent('<button>Submit</button>');
  251 |     const scriptPromise = (async () => {
  252 |       // @ts-ignore
  253 |       await page.pause({ __testHookKeepTestTimeout: true });
  254 |       await page.click('button');
  255 |       // @ts-ignore
  256 |       await page.pause({ __testHookKeepTestTimeout: true });  // 2
  257 |     })();
  258 |     const recorderPage = await recorderPageGetter();
  259 |     await recorderPage.click('[title="Resume (F8)"]');
  260 |     await recorderPage.waitForSelector('.source-line-paused:has-text("page.pause({ __testHookKeepTestTimeout: true });  // 2")');
  261 |     await recorderPage.click('[title="Resume (F8)"]');
  262 |     await scriptPromise;
  263 |   });
  264 | 
  265 |   it('should populate log', async ({ page, recorderPageGetter }) => {
  266 |     await page.setContent('<button>Submit</button>');
  267 |     const scriptPromise = (async () => {
  268 |       // @ts-ignore
  269 |       await page.pause({ __testHookKeepTestTimeout: true });
  270 |       await page.click('button');
  271 |       // @ts-ignore
  272 |       await page.pause({ __testHookKeepTestTimeout: true });  // 2
  273 |     })();
  274 |     const recorderPage = await recorderPageGetter();
  275 |     await recorderPage.click('[title="Resume (F8)"]');
  276 |     await recorderPage.waitForSelector('.source-line-paused:has-text("page.pause({ __testHookKeepTestTimeout: true });  // 2")');
  277 |     expect(await sanitizeLog(recorderPage)).toEqual([
  278 |       'Pause- XXms',
  279 |       'Click(page.locator(\'button\'))- XXms',
  280 |       'Pause',
  281 |     ]);
  282 |     await recorderPage.click('[title="Resume (F8)"]');
  283 |     await scriptPromise;
  284 |   });
  285 | 
  286 |   it('should hide internal calls', async ({ page, recorderPageGetter, trace }) => {
  287 |     it.skip(trace === 'on');
  288 | 
  289 |     const scriptPromise = (async () => {
  290 |       // @ts-ignore
  291 |       await page.pause({ __testHookKeepTestTimeout: true });
  292 |       await page.context().tracing.start();
  293 |       page.setDefaultTimeout(0);
  294 |       page.context().setDefaultNavigationTimeout(0);
  295 |       await page.context().tracing.stop();
  296 |       // @ts-ignore
  297 |       await page.pause({ __testHookKeepTestTimeout: true });  // 2
  298 |     })();
  299 |     const recorderPage = await recorderPageGetter();
  300 |     await recorderPage.click('[title="Resume (F8)"]');
  301 |     await recorderPage.waitForSelector('.source-line-paused:has-text("page.pause({ __testHookKeepTestTimeout: true });  // 2")');
  302 |     expect(await sanitizeLog(recorderPage)).toEqual([
  303 |       'Pause- XXms',
  304 |       'Start tracing- XXms',
  305 |       'Stop tracing- XXms',
  306 |       'Pause',
  307 |     ]);
  308 |     await recorderPage.click('[title="Resume (F8)"]');
```