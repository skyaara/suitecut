# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/inspector/cli-codegen-2.spec.ts >> cli codegen >> should record open in a new tab with url
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/inspector/cli-codegen-2.spec.ts:339:7

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "page1"
Received string:    "const { chromium } = require('playwright');·
(async () => {
  const browser = await chromium.launch({
    headless: false
  });
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto('about:blank');
  await page.getByRole('link', { name: 'link' }).click({
    modifiers: ['ControlOrMeta']
  });·
  // ---------------------
  await context.close();
  await browser.close();
})();"

Call Log:
- Test timeout of 30000ms exceeded
```

# Test source

```ts
  247 | 
  248 |     expect.soft(sources.get('JavaScript')!.text).toContain(`
  249 |   const downloadPromise = page.waitForEvent('download');
  250 |   await page.getByRole('link', { name: 'Download' }).click();
  251 |   const download = await downloadPromise;`);
  252 | 
  253 |     expect.soft(sources.get('Java')!.text).toContain(`
  254 |       Download download = page.waitForDownload(() -> {
  255 |         page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Download")).click();
  256 |       });`);
  257 | 
  258 |     expect.soft(sources.get('Python')!.text).toContain(`
  259 |     with page.expect_download() as download_info:
  260 |         page.get_by_role("link", name="Download").click()
  261 |     download = download_info.value`);
  262 | 
  263 |     expect.soft(sources.get('Python Async')!.text).toContain(`
  264 |     async with page.expect_download() as download_info:
  265 |         await page.get_by_role("link", name="Download").click()
  266 |     download = await download_info.value`);
  267 | 
  268 |     expect.soft(sources.get('C#')!.text).toContain(`
  269 | var download = await page.RunAndWaitForDownloadAsync(async () =>
  270 | {
  271 |     await page.GetByRole(AriaRole.Link, new() { Name = "Download" }).ClickAsync();
  272 | });`);
  273 |   });
  274 | 
  275 |   test('should handle dialogs', async ({ openRecorder }) => {
  276 |     const { page, recorder } = await openRecorder();
  277 | 
  278 |     await recorder.setContentAndWait(`
  279 |     <button onclick="alert()">click me</button>
  280 |     `);
  281 |     await recorder.hoverOverElement('button');
  282 |     page.once('dialog', async dialog => {
  283 |       await dialog.dismiss();
  284 |     });
  285 |     await page.click('button');
  286 | 
  287 |     const sources = await recorder.waitForOutput('JavaScript', 'once');
  288 | 
  289 |     expect.soft(sources.get('JavaScript')!.text).toContain(`
  290 |   page.once('dialog', dialog => {
  291 |     console.log(\`Dialog message: \${dialog.message()}\`);
  292 |     dialog.dismiss().catch(() => {});
  293 |   });
  294 |   await page.getByRole('button', { name: 'click me' }).click();`);
  295 | 
  296 |     expect.soft(sources.get('Java')!.text).toContain(`
  297 |       page.onceDialog(dialog -> {
  298 |         System.out.println(String.format("Dialog message: %s", dialog.message()));
  299 |         dialog.dismiss();
  300 |       });
  301 |       page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("click me")).click();`);
  302 | 
  303 |     expect.soft(sources.get('Python')!.text).toContain(`
  304 |     page.once(\"dialog\", lambda dialog: dialog.dismiss())
  305 |     page.get_by_role("button", name="click me").click()`);
  306 | 
  307 |     expect.soft(sources.get('Python Async')!.text).toContain(`
  308 |     page.once(\"dialog\", lambda dialog: dialog.dismiss())
  309 |     await page.get_by_role("button", name="click me").click()`);
  310 | 
  311 |     expect.soft(sources.get('C#')!.text).toContain(`
  312 | void page_Dialog_EventHandler(object sender, IDialog dialog)
  313 | {
  314 |     Console.WriteLine($\"Dialog message: {dialog.Message}\");
  315 |     dialog.DismissAsync();
  316 |     page.Dialog -= page_Dialog_EventHandler;
  317 | }
  318 | page.Dialog += page_Dialog_EventHandler;
  319 | await page.GetByRole(AriaRole.Button, new() { Name = "click me" }).ClickAsync();`);
  320 | 
  321 |   });
  322 | 
  323 |   test('should handle history.postData', async ({ openRecorder, server }) => {
  324 |     const { page, recorder } = await openRecorder();
  325 | 
  326 |     await recorder.setContentAndWait(`
  327 |     <script>
  328 |     let seqNum = 0;
  329 |     function pushState() {
  330 |       history.pushState({}, 'title', '${server.PREFIX}/#seqNum=' + (++seqNum));
  331 |     }
  332 |     </script>`, server.PREFIX);
  333 |     for (let i = 1; i < 3; ++i) {
  334 |       await page.evaluate('pushState()');
  335 |       await recorder.waitForOutput('JavaScript', `await page.goto('${server.PREFIX}/#seqNum=${i}');`);
  336 |     }
  337 |   });
  338 | 
  339 |   test('should record open in a new tab with url', async ({ openRecorder, browserName }) => {
  340 |     const { page, recorder } = await openRecorder();
  341 |     await recorder.setContentAndWait(`<a href="about:blank?foo">link</a>`);
  342 | 
  343 |     const locator = await recorder.hoverOverElement('a');
  344 |     expect(locator).toBe(`getByRole('link', { name: 'link' })`);
  345 | 
  346 |     await page.click('a', { modifiers: ['ControlOrMeta'] });
> 347 |     const sources = await recorder.waitForOutput('JavaScript', 'page1');
      |                     ^ Error: expect(received).toContain(expected) // indexOf
  348 | 
  349 |     if (browserName !== 'firefox') {
  350 |       expect(sources.get('JavaScript')!.text).toContain(`
  351 |   const page1 = await context.newPage();
  352 |   await page1.goto('about:blank?foo');`);
  353 |       expect(sources.get('Python Async')!.text).toContain(`
  354 |     page1 = await context.new_page()
  355 |     await page1.goto("about:blank?foo")`);
  356 |       expect(sources.get('C#')!.text).toContain(`
  357 | var page1 = await context.NewPageAsync();
  358 | await page1.GotoAsync("about:blank?foo");`);
  359 |     } else {
  360 |       expect(sources.get('JavaScript')!.text).toContain(`
  361 |   const page1Promise = page.waitForEvent('popup');
  362 |   await page.getByRole('link', { name: 'link' }).click({
  363 |     modifiers: ['ControlOrMeta']
  364 |   });
  365 |   const page1 = await page1Promise;`);
  366 |     }
  367 |   });
  368 | 
  369 |   test('should not clash pages', async ({ openRecorder, browserName }) => {
  370 |     const { page, recorder } = await openRecorder();
  371 |     const [popup1] = await Promise.all([
  372 |       page.context().waitForEvent('page'),
  373 |       page.evaluate(`window.open('about:blank')`)
  374 |     ]);
  375 |     await recorder.setPageContentAndWait(popup1, '<input id=name>');
  376 | 
  377 |     const [popup2] = await Promise.all([
  378 |       page.context().waitForEvent('page'),
  379 |       page.evaluate(`window.open('about:blank')`)
  380 |     ]);
  381 |     await recorder.setPageContentAndWait(popup2, '<input id=name>');
  382 | 
  383 |     await popup1.type('input', 'TextA');
  384 |     await recorder.waitForOutput('JavaScript', 'TextA');
  385 | 
  386 |     await popup2.type('input', 'TextB');
  387 |     await recorder.waitForOutput('JavaScript', 'TextB');
  388 | 
  389 |     const sources = recorder.sources();
  390 |     expect(sources.get('JavaScript')!.text).toContain(`await page1.locator('#name').fill('TextA');`);
  391 |     expect(sources.get('JavaScript')!.text).toContain(`await page2.locator('#name').fill('TextB');`);
  392 | 
  393 |     expect(sources.get('Java')!.text).toContain(`page1.locator("#name").fill("TextA");`);
  394 |     expect(sources.get('Java')!.text).toContain(`page2.locator("#name").fill("TextB");`);
  395 | 
  396 |     expect(sources.get('Python')!.text).toContain(`page1.locator("#name").fill("TextA")`);
  397 |     expect(sources.get('Python')!.text).toContain(`page2.locator("#name").fill("TextB")`);
  398 | 
  399 |     expect(sources.get('Python Async')!.text).toContain(`await page1.locator("#name").fill("TextA")`);
  400 |     expect(sources.get('Python Async')!.text).toContain(`await page2.locator("#name").fill("TextB")`);
  401 | 
  402 |     expect(sources.get('C#')!.text).toContain(`await page1.Locator("#name").FillAsync("TextA");`);
  403 |     expect(sources.get('C#')!.text).toContain(`await page2.Locator("#name").FillAsync("TextB");`);
  404 |   });
  405 | 
  406 |   test('click should emit events in order', async ({ openRecorder }) => {
  407 |     const { page, recorder } = await openRecorder();
  408 | 
  409 |     await recorder.setContentAndWait(`
  410 |       <button id=button>
  411 |       <script>
  412 |       button.addEventListener('mousedown', e => console.log(e.type));
  413 |       button.addEventListener('mouseup', e => console.log(e.type));
  414 |       button.addEventListener('click', e => console.log(e.type));
  415 |       </script>
  416 |     `);
  417 | 
  418 |     const messages: any[] = [];
  419 |     page.on('console', message => {
  420 |       if (message.type() !== 'error')
  421 |         messages.push(message.text());
  422 |     });
  423 |     await Promise.all([
  424 |       page.click('button'),
  425 |       recorder.waitForOutput('JavaScript', '.click(')
  426 |     ]);
  427 |     await expect.poll(() => messages).toEqual(['mousedown', 'mouseup', 'click']);
  428 |   });
  429 | 
  430 |   test('should reset hover model on action when element detaches', async ({ openRecorder }) => {
  431 |     const { page, recorder } = await openRecorder();
  432 | 
  433 |     await recorder.setContentAndWait(`<input id="checkbox" onclick="document.getElementById('checkbox').remove()">`);
  434 |     const [models] = await Promise.all([
  435 |       recorder.waitForActionPerformed(),
  436 |       page.click('input')
  437 |     ]);
  438 |     expect(models.hovered).toBe(null);
  439 |   });
  440 | 
  441 |   test('should update active model on action', async ({ openRecorder, browserName, headless }) => {
  442 |     test.skip(browserName === 'webkit', 'webkit does not actually focus the input after click');
  443 | 
  444 |     const { page, recorder } = await openRecorder();
  445 |     await recorder.setContentAndWait(`<input id="checkbox" type="checkbox" name="accept" onchange="checkbox.name='updated'"></input>`);
  446 |     const [models] = await Promise.all([
  447 |       recorder.waitForActionPerformed(),
```