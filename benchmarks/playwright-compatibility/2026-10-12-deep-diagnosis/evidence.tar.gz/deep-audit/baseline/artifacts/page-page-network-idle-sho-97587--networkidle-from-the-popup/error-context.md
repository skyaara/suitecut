# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-network-idle.spec.ts >> should wait for networkidle from the popup
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-network-idle.spec.ts:142:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.waitForLoadState: Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - button "Button1" [active] [ref=e2]
  - button "Button2" [ref=e3]
  - button "Button3" [ref=e4]
  - button "Button4" [ref=e5]
  - button "Button5" [ref=e6]
```

# Test source

```ts
  56  | 
  57  |   // Wait for the initial resource to be requested.
  58  |   await firstFetchResourceRequested;
  59  |   expect(actionFinished).toBe(false);
  60  | 
  61  |   // Trigger the second request.
  62  |   await frame.page().evaluate(() => window['fetchSecond']());
  63  |   // Finish the first request.
  64  |   responseA.statusCode = 404;
  65  |   responseA.end(`File not found`);
  66  | 
  67  |   // Wait for the second round to be requested.
  68  |   await secondFetchResourceRequested;
  69  |   expect(actionFinished).toBe(false);
  70  | 
  71  |   // Finishing the second response should trigger networkidle.
  72  |   let timerTriggered = false;
  73  |   const timer = setTimeout(() => timerTriggered = true, 500);
  74  |   responseB.statusCode = 404;
  75  |   responseB.end(`File not found`);
  76  | 
  77  |   const response = await actionPromise;
  78  |   clearTimeout(timer);
  79  |   expect(timerTriggered).toBe(true);
  80  |   if (!isSetContent)
  81  |     expect(response.ok()).toBe(true);
  82  | }
  83  | 
  84  | it('should wait for networkidle to succeed navigation', async ({ page, server }) => {
  85  |   await networkIdleTest(page.mainFrame(), server, () => {
  86  |     return page.goto(server.PREFIX + '/networkidle.html', { waitUntil: 'networkidle' });
  87  |   });
  88  | });
  89  | 
  90  | it('should wait for networkidle to succeed navigation with request from previous navigation', async ({ page, server }) => {
  91  |   await page.goto(server.EMPTY_PAGE);
  92  |   server.setRoute('/foo.js', () => {});
  93  |   await page.setContent(`<script>fetch('foo.js');</script>`);
  94  |   await networkIdleTest(page.mainFrame(), server, () => {
  95  |     return page.goto(server.PREFIX + '/networkidle.html', { waitUntil: 'networkidle' });
  96  |   });
  97  | });
  98  | 
  99  | it('should wait for networkidle in waitForNavigation', async ({ page, server }) => {
  100 |   await networkIdleTest(page.mainFrame(), server, () => {
  101 |     const promise = page.waitForNavigation({ waitUntil: 'networkidle' });
  102 |     void page.goto(server.PREFIX + '/networkidle.html');
  103 |     return promise;
  104 |   });
  105 | });
  106 | 
  107 | it('should wait for networkidle in setContent', async ({ page, server }) => {
  108 |   await page.goto(server.EMPTY_PAGE);
  109 |   await networkIdleTest(page.mainFrame(), server, () => {
  110 |     return page.setContent(`<script src='networkidle.js'></script>`, { waitUntil: 'networkidle' });
  111 |   }, true);
  112 | });
  113 | 
  114 | it('should wait for networkidle in setContent with request from previous navigation', async ({ page, server }) => {
  115 |   await page.goto(server.EMPTY_PAGE);
  116 |   server.setRoute('/foo.js', () => {});
  117 |   await page.setContent(`<script>fetch('foo.js');</script>`);
  118 |   await networkIdleTest(page.mainFrame(), server, () => {
  119 |     return page.setContent(`<script src='networkidle.js'></script>`, { waitUntil: 'networkidle' });
  120 |   }, true);
  121 | });
  122 | 
  123 | it('should wait for networkidle when navigating iframe', async ({ page, server }) => {
  124 |   await page.goto(server.PREFIX + '/frames/one-frame.html');
  125 |   const frame = page.mainFrame().childFrames()[0];
  126 |   await networkIdleTest(frame, server, () => frame.goto(server.PREFIX + '/networkidle.html', { waitUntil: 'networkidle' }));
  127 | });
  128 | 
  129 | it('should wait for networkidle in setContent from the child frame', async ({ page, server }) => {
  130 |   await page.goto(server.EMPTY_PAGE);
  131 |   await networkIdleTest(page.mainFrame(), server, () => {
  132 |     return page.setContent(`<iframe src='networkidle.html'></iframe>`, { waitUntil: 'networkidle' });
  133 |   }, true);
  134 | });
  135 | 
  136 | it('should wait for networkidle from the child frame', async ({ page, server }) => {
  137 |   await networkIdleTest(page.mainFrame(), server, () => {
  138 |     return page.goto(server.PREFIX + '/networkidle-frame.html', { waitUntil: 'networkidle' });
  139 |   });
  140 | });
  141 | 
  142 | it('should wait for networkidle from the popup', async ({ page, server }) => {
  143 |   await page.goto(server.EMPTY_PAGE);
  144 |   await page.setContent(`
  145 |     <button id=box1 onclick="window.open('./popup/popup.html')">Button1</button>
  146 |     <button id=box2 onclick="window.open('./popup/popup.html')">Button2</button>
  147 |     <button id=box3 onclick="window.open('./popup/popup.html')">Button3</button>
  148 |     <button id=box4 onclick="window.open('./popup/popup.html')">Button4</button>
  149 |     <button id=box5 onclick="window.open('./popup/popup.html')">Button5</button>
  150 |   `);
  151 |   for (let i = 1; i < 6; ++i) {
  152 |     const [popup] = await Promise.all([
  153 |       page.waitForEvent('popup'),
  154 |       page.click('#box' + i)
  155 |     ]);
> 156 |     await popup.waitForLoadState('networkidle');
      |                 ^ Error: page.waitForLoadState: Test timeout of 30000ms exceeded.
  157 |   }
  158 | });
  159 | 
  160 | it('should wait for networkidle when iframe attaches and detaches', async ({ page, server }) => {
  161 |   server.setRoute('/empty.html', () => {});
  162 |   let done = false;
  163 |   const promise = page.setContent(`
  164 |     <body>
  165 |       <script>
  166 |         const iframe = document.createElement('iframe');
  167 |         iframe.src = ${JSON.stringify(server.EMPTY_PAGE)};
  168 |         document.body.appendChild(iframe);
  169 |       </script>
  170 |     </body>
  171 |   `, { waitUntil: 'networkidle' }).then(() => done = true);
  172 |   await page.waitForTimeout(600);
  173 |   expect(done).toBe(false);
  174 |   await page.evaluate(() => {
  175 |     document.querySelector('iframe').remove();
  176 |   });
  177 |   await promise;
  178 |   expect(done).toBe(true);
  179 | });
  180 | 
  181 | it('should work after repeated navigations in the same page', async ({ page, server }) => {
  182 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/18283' });
  183 | 
  184 |   let requestCount = 0;
  185 |   await page.route('**/empty.html', route => {
  186 |     void route.fulfill({
  187 |       contentType: 'text/html',
  188 |       body: `
  189 |         <script>
  190 |           fetch('http://localhost:8000/sample').then(res => console.log(res.json()))
  191 |         </script>`
  192 |     });
  193 |   });
  194 | 
  195 |   await page.route('**/sample', route => {
  196 |     requestCount++;
  197 |     void route.fulfill({
  198 |       contentType: 'application/json',
  199 |       body: JSON.stringify({
  200 |         content: 'sample'
  201 |       })
  202 |     });
  203 |   });
  204 | 
  205 |   await page.goto(server.EMPTY_PAGE, { waitUntil: 'networkidle' });
  206 |   expect(requestCount).toBe(1);
  207 |   await page.goto(server.EMPTY_PAGE, { waitUntil: 'networkidle' });
  208 |   expect(requestCount).toBe(2);
  209 | });
  210 | 
  211 | it('should not wait for an open EventSource connection', async ({ page, server }) => {
  212 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/37226' });
  213 | 
  214 |   server.setRoute('/sse', (req, res) => {
  215 |     res.writeHead(200, {
  216 |       'Content-Type': 'text/event-stream',
  217 |       'Connection': 'keep-alive',
  218 |       'Cache-Control': 'no-cache',
  219 |     });
  220 |     res.write('data: hello\n\n');
  221 |   });
  222 |   server.setRoute('/sse-page.html', (req, res) => {
  223 |     res.writeHead(200, { 'Content-Type': 'text/html' });
  224 |     res.end(`<script>new EventSource('/sse');</script>`);
  225 |   });
  226 | 
  227 |   const response = await page.goto(server.PREFIX + '/sse-page.html', { waitUntil: 'networkidle' });
  228 |   expect(response.status()).toBe(200);
  229 | });
  230 | 
  231 | it('should not wait for an open EventSource connection in setContent', async ({ page, server }) => {
  232 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/37226' });
  233 | 
  234 |   server.setRoute('/sse', (req, res) => {
  235 |     res.writeHead(200, {
  236 |       'Content-Type': 'text/event-stream',
  237 |       'Connection': 'keep-alive',
  238 |       'Cache-Control': 'no-cache',
  239 |     });
  240 |     res.write('data: hello\n\n');
  241 |   });
  242 | 
  243 |   await page.goto(server.EMPTY_PAGE);
  244 |   await page.setContent(`<script>
  245 |     window.__sseOpened = new Promise(resolve => {
  246 |       const es = new EventSource('/sse');
  247 |       es.onmessage = () => resolve();
  248 |     });
  249 |   </script>`, { waitUntil: 'networkidle' });
  250 |   await page.evaluate(() => window['__sseOpened']);
  251 | });
  252 | 
```