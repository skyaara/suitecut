# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-evaluate.spec.ts >> promise collected
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-evaluate.spec.ts:894:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "Resulting promise was garbage collected"
Received string:    "page.evaluate: Test timeout of 30000ms exceeded."
```

# Test source

```ts
  801 |   await page.goto(server.PREFIX + '/test');
  802 |   expect(await page.evaluate('1+2')).toBe(3);
  803 | });
  804 | 
  805 | it('should work with busted Array.prototype.map/push', async ({ page, server }) => {
  806 |   server.setRoute('/test', (req, res) => {
  807 |     res.writeHead(200, {
  808 |       'content-type': 'text/html',
  809 |     });
  810 |     res.end(`<script>
  811 |       Array.prototype.map = null;
  812 |       Array.prototype.push = null;
  813 |     </script>`);
  814 |   });
  815 |   await page.goto(server.PREFIX + '/test');
  816 |   expect(await page.evaluate('1+2')).toBe(3);
  817 |   expect(await ((await page.evaluateHandle('1+2')).jsonValue())).toBe(3);
  818 | });
  819 | 
  820 | it('should work with overridden globalThis.Window/Document/Node', async ({ page, server }) => {
  821 |   const testCases = [
  822 |     // @ts-ignore
  823 |     () => globalThis.Window = {},
  824 |     // @ts-ignore
  825 |     () => globalThis.Document = {},
  826 |     // @ts-ignore
  827 |     () => globalThis.Node = {},
  828 |     () => globalThis.Window = null,
  829 |     () => globalThis.Document = null,
  830 |     () => globalThis.Node = null,
  831 |   ];
  832 |   for (const testCase of testCases) {
  833 |     await it.step(testCase.toString(), async () => {
  834 |       await page.goto(server.EMPTY_PAGE);
  835 |       await page.evaluate(testCase);
  836 |       expect(await page.evaluate('1+2')).toBe(3);
  837 |       expect(await page.evaluate(() => ['foo'])).toEqual(['foo']);
  838 |     });
  839 |   }
  840 | });
  841 | 
  842 | it('should work with overridden URL/Date/RegExp', async ({ page, server }) => {
  843 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/21109' });
  844 |   const testCases = [
  845 |     // @ts-ignore
  846 |     () => globalThis.URL = 'foo',
  847 |     // @ts-ignore
  848 |     () => globalThis.RegExp = 'foo',
  849 |     // @ts-ignore
  850 |     () => globalThis.Date = 'foo',
  851 |   ];
  852 |   for (const testCase of testCases) {
  853 |     await it.step(testCase.toString(), async () => {
  854 |       await page.goto(server.EMPTY_PAGE);
  855 |       await page.evaluate(testCase);
  856 |       expect(await page.evaluate('1+2')).toBe(3);
  857 |       expect(await page.evaluate(() => ({ 'a': 2023 }))).toEqual({ 'a': 2023 });
  858 |     });
  859 |   }
  860 | });
  861 | 
  862 | it('should work with Array.from/map', async ({ page }) => {
  863 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/28520' });
  864 |   expect(await page.evaluate(() => {
  865 |     const r = (str, amount) => Array.from(Array(amount)).map(() => str).join('');
  866 |     return r('([a-f0-9]{2})', 3);
  867 |   })).toBe('([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})');
  868 | });
  869 | 
  870 | it('should work with a using declaration', async ({ page, nodeVersion, browserName }) => {
  871 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/41511' });
  872 |   it.skip(nodeVersion.major < 24, 'using is lowered to a module-scope helper that does not survive evaluate serialization on Node < 24');
  873 |   it.skip(browserName === 'webkit', 'WebKit does not support using declarations');
  874 |   const disposed = await page.evaluate(() => {
  875 |     let disposed = false;
  876 |     {
  877 |       using r = { [Symbol.dispose]: () => { disposed = true; } };
  878 |       void r;
  879 |     }
  880 |     return disposed;
  881 |   });
  882 |   expect(disposed).toBe(true);
  883 | });
  884 | 
  885 | it('should ignore dangerous object keys', async ({ page }) => {
  886 |   const input = {
  887 |     __proto__: { polluted: true },
  888 |     safeKey: 'safeValue'
  889 |   };
  890 |   const result = await page.evaluate(arg => arg, input);
  891 |   expect(result).toEqual({ safeKey: 'safeValue' });
  892 | });
  893 | 
  894 | it('promise collected', async ({ page, browserName }) => {
  895 |   it.skip(browserName !== 'chromium', 'this is a chromium-only behavior');
  896 | 
  897 |   const resultPromise = page.evaluate(() => new Promise<void>(() => {})).catch(e => e);
  898 |   for (let i = 0; i < 20; i++)
  899 |     await page.requestGC();
  900 |   const error = await resultPromise;
> 901 |   expect(error.message).toContain('Resulting promise was garbage collected');
      |                         ^ Error: expect(received).toContain(expected) // indexOf
  902 | });
  903 | 
```