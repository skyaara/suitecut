# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-basic.spec.ts >> should create new context @smoke
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-basic.spec.ts:23:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 1
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2018 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { kTargetClosedErrorMessage } from '../config/errors';
  19  | import { browserTest as it, expect } from '../config/browserTest';
  20  | import { attachFrame, verifyViewport } from '../config/utils';
  21  | import type { Page } from '@playwright/test';
  22  | 
  23  | it('should create new context @smoke', async function({ browser }) {
> 24  |   expect(browser.contexts().length).toBe(0);
      |                                     ^ Error: expect(received).toBe(expected) // Object.is equality
  25  |   const context = await browser.newContext();
  26  |   expect(browser.contexts()).toEqual([context]);
  27  |   expect(browser).toBe(context.browser());
  28  |   const context2 = await browser.newContext();
  29  |   expect(browser.contexts()).toEqual([context, context2]);
  30  |   await context.close();
  31  |   expect(browser.contexts()).toEqual([context2]);
  32  |   expect(browser).toBe(context.browser());
  33  |   await context2.close();
  34  | });
  35  | 
  36  | it('should be able to click across browser contexts', async function({ browser }) {
  37  |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/29096' });
  38  |   expect(browser.contexts().length).toBe(0);
  39  | 
  40  |   const createPage = async () => {
  41  |     const page = await browser.newPage();
  42  |     await page.setContent(`<button>Click me</button>`);
  43  |     await page.locator('button').evaluate(button => {
  44  |       window['clicks'] = 0;
  45  |       button.addEventListener('click', () => ++window['clicks'], false);
  46  |     });
  47  |     return page;
  48  |   };
  49  | 
  50  |   const clickInPage = async (page, count) => {
  51  |     for (let i = 0; i < count; ++i)
  52  |       await page.locator('button').click();
  53  |   };
  54  | 
  55  |   const getClicks = async page => page.evaluate(() => window['clicks']);
  56  | 
  57  |   const page1 = await createPage();
  58  |   const page2 = await createPage();
  59  | 
  60  |   const CLICK_COUNT = 20;
  61  |   await Promise.all([
  62  |     clickInPage(page1, CLICK_COUNT),
  63  |     clickInPage(page2, CLICK_COUNT),
  64  |   ]);
  65  |   expect(await getClicks(page1)).toBe(CLICK_COUNT);
  66  |   expect(await getClicks(page2)).toBe(CLICK_COUNT);
  67  | 
  68  |   await page1.close();
  69  |   await page2.close();
  70  | });
  71  | 
  72  | it('should be able to hover across browser contexts in parallel', async function({ browser, browserName, headless }) {
  73  |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40562' });
  74  |   it.fixme(browserName === 'firefox' && !headless, 'Hover is flaky in headed Firefox');
  75  | 
  76  |   const html = `
  77  |     <style>
  78  |       [role="tooltip"] { display: none; }
  79  |       [role="tooltip"].visible { display: block; }
  80  |     </style>
  81  |     <button>Hover me</button>
  82  |     <div role="tooltip">Tooltip content</div>
  83  |     <script>
  84  |       const button = document.querySelector('button');
  85  |       const tooltip = document.querySelector('[role="tooltip"]');
  86  |       button.addEventListener('pointerenter', () => tooltip.classList.add('visible'));
  87  |       button.addEventListener('pointerleave', () => tooltip.classList.remove('visible'));
  88  |     </script>
  89  |   `;
  90  | 
  91  |   const pages: Page[] = await Promise.all([1, 2, 3, 4, 5].map(async () => {
  92  |     const context = await browser.newContext();
  93  |     const page = await context.newPage();
  94  |     await page.setContent(html);
  95  |     return page;
  96  |   }));
  97  | 
  98  |   await Promise.all(pages.map(async (page, index) => {
  99  |     await page.getByRole('button', { name: 'Hover me' }).hover();
  100 |     await expect.soft(page.getByRole('tooltip'), `Tooltip for page ${index + 1} should be visible`).toBeVisible();
  101 |   }));
  102 | 
  103 |   await Promise.all(pages.map(page => page.context().close()));
  104 | });
  105 | 
  106 | it('window.open should use parent tab context', async function({ browser, server }) {
  107 |   const context = await browser.newContext();
  108 |   const page = await context.newPage();
  109 |   await page.goto(server.EMPTY_PAGE);
  110 |   const [popup] = await Promise.all([
  111 |     page.waitForEvent('popup'),
  112 |     page.evaluate(url => window.open(url), server.EMPTY_PAGE)
  113 |   ]);
  114 |   expect(popup.context()).toBe(context);
  115 |   await context.close();
  116 | });
  117 | 
  118 | it('should isolate localStorage and cookies @smoke', async function({ browser, server }) {
  119 |   // Create two incognito contexts.
  120 |   const context1 = await browser.newContext();
  121 |   const context2 = await browser.newContext();
  122 |   expect(context1.pages().length).toBe(0);
  123 |   expect(context2.pages().length).toBe(0);
  124 | 
```