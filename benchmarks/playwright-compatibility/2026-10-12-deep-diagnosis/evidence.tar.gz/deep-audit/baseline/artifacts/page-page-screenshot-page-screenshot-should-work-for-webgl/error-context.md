# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-screenshot.spec.ts >> page screenshot >> should work for webgl
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-screenshot.spec.ts:394:5

# Error details

```
Error: expect(Buffer).toMatchSnapshot(expected) failed

  38160 pixels (ratio 0.13 of all image pixels) are different.

  Snapshot: screenshot-webgl.png

```

# Test source

```ts
  301 |     await page.goto(server.PREFIX + '/grid.html');
  302 |     const lowQuality = await page.screenshot({ type: 'webp', quality: 0 });
  303 |     const highQuality = await page.screenshot({ type: 'webp', quality: 100 });
  304 |     expect(lowQuality.byteLength).toBeLessThan(highQuality.byteLength);
  305 |   });
  306 | 
  307 |   it('webp screenshots should be lossless by default', async ({ page, server }) => {
  308 |     await page.goto(server.PREFIX + '/grid.html');
  309 |     expect(utils.isLosslessWebp(await page.screenshot({ type: 'webp' }))).toBe(true);
  310 |     expect(utils.isLosslessWebp(await page.screenshot({ type: 'webp', quality: 80 }))).toBe(false);
  311 |   });
  312 | 
  313 |   it('should allow transparency with webp', async ({ page, browserName, isBidi }) => {
  314 |     it.skip(isBidi, 'transparency is not supported via WebDriver BiDi');
  315 |     it.fail(browserName === 'firefox');
  316 | 
  317 |     await page.setViewportSize({ width: 300, height: 300 });
  318 |     await page.setContent(`
  319 |       <style>
  320 |         body { margin: 0 }
  321 |         div { width: 300px; height: 100px; }
  322 |       </style>
  323 |       <div style="background:black"></div>
  324 |       <div style="background:white"></div>
  325 |       <div style="background:transparent"></div>
  326 |     `);
  327 |     const screenshot = await page.screenshot({ omitBackground: true, type: 'webp' });
  328 |     const { width, height, data } = utils.decodeWebp(screenshot);
  329 |     expect(width).toBe(300);
  330 |     expect(height).toBe(300);
  331 |     const pixel = (x: number, y: number) => [...data.subarray((y * width + x) * 4, (y * width + x) * 4 + 4)];
  332 |     expect(pixel(150, 50)).toEqual([0, 0, 0, 255]);
  333 |     expect(pixel(150, 150)).toEqual([255, 255, 255, 255]);
  334 |     expect(pixel(150, 250)[3]).toBe(0);
  335 |   });
  336 | 
  337 |   it('quality option should throw for webp when out of range', async ({ page }) => {
  338 |     const error = await page.screenshot({ type: 'webp', quality: 101 }).catch(e => e);
  339 |     expect(error.message).toContain('Expected options.quality to be between 0 and 100');
  340 |   });
  341 | 
  342 |   it('should work with odd clip size on Retina displays', async ({ page, isElectron }) => {
  343 |     it.skip(isElectron, 'electron does not set device scale factor to 1');
  344 | 
  345 |     const screenshot = await page.screenshot({
  346 |       clip: {
  347 |         x: 0,
  348 |         y: 0,
  349 |         width: 11,
  350 |         height: 11,
  351 |       }
  352 |     });
  353 |     expect(screenshot).toMatchSnapshot('screenshot-clip-odd-size.png');
  354 |   });
  355 | 
  356 |   it('should work for canvas', async ({ page, server }) => {
  357 |     await page.setViewportSize({ width: 500, height: 500 });
  358 |     await page.goto(server.PREFIX + '/screenshots/canvas.html');
  359 |     const screenshot = await page.screenshot();
  360 |     // Allow 4 corners to be rendered differently on various platforms/browsers.
  361 |     expect(screenshot).toMatchSnapshot('screenshot-canvas.png', { maxDiffPixels: 4 });
  362 |   });
  363 | 
  364 |   it('should capture canvas changes', async ({ page, isElectron }) => {
  365 |     it.skip(isElectron);
  366 |     await page.goto('data:text/html,<canvas></canvas>');
  367 |     await page.evaluate(() => {
  368 |       const canvas = document.querySelector('canvas');
  369 |       canvas.width = 600;
  370 |       canvas.height = 600;
  371 |     });
  372 | 
  373 |     async function addLine(step: number) {
  374 |       await page.evaluate(n => {
  375 |         const canvas = document.querySelector('canvas');
  376 |         const ctx = canvas.getContext('2d');
  377 |         ctx.lineWidth = 1;
  378 |         ctx.beginPath();
  379 |         ctx.moveTo(0, n * 100);
  380 |         ctx.lineTo(300, n * 100);
  381 |         ctx.stroke();
  382 |       }, step);
  383 |     }
  384 | 
  385 |     for (let i = 0; i < 3; i++) {
  386 |       await addLine(i);
  387 |       // With the slight delay WebKit stops reflecting changes in the screenshots on macOS.
  388 |       await new Promise(f => setTimeout(f, 100));
  389 |       const screenshot = await page.screenshot();
  390 |       expect(screenshot).toMatchSnapshot(`canvas-changes-${i}.png`);
  391 |     }
  392 |   });
  393 | 
  394 |   it('should work for webgl', async ({ page, server, browserName, platform, isElectron }) => {
  395 |     it.skip(browserName === 'webkit' && platform === 'darwin' && os.arch() === 'x64', 'WebGL is not available on Intel macOS - https://bugs.webkit.org/show_bug.cgi?id=278277');
  396 |     it.skip(isElectron, 'different rendering in electron');
  397 | 
  398 |     await page.setViewportSize({ width: 640, height: 480 });
  399 |     await page.goto(server.PREFIX + '/screenshots/webgl.html');
  400 |     const screenshot = await page.screenshot();
> 401 |     expect(screenshot).toMatchSnapshot('screenshot-webgl.png');
      |                        ^ Error: expect(Buffer).toMatchSnapshot(expected) failed
  402 |   });
  403 | 
  404 |   it('should work for translateZ', async ({ page, server }) => {
  405 |     await page.setViewportSize({ width: 500, height: 500 });
  406 |     await page.goto(server.PREFIX + '/screenshots/translateZ.html');
  407 |     const screenshot = await page.screenshot();
  408 |     expect(screenshot).toMatchSnapshot('screenshot-translateZ.png');
  409 |   });
  410 | 
  411 |   it('should work while navigating', async ({ page, server }) => {
  412 |     await page.setViewportSize({ width: 500, height: 500 });
  413 |     await page.goto(server.PREFIX + '/redirectloop1.html');
  414 |     for (let i = 0; i < 10; i++) {
  415 |       const screenshot = await page.screenshot({ fullPage: true }).catch(e => {
  416 |         if (e.message.includes('Cannot take a screenshot while page is navigating'))
  417 |           return Buffer.from('');
  418 |         throw e;
  419 |       });
  420 |       expect(screenshot).toBeInstanceOf(Buffer);
  421 |     }
  422 |   });
  423 | 
  424 |   it('should work with iframe in shadow', async ({ page, server }) => {
  425 |     await page.setViewportSize({ width: 500, height: 500 });
  426 |     await page.goto(server.PREFIX + '/grid-iframe-in-shadow.html');
  427 |     expect(await page.screenshot()).toMatchSnapshot('screenshot-iframe.png');
  428 |   });
  429 | 
  430 |   it('path option should work', async ({ page, server }, testInfo) => {
  431 |     await page.setViewportSize({ width: 500, height: 500 });
  432 |     await page.goto(server.PREFIX + '/grid.html');
  433 |     const outputPath = testInfo.outputPath('screenshot.png');
  434 |     await page.screenshot({ path: outputPath });
  435 |     expect(await fs.promises.readFile(outputPath)).toMatchSnapshot('screenshot-sanity.png');
  436 |   });
  437 | 
  438 |   it('path option should create subdirectories', async ({ page, server }, testInfo) => {
  439 |     await page.setViewportSize({ width: 500, height: 500 });
  440 |     await page.goto(server.PREFIX + '/grid.html');
  441 |     const outputPath = testInfo.outputPath(path.join('these', 'are', 'directories', 'screenshot.png'));
  442 |     await page.screenshot({ path: outputPath });
  443 |     expect(await fs.promises.readFile(outputPath)).toMatchSnapshot('screenshot-sanity.png');
  444 |   });
  445 | 
  446 |   it('path option should detect jpeg', async ({ page, server, isElectron }, testInfo) => {
  447 |     await page.setViewportSize({ width: 300, height: 300 });
  448 |     await page.goto(server.EMPTY_PAGE);
  449 |     const outputPath = testInfo.outputPath('screenshot.jpg');
  450 |     const screenshot = await page.screenshot({ omitBackground: true, path: outputPath });
  451 |     expect(await fs.promises.readFile(outputPath)).toMatchSnapshot('white.jpg');
  452 |     expect(screenshot).toMatchSnapshot('white.jpg');
  453 |   });
  454 | 
  455 |   it('path option should throw for unsupported mime type', async ({ page }) => {
  456 |     const error = await page.screenshot({ path: 'file.txt' }).catch(e => e);
  457 |     expect(error.message).toContain('path: unsupported mime type "text/plain"');
  458 |   });
  459 | 
  460 |   it('quality option should throw for png', async ({ page }) => {
  461 |     const error = await page.screenshot({ quality: 10 }).catch(e => e);
  462 |     expect(error.message).toContain('options.quality is unsupported for the png');
  463 |   });
  464 | 
  465 |   it('zero quality option should throw for png', async ({ page }) => {
  466 |     const error = await page.screenshot({ quality: 0, type: 'png' }).catch(e => e);
  467 |     expect(error.message).toContain('options.quality is unsupported for the png');
  468 |   });
  469 | 
  470 |   it('quality option should work for jpeg', async ({ page, server }) => {
  471 |     await page.goto(server.PREFIX + '/grid.html');
  472 |     const zeroQuality = await page.screenshot({ type: 'jpeg', quality: 0 });
  473 |     const highQuality = await page.screenshot({ type: 'jpeg', quality: 100 });
  474 |     expect(zeroQuality.byteLength).toBeLessThan(highQuality.byteLength);
  475 |   });
  476 | 
  477 |   it('should prefer type over extension', async ({ page }, testInfo) => {
  478 |     const outputPath = testInfo.outputPath('file.png');
  479 |     const buffer = await page.screenshot({ path: outputPath, type: 'jpeg' });
  480 |     expect([buffer[0], buffer[1], buffer[2]]).toEqual([0xFF, 0xD8, 0xFF]);
  481 |   });
  482 | 
  483 |   it('should not issue resize event', async ({ page, server }) => {
  484 |     await page.goto(server.PREFIX + '/grid.html');
  485 |     let resizeTriggered = false;
  486 |     await page.exposeFunction('resize', () => {
  487 |       resizeTriggered = true;
  488 |     });
  489 |     await page.evaluate(() => {
  490 |       window.addEventListener('resize', () => (window as any).resize());
  491 |     });
  492 |     await page.screenshot();
  493 |     expect(resizeTriggered).toBeFalsy();
  494 |   });
  495 | 
  496 |   it('should work with Array deleted', async ({ page, server }) => {
  497 |     await page.setViewportSize({ width: 500, height: 500 });
  498 |     await page.goto(server.PREFIX + '/grid.html');
  499 |     await page.evaluate(() => delete window.Array);
  500 |     const screenshot = await page.screenshot({ fullPage: true });
  501 |     expect(screenshot).toMatchSnapshot('screenshot-grid-fullpage.png');
```