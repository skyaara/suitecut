# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/popup.spec.ts >> should not dispatch binding on a closed page
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/popup.spec.ts:224:3

# Error details

```
Error: page.evaluate: TypeError: win.add is not a function
    at eval (eval at evaluate (:311:30), <anonymous>:3:15)
    at UtilityScript.evaluate (<anonymous>:313:16)
    at UtilityScript.<anonymous> (<anonymous>:1:44)
```