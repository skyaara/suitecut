# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-aria-snapshot.spec.ts >> auto-waits the locator and does not include iframes
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-aria-snapshot.spec.ts:699:3

# Error details

```
Error: locator.ariaSnapshot: Target page, context or browser has been closed
Call log:
  - waiting for locator('#target')

```

# Test source

```ts
  604 |     <a href="#">-</a>-
  605 |     <input type=text value="555">
  606 |   `);
  607 | 
  608 |   await checkAndMatchSnapshot(page.locator('body'), `
  609 |     - link "true":
  610 |       - /url: "#"
  611 |     - text: "False"
  612 |     - link "NO":
  613 |       - /url: "#"
  614 |     - text: "yes"
  615 |     - link "y":
  616 |       - /url: "#"
  617 |     - text: "N"
  618 |     - link "on":
  619 |       - /url: "#"
  620 |     - text: "Off"
  621 |     - link "null":
  622 |       - /url: "#"
  623 |     - text: "NULL"
  624 |     - link "123":
  625 |       - /url: "#"
  626 |     - text: "123"
  627 |     - link "-1.2":
  628 |       - /url: "#"
  629 |     - text: "-1.2"
  630 |     - link "-":
  631 |       - /url: "#"
  632 |     - text: "-"
  633 |     - textbox: "555"
  634 |   `);
  635 | });
  636 | 
  637 | it('should not report textarea textContent', async ({ page }) => {
  638 |   await page.setContent(`<textarea>Before</textarea>`);
  639 |   await checkAndMatchSnapshot(page.locator('body'), `
  640 |     - textbox: Before
  641 |   `);
  642 |   await page.evaluate(() => {
  643 |     document.querySelector('textarea').value = 'After';
  644 |   });
  645 |   await checkAndMatchSnapshot(page.locator('body'), `
  646 |     - textbox: After
  647 |   `);
  648 | });
  649 | 
  650 | it('should not show visible children of hidden elements', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36296' }  }, async ({ page }) => {
  651 |   await page.setContent(`
  652 |     <div style="visibility: hidden;">
  653 |       <div style="visibility: visible;">
  654 |         <button>Button</button>
  655 |       </div>
  656 |     </div>
  657 |   `);
  658 | 
  659 |   expect(await page.locator('body').ariaSnapshot()).toBe('');
  660 | });
  661 | 
  662 | it('should not show unhidden children of aria-hidden elements', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36296' }  }, async ({ page }) => {
  663 |   await page.setContent(`
  664 |     <div aria-hidden="true">
  665 |       <div aria-hidden="false">
  666 |         <button>Button</button>
  667 |       </div>
  668 |     </div>
  669 |   `);
  670 | 
  671 |   expect(await page.locator('body').ariaSnapshot()).toBe('');
  672 | });
  673 | 
  674 | it('should snapshot placeholder when different from the name', async ({ page }) => {
  675 |   await page.setContent(`
  676 |     <input placeholder="Placeholder">
  677 |   `);
  678 |   expect(await page.locator('body').ariaSnapshot()).toContainYaml(`
  679 |     - textbox "Placeholder"
  680 |   `);
  681 | 
  682 |   await page.setContent(`
  683 |     <input placeholder="Placeholder" aria-label="Label">
  684 |   `);
  685 |   expect(await page.locator('body').ariaSnapshot()).toContainYaml(`
  686 |     - textbox "Label":
  687 |       - /placeholder: Placeholder
  688 |   `);
  689 | });
  690 | 
  691 | it('match values both against regex and string', async ({ page }) => {
  692 |   await page.setContent(`<a href="/auth?r=/">Log in</a>`);
  693 |   await checkAndMatchSnapshot(page.locator('body'), `
  694 |     - link "Log in":
  695 |       - /url: /auth?r=/
  696 |   `);
  697 | });
  698 | 
  699 | it('auto-waits the locator and does not include iframes', async ({ page }) => {
  700 |   await page.setContent(`
  701 |     <div>Hello</div>
  702 |   `);
  703 | 
> 704 |   const snapshotPromise = page.locator('#target').ariaSnapshot();
      |                                                   ^ Error: locator.ariaSnapshot: Target page, context or browser has been closed
  705 |   await page.waitForTimeout(2000);
  706 |   await page.setContent(`
  707 |     <div id=target>
  708 |       Hello
  709 |       <iframe srcdoc="<ul><li>Item 1</li><li>Item 2</li></ul>"></iframe>
  710 |     </div>
  711 |   `);
  712 |   expect(await snapshotPromise).toContainYaml(`
  713 |     - text: Hello
  714 |   `);
  715 | });
  716 | 
  717 | it('should limit depth', async ({ page }) => {
  718 |   await page.setContent(`
  719 |     <ul id=target>
  720 |       <li>item2</li>
  721 |       <li>
  722 |         <ul>
  723 |           <li>item3</li>
  724 |         </ul>
  725 |       </li>
  726 |     </ul>
  727 |   `);
  728 | 
  729 |   const snapshot = await page.locator('#target').ariaSnapshot({ depth: 1 });
  730 |   expect(snapshot).toContainYaml(`
  731 |     - list:
  732 |       - listitem: item2
  733 |       - listitem
  734 |   `);
  735 | });
  736 | 
  737 | it('should snapshot a locator inside an iframe', async ({ page }) => {
  738 |   await page.setContent(`
  739 |     <h1>Main Page</h1>
  740 |     <iframe srcdoc="<ul><li>Item 1</li><li>Item 2</li></ul>"></iframe>
  741 |   `);
  742 | 
  743 |   const list = page.frames()[1].locator('ul');
  744 |   const snapshot = await list.ariaSnapshot();
  745 |   expect(snapshot).toContainYaml(`
  746 |     - list:
  747 |       - listitem: Item 1
  748 |       - listitem: Item 2
  749 |   `);
  750 | });
  751 | 
  752 | it('should include frames on frameset pages', { annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/41784' } }, async ({ page, server }) => {
  753 |   server.setRoute('/frameset.html', (req, res) => {
  754 |     res.setHeader('Content-Type', 'text/html');
  755 |     res.end(`<frameset cols="50%,50%"><frame src="/frames/frame.html"><frame src="/frames/frame.html"></frameset>`);
  756 |   });
  757 |   await page.goto(server.PREFIX + '/frameset.html');
  758 |   // Like iframes, frames are listed in the snapshot, but their content is not included.
  759 |   expect(await page.ariaSnapshot({ timeout: 3000 })).toBe(unshift(`
  760 |     - iframe
  761 |     - iframe
  762 |   `));
  763 | });
  764 | 
  765 | it('should snapshot a locator inside a frameset frame', async ({ page, server }) => {
  766 |   await page.goto(server.PREFIX + '/frames/frameset.html');
  767 |   await checkAndMatchSnapshot(page.frameLocator('frame').first().locator('body'), `
  768 |     - text: Hi, I'm frame
  769 |   `);
  770 | });
  771 | 
  772 | it('should snapshot with box from page', async ({ page }) => {
  773 |   await page.setContent(`
  774 |     <button style="position:absolute;left:100px;top:50px;width:80px;height:40px;margin:0;padding:0;border:0;">click</button>
  775 |   `);
  776 | 
  777 |   const snapshot = await page.ariaSnapshot({ boxes: true });
  778 |   expect(snapshot).toBe(`- button "click" [box=100,50,80,40]`);
  779 | });
  780 | 
  781 | it('should snapshot with box from locator', async ({ page }) => {
  782 |   await page.setContent(`
  783 |     <div style="position:absolute;left:10px;top:20px;width:200px;height:100px;">
  784 |       <button style="position:absolute;left:5px;top:5px;width:60px;height:30px;margin:0;padding:0;border:0;">ok</button>
  785 |     </div>
  786 |   `);
  787 | 
  788 |   const snapshot = await page.locator('div').ariaSnapshot({ boxes: true });
  789 |   expect(snapshot).toBe(`- button "ok" [box=15,25,60,30]`);
  790 | });
  791 | 
  792 | it('should not include box when option is omitted', async ({ page }) => {
  793 |   await page.setContent(`<button>click</button>`);
  794 |   const snapshot = await page.ariaSnapshot();
  795 |   expect(snapshot).not.toMatch(/\[box=/);
  796 | });
  797 | 
```