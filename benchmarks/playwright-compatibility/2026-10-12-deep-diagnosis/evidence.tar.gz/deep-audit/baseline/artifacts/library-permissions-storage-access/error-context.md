# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/permissions.spec.ts >> storage access
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/permissions.spec.ts:222:3

# Error details

```
Error: browserContext.grantPermissions: Protocol error (Browser.grantPermissions): Unsupported native permission: storageAccess
```

# Test source

```ts
  127 |           window['events'].push(result.state);
  128 |         };
  129 |       });
  130 |     });
  131 |     const expectedEvents = ['prompt'];
  132 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  133 |     await context.grantPermissions([], { origin: server.EMPTY_PAGE });
  134 |     if (!isBidi)
  135 |       expectedEvents.push('denied');
  136 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  137 |     await context.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  138 |     expectedEvents.push('granted');
  139 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  140 |     await context.clearPermissions();
  141 |     expectedEvents.push('prompt');
  142 |     expect(await page.evaluate(() => window['events'])).toEqual(expectedEvents);
  143 |   });
  144 | 
  145 |   it('should isolate permissions between browser contexts', async ({ server, browser, browserName, isBidi, isFrozenWebkit }) => {
  146 |     it.skip(isFrozenWebkit);
  147 | 
  148 |     const context = await browser.newContext();
  149 |     const page = await context.newPage();
  150 |     await page.goto(server.EMPTY_PAGE);
  151 |     const otherContext = await browser.newContext();
  152 |     const otherPage = await otherContext.newPage();
  153 |     await otherPage.goto(server.EMPTY_PAGE);
  154 |     expect(await getPermission(page, 'geolocation')).toBe('prompt');
  155 |     expect(await getPermission(otherPage, 'geolocation')).toBe('prompt');
  156 | 
  157 |     await context.grantPermissions([], { origin: server.EMPTY_PAGE });
  158 |     await otherContext.grantPermissions(['geolocation'], { origin: server.EMPTY_PAGE });
  159 |     if (browserName === 'webkit') {
  160 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  161 |       // Since https://github.com/WebKit/WebKit/pull/45470 WebKit only returns actual
  162 |       // permission value, if the API has been accessed.
  163 |       await page.evaluate(() => navigator.geolocation.getCurrentPosition(() => { }));
  164 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  165 |     } else if (isBidi) {
  166 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  167 |     } else {
  168 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  169 |     }
  170 |     expect(await getPermission(otherPage, 'geolocation')).toBe('granted');
  171 | 
  172 |     await context.clearPermissions();
  173 |     if (browserName === 'webkit') {
  174 |       // Since https://github.com/WebKit/WebKit/pull/45470 WebKit returns the cached
  175 |       // permission value, if the geolocation API has been accessed.
  176 |       // TODO: We can probably reset the cached state in the Web Process when resetting
  177 |       // permissions.
  178 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  179 | 
  180 |       // Geolocation API in the new page in the same context has not been accessed yet,
  181 |       // so the permission status should be prompt.
  182 |       const page2 = await context.newPage();
  183 |       await page2.goto(server.EMPTY_PAGE);
  184 |       expect(await getPermission(page2, 'geolocation')).toBe('prompt');
  185 |       await page2.close();
  186 |     } else {
  187 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  188 |     }
  189 |     expect(await getPermission(otherPage, 'geolocation')).toBe('granted');
  190 |     await otherContext.close();
  191 |     await context.close();
  192 |   });
  193 | });
  194 | 
  195 | it('should support clipboard read', async ({ page, context, server, browserName, isWindows, isLinux, headless, isHeadlessShell }) => {
  196 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/27475' });
  197 |   it.fail(browserName === 'firefox', 'No such permissions (requires flag) in Firefox');
  198 |   it.fixme(browserName === 'webkit' && isWindows, 'WebPasteboardProxy::allPasteboardItemInfo not implemented for Windows.');
  199 |   it.fixme(browserName === 'webkit' && isLinux && headless, 'WebPasteboardProxy::allPasteboardItemInfo not implemented for WPE.');
  200 | 
  201 |   await page.goto(server.EMPTY_PAGE);
  202 |   // There is no 'clipboard-read' permission in WebKit Web API.
  203 |   if (browserName !== 'webkit')
  204 |     expect(await getPermission(page, 'clipboard-read')).toBe('prompt');
  205 | 
  206 |   if (isHeadlessShell) {
  207 |     // Chromium (but not headless-shell) shows a dialog and does not resolve the promise.
  208 |     const error = await page.evaluate(() => navigator.clipboard.readText()).catch(e => e);
  209 |     expect(error.toString()).toContain('denied');
  210 |   }
  211 | 
  212 |   await context.grantPermissions(['clipboard-read']);
  213 |   if (browserName !== 'webkit')
  214 |     expect(await getPermission(page, 'clipboard-read')).toBe('granted');
  215 |   // There is no 'clipboard-write' permission in WebKit Web API.
  216 |   if (browserName === 'chromium')
  217 |     await context.grantPermissions(['clipboard-write']);
  218 |   await page.evaluate(() => navigator.clipboard.writeText('test content'));
  219 |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe('test content');
  220 | });
  221 | 
  222 | it('storage access', {
  223 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/31227' }
  224 | }, async ({ page, context, server, browserName }) => {
  225 |   it.skip(browserName !== 'chromium', 'chromium-only api');
  226 | 
> 227 |   await context.grantPermissions(['storage-access']);
      |                 ^ Error: browserContext.grantPermissions: Protocol error (Browser.grantPermissions): Unsupported native permission: storageAccess
  228 |   expect(await getPermission(page, 'storage-access')).toBe('granted');
  229 |   server.setRoute('/set-cookie.html', (req, res) => {
  230 |     res.setHeader('Set-Cookie', 'name=value; Path=/; SameSite=Strict; Secure');
  231 |     res.end();
  232 |   });
  233 |   server.setRoute('/my-frame.html', (req, res) => {
  234 |     res.setHeader('Content-type', 'text/html');
  235 |     res.end(`<iframe src="${server.CROSS_PROCESS_PREFIX + '/empty.html'}"></iframe>`);
  236 |   });
  237 | 
  238 |   // Navigate once to the domain as top level.
  239 |   await page.goto(server.CROSS_PROCESS_PREFIX + '/set-cookie.html');
  240 |   await page.goto(server.PREFIX + '/my-frame.html');
  241 | 
  242 |   const frame = page.frames()[1];
  243 |   expect(await getPermission(frame, 'storage-access')).toBe('granted');
  244 |   const access = await frame.evaluate(() => document.requestStorageAccess().then(() => true, () => false));
  245 |   expect(access).toBe(true);
  246 |   expect(await frame.evaluate(() => document.hasStorageAccess())).toBe(true);
  247 | });
  248 | 
  249 | it.describe(() => {
  250 |   // Secure context
  251 |   it.use({ ignoreHTTPSErrors: true, });
  252 | 
  253 |   it('should be able to use the local-fonts API', async ({ page, context, httpsServer, browserName, channel, headless }) => {
  254 |     it.skip(browserName !== 'chromium', 'chromium-only api');
  255 |     it.skip(!!channel && channel.startsWith('msedge'), 'always times out in edge');
  256 |     it.fixme(!headless, 'times out in headed');
  257 |     it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36113' });
  258 | 
  259 |     await page.goto(httpsServer.EMPTY_PAGE);
  260 |     expect(await getPermission(page, 'local-fonts')).toBe('prompt');
  261 |     await context.grantPermissions(['local-fonts']);
  262 |     expect(await getPermission(page, 'local-fonts')).toBe('granted');
  263 |     expect(await page.evaluate(async () => (await (window as any).queryLocalFonts()).length > 0)).toBe(true);
  264 |   });
  265 | });
  266 | 
  267 | it('local network request is allowed from public origin', {
  268 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/37861' }
  269 | }, async ({ page, context, server, browserName, channel, browserMajorVersion }) => {
  270 |   it.skip(browserName === 'webkit');
  271 |   it.skip(browserName === 'chromium' && browserMajorVersion < 145, 'local-network-access permission support has changed between versions');
  272 | 
  273 |   if (browserName === 'chromium' || browserName === 'firefox')
  274 |     await context.grantPermissions(['local-network-access']);
  275 |   const serverRequests = [];
  276 |   server.setRoute('/cors', (req, res) => {
  277 |     serverRequests.push(`${req.method} ${req.url}`);
  278 |     if (req.method === 'OPTIONS') {
  279 |       res.writeHead(204, {
  280 |         'Access-Control-Allow-Origin': '*',
  281 |         'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
  282 |         'Access-Control-Allow-Headers': '*',
  283 |       });
  284 |       res.end();
  285 |       return;
  286 |     }
  287 |     res.writeHead(200, { 'Content-type': 'text/plain', 'Access-Control-Allow-Origin': '*' });
  288 |     res.end('Hello there!');
  289 |   });
  290 |   const clientRequests = [];
  291 |   // Has to be a public origin.
  292 |   await page.goto('https://demo.playwright.dev/todomvc/');
  293 |   page.on('request', request => {
  294 |     clientRequests.push(`${request.method()} ${request.url()}`);
  295 |   });
  296 |   const response = await page.evaluate(async url => {
  297 |     const response = await fetch(url, {
  298 |       method: 'POST',
  299 |       body: '',
  300 |       headers: {
  301 |         'Content-Type': 'application/json',
  302 |         'X-Custom-Header': 'test-value'
  303 |       }
  304 |     });
  305 |     return await response.text();
  306 |   }, server.CROSS_PROCESS_PREFIX + '/cors').catch(e => e.message);
  307 |   expect(response).toBe('Hello there!');
  308 |   expect(serverRequests).toEqual([
  309 |     'OPTIONS /cors',
  310 |     'POST /cors',
  311 |   ]);
  312 |   expect(clientRequests).toEqual([
  313 |     `POST ${server.CROSS_PROCESS_PREFIX}/cors`,
  314 |   ]);
  315 | });
  316 | 
  317 | it('can request screen-wake-lock', {
  318 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/39115' }
  319 | }, async ({ page, context }) => {
  320 |   await context.grantPermissions(['screen-wake-lock']);
  321 |   await page.route('**/*', route => route.fulfill({ status: 200, body: '<div>Hello there!</div>', contentType: 'text/html' }));
  322 |   await page.goto('https://example.com');
  323 |   await page.evaluate(() => navigator.wakeLock.request('screen'));
  324 | });
  325 | 
  326 | it.describe('camera and microphone', () => {
  327 |   // WebKit exposes deterministic mock capture devices; capture is gated on the
```