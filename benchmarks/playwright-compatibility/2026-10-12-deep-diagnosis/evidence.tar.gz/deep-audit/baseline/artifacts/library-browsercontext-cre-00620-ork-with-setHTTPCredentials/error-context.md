# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-credentials.spec.ts >> should work with setHTTPCredentials
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-credentials.spec.ts:37:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Matcher error: received value must not be null nor undefined

Received has value: undefined
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2018 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { browserTest as base, expect } from '../config/browserTest';
  19  | 
  20  | const it = base.extend<{ failsOn401: boolean }>({
  21  |   failsOn401: async ({ browserName, isHeadlessShell }, use) => {
  22  |     await use(browserName === 'chromium' && !isHeadlessShell);
  23  |   },
  24  | });
  25  | 
  26  | it('should fail without credentials', async ({ browser, server, failsOn401 }) => {
  27  |   server.setAuth('/empty.html', 'user', 'pass');
  28  |   const context = await browser.newContext();
  29  |   const page = await context.newPage();
  30  |   const responseOrError = await page.goto(server.EMPTY_PAGE).catch(e => e);
  31  |   if (failsOn401)
  32  |     expect(responseOrError.message).toContain('net::ERR_INVALID_AUTH_CREDENTIALS');
  33  |   else
  34  |     expect(responseOrError.status()).toBe(401);
  35  | });
  36  | 
  37  | it('should work with setHTTPCredentials', async ({ browser, server, failsOn401 }) => {
  38  |   server.setAuth('/empty.html', 'user', 'pass');
  39  |   const context = await browser.newContext();
  40  |   const page = await context.newPage();
  41  | 
  42  |   let responseOrError = await page.goto(server.EMPTY_PAGE).catch(e => e);
  43  |   if (failsOn401)
> 44  |     expect(responseOrError.message).toContain('net::ERR_INVALID_AUTH_CREDENTIALS');
      |                                     ^ Error: expect(received).toContain(expected) // indexOf
  45  |   else
  46  |     expect(responseOrError.status()).toBe(401);
  47  | 
  48  |   await context.setHTTPCredentials({ username: 'user', password: 'pass' });
  49  |   responseOrError = await page.reload();
  50  |   expect(responseOrError.status()).toBe(200);
  51  |   await context.close();
  52  | });
  53  | 
  54  | it('should work with correct credentials @smoke', async ({ browser, server }) => {
  55  |   server.setAuth('/empty.html', 'user', 'pass');
  56  |   const context = await browser.newContext({
  57  |     httpCredentials: { username: 'user', password: 'pass' }
  58  |   });
  59  |   const page = await context.newPage();
  60  |   const response = await page.goto(server.EMPTY_PAGE);
  61  |   expect(response!.status()).toBe(200);
  62  |   await context.close();
  63  | });
  64  | 
  65  | it('should fail with wrong credentials', async ({ browser, server }) => {
  66  |   server.setAuth('/empty.html', 'user', 'pass');
  67  |   const context = await browser.newContext({
  68  |     httpCredentials: { username: 'foo', password: 'bar' }
  69  |   });
  70  |   const page = await context.newPage();
  71  |   const response = await page.goto(server.EMPTY_PAGE);
  72  |   expect(response!.status()).toBe(401);
  73  |   await context.close();
  74  | });
  75  | 
  76  | it('should return resource body', async ({ browser, server }) => {
  77  |   server.setAuth('/playground.html', 'user', 'pass');
  78  |   const context = await browser.newContext({
  79  |     httpCredentials: { username: 'user', password: 'pass' }
  80  |   });
  81  |   const page = await context.newPage();
  82  |   const response = await page.goto(server.PREFIX + '/playground.html');
  83  |   expect(response!.status()).toBe(200);
  84  |   expect(await page.title()).toBe('Playground');
  85  |   expect((await response!.body()).toString()).toContain('Playground');
  86  |   await context.close();
  87  | });
  88  | 
  89  | it('should work with correct credentials and matching origin', async ({ browser, server }) => {
  90  |   server.setAuth('/empty.html', 'user', 'pass');
  91  |   const context = await browser.newContext({
  92  |     httpCredentials: { username: 'user', password: 'pass', origin: server.PREFIX }
  93  |   });
  94  |   const page = await context.newPage();
  95  |   const response = await page.goto(server.EMPTY_PAGE);
  96  |   expect(response!.status()).toBe(200);
  97  |   await context.close();
  98  | });
  99  | 
  100 | it('should work with correct credentials and matching origin case insensitive', async ({ browser, server }) => {
  101 |   server.setAuth('/empty.html', 'user', 'pass');
  102 |   const context = await browser.newContext({
  103 |     httpCredentials: { username: 'user', password: 'pass', origin: server.PREFIX.toUpperCase() }
  104 |   });
  105 |   const page = await context.newPage();
  106 |   const response = await page.goto(server.EMPTY_PAGE);
  107 |   expect(response!.status()).toBe(200);
  108 |   await context.close();
  109 | });
  110 | 
  111 | it('should fail with correct credentials and mismatching scheme', async ({ browser, server, failsOn401 }) => {
  112 |   server.setAuth('/empty.html', 'user', 'pass');
  113 |   const context = await browser.newContext({
  114 |     httpCredentials: { username: 'user', password: 'pass', origin: server.PREFIX.replace('http://', 'https://') }
  115 |   });
  116 |   const page = await context.newPage();
  117 |   const responseOrError = await page.goto(server.EMPTY_PAGE).catch(e => e);
  118 |   if (failsOn401)
  119 |     expect(responseOrError.message).toContain('net::ERR_INVALID_AUTH_CREDENTIALS');
  120 |   else
  121 |     expect(responseOrError.status()).toBe(401);
  122 |   await context.close();
  123 | });
  124 | 
  125 | it('should fail with correct credentials and mismatching hostname', async ({ browser, server, failsOn401 }) => {
  126 |   server.setAuth('/empty.html', 'user', 'pass');
  127 |   const hostname = new URL(server.PREFIX).hostname;
  128 |   const origin = server.PREFIX.replace(hostname, 'mismatching-hostname');
  129 |   const context = await browser.newContext({
  130 |     httpCredentials: { username: 'user', password: 'pass', origin: origin }
  131 |   });
  132 |   const page = await context.newPage();
  133 |   const responseOrError = await page.goto(server.EMPTY_PAGE).catch(e => e);
  134 |   if (failsOn401)
  135 |     expect(responseOrError.message).toContain('net::ERR_INVALID_AUTH_CREDENTIALS');
  136 |   else
  137 |     expect(responseOrError.status()).toBe(401);
  138 |   await context.close();
  139 | });
  140 | 
  141 | it('should fail with correct credentials and mismatching port', async ({ browser, server, failsOn401 }) => {
  142 |   server.setAuth('/empty.html', 'user', 'pass');
  143 |   const origin = server.PREFIX.replace(server.PORT.toString(), (server.PORT + 1).toString());
  144 |   const context = await browser.newContext({
```