# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-aria-snapshot-ai.spec.ts >> should persist iframe references
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-aria-snapshot-ai.spec.ts:175:3

# Error details

```
Error: page.setContent: Target page, context or browser has been closed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  76  |   const list = page.frames()[1].locator('ul');
  77  |   const snapshot = await list.ariaSnapshot({ mode: 'ai' });
  78  |   expect(snapshot).toContainYaml(`
  79  |     - list [ref=f1e1]:
  80  |       - listitem [ref=f1e2]: Item 1
  81  |       - listitem [ref=f1e3]: Item 2
  82  |   `);
  83  | });
  84  | 
  85  | it('should limit depth across iframe boundary', async ({ page }) => {
  86  |   await page.setContent(`
  87  |     <nav>
  88  |       <iframe srcdoc="<ul><li><button>Deep</button></li></ul>"></iframe>
  89  |     </nav>
  90  |   `);
  91  | 
  92  |   const snapshot = await snapshotForAI(page, { depth: 3 });
  93  |   expect(snapshot).toContainYaml(`
  94  |     - navigation [ref=e2]:
  95  |       - iframe [ref=e3]:
  96  |         - list [ref=f1e2]:
  97  |           - listitem [ref=f1e3]
  98  |   `);
  99  |   expect(snapshot).not.toContain('button');
  100 | });
  101 | 
  102 | it('should stitch all frame snapshots', async ({ page, server }) => {
  103 |   await page.goto(server.PREFIX + '/frames/nested-frames.html');
  104 |   const snapshot = await snapshotForAI(page);
  105 |   expect(snapshot).toContainYaml(`
  106 |     - generic [active] [ref=e1]:
  107 |       - iframe [ref=e2]:
  108 |         - generic [ref=f1e1]:
  109 |           - iframe [ref=f1e2]:
  110 |             - generic [ref=f3e1]: Hi, I'm frame
  111 |           - iframe [ref=f1e3]:
  112 |             - generic [ref=f4e1]: Hi, I'm frame
  113 |       - iframe [ref=e3]:
  114 |         - generic [ref=f2e1]: Hi, I'm frame
  115 |   `);
  116 | 
  117 |   const href = await page.locator('aria-ref=e1').evaluate(e => e.ownerDocument.defaultView.location.href);
  118 |   expect(href).toBe(server.PREFIX + '/frames/nested-frames.html');
  119 | 
  120 |   const href2 = await page.locator('aria-ref=f1e2').evaluate(e => e.ownerDocument.defaultView.location.href);
  121 |   expect(href2).toBe(server.PREFIX + '/frames/two-frames.html');
  122 | 
  123 |   const href3 = await page.locator('aria-ref=f4e2').evaluate(e => e.ownerDocument.defaultView.location.href);
  124 |   expect(href3).toBe(server.PREFIX + '/frames/frame.html');
  125 | 
  126 |   {
  127 |     const resolved = await page.locator('aria-ref=e1').normalize();
  128 |     expect(resolved.toString()).toBe(`locator('body')`);
  129 |   }
  130 |   {
  131 |     const resolved = await page.locator('aria-ref=f4e2').normalize();
  132 |     expect(resolved.toString()).toBe(`locator('iframe[name="2frames"]').contentFrame().locator('iframe[name="dos"]').contentFrame().getByText('Hi, I\\'m frame')`);
  133 |   }
  134 |   {
  135 |     // Should tolerate .describe().
  136 |     const resolved = await page.locator('aria-ref=f3e2').describe('foo bar').normalize();
  137 |     expect(resolved.toString()).toBe(`locator('iframe[name=\"2frames\"]').contentFrame().locator('iframe[name=\"uno\"]').contentFrame().getByText('Hi, I\\'m frame')`);
  138 |   }
  139 |   {
  140 |     const error = await page.locator('aria-ref=e1000').normalize().catch(e => e);
  141 |     expect(error.message).toContain(`No element matching aria-ref=e1000`);
  142 |   }
  143 | });
  144 | 
  145 | it('should re-number refs across navigations but not same-document navigations', async ({ page, server }) => {
  146 |   server.setRoute('/one.html', (req, res) => {
  147 |     res.setHeader('Content-Type', 'text/html');
  148 |     res.end('<button>One</button>');
  149 |   });
  150 |   server.setRoute('/two.html', (req, res) => {
  151 |     res.setHeader('Content-Type', 'text/html');
  152 |     res.end('<button>Two</button>');
  153 |   });
  154 | 
  155 |   // The first committed document keeps the base seq, so the main frame has no prefix.
  156 |   await page.goto(server.PREFIX + '/one.html');
  157 |   const oneRef = (await snapshotForAI(page)).match(/button "One" \[ref=(e\d+)\]/)![1];
  158 |   await expect(page.locator(`aria-ref=${oneRef}`)).toHaveText('One');
  159 | 
  160 |   // Cross-document navigation re-numbers the main frame, so its refs gain a frame prefix.
  161 |   await page.goto(server.PREFIX + '/two.html');
  162 |   const twoRef = (await snapshotForAI(page)).match(/button "Two" \[ref=(f\d+e\d+)\]/)![1];
  163 |   await expect(page.locator(`aria-ref=${twoRef}`)).toHaveText('Two');
  164 | 
  165 |   // The stale ref from the previous document must not resolve against the new one.
  166 |   const error = await page.locator(`aria-ref=${oneRef}`).normalize().catch(e => e);
  167 |   expect(error.message).toContain(`No element matching aria-ref=${oneRef}`);
  168 | 
  169 |   // Same-document navigation keeps refs intact.
  170 |   await page.evaluate(() => history.pushState({}, '', '/pushed.html'));
  171 |   expect(await snapshotForAI(page)).toContain(`button "Two" [ref=${twoRef}]`);
  172 |   await expect(page.locator(`aria-ref=${twoRef}`)).toHaveText('Two');
  173 | });
  174 | 
  175 | it('should persist iframe references', async ({ page }) => {
> 176 |   await page.setContent(`
      |              ^ Error: page.setContent: Target page, context or browser has been closed
  177 |     <ul>
  178 |       <li><iframe srcdoc="<button>button1</button>"></iframe></li>
  179 |       <li><iframe srcdoc="<button>button2</button>"></iframe></li>
  180 |     </ul>
  181 |   `);
  182 |   expect(await snapshotForAI(page)).toContainYaml(`
  183 |     - list [ref=e2]:
  184 |       - listitem [ref=e3]:
  185 |         - iframe [ref=e4]:
  186 |           - button "button1" [ref=f1e2]
  187 |       - listitem [ref=e5]:
  188 |         - iframe [ref=e6]:
  189 |           - button "button2" [ref=f2e2]
  190 |   `);
  191 | 
  192 |   await page.evaluate(() => document.querySelector('iframe').remove());
  193 |   expect(await snapshotForAI(page)).toContainYaml(`
  194 |     - list [ref=e2]:
  195 |       - listitem [ref=e3]
  196 |       - listitem [ref=e5]:
  197 |         - iframe [ref=e6]:
  198 |           - button "button2" [ref=f2e2]
  199 |   `);
  200 |   await expect(page.locator('aria-ref=f2e2')).toHaveText('button2');
  201 | 
  202 |   await page.evaluate(() => {
  203 |     const frame = document.createElement('iframe');
  204 |     frame.setAttribute('srcdoc', '<button>button1</button>');
  205 |     document.querySelector('li').appendChild(frame);
  206 |   });
  207 |   expect(await snapshotForAI(page)).toContainYaml(`
  208 |     - list [ref=e2]:
  209 |       - listitem [ref=e3]:
  210 |         - iframe [ref=e7]:
  211 |           - button "button1" [ref=f3e2]
  212 |       - listitem [ref=e5]:
  213 |         - iframe [ref=e6]:
  214 |           - button "button2" [ref=f2e2]
  215 |   `);
  216 |   await expect(page.locator('aria-ref=f3e2')).toHaveText('button1');
  217 |   await expect(page.locator('aria-ref=f2e2')).toHaveText('button2');
  218 | });
  219 | 
  220 | it('should not generate refs for elements with pointer-events:none', async ({ page }) => {
  221 |   await page.setContent(`
  222 |     <button style="pointer-events: none">no-ref</button>
  223 |     <div style="pointer-events: none">
  224 |       <button style="pointer-events: auto">with-ref</button>
  225 |     </div>
  226 |     <div style="pointer-events: none">
  227 |       <div style="pointer-events: initial">
  228 |         <button>with-ref</button>
  229 |       </div>
  230 |     </div>
  231 |     <div style="pointer-events: none">
  232 |       <div style="pointer-events: auto">
  233 |         <button>with-ref</button>
  234 |       </div>
  235 |     </div>
  236 |     <div style="pointer-events: auto">
  237 |       <div style="pointer-events: none">
  238 |         <button>no-ref</button>
  239 |       </div>
  240 |     </div>
  241 |   `);
  242 | 
  243 |   const snapshot = await snapshotForAI(page);
  244 |   expect(snapshot).toContainYaml(`
  245 |     - generic [active] [ref=e1]:
  246 |       - button "no-ref"
  247 |       - button "with-ref" [ref=e2]
  248 |       - button "with-ref" [ref=e4]
  249 |       - button "with-ref" [ref=e6]
  250 |       - generic [ref=e7]:
  251 |         - generic:
  252 |           - button "no-ref"
  253 |   `);
  254 | });
  255 | 
  256 | it('emit generic roles for nodes w/o roles', async ({ page }) => {
  257 |   await page.setContent(`
  258 |     <style>
  259 |     input {
  260 |       width: 0;
  261 |       height: 0;
  262 |       opacity: 0;
  263 |     }
  264 |     </style>
  265 |     <div>
  266 |       <label>
  267 |         <span>
  268 |           <input type="radio" value="Apple" checked="">
  269 |         </span>
  270 |         <span>Apple</span>
  271 |       </label>
  272 |       <label>
  273 |         <span>
  274 |           <input type="radio" value="Pear">
  275 |         </span>
  276 |         <span>Pear</span>
```