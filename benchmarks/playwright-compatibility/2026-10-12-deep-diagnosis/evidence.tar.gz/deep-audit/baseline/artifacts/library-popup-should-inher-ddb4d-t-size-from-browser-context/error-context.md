# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/popup.spec.ts >> should inherit viewport size from browser context
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/popup.spec.ts:117:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

  Object {
-   "height": 500,
-   "width": 400,
+   "height": 0,
+   "width": 0,
  }
```

# Test source

```ts
  28  |   await page.setContent('<a target=_blank rel=noopener href="/popup/popup.html">link</a>');
  29  |   const requestPromise = server.waitForRequest('/popup/popup.html');
  30  |   const [popup] = await Promise.all([
  31  |     context.waitForEvent('page'),
  32  |     page.click('a'),
  33  |   ]);
  34  |   await popup.waitForLoadState('domcontentloaded');
  35  |   const userAgent = await popup.evaluate(() => window['initialUserAgent']);
  36  |   const request = await requestPromise;
  37  |   await context.close();
  38  |   expect(userAgent).toBe('hey');
  39  |   expect(request.headers['user-agent']).toBe('hey');
  40  | });
  41  | 
  42  | it('should respect routes from browser context', async function({ browser, server }) {
  43  |   const context = await browser.newContext();
  44  |   const page = await context.newPage();
  45  |   await page.goto(server.EMPTY_PAGE);
  46  |   await page.setContent('<a target=_blank rel=noopener href="empty.html">link</a>');
  47  |   let intercepted = false;
  48  |   await context.route('**/empty.html', route => {
  49  |     void route.continue();
  50  |     intercepted = true;
  51  |   });
  52  |   await Promise.all([
  53  |     context.waitForEvent('page'),
  54  |     page.click('a'),
  55  |   ]);
  56  |   await context.close();
  57  |   expect(intercepted).toBe(true);
  58  | });
  59  | 
  60  | it('should inherit extra headers from browser context', async function({ browser, server }) {
  61  |   const context = await browser.newContext({
  62  |     extraHTTPHeaders: { 'foo': 'bar' },
  63  |   });
  64  |   const page = await context.newPage();
  65  |   await page.goto(server.EMPTY_PAGE);
  66  |   const requestPromise = server.waitForRequest('/dummy.html');
  67  |   await page.evaluate(url => window['_popup'] = window.open(url), server.PREFIX + '/dummy.html');
  68  |   const request = await requestPromise;
  69  |   await context.close();
  70  |   expect(request.headers['foo']).toBe('bar');
  71  | });
  72  | 
  73  | it('should inherit offline from browser context', async function({ browser, server }) {
  74  |   const context = await browser.newContext();
  75  |   const page = await context.newPage();
  76  |   await page.goto(server.EMPTY_PAGE);
  77  |   await context.setOffline(true);
  78  |   const online = await page.evaluate(url => {
  79  |     const win = window.open(url);
  80  |     return win.navigator.onLine;
  81  |   }, server.PREFIX + '/dummy.html');
  82  |   await context.close();
  83  |   expect(online).toBe(false);
  84  | });
  85  | 
  86  | it('should inherit http credentials from browser context', async function({ browser, server }) {
  87  |   server.setAuth('/title.html', 'user', 'pass');
  88  |   const context = await browser.newContext({
  89  |     httpCredentials: { username: 'user', password: 'pass' }
  90  |   });
  91  |   const page = await context.newPage();
  92  |   await page.goto(server.EMPTY_PAGE);
  93  |   const [popup] = await Promise.all([
  94  |     page.waitForEvent('popup'),
  95  |     page.evaluate(url => window['_popup'] = window.open(url), server.PREFIX + '/title.html'),
  96  |   ]);
  97  |   await popup.waitForLoadState('domcontentloaded');
  98  |   expect(await popup.title()).toBe('Woof-Woof');
  99  |   await context.close();
  100 | });
  101 | 
  102 | it('should inherit touch support from browser context', async function({ browser, server }) {
  103 |   const context = await browser.newContext({
  104 |     viewport: { width: 400, height: 500 },
  105 |     hasTouch: true
  106 |   });
  107 |   const page = await context.newPage();
  108 |   await page.goto(server.EMPTY_PAGE);
  109 |   const hasTouch = await page.evaluate(() => {
  110 |     const win = window.open('');
  111 |     return 'ontouchstart' in win;
  112 |   });
  113 |   await context.close();
  114 |   expect(hasTouch).toBe(true);
  115 | });
  116 | 
  117 | it('should inherit viewport size from browser context', async function({ browser, server }) {
  118 |   const context = await browser.newContext({
  119 |     viewport: { width: 400, height: 500 }
  120 |   });
  121 |   const page = await context.newPage();
  122 |   await page.goto(server.EMPTY_PAGE);
  123 |   const size = await page.evaluate(() => {
  124 |     const win = window.open('about:blank');
  125 |     return { width: win.innerWidth, height: win.innerHeight };
  126 |   });
  127 |   await context.close();
> 128 |   expect(size).toEqual({ width: 400, height: 500 });
      |                ^ Error: expect(received).toEqual(expected) // deep equality
  129 | });
  130 | 
  131 | it('should use viewport size from window features', async function({ browser, server, browserName }) {
  132 |   const context = await browser.newContext({
  133 |     viewport: { width: 700, height: 700 }
  134 |   });
  135 |   const page = await context.newPage();
  136 |   await page.goto(server.EMPTY_PAGE);
  137 |   const [size, popup] = await Promise.all([
  138 |     page.evaluate(async () => {
  139 |       const win = window.open(window.location.href, 'Title', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=300,top=0,left=0');
  140 |       await new Promise<void>(resolve => {
  141 |         const interval = window.builtins.setInterval(() => {
  142 |           if (win.innerWidth === 600 && win.innerHeight === 300) {
  143 |             window.builtins.clearInterval(interval);
  144 |             resolve();
  145 |           }
  146 |         }, 10);
  147 |       });
  148 |       return { width: win.innerWidth, height: win.innerHeight };
  149 |     }),
  150 |     page.waitForEvent('popup'),
  151 |   ]);
  152 |   await popup.setViewportSize({ width: 500, height: 400 });
  153 |   await popup.waitForLoadState();
  154 |   const resized = await popup.evaluate(() => ({ width: window.innerWidth, height: window.innerHeight }));
  155 |   await context.close();
  156 |   expect(size).toEqual({ width: 600, height: 300 });
  157 |   expect(resized).toEqual({ width: 500, height: 400 });
  158 | });
  159 | 
  160 | it('should respect routes from browser context when using window.open', async function({ browser, server }) {
  161 |   const context = await browser.newContext();
  162 |   const page = await context.newPage();
  163 |   await page.goto(server.EMPTY_PAGE);
  164 |   let intercepted = false;
  165 |   await context.route('**/empty.html', route => {
  166 |     void route.continue();
  167 |     intercepted = true;
  168 |   });
  169 |   await Promise.all([
  170 |     page.waitForEvent('popup'),
  171 |     page.evaluate(url => window['__popup'] = window.open(url), server.EMPTY_PAGE),
  172 |   ]);
  173 |   expect(intercepted).toBe(true);
  174 |   await context.close();
  175 | });
  176 | 
  177 | it('BrowserContext.addInitScript should apply to an in-process popup', async function({ browser, server }) {
  178 |   const context = await browser.newContext();
  179 |   await context.addInitScript(() => window['injected'] = 123);
  180 |   const page = await context.newPage();
  181 |   await page.goto(server.EMPTY_PAGE);
  182 |   const injected = await page.evaluate(() => {
  183 |     const win = window.open('about:blank');
  184 |     return win['injected'];
  185 |   });
  186 |   await context.close();
  187 |   expect(injected).toBe(123);
  188 | });
  189 | 
  190 | it('BrowserContext.addInitScript should apply to a cross-process popup', async function({ browser, server }) {
  191 |   const context = await browser.newContext();
  192 |   await context.addInitScript(() => window['injected'] = 123);
  193 |   const page = await context.newPage();
  194 |   await page.goto(server.EMPTY_PAGE);
  195 |   const [popup] = await Promise.all([
  196 |     page.waitForEvent('popup'),
  197 |     page.evaluate(url => window.open(url), server.CROSS_PROCESS_PREFIX + '/title.html'),
  198 |   ]);
  199 |   expect(await popup.evaluate('injected')).toBe(123);
  200 |   await popup.reload();
  201 |   expect(await popup.evaluate('injected')).toBe(123);
  202 |   await context.close();
  203 | });
  204 | 
  205 | it('should expose function from browser context', async function({ browser, server }) {
  206 |   const context = await browser.newContext();
  207 |   const messages = [];
  208 |   await context.exposeFunction('add', (a, b) => {
  209 |     messages.push('binding');
  210 |     return a + b;
  211 |   });
  212 |   const page = await context.newPage();
  213 |   context.on('page', () => messages.push('page'));
  214 |   await page.goto(server.EMPTY_PAGE);
  215 |   const added = await page.evaluate(async () => {
  216 |     const win = window.open('about:blank');
  217 |     return win['add'](9, 4);
  218 |   });
  219 |   await context.close();
  220 |   expect(added).toBe(13);
  221 |   expect(messages.join('|')).toBe('page|binding');
  222 | });
  223 | 
  224 | it('should not dispatch binding on a closed page', async function({ browser, server, browserName }) {
  225 |   const context = await browser.newContext();
  226 |   let wasClosed: boolean | undefined;
  227 |   await context.exposeBinding('add', (source, a, b) => {
  228 |     wasClosed = source.page.isClosed();
```