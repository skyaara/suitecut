# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/page-event-crash.spec.ts >> should be able to close context when page crashes
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/page-event-crash.spec.ts:92:1

# Error details

```
Error: page.waitForEvent: Target page, context or browser has been closed
=========================== logs ===========================
waiting for event "crash"
============================================================
```

```
Error: browserContext.close: Target page, context or browser has been closed
```