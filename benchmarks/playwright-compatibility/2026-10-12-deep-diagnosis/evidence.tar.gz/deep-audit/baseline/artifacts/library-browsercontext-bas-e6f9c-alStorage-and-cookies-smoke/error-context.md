# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-basic.spec.ts >> should isolate localStorage and cookies @smoke
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-basic.spec.ts:118:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 1
```

# Test source

```ts
  60  |   const CLICK_COUNT = 20;
  61  |   await Promise.all([
  62  |     clickInPage(page1, CLICK_COUNT),
  63  |     clickInPage(page2, CLICK_COUNT),
  64  |   ]);
  65  |   expect(await getClicks(page1)).toBe(CLICK_COUNT);
  66  |   expect(await getClicks(page2)).toBe(CLICK_COUNT);
  67  | 
  68  |   await page1.close();
  69  |   await page2.close();
  70  | });
  71  | 
  72  | it('should be able to hover across browser contexts in parallel', async function({ browser, browserName, headless }) {
  73  |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40562' });
  74  |   it.fixme(browserName === 'firefox' && !headless, 'Hover is flaky in headed Firefox');
  75  | 
  76  |   const html = `
  77  |     <style>
  78  |       [role="tooltip"] { display: none; }
  79  |       [role="tooltip"].visible { display: block; }
  80  |     </style>
  81  |     <button>Hover me</button>
  82  |     <div role="tooltip">Tooltip content</div>
  83  |     <script>
  84  |       const button = document.querySelector('button');
  85  |       const tooltip = document.querySelector('[role="tooltip"]');
  86  |       button.addEventListener('pointerenter', () => tooltip.classList.add('visible'));
  87  |       button.addEventListener('pointerleave', () => tooltip.classList.remove('visible'));
  88  |     </script>
  89  |   `;
  90  | 
  91  |   const pages: Page[] = await Promise.all([1, 2, 3, 4, 5].map(async () => {
  92  |     const context = await browser.newContext();
  93  |     const page = await context.newPage();
  94  |     await page.setContent(html);
  95  |     return page;
  96  |   }));
  97  | 
  98  |   await Promise.all(pages.map(async (page, index) => {
  99  |     await page.getByRole('button', { name: 'Hover me' }).hover();
  100 |     await expect.soft(page.getByRole('tooltip'), `Tooltip for page ${index + 1} should be visible`).toBeVisible();
  101 |   }));
  102 | 
  103 |   await Promise.all(pages.map(page => page.context().close()));
  104 | });
  105 | 
  106 | it('window.open should use parent tab context', async function({ browser, server }) {
  107 |   const context = await browser.newContext();
  108 |   const page = await context.newPage();
  109 |   await page.goto(server.EMPTY_PAGE);
  110 |   const [popup] = await Promise.all([
  111 |     page.waitForEvent('popup'),
  112 |     page.evaluate(url => window.open(url), server.EMPTY_PAGE)
  113 |   ]);
  114 |   expect(popup.context()).toBe(context);
  115 |   await context.close();
  116 | });
  117 | 
  118 | it('should isolate localStorage and cookies @smoke', async function({ browser, server }) {
  119 |   // Create two incognito contexts.
  120 |   const context1 = await browser.newContext();
  121 |   const context2 = await browser.newContext();
  122 |   expect(context1.pages().length).toBe(0);
  123 |   expect(context2.pages().length).toBe(0);
  124 | 
  125 |   // Create a page in first incognito context.
  126 |   const page1 = await context1.newPage();
  127 |   await page1.goto(server.EMPTY_PAGE);
  128 |   await page1.evaluate(() => {
  129 |     localStorage.setItem('name', 'page1');
  130 |     document.cookie = 'name=page1';
  131 |   });
  132 | 
  133 |   expect(context1.pages().length).toBe(1);
  134 |   expect(context2.pages().length).toBe(0);
  135 | 
  136 |   // Create a page in second incognito context.
  137 |   const page2 = await context2.newPage();
  138 |   await page2.goto(server.EMPTY_PAGE);
  139 |   await page2.evaluate(() => {
  140 |     localStorage.setItem('name', 'page2');
  141 |     document.cookie = 'name=page2';
  142 |   });
  143 | 
  144 |   expect(context1.pages().length).toBe(1);
  145 |   expect(context2.pages().length).toBe(1);
  146 |   expect(context1.pages()[0]).toBe(page1);
  147 |   expect(context2.pages()[0]).toBe(page2);
  148 | 
  149 |   // Make sure pages don't share localstorage or cookies.
  150 |   expect(await page1.evaluate(() => localStorage.getItem('name'))).toBe('page1');
  151 |   expect(await page1.evaluate(() => document.cookie)).toBe('name=page1');
  152 |   expect(await page2.evaluate(() => localStorage.getItem('name'))).toBe('page2');
  153 |   expect(await page2.evaluate(() => document.cookie)).toBe('name=page2');
  154 | 
  155 |   // Cleanup contexts.
  156 |   await Promise.all([
  157 |     context1.close(),
  158 |     context2.close()
  159 |   ]);
> 160 |   expect(browser.contexts().length).toBe(0);
      |                                     ^ Error: expect(received).toBe(expected) // Object.is equality
  161 | });
  162 | 
  163 | it('should propagate default viewport to the page', async ({ browser }) => {
  164 |   const context = await browser.newContext({ viewport: { width: 456, height: 789 } });
  165 |   const page = await context.newPage();
  166 |   await verifyViewport(page, 456, 789);
  167 |   await context.close();
  168 | });
  169 | 
  170 | it('should make a copy of default viewport', async ({ browser }) => {
  171 |   const viewport = { width: 456, height: 789 };
  172 |   const context = await browser.newContext({ viewport });
  173 |   viewport.width = 567;
  174 |   const page = await context.newPage();
  175 |   await verifyViewport(page, 456, 789);
  176 |   await context.close();
  177 | });
  178 | 
  179 | it('should respect deviceScaleFactor', async ({ browser }) => {
  180 |   const context = await browser.newContext({ deviceScaleFactor: 3 });
  181 |   const page = await context.newPage();
  182 |   expect(await page.evaluate('window.devicePixelRatio')).toBe(3);
  183 |   await context.close();
  184 | });
  185 | 
  186 | it('should not allow deviceScaleFactor with null viewport', async ({ browser }) => {
  187 |   const error = await browser.newContext({ viewport: null, deviceScaleFactor: 1 }).catch(e => e);
  188 |   expect(error.message).toContain('"deviceScaleFactor" option is not supported with null "viewport"');
  189 | });
  190 | 
  191 | it('should not allow isMobile with null viewport', async ({ browser }) => {
  192 |   const error = await browser.newContext({ viewport: null, isMobile: true }).catch(e => e);
  193 |   expect(error.message).toContain('"isMobile" option is not supported with null "viewport"');
  194 | });
  195 | 
  196 | it('close() should work for empty context', async ({ browser }) => {
  197 |   const context = await browser.newContext();
  198 |   await context.close();
  199 | });
  200 | 
  201 | it('close() should abort waitForEvent', async ({ browser }) => {
  202 |   const context = await browser.newContext();
  203 |   const promise = context.waitForEvent('page').catch(e => e);
  204 |   await context.close();
  205 |   const error = await promise;
  206 |   expect(error.message).toContain(kTargetClosedErrorMessage);
  207 | });
  208 | 
  209 | it('close() should be callable twice', async ({ browser }) => {
  210 |   const context = await browser.newContext();
  211 |   await context.close();
  212 |   await context.close();
  213 | });
  214 | 
  215 | it('should pass self to close event', async ({ browser }) => {
  216 |   const newContext = await browser.newContext();
  217 |   const [closedContext] = await Promise.all([
  218 |     newContext.waitForEvent('close'),
  219 |     newContext.close()
  220 |   ]);
  221 |   expect(closedContext).toBe(newContext);
  222 | });
  223 | 
  224 | it('should not report frameless pages on error', async ({ browser, server }) => {
  225 |   const context = await browser.newContext();
  226 |   const page = await context.newPage();
  227 |   server.setRoute('/empty.html', (req, res) => {
  228 |     res.end(`<a href="${server.EMPTY_PAGE}" target="_blank">Click me</a>`);
  229 |   });
  230 |   let popup: Page | undefined;
  231 |   context.on('page', p => popup = p);
  232 |   await page.goto(server.EMPTY_PAGE);
  233 |   await page.click('"Click me"');
  234 |   await context.close();
  235 |   if (popup) {
  236 |     // This races on Firefox :/
  237 |     expect(popup.isClosed()).toBeTruthy();
  238 |     expect(popup.mainFrame()).toBeTruthy();
  239 |   }
  240 | });
  241 | 
  242 | it('should return all of the pages', async ({ browser, server }) => {
  243 |   const context = await browser.newContext();
  244 |   const page = await context.newPage();
  245 |   const second = await context.newPage();
  246 |   const allPages = context.pages();
  247 |   expect(allPages.length).toBe(2);
  248 |   expect(allPages).toContain(page);
  249 |   expect(allPages).toContain(second);
  250 |   await context.close();
  251 | });
  252 | 
  253 | it('should close all belonging pages once closing context', async function({ browser }) {
  254 |   const context = await browser.newContext();
  255 |   await context.newPage();
  256 |   expect(context.pages().length).toBe(1);
  257 | 
  258 |   await context.close();
  259 |   expect(context.pages().length).toBe(0);
  260 | });
```