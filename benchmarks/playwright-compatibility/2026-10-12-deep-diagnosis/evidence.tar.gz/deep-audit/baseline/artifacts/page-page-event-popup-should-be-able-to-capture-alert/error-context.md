# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-event-popup.spec.ts >> should be able to capture alert
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-event-popup.spec.ts:61:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: page.waitForEvent: Test timeout of 30000ms exceeded.
=========================== logs ===========================
waiting for event "popup"
============================================================
```

```
Error: page.evaluate: Test timeout of 30000ms exceeded.
```

# Test source

```ts
  1   | /**
  2   |  * Copyright (c) Microsoft Corporation.
  3   |  *
  4   |  * Licensed under the Apache License, Version 2.0 (the "License");
  5   |  * you may not use this file except in compliance with the License.
  6   |  * You may obtain a copy of the License at
  7   |  *
  8   |  * http://www.apache.org/licenses/LICENSE-2.0
  9   |  *
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import { test as it, expect } from './pageTest';
  18  | 
  19  | it('should work @smoke', async ({ page }) => {
  20  |   const [popup] = await Promise.all([
  21  |     page.waitForEvent('popup'),
  22  |     page.evaluate(() => window['__popup'] = window.open('about:blank')),
  23  |   ]);
  24  |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  25  |   expect(await popup.evaluate(() => !!window.opener)).toBe(true);
  26  | });
  27  | 
  28  | it('should work with window features', async ({ page, server }) => {
  29  |   await page.goto(server.EMPTY_PAGE);
  30  |   const [popup] = await Promise.all([
  31  |     page.waitForEvent('popup'),
  32  |     page.evaluate(() => window['__popup'] = window.open(window.location.href, 'Title', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=780,height=200,top=0,left=0')),
  33  |   ]);
  34  |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  35  |   expect(await popup.evaluate(() => !!window.opener)).toBe(true);
  36  | });
  37  | 
  38  | it('should emit for immediately closed popups', async ({ page }) => {
  39  |   const [popup] = await Promise.all([
  40  |     page.waitForEvent('popup'),
  41  |     page.evaluate(() => {
  42  |       const win = window.open('about:blank');
  43  |       win.close();
  44  |     }),
  45  |   ]);
  46  |   expect(popup).toBeTruthy();
  47  | });
  48  | 
  49  | it('should emit for immediately closed popups 2', async ({ page, server, browserName, video }) => {
  50  |   await page.goto(server.EMPTY_PAGE);
  51  |   const [popup] = await Promise.all([
  52  |     page.waitForEvent('popup'),
  53  |     page.evaluate(() => {
  54  |       const win = window.open(window.location.href);
  55  |       win.close();
  56  |     }),
  57  |   ]);
  58  |   expect(popup).toBeTruthy();
  59  | });
  60  | 
  61  | it('should be able to capture alert', async ({ page }) => {
> 62  |   const evaluatePromise = page.evaluate(() => {
      |                                ^ Error: page.evaluate: Test timeout of 30000ms exceeded.
  63  |     const win = window.open('');
  64  |     win.alert('hello');
  65  |   });
  66  |   const [popup, dialog] = await Promise.all([
  67  |     page.waitForEvent('popup'),
  68  |     page.context().waitForEvent('dialog'),
  69  |   ]);
  70  |   expect(dialog.message()).toBe('hello');
  71  |   expect(dialog.page()).toBe(popup);
  72  |   await dialog.dismiss();
  73  |   await evaluatePromise;
  74  | });
  75  | 
  76  | it('should work with empty url', async ({ page }) => {
  77  |   const [popup] = await Promise.all([
  78  |     page.waitForEvent('popup'),
  79  |     page.evaluate(() => window['__popup'] = window.open('')),
  80  |   ]);
  81  |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  82  |   expect(await popup.evaluate(() => !!window.opener)).toBe(true);
  83  | });
  84  | 
  85  | it('should work with noopener and no url', async ({ page }) => {
  86  |   const [popup] = await Promise.all([
  87  |     page.waitForEvent('popup'),
  88  |     page.evaluate(() => window['__popup'] = window.open(undefined, null, 'noopener')),
  89  |   ]);
  90  |   // Chromium reports `about:blank#blocked` here.
  91  |   expect(popup.url().split('#')[0]).toBe('about:blank');
  92  |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  93  |   expect(await popup.evaluate(() => !!window.opener)).toBe(false);
  94  | });
  95  | 
  96  | it('should work with noopener and about:blank', async ({ page }) => {
  97  |   const [popup] = await Promise.all([
  98  |     page.waitForEvent('popup'),
  99  |     page.evaluate(() => window['__popup'] = window.open('about:blank', null, 'noopener')),
  100 |   ]);
  101 |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  102 |   expect(await popup.evaluate(() => !!window.opener)).toBe(false);
  103 | });
  104 | 
  105 | it('should work with noopener and url', async ({ page, server }) => {
  106 |   await page.goto(server.EMPTY_PAGE);
  107 |   const [popup] = await Promise.all([
  108 |     page.waitForEvent('popup'),
  109 |     page.evaluate(url => window['__popup'] = window.open(url, null, 'noopener'), server.EMPTY_PAGE),
  110 |   ]);
  111 |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  112 |   expect(await popup.evaluate(() => !!window.opener)).toBe(false);
  113 | });
  114 | 
  115 | it('should work with clicking target=_blank', async ({ page, server }) => {
  116 |   await page.goto(server.EMPTY_PAGE);
  117 |   await page.setContent('<a target=_blank rel="opener" href="/one-style.html">yo</a>');
  118 |   const [popup] = await Promise.all([
  119 |     page.waitForEvent('popup'),
  120 |     page.click('a'),
  121 |   ]);
  122 |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  123 |   expect(await popup.evaluate(() => !!window.opener)).toBe(true);
  124 |   expect(popup.mainFrame().page()).toBe(popup);
  125 | });
  126 | 
  127 | it('should work with fake-clicking target=_blank and rel=noopener', async ({ page, server }) => {
  128 |   await page.goto(server.EMPTY_PAGE);
  129 |   await page.setContent('<a target=_blank rel=noopener href="/one-style.html">yo</a>');
  130 |   const [popup] = await Promise.all([
  131 |     page.waitForEvent('popup'),
  132 |     page.$eval('a', a => a.click()),
  133 |   ]);
  134 |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  135 |   expect(await popup.evaluate(() => !!window.opener)).toBe(false);
  136 | });
  137 | 
  138 | it('should work with clicking target=_blank and rel=noopener', async ({ page, server }) => {
  139 |   await page.goto(server.EMPTY_PAGE);
  140 |   await page.setContent('<a target=_blank rel=noopener href="/one-style.html">yo</a>');
  141 |   const [popup] = await Promise.all([
  142 |     page.waitForEvent('popup'),
  143 |     page.click('a'),
  144 |   ]);
  145 |   expect(await page.evaluate(() => !!window.opener)).toBe(false);
  146 |   expect(await popup.evaluate(() => !!window.opener)).toBe(false);
  147 | });
  148 | 
  149 | it('should report popup opened from iframes', async ({ page, server, browserName }) => {
  150 |   await page.goto(server.PREFIX + '/frames/two-frames.html');
  151 |   const frame = page.frames()[1];
  152 |   expect(frame).toBeTruthy();
  153 |   const [popup] = await Promise.all([
  154 |     page.waitForEvent('popup'),
  155 |     frame.evaluate(() => window.open('')),
  156 |   ]);
  157 |   expect(popup).toBeTruthy();
  158 | });
  159 | 
```