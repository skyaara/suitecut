# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/trace-viewer.spec.ts >> take trace paths via stdin
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/trace-viewer.spec.ts:2539:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.action-title')
Timeout: 10000ms
- Expected  - 3
+ Received  + 1

- Array [
-   /Create page/,
- ]
+ Array []

Call log:
  - Expect "toContainText" with timeout 10000ms
  - waiting for locator('.action-title')
    24 × locator resolved to 0 elements

```

# Page snapshot

```yaml
- button "clicked by client" [active] [ref=e2]
```

# Test source

```ts
  2443 | 
  2444 | test('should drop meta http-equiv refresh during recording', async ({ runAndTrace, page, server }) => {
  2445 |   const traceViewer = await runAndTrace(async () => {
  2446 |     await page.goto(server.EMPTY_PAGE);
  2447 |     // Use a very large delay so the recorded page does not actually navigate before the snapshot is taken.
  2448 |     await page.setContent(`
  2449 |       <head>
  2450 |         <meta http-equiv="refresh" content="999999; url=https://example.com/evil">
  2451 |       </head>
  2452 |       <body><div>safe</div></body>
  2453 |     `);
  2454 |   });
  2455 |   const frame = await traceViewer.snapshotFrame('Set content');
  2456 |   await expect(frame.locator('div')).toHaveText('safe');
  2457 |   // Refresh META must be stripped from the snapshot, so the iframe is not navigated.
  2458 |   await expect.poll(() => frame.locator('head').evaluate(head => head.querySelector('meta[http-equiv]')?.outerHTML.toLowerCase() ?? '')).toBe('');
  2459 |   // The trace viewer top-level title and body must remain untouched.
  2460 |   await expect(traceViewer.page).toHaveTitle(/Playwright Trace Viewer/);
  2461 |   await expect(traceViewer.page.locator('body')).not.toHaveAttribute('data-pwned', /.*/);
  2462 | });
  2463 | 
  2464 | test('should neutralize meta http-equiv refresh during rendering', async ({ runAndTrace, page, server }) => {
  2465 |   // Inject a META refresh directly via DOM manipulation that bypasses the
  2466 |   // recording-time strip (so this test specifically validates the renderer-side defense).
  2467 |   const traceViewer = await runAndTrace(async () => {
  2468 |     await page.goto(server.EMPTY_PAGE);
  2469 |     await page.evaluate(() => {
  2470 |       const meta = document.createElement('meta');
  2471 |       meta.setAttribute('http-equiv', 'refresh');
  2472 |       meta.setAttribute('content', '999999; url=https://example.com/evil');
  2473 |       document.head.appendChild(meta);
  2474 |       const div = document.createElement('div');
  2475 |       div.textContent = 'safe';
  2476 |       document.body.appendChild(div);
  2477 |     });
  2478 |   });
  2479 |   const frame = await traceViewer.snapshotFrame('Evaluate');
  2480 |   await expect(frame.locator('div')).toHaveText('safe');
  2481 |   // Even if a META refresh is in the recorded snapshot, the renderer must
  2482 |   // neutralize the http-equiv and content attributes so it has no effect.
  2483 |   await expect.poll(() => frame.locator('head').evaluate(head => !!head.querySelector('meta[http-equiv="refresh"]'))).toBe(false);
  2484 |   await expect(traceViewer.page).toHaveTitle(/Playwright Trace Viewer/);
  2485 | });
  2486 | 
  2487 | test('snapshot iframes should be sandboxed', async ({ runAndTrace, page, server }) => {
  2488 |   const traceViewer = await runAndTrace(async () => {
  2489 |     await page.goto(server.EMPTY_PAGE);
  2490 |     await page.setContent('<div>hello</div>');
  2491 |   });
  2492 |   await traceViewer.snapshotFrame('Set content');
  2493 |   const sandboxValues = await traceViewer.page.locator('iframe[name=snapshot]').evaluateAll(frames => frames.map(f => f.getAttribute('sandbox')));
  2494 |   for (const value of sandboxValues) {
  2495 |     expect(value).toBeTruthy();
  2496 |     expect(value).toContain('allow-same-origin');
  2497 |     expect(value).toContain('allow-scripts');
  2498 |   }
  2499 | });
  2500 | 
  2501 | test('should capture iframe with srcdoc', async ({ page, server, runAndTrace }) => {
  2502 |   await page.route('**/empty.html', route => {
  2503 |     void route.fulfill({
  2504 |       body: `<iframe srcdoc="<button>Hello iframe</button>"></iframe>`,
  2505 |       contentType: 'text/html'
  2506 |     }).catch(() => {});
  2507 |   });
  2508 | 
  2509 |   const traceViewer = await runAndTrace(async () => {
  2510 |     await page.goto(server.EMPTY_PAGE);
  2511 |     await expect(page.frameLocator('iframe').locator('button')).toHaveText('Hello iframe');
  2512 |     await page.evaluate('2+2');
  2513 |   });
  2514 | 
  2515 |   const frame = await traceViewer.snapshotFrame('Evaluate');
  2516 |   await expect(frame.frameLocator('iframe').getByRole('button')).toHaveText('Hello iframe');
  2517 | });
  2518 | 
  2519 | test('should render snapshots from the second chunk', async ({ context, page, server, showTraceViewer }, testInfo) => {
  2520 |   await context.tracing.start({ screenshots: true, snapshots: true });
  2521 |   await page.goto(server.EMPTY_PAGE);
  2522 |   await page.setContent('<button>Click</button>');
  2523 | 
  2524 |   await context.tracing.startChunk();
  2525 |   await page.click('"Click"');
  2526 |   await context.tracing.stopChunk({ path: testInfo.outputPath('trace1.zip') });
  2527 | 
  2528 |   await context.tracing.startChunk();
  2529 |   await page.hover('"Click"');
  2530 |   await context.tracing.stopChunk({ path: testInfo.outputPath('trace2.zip') });
  2531 | 
  2532 |   // Snapshots in the second chunk must be self-contained and not reference
  2533 |   // snapshot state from the first chunk.
  2534 |   const traceViewer = await showTraceViewer(testInfo.outputPath('trace2.zip'));
  2535 |   const frame = await traceViewer.snapshotFrame('Hover');
  2536 |   await expect(frame.locator('button')).toHaveText('Click');
  2537 | });
  2538 | 
  2539 | test('take trace paths via stdin', async ({ showTraceViewer }) => {
  2540 |   const traceViewer = await showTraceViewer(undefined, { stdin: true });
  2541 |   await expect(traceViewer.page).toHaveTitle('Playwright Trace Viewer');
  2542 |   traceViewer.process.write(traceFile);
> 2543 |   await expect(traceViewer.actionTitles).toContainText([
       |                                          ^ Error: expect(locator).toContainText(expected) failed
  2544 |     /Create page/,
  2545 |   ]);
  2546 | });
  2547 | 
```