from pathlib import Path
import tarfile,hashlib,json,shutil,os
base=Path('/tmp/suitecut-deep-audit');out=Path('/workspace/suitecut/benchmarks/playwright-compatibility/2026-10-12-deep-diagnosis')
excluded={'clean-consumer','consumer-store','coreBundle.before.js','coreBundle.pristine.js','browser.cc.o','browser.cc.o.d','cef-control.o','cef-control.o.d','standalone-profile','runtime-env.json','stop-runtime','support'}
temporary=out/('.evidence-'+str(os.getpid())+'.tmp')
with tarfile.open(temporary,'w:gz',compresslevel=6) as archive:
 for p in sorted(base.iterdir()):
  if p.name in excluded:continue
  archive.add(p,arcname='deep-audit/'+p.name,recursive=True)
 for name in ['package.json','pnpm-workspace.yaml','pnpm-lock.yaml','patches/playwright-core@1.62.1.patch']:
  archive.add(base/'clean-consumer'/name,arcname='deep-audit/clean-consumer/'+name)
 archive.add('/tmp/suitecut-playwright-upstream/playwright-1.62.1/packages/playwright-client/lib/index.mjs',arcname='deep-audit/generated-client/index.mjs')
 for p in (out/'reproduction').iterdir():archive.add(p,arcname='sealed-reproduction/'+p.name)
os.replace(temporary,out/'evidence.tar.gz')
manifest=[]
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS':manifest.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out)))
(out/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
print('Evidence archive bytes:',(out/'evidence.tar.gz').stat().st_size)
