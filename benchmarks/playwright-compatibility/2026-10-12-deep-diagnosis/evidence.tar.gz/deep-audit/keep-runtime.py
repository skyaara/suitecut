import pathlib,os,json,time
base=pathlib.Path('/tmp/suitecut-deep-audit')
json.dump({k:os.environ[k] for k in ['DISPLAY','PULSE_SERVER','LD_LIBRARY_PATH']},open(base/'runtime-env.json','w'))
deadline=time.monotonic()+3600
while not (base/'stop-runtime').exists() and time.monotonic()<deadline:time.sleep(.2)
