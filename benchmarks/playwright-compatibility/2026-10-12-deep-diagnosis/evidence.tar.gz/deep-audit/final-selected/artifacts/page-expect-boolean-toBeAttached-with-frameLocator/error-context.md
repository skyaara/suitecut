# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/expect-boolean.spec.ts >> toBeAttached >> with frameLocator
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/expect-boolean.spec.ts:680:7

# Error details

```
Error: expect(locator).toBeAttached() failed

Locator: locator('iframe').contentFrame().locator('input')
Expected: attached
Error: element(s) not found

Call log:
  - Expect "toBeAttached" with timeout 10000ms
  - waiting for locator('iframe').contentFrame().locator('input')
  - Page crashed

```

```
Error: page.setContent: Page crashed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  587 |       expect(error.message).toContain(`← 404 Not Found`);
  588 |       expect(error.message).not.toContain(`No content type error`);
  589 |     });
  590 | 
  591 |     test('image content type', async ({ page, server }) => {
  592 |       const res = await page.request.get(`${server.PREFIX}/image-content-type`);
  593 |       const error = await expect(res).toBeOK().catch(e => e);
  594 |       expect(error.message).toContain(`→ GET ${server.PREFIX}/image-content-type`);
  595 |       expect(error.message).toContain(`← 404 Not Found`);
  596 |       expect(error.message).not.toContain(`Image content type error`);
  597 |     });
  598 |   });
  599 | });
  600 | 
  601 | test.describe('toBeAttached', () => {
  602 |   test('default', async ({ page }) => {
  603 |     await page.setContent('<input></input>');
  604 |     const locator = page.locator('input');
  605 |     await expect(locator).toBeAttached();
  606 |   });
  607 | 
  608 |   test('with hidden element', async ({ page }) => {
  609 |     await page.setContent('<button style="display:none">hello</button>');
  610 |     const locator = page.locator('button');
  611 |     await expect(locator).toBeAttached();
  612 |   });
  613 | 
  614 |   test('with not', async ({ page }) => {
  615 |     await page.setContent('<button>hello</button>');
  616 |     const locator = page.locator('input');
  617 |     await expect(locator).not.toBeAttached();
  618 |   });
  619 | 
  620 |   test('with attached:true', async ({ page }) => {
  621 |     await page.setContent('<button>hello</button>');
  622 |     const locator = page.locator('button');
  623 |     await expect(locator).toBeAttached({ attached: true });
  624 |   });
  625 | 
  626 |   test('with attached:false', async ({ page }) => {
  627 |     await page.setContent('<button>hello</button>');
  628 |     const locator = page.locator('input');
  629 |     await expect(locator).toBeAttached({ attached: false });
  630 |   });
  631 | 
  632 |   test('with not and attached:false', async ({ page }) => {
  633 |     await page.setContent('<button>hello</button>');
  634 |     const locator = page.locator('button');
  635 |     await expect(locator).not.toBeAttached({ attached: false });
  636 |   });
  637 | 
  638 |   test('eventually', async ({ page }) => {
  639 |     await page.setContent('<div></div>');
  640 |     const locator = page.locator('span');
  641 |     setTimeout(() => {
  642 |       page.$eval('div', div => div.innerHTML = '<span>Hello</span>').catch(() => {});
  643 |     }, 0);
  644 |     await expect(locator).toBeAttached();
  645 |   });
  646 | 
  647 |   test('eventually with not', async ({ page }) => {
  648 |     await page.setContent('<div><span>Hello</span></div>');
  649 |     const locator = page.locator('span');
  650 |     setTimeout(() => {
  651 |       page.$eval('div', div => div.textContent = '').catch(() => {});
  652 |     }, 0);
  653 |     await expect(locator).not.toBeAttached();
  654 |   });
  655 | 
  656 |   test('fail', async ({ page }) => {
  657 |     await page.setContent('<button>Hello</button>');
  658 |     const locator = page.locator('input');
  659 |     const error = await expect(locator).toBeAttached({ timeout: 1000 }).catch(e => e);
  660 |     expect(error.message).not.toContain(`locator resolved to`);
  661 |   });
  662 | 
  663 |   test('fail with not', async ({ page }) => {
  664 |     await page.setContent('<input></input>');
  665 |     const locator = page.locator('input');
  666 |     const error = await expect(locator).not.toBeAttached({ timeout: 3000 }).catch(e => e);
  667 |     expect(error.message).toContain(`locator resolved to <input/>`);
  668 |   });
  669 | 
  670 |   test('with impossible timeout', async ({ page }) => {
  671 |     await page.setContent('<div id=node>Text content</div>');
  672 |     await expect(page.locator('#node')).toBeAttached({ timeout: 1 });
  673 |   });
  674 | 
  675 |   test('with impossible timeout .not', async ({ page }) => {
  676 |     await page.setContent('<div id=node>Text content</div>');
  677 |     await expect(page.locator('no-such-thing')).not.toBeAttached({ timeout: 1 });
  678 |   });
  679 | 
  680 |   test('with frameLocator', async ({ page }) => {
  681 |     await page.setContent('<div></div>');
  682 |     const locator = page.frameLocator('iframe').locator('input');
  683 |     let done = false;
  684 |     const promise = expect(locator).toBeAttached().then(() => done = true);
  685 |     await page.waitForTimeout(1000);
  686 |     expect(done).toBe(false);
> 687 |     await page.setContent('<iframe srcdoc="<input>"></iframe>');
      |                ^ Error: page.setContent: Page crashed
  688 |     await promise;
  689 |     expect(done).toBe(true);
  690 |   });
  691 | 
  692 |   test('over navigation', async ({ page, server }) => {
  693 |     await page.goto(server.EMPTY_PAGE);
  694 |     let done = false;
  695 |     const promise = expect(page.locator('input')).toBeAttached().then(() => done = true);
  696 |     await page.waitForTimeout(1000);
  697 |     expect(done).toBe(false);
  698 |     await page.goto(server.PREFIX + '/input/checkbox.html');
  699 |     await promise;
  700 |     expect(done).toBe(true);
  701 |   });
  702 | });
  703 | 
```