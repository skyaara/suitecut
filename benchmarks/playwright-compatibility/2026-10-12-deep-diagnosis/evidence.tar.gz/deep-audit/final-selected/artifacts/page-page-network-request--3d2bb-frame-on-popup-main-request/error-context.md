# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-network-request.spec.ts >> should not allow to access frame on popup main request
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-network-request.spec.ts:478:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: browserContext.waitForEvent: Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- link "click me" [active] [ref=e2] [cursor=pointer]:
  - /url: http://localhost:9159/empty.html
```

# Test source

```ts
  380 | it('should return navigation bit when navigating to image', async ({ page, server }) => {
  381 |   const requests = [];
  382 |   page.on('request', request => requests.push(request));
  383 |   await page.goto(server.PREFIX + '/pptr.png');
  384 |   expect(requests[0].isNavigationRequest()).toBe(true);
  385 | });
  386 | 
  387 | it('should report raw headers', async ({ page, server, browserName, platform, isElectron, browserMajorVersion, channel }) => {
  388 |   it.skip(isElectron && browserMajorVersion < 99, 'This needs Chromium >= 99');
  389 | 
  390 |   let expectedHeaders: { name: string, value: string }[];
  391 |   server.setRoute('/headers', (req, res) => {
  392 |     expectedHeaders = [];
  393 |     for (let i = 0; i < req.rawHeaders.length; i += 2)
  394 |       expectedHeaders.push({ name: req.rawHeaders[i], value: req.rawHeaders[i + 1] });
  395 |     if (browserName === 'webkit' && platform === 'win32' && channel !== 'webkit-wsl') {
  396 |       expectedHeaders = expectedHeaders.filter(({ name }) => name.toLowerCase() !== 'accept-encoding');
  397 |       // Convert "value": "en-US, en-US" => "en-US"
  398 |       expectedHeaders = expectedHeaders.map(e => {
  399 |         const { name, value } = e;
  400 |         if (name.toLowerCase() !== 'accept-language')
  401 |           return e;
  402 |         const values = value.split(',').map(v => v.trim());
  403 |         if (values.length === 1)
  404 |           return e;
  405 |         if (values[0] !== values[1])
  406 |           return e;
  407 |         return { name, value: values[0] };
  408 |       });
  409 |     }
  410 |     if (browserName === 'firefox')
  411 |       expectedHeaders = expectedHeaders.filter(({ name }) => name.toLowerCase() !== 'priority');
  412 | 
  413 |     res.end();
  414 |   });
  415 |   await page.goto(server.EMPTY_PAGE);
  416 |   const [request] = await Promise.all([
  417 |     page.waitForRequest('**/*'),
  418 |     page.evaluate(() => fetch('/headers', {
  419 |       headers: [
  420 |         ['header-a', 'value-a'],
  421 |         ['header-b', 'value-b'],
  422 |         ['header-a', 'value-a-1'],
  423 |         ['header-a', 'value-a-2'],
  424 |       ]
  425 |     }))
  426 |   ]);
  427 |   const headers = await request.headersArray();
  428 |   expect(headers.sort((a, b) => a.name.localeCompare(b.name))).toEqual(expectedHeaders.sort((a, b) => a.name.localeCompare(b.name)));
  429 |   expect(await request.headerValue('header-a')).toEqual('value-a, value-a-1, value-a-2');
  430 |   expect(await request.headerValue('not-there')).toEqual(null);
  431 | });
  432 | 
  433 | it('should report raw response headers in redirects', async ({ page, server, browserName }) => {
  434 |   it.skip(browserName === 'webkit', `WebKit won't give us raw headers for redirects`);
  435 |   server.setExtraHeaders('/redirect/1.html', { 'sec-test-header': '1.html' });
  436 |   server.setExtraHeaders('/redirect/2.html', { 'sec-test-header': '2.html' });
  437 |   server.setExtraHeaders('/empty.html', { 'sec-test-header': 'empty.html' });
  438 |   server.setRedirect('/redirect/1.html', '/redirect/2.html');
  439 |   server.setRedirect('/redirect/2.html', '/empty.html');
  440 | 
  441 |   const expectedUrls = ['/redirect/1.html', '/redirect/2.html', '/empty.html'].map(s => server.PREFIX + s);
  442 |   const expectedHeaders = ['1.html', '2.html', 'empty.html'];
  443 | 
  444 |   const response = await page.goto(server.PREFIX + '/redirect/1.html');
  445 |   const redirectChain = [];
  446 |   const headersChain = [];
  447 |   for (let req = response.request(); req; req = req.redirectedFrom()) {
  448 |     redirectChain.unshift(req.url());
  449 |     const res = await req.response();
  450 |     const headers = await res.allHeaders();
  451 |     headersChain.unshift(headers['sec-test-header']);
  452 |   }
  453 | 
  454 |   expect(redirectChain).toEqual(expectedUrls);
  455 |   expect(headersChain).toEqual(expectedHeaders);
  456 | });
  457 | 
  458 | it('should report all cookies in one header', async ({ page, server, isElectron, browserMajorVersion }) => {
  459 |   it.skip(isElectron && browserMajorVersion < 99, 'This needs Chromium >= 99');
  460 | 
  461 |   const expectedHeaders = {};
  462 |   server.setRoute('/headers', (req, res) => {
  463 |     for (let i = 0; i < req.rawHeaders.length; i += 2)
  464 |       expectedHeaders[req.rawHeaders[i]] = req.rawHeaders[i + 1];
  465 |     res.end();
  466 |   });
  467 | 
  468 |   await page.goto(server.EMPTY_PAGE);
  469 |   await page.evaluate(() => {
  470 |     document.cookie = 'myCookie=myValue';
  471 |     document.cookie = 'myOtherCookie=myOtherValue';
  472 |   });
  473 |   const response = await page.goto(server.EMPTY_PAGE);
  474 |   const cookie = (await response.request().allHeaders())['cookie'];
  475 |   expect(cookie).toBe('myCookie=myValue; myOtherCookie=myOtherValue');
  476 | });
  477 | 
  478 | it('should not allow to access frame on popup main request', async ({ page, server }) => {
  479 |   await page.setContent(`<a target=_blank href="${server.EMPTY_PAGE}">click me</a>`);
> 480 |   const requestPromise = page.context().waitForEvent('request');
      |                                         ^ Error: browserContext.waitForEvent: Test timeout of 30000ms exceeded.
  481 |   const popupPromise = page.context().waitForEvent('page');
  482 |   const clicked = page.getByText('click me').click();
  483 |   const request = await requestPromise;
  484 | 
  485 |   expect(request.isNavigationRequest()).toBe(true);
  486 | 
  487 |   let error;
  488 |   try {
  489 |     request.frame();
  490 |   } catch (e) {
  491 |     error = e;
  492 |   }
  493 |   expect(error.message).toContain('Frame for this navigation request is not available');
  494 | 
  495 |   const response = await request.response();
  496 |   await response.finished();
  497 |   await popupPromise;
  498 |   await clicked;
  499 | });
  500 | 
  501 | it('page.reload return 304 status code', async ({ page, server, browserName, isBidi }) => {
  502 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/28779' });
  503 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/29441' });
  504 |   it.fixme(browserName === 'firefox' && !isBidi, 'Does not send second request');
  505 |   let requestNumber = 0;
  506 |   server.setRoute('/test.html', (req, res) => {
  507 |     ++requestNumber;
  508 |     const headers = {
  509 |       'cf-cache-status': 'DYNAMIC',
  510 |       'Content-Type': 'text/html;charset=UTF-8',
  511 |       'Last-Modified': 'Fri, 05 Jan 2024 01:56:20 GMT',
  512 |       'Vary': 'Access-Control-Request-Headers',
  513 |     };
  514 |     if (requestNumber === 1)
  515 |       res.writeHead(200, headers);
  516 |     else
  517 |       res.writeHead(304, 'Not Modified', headers);
  518 |     res.write(`<div>Test</div>`);
  519 |     res.end();
  520 |   });
  521 |   const response1 = await page.goto(server.PREFIX + '/test.html');
  522 |   expect(response1.status()).toBe(200);
  523 |   const response2 = await page.reload();
  524 |   expect(requestNumber).toBe(2);
  525 |   if (browserName === 'chromium') {
  526 |     expect(response2.status()).toBe(200);
  527 |     expect(response2.statusText()).toBe('OK');
  528 |     expect(await response2.text()).toBe('<div>Test</div>');
  529 |   } else {
  530 |     expect(response2.status()).toBe(304);
  531 |     expect(response2.statusText()).toBe('Not Modified');
  532 |   }
  533 | });
  534 | 
  535 | it('should handle mixed-content blocked requests', async ({ page, asset, browserName }) => {
  536 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/29833' });
  537 |   it.skip(browserName !== 'chromium', 'FF and WK actually succeed with the request, and block afterwards');
  538 | 
  539 |   await page.route('**/mixedcontent.html', route => {
  540 |     void route.fulfill({
  541 |       status: 200,
  542 |       contentType: 'text/html',
  543 |       body: `
  544 |         <!doctype html>
  545 |         <meta charset="utf-8">
  546 |         <style>
  547 |         @font-face {
  548 |           font-family: 'pwtest-iconfont';
  549 |           src: url('http://another.com/iconfont.woff2') format('woff2');
  550 |         }
  551 |         body {
  552 |           font-family: 'pwtest-iconfont';
  553 |         }
  554 |         </style>
  555 |         <span>+-</span>
  556 |     `,
  557 |     });
  558 |   });
  559 |   await page.route('**/iconfont.woff2', async route => {
  560 |     const body = await fs.promises.readFile(asset('webfont/iconfont2.woff'));
  561 |     await route.fulfill({ body });
  562 |   });
  563 | 
  564 |   const [request] = await Promise.all([
  565 |     page.waitForEvent('requestfailed', r => r.url().includes('iconfont.woff2')),
  566 |     page.goto('https://example.com/mixedcontent.html'),
  567 |   ]);
  568 |   const headers = await request.allHeaders();
  569 |   expect(headers['origin']).toBeTruthy();
  570 |   expect(request.failure().errorText).toBe('mixed-content');
  571 | });
  572 | 
```