# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/hit-target.spec.ts >> should detect overlaid element in a transformed iframe
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/hit-target.spec.ts:366:3

# Error details

```
Error: page.setContent: Page crashed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  267 |   const target = page.frameLocator('iframe').frameLocator('iframe').locator('text=inner');
  268 |   const error = await target.click({ timeout: 3000 }).catch(e => e);
  269 |   expect(await page.evaluate('window._clicked')).toBe(undefined);
  270 |   expect(error.message).toContain(`<div onclick="window.top._clicked=5">PINK OVERLAY</div> intercepts pointer events`);
  271 | 
  272 |   await page.locator('text=overlay').evaluate(e => e.style.display = 'none');
  273 | 
  274 |   await target.click();
  275 |   expect(await page.evaluate('window._clicked')).toBe(3);
  276 | });
  277 | 
  278 | it('should click into frame inside closed shadow root', async ({ page, server }) => {
  279 |   await page.goto(server.EMPTY_PAGE);
  280 |   await page.setContent(`
  281 |     <div id=framecontainer>
  282 |     </div>
  283 |     <script>
  284 |       const iframe = document.createElement('iframe');
  285 |       iframe.setAttribute('name', 'myframe');
  286 |       iframe.setAttribute('srcdoc', '<div onclick="window.top.__clicked = true">click me</div>');
  287 |       const div = document.getElementById('framecontainer');
  288 |       const host = div.attachShadow({ mode: 'closed' });
  289 |       host.appendChild(iframe);
  290 |     </script>
  291 |   `);
  292 | 
  293 |   const frame = page.frames()[1];
  294 |   await frame.locator('text=click me').click();
  295 |   expect(await page.evaluate('window.__clicked')).toBe(true);
  296 | });
  297 | 
  298 | it('should click an element inside closed shadow root', async ({ page, server }) => {
  299 |   await page.goto(server.EMPTY_PAGE);
  300 |   await page.setContent(`
  301 |     <div id=container>
  302 |     </div>
  303 |     <script>
  304 |       const span = document.createElement('span');
  305 |       span.textContent = 'click me';
  306 |       span.addEventListener('click', () => window.__clicked = true);
  307 |       const div = document.getElementById('container');
  308 |       const host = div.attachShadow({ mode: 'closed' });
  309 |       host.appendChild(span);
  310 |       window.__target = span;
  311 |     </script>
  312 |   `);
  313 | 
  314 |   const handle = await page.evaluateHandle('window.__target');
  315 |   await (handle as any as ElementHandle).click();
  316 |   expect(await page.evaluate('window.__clicked')).toBe(true);
  317 | });
  318 | 
  319 | it('should detect overlay from another shadow root', async ({ page, server }) => {
  320 |   await page.goto(server.EMPTY_PAGE);
  321 |   await page.setContent(`
  322 |     <style>
  323 |       div > div {
  324 |         position: absolute;
  325 |         top: 0;
  326 |         left: 0;
  327 |         width: 10px;
  328 |         height: 10px;
  329 |       }
  330 |       span {
  331 |         display: block;
  332 |         position: absolute;
  333 |         left: 0;
  334 |         top: 0;
  335 |         width: 300px;
  336 |         height: 300px;
  337 |       }
  338 |     </style>
  339 |     <div style="position:relative; width:300px; height:300px">
  340 |       <div id=container1></div>
  341 |       <div id=container2></div>
  342 |     </div>
  343 |     <script>
  344 |       for (const id of ['container1', 'container2']) {
  345 |         const span = document.createElement('span');
  346 |         span.id = id + '-span';
  347 |         span.textContent = 'click me';
  348 |         span.style.display = 'block';
  349 |         span.style.position = 'absolute';
  350 |         span.style.left = '20px';
  351 |         span.style.top = '20px';
  352 |         span.style.width = '300px';
  353 |         span.style.height = '300px';
  354 |         span.addEventListener('click', () => window.__clicked = id);
  355 |         const div = document.getElementById(id);
  356 |         const host = div.attachShadow({ mode: 'open' });
  357 |         host.appendChild(span);
  358 |       }
  359 |     </script>
  360 |   `);
  361 | 
  362 |   const error = await page.locator('#container1 >> text=click me').click({ timeout: 3000 }).catch(e => e);
  363 |   expect(error.message).toContain(`<div id="container2"></div> intercepts pointer events`);
  364 | });
  365 | 
  366 | it('should detect overlaid element in a transformed iframe', async ({ page }) => {
> 367 |   await page.setContent(`
      |              ^ Error: page.setContent: Page crashed
  368 |     <style>
  369 |       body, html, iframe { margin: 0; padding: 0; border: none; }
  370 |       iframe {
  371 |         border: 4px solid black;
  372 |         background: gray;
  373 |         margin-left: 33px;
  374 |         margin-top: 24px;
  375 |         width: 400px;
  376 |         height: 400px;
  377 |         transform: scale(1.2);
  378 |       }
  379 |     </style>
  380 |     <iframe srcdoc="
  381 |       <style>
  382 |         body, html { margin: 0; padding: 0; }
  383 |         div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  384 |         section { position: absolute; top: 0; left: 0; bottom: 0; right: 0; }
  385 |       </style>
  386 |       <div>Target</div>
  387 |       <section>Overlay</section>
  388 |       <script>
  389 |         document.querySelector('div').addEventListener('click', () => window.top._clicked = true);
  390 |       </script>
  391 |     "></iframe>
  392 |   `);
  393 |   const locator = page.frameLocator('iframe').locator('div');
  394 |   const error = await locator.click({ timeout: 5000 }).catch(e => e);
  395 |   expect(error.message).toContain('<section>Overlay</section> intercepts pointer events');
  396 | });
  397 | 
  398 | it('should click in iframe with padding', async ({ page }) => {
  399 |   await page.setContent(`
  400 |     <style>
  401 |       body, html, iframe { margin: 0; padding: 0; border: none; box-sizing: border-box; }
  402 |       iframe { background: gray; width: 200px; height: 200px; padding-top: 100px; }
  403 |     </style>
  404 |     <iframe srcdoc="
  405 |       <style>
  406 |         body, html { margin: 0; padding: 0; }
  407 |         div { height: 100px; }
  408 |       </style>
  409 |       <div>Non-target</div>
  410 |       <div id=target>Target</div>
  411 |       <div>Non-target</div>
  412 |       <script>
  413 |         document.querySelector('#target').addEventListener('click', () => window.top._clicked = true);
  414 |       </script>
  415 |     "></iframe>
  416 |   `);
  417 |   const locator = page.frameLocator('iframe').locator('#target');
  418 |   await locator.click();
  419 |   expect(await page.evaluate('window._clicked')).toBe(true);
  420 | });
  421 | 
  422 | it('should click in iframe with padding 2', async ({ page }) => {
  423 |   await page.setContent(`
  424 |     <style>
  425 |       body, html, iframe { margin: 0; padding: 0; border: none; box-sizing: content-box; }
  426 |       iframe { background: gray; width: 200px; height: 200px; padding-top: 100px; }
  427 |     </style>
  428 |     <iframe srcdoc="
  429 |       <style>
  430 |         body, html { margin: 0; padding: 0; }
  431 |         div { height: 100px; }
  432 |       </style>
  433 |       <div>Non-target</div>
  434 |       <div id=target>Target</div>
  435 |       <div>Non-target</div>
  436 |       <script>
  437 |         document.querySelector('#target').addEventListener('click', () => window.top._clicked = true);
  438 |       </script>
  439 |     "></iframe>
  440 |   `);
  441 |   const locator = page.frameLocator('iframe').locator('#target');
  442 |   await locator.click();
  443 |   expect(await page.evaluate('window._clicked')).toBe(true);
  444 | });
  445 | 
  446 | it('should click in custom element', async ({ page }) => {
  447 |   await page.setContent(`
  448 |     <html>
  449 |       <body>
  450 |         <my-input></my-input>
  451 |         <script>
  452 |           class MyInput extends HTMLElement {
  453 |             connectedCallback() {
  454 |               this.attachShadow({mode:'open'});
  455 |               this.shadowRoot.innerHTML = '<div><span><input type="text" /></span></div>';
  456 |               this.shadowRoot.querySelector('input').addEventListener('click', () => window.__clicked = true);
  457 |             }
  458 |           }
  459 |           customElements.define('my-input', MyInput);
  460 |         </script>
  461 |       </body>
  462 |     </html>
  463 |   `);
  464 |   await page.locator('input').click();
  465 |   expect(await page.evaluate('window.__clicked')).toBe(true);
  466 | });
  467 | 
```