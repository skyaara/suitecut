# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-route.spec.ts >> should fulfill popup main request using alias
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-route.spec.ts:419:3

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('body')
Expected: "hello"
Received: ""
Timeout:  10000ms

Call log:
  - Expect "toHaveText" with timeout 10000ms
  - waiting for locator('body')
    24 × locator resolved to <body></body>
       - unexpected value ""

```

# Page snapshot

```yaml
- link "click me" [active] [ref=e2] [cursor=pointer]:
  - /url: http://localhost:8959/empty.html
```

# Test source

```ts
  332 |   await context.route('**/empty.html', route => {
  333 |     void route.fallback();
  334 |   });
  335 |   const e = await page.goto(server.EMPTY_PAGE).catch(e => e);
  336 |   expect(e).toBeTruthy();
  337 |   expect(failed).toBeFalsy();
  338 | });
  339 | 
  340 | it('should chain fallback into page', async ({ context, page, server }) => {
  341 |   const intercepted: number[] = [];
  342 |   await context.route('**/empty.html', route => {
  343 |     intercepted.push(1);
  344 |     void route.fallback();
  345 |   });
  346 |   await context.route('**/empty.html', route => {
  347 |     intercepted.push(2);
  348 |     void route.fallback();
  349 |   });
  350 |   await context.route('**/empty.html', route => {
  351 |     intercepted.push(3);
  352 |     void route.fallback();
  353 |   });
  354 |   await page.route('**/empty.html', route => {
  355 |     intercepted.push(4);
  356 |     void route.fallback();
  357 |   });
  358 |   await page.route('**/empty.html', route => {
  359 |     intercepted.push(5);
  360 |     void route.fallback();
  361 |   });
  362 |   await page.route('**/empty.html', route => {
  363 |     intercepted.push(6);
  364 |     void route.fallback();
  365 |   });
  366 |   await page.goto(server.EMPTY_PAGE);
  367 |   expect(intercepted).toEqual([6, 5, 4, 3, 2, 1]);
  368 | });
  369 | 
  370 | it('should fall back async', async ({ page, context, server }) => {
  371 |   const intercepted: number[] = [];
  372 |   await context.route('**/empty.html', async route => {
  373 |     intercepted.push(1);
  374 |     await new Promise(r => setTimeout(r, 100));
  375 |     void route.fallback();
  376 |   });
  377 |   await context.route('**/empty.html', async route => {
  378 |     intercepted.push(2);
  379 |     await new Promise(r => setTimeout(r, 100));
  380 |     void route.fallback();
  381 |   });
  382 |   await context.route('**/empty.html', async route => {
  383 |     intercepted.push(3);
  384 |     await new Promise(r => setTimeout(r, 100));
  385 |     void route.fallback();
  386 |   });
  387 |   await page.goto(server.EMPTY_PAGE);
  388 |   expect(intercepted).toEqual([3, 2, 1]);
  389 | });
  390 | 
  391 | it('should bypass disk cache when context interception is enabled', async ({ page, server }) => {
  392 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/30000' });
  393 |   await page.context().route('**/api*', route => route.continue());
  394 |   await page.goto(server.PREFIX + '/frames/one-frame.html');
  395 |   {
  396 |     const requests = [];
  397 |     server.setRoute('/api', (req, res) => {
  398 |       requests.push(req);
  399 |       res.statusCode = 200;
  400 |       res.setHeader('content-type', 'text/plain');
  401 |       res.setHeader('cache-control', 'public, max-age=31536000');
  402 |       res.end('Hello');
  403 |     });
  404 |     for (let i = 0; i < 3; i++) {
  405 |       await it.step(`main frame iteration ${i}`, async () => {
  406 |         const respPromise = page.waitForResponse('**/api');
  407 |         await page.evaluate(async () => {
  408 |           const response = await fetch('/api');
  409 |           return response.status;
  410 |         });
  411 |         const response = await respPromise;
  412 |         expect(response.status()).toBe(200);
  413 |         expect(requests.length).toBe(i + 1);
  414 |       });
  415 |     }
  416 |   }
  417 | });
  418 | 
  419 | it('should fulfill popup main request using alias', async ({ page, server, isElectron, electronMajorVersion, isAndroid }) => {
  420 |   it.skip(isElectron && electronMajorVersion < 30, 'error: Browser context management is not supported.');
  421 |   it.skip(isAndroid, 'The internal Android localhost (10.0.0.2) != the localhost on the host');
  422 | 
  423 |   await page.context().route('**/*', async route => {
  424 |     const response = await route.fetch();
  425 |     await route.fulfill({ response, body: 'hello' });
  426 |   });
  427 |   await page.setContent(`<a target=_blank href="${server.EMPTY_PAGE}">click me</a>`);
  428 |   const [popup] = await Promise.all([
  429 |     page.waitForEvent('popup'),
  430 |     page.getByText('click me').click(),
  431 |   ]);
> 432 |   await expect(popup.locator('body')).toHaveText('hello');
      |                                       ^ Error: expect(locator).toHaveText(expected) failed
  433 | });
  434 | 
```