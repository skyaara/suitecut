# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-click.spec.ts >> should click in an iframe with border 2
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-click.spec.ts:1008:3

# Error details

```
Error: page.setContent: Page crashed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  909  | 
  910  | it('should retry when navigating during the click', async ({ page, server, mode, isAndroid }) => {
  911  |   it.skip(mode !== 'default');
  912  |   it.fixme(isAndroid);
  913  | 
  914  |   await page.goto(server.PREFIX + '/input/button.html');
  915  |   let firstTime = true;
  916  |   const __testHookBeforeStable = async () => {
  917  |     if (!firstTime)
  918  |       return;
  919  |     firstTime = false;
  920  |     await page.goto(server.EMPTY_PAGE);
  921  |   };
  922  |   const error = await page.click('button', { __testHookBeforeStable, timeout: 2000 } as any).catch(e => e);
  923  |   expect(error.message).toContain('element was detached from the DOM, retrying');
  924  | });
  925  | 
  926  | it('should not hang when frame is detached', async ({ page, server, mode }) => {
  927  |   it.skip(mode !== 'default');
  928  | 
  929  |   await attachFrame(page, 'frame1', server.EMPTY_PAGE);
  930  |   const frame = page.frames()[1];
  931  |   await frame.goto(server.PREFIX + '/input/button.html');
  932  | 
  933  |   // Start moving the button.
  934  |   await frame.$eval('button', button => {
  935  |     button.style.transition = 'margin 5s linear 0s';
  936  |     button.style.marginLeft = '200px';
  937  |   });
  938  | 
  939  |   let resolveDetachPromise;
  940  |   const detachPromise = new Promise(resolve => resolveDetachPromise = resolve);
  941  |   let firstTime = true;
  942  |   const __testHookBeforeStable = () => {
  943  |     // Detach the frame after "waiting for stable" has started.
  944  |     if (!firstTime)
  945  |       return;
  946  |     firstTime = false;
  947  |     setTimeout(async () => {
  948  |       await detachFrame(page, 'frame1');
  949  |       resolveDetachPromise();
  950  |     }, 1000);
  951  |   };
  952  |   const promise = frame.click('button', { __testHookBeforeStable } as any).catch(e => e);
  953  | 
  954  |   await detachPromise;
  955  |   const error = await promise;
  956  |   expect(error).toBeTruthy();
  957  |   expect(error.message).toMatch(/frame got detached|Frame was detached/);
  958  | });
  959  | 
  960  | it('should climb dom for inner label with pointer-events:none', async ({ page }) => {
  961  |   await page.setContent('<button onclick="window.__CLICKED=true;"><label style="pointer-events:none">Click target</label></button>');
  962  |   await page.click('text=Click target');
  963  |   expect(await page.evaluate('__CLICKED')).toBe(true);
  964  | });
  965  | 
  966  | it('should climb up to [role=button]', async ({ page }) => {
  967  |   await page.setContent('<div role=button onclick="window.__CLICKED=true;"><div style="pointer-events:none"><span><div>Click target</div></span></div>');
  968  |   await page.click('text=Click target');
  969  |   expect(await page.evaluate('__CLICKED')).toBe(true);
  970  | });
  971  | 
  972  | it('should climb up to a anchor', async ({ page }) => {
  973  |   // For Firefox its not allowed to return anything: https://bugzilla.mozilla.org/show_bug.cgi?id=1392046
  974  |   // Note the intermediate div - it is necessary, otherwise <a><non-clickable/></a> is not recognized as a clickable link.
  975  |   await page.setContent(`<a href="#" onclick="window.__CLICKED=true" id="outer"><div id="intermediate"><div id="inner" style="pointer-events: none">Inner</div></div></a>`);
  976  |   await page.click('#inner');
  977  |   expect(await page.evaluate('__CLICKED')).toBe(true);
  978  | });
  979  | 
  980  | it('should climb up to a [role=link]', async ({ page }) => {
  981  |   await page.setContent(`<div role=link onclick="window.__CLICKED=true" id="outer"><div id="inner" style="pointer-events: none">Inner</div></div>`);
  982  |   await page.click('#inner');
  983  |   expect(await page.evaluate('__CLICKED')).toBe(true);
  984  | });
  985  | 
  986  | it('should click in an iframe with border', async ({ page }) => {
  987  |   await page.setContent(`
  988  |     <style>
  989  |       body, html, iframe { margin: 0; padding: 0; border: none; box-sizing: border-box; }
  990  |       iframe { border: 4px solid black; background: gray; margin-left: 33px; margin-top: 24px; width: 400px; height: 400px; }
  991  |     </style>
  992  |     <iframe srcdoc="
  993  |       <style>
  994  |         body, html { margin: 0; padding: 0; }
  995  |         div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  996  |       </style>
  997  |       <div>Target</div>
  998  |       <script>
  999  |         document.querySelector('div').addEventListener('click', () => window.top._clicked = true);
  1000 |       </script>
  1001 |     "></iframe>
  1002 |   `);
  1003 |   const locator = page.frameLocator('iframe').locator('div');
  1004 |   await locator.click();
  1005 |   expect(await page.evaluate('window._clicked')).toBe(true);
  1006 | });
  1007 | 
  1008 | it('should click in an iframe with border 2', async ({ page }) => {
> 1009 |   await page.setContent(`
       |              ^ Error: page.setContent: Page crashed
  1010 |     <style>
  1011 |       body, html, iframe { margin: 0; padding: 0; border: none; }
  1012 |       iframe { border: 4px solid black; background: gray; margin-left: 33px; margin-top: 24px; width: 400px; height: 400px; }
  1013 |     </style>
  1014 |     <iframe srcdoc="
  1015 |       <style>
  1016 |         body, html { margin: 0; padding: 0; }
  1017 |         div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  1018 |       </style>
  1019 |       <div>Target</div>
  1020 |       <script>
  1021 |         document.querySelector('div').addEventListener('click', () => window.top._clicked = true);
  1022 |       </script>
  1023 |     "></iframe>
  1024 |   `);
  1025 |   const locator = page.frameLocator('iframe').locator('div');
  1026 |   await locator.click();
  1027 |   expect(await page.evaluate('window._clicked')).toBe(true);
  1028 | });
  1029 | 
  1030 | it('should click in a transformed iframe', async ({ page }) => {
  1031 |   await page.setContent(`
  1032 |     <style>
  1033 |       body, html, iframe { margin: 0; padding: 0; border: none; }
  1034 |       iframe {
  1035 |         border: 4px solid black;
  1036 |         background: gray;
  1037 |         margin-left: 33px;
  1038 |         margin-top: 24px;
  1039 |         width: 400px;
  1040 |         height: 400px;
  1041 |         transform: translate(100px, 100px) scale(1.2) rotate3d(1, 1, 1, 25deg);
  1042 |       }
  1043 |     </style>
  1044 |     <iframe srcdoc="
  1045 |       <style>
  1046 |         body, html { margin: 0; padding: 0; }
  1047 |         div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  1048 |       </style>
  1049 |       <div>Target</div>
  1050 |       <script>
  1051 |         document.querySelector('div').addEventListener('click', () => window.top._clicked = true);
  1052 |       </script>
  1053 |     "></iframe>
  1054 |   `);
  1055 |   const locator = page.frameLocator('iframe').locator('div');
  1056 |   await locator.click();
  1057 |   expect(await page.evaluate('window._clicked')).toBe(true);
  1058 | });
  1059 | 
  1060 | it('should click a button that is overlaid by a permission popup', async ({ page, server }) => {
  1061 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/23280' });
  1062 |   await page.setViewportSize({ width: 500, height: 500 });
  1063 |   await page.goto(server.EMPTY_PAGE);
  1064 |   await page.setContent(`
  1065 |     <style>body, html { padding: 0; margin: 0; }</style>
  1066 |     <script type='text/javascript'>
  1067 |       window.addEventListener('DOMContentLoaded', () => {
  1068 |         // Viewport filled with buttons.
  1069 |         for (let i = 0; i < 100; ++i) {
  1070 |           const button = document.createElement('button');
  1071 |           button.textContent = i;
  1072 |           button.style.setProperty('width', '50px');
  1073 |           button.style.setProperty('height', '50px');
  1074 |           document.body.append(button);
  1075 |         }
  1076 |       }, false);
  1077 |     </script>
  1078 |   `);
  1079 |   // Issue a geolocation request. This should show a browser popup.
  1080 |   // NOTE: this is a bit racy since we can't wait for the geolocation
  1081 |   // popup to be shown.
  1082 |   await page.evaluate(() => {
  1083 |     navigator.geolocation.getCurrentPosition(position => { });
  1084 |   });
  1085 |   // If popup blocks the click, then some of the `page.click` calls below will hang.
  1086 |   for (let i = 0; i < 30; ++i)
  1087 |     await page.click(`text=${i}`);
  1088 | });
  1089 | 
  1090 | it('should click in a transformed iframe with force', async ({ page }) => {
  1091 |   await page.setContent(`
  1092 |     <style>
  1093 |       body, html, iframe { margin: 0; padding: 0; border: none; }
  1094 |       iframe { background: gray; margin-left: 33px; margin-top: 24px; width: 400px; height: 400px; transform: translate(-40px, -40px) scale(0.8); }
  1095 |     </style>
  1096 |     <iframe srcdoc="
  1097 |       <style>
  1098 |         body, html { margin: 0; padding: 0; }
  1099 |         div { margin-left: 10px; margin-top: 20px; width: 2px; height: 2px; }
  1100 |       </style>
  1101 |       <div>Target</div>
  1102 |       <script>
  1103 |         document.querySelector('div').addEventListener('click', () => window.top._clicked = true);
  1104 |       </script>
  1105 |     "></iframe>
  1106 |   `);
  1107 |   const locator = page.frameLocator('iframe').locator('div');
  1108 |   await locator.click({ force: true });
  1109 |   expect(await page.evaluate('window._clicked')).toBe(true);
```