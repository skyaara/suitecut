# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/inspector/pause.spec.ts >> pause >> should highlight pointer, only in main frame
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/inspector/pause.spec.ts:207:5

# Error details

```
Error: page.setContent: Page crashed
Call log:
  - setting frame content, waiting until "load"

```

```
Test timeout of 30000ms exceeded while running "afterEach" hook.
```

# Test source

```ts
  1   | /**
  2   |  * Copyright (c) Microsoft Corporation.
  3   |  *
  4   |  * Licensed under the Apache License, Version 2.0 (the "License");
  5   |  * you may not use this file except in compliance with the License.
  6   |  * You may obtain a copy of the License at
  7   |  *
  8   |  * http://www.apache.org/licenses/LICENSE-2.0
  9   |  *
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import type { Page } from 'playwright-core';
  18  | import { test as it, expect, Recorder } from './inspectorTest';
  19  | import { roundBox, waitForTestLog } from '../../config/utils';
  20  | import type { BoundingBox } from '../../config/utils';
  21  | import { pauseHelper } from './pause-helper';
  22  | 
  23  | it('should resume when closing inspector', async ({ page, recorderPageGetter, closeRecorder, mode }) => {
  24  |   const scriptPromise = (async () => {
  25  |     // @ts-ignore
  26  |     await page.pause({ __testHookKeepTestTimeout: true });
  27  |   })();
  28  |   await recorderPageGetter();
  29  |   await closeRecorder();
  30  |   await scriptPromise;
  31  | });
  32  | 
  33  | it('should not reset timeouts', async ({ page, recorderPageGetter, closeRecorder, server }) => {
  34  |   page.context().setDefaultNavigationTimeout(1000);
  35  |   page.context().setDefaultTimeout(1000);
  36  | 
  37  |   // @ts-ignore
  38  |   const pausePromise = page.pause({ __testHookKeepTestTimeout: true });
  39  |   await recorderPageGetter();
  40  |   await closeRecorder();
  41  |   await pausePromise;
  42  | 
  43  |   server.setRoute('/empty.html', () => {});
  44  |   const error = await page.goto(server.EMPTY_PAGE).catch(e => e);
  45  |   expect(error.message).toContain('page.goto: Timeout 1000ms exceeded.');
  46  | });
  47  | 
  48  | it('should collapse log entries to a single line', async ({ page, recorderPageGetter }) => {
  49  |   const scriptPromise = (async () => {
  50  |     // @ts-ignore
  51  |     await page.pause({ __testHookKeepTestTimeout: true });
  52  |     await page.keyboard.type(`Hello
  53  | world`);
  54  |   })();
  55  | 
  56  |   const recorderPage = await recorderPageGetter();
  57  |   await recorderPage.click('[title="Resume (F8)"]');
  58  |   await expect(recorderPage.locator('.call-log-call').nth(1)).toContainText('Type "Hello\\nworld"');
  59  |   await scriptPromise;
  60  | });
  61  | 
  62  | it.describe('pause', () => {
> 63  |   it.afterEach(async ({ recorderPageGetter }, testInfo) => {
      |      ^ Test timeout of 30000ms exceeded while running "afterEach" hook.
  64  |     if (testInfo.status === 'skipped')
  65  |       return;
  66  |     try {
  67  |       const recorderPage = await recorderPageGetter();
  68  |       recorderPage.click('[title="Resume (F8)"]').catch(() => {});
  69  |     } catch (e) {
  70  |       // Some tests close context.
  71  |     }
  72  |   });
  73  | 
  74  |   it('should pause and resume the script', async ({ page, recorderPageGetter }) => {
  75  |     const scriptPromise = (async () => {
  76  |       // @ts-ignore
  77  |       await page.pause({ __testHookKeepTestTimeout: true });
  78  |     })();
  79  |     const recorderPage = await recorderPageGetter();
  80  |     await recorderPage.click('[title="Resume (F8)"]');
  81  |     await scriptPromise;
  82  |   });
  83  | 
  84  |   it('should pause and resume the script with keyboard shortcut', async ({ page, recorderPageGetter }) => {
  85  |     const scriptPromise = (async () => {
  86  |       // @ts-ignore
  87  |       await page.pause({ __testHookKeepTestTimeout: true });
  88  |     })();
  89  |     const recorderPage = await recorderPageGetter();
  90  |     await expect(recorderPage.getByRole('button', { name: 'Resume' })).toBeEnabled();
  91  |     await recorderPage.keyboard.press('F8');
  92  |     await scriptPromise;
  93  |   });
  94  | 
  95  |   it('should resume from console', async ({ page, mode }) => {
  96  |     it.skip(mode !== 'default');
  97  | 
  98  |     const scriptPromise = (async () => {
  99  |       // @ts-ignore
  100 |       await page.pause({ __testHookKeepTestTimeout: true });
  101 |     })();
  102 |     await page.waitForFunction(() => (window as any).playwright && (window as any).playwright.resume() !== false);
  103 |     await scriptPromise;
  104 |   });
  105 | 
  106 |   it('should pause after a navigation', async ({ page, server, recorderPageGetter }) => {
  107 |     const scriptPromise = (async () => {
  108 |       await page.goto(server.EMPTY_PAGE);
  109 |       // @ts-ignore
  110 |       await page.pause({ __testHookKeepTestTimeout: true });
  111 |     })();
  112 |     const recorderPage = await recorderPageGetter();
  113 |     await recorderPage.click('[title="Resume (F8)"]');
  114 |     await scriptPromise;
  115 |   });
  116 | 
  117 |   it('should show source', async ({ page, recorderPageGetter }) => {
  118 |     const scriptPromise = (async () => {
  119 |       // @ts-ignore
  120 |       await page.pause({ __testHookKeepTestTimeout: true });
  121 |       await pauseHelper(page);
  122 |     })();
  123 |     const recorderPage = await recorderPageGetter();
  124 |     await expect(recorderPage.getByRole('combobox', { name: 'Source chooser' })).toHaveValue(/pause\.spec\.ts/);
  125 |     await expect(recorderPage.locator('.source-line-paused')).toContainText('page.pause({ __testHookKeepTestTimeout: true })');
  126 | 
  127 |     await recorderPage.click('[title="Step over (F10)"]');
  128 |     await expect(recorderPage.getByRole('combobox', { name: 'Source chooser' })).toHaveValue(/pause-helper\.ts/);
  129 |     await expect(recorderPage.locator('.source-line-paused')).toContainText('page.setContent(\'<div>here we go</div>\')');
  130 | 
  131 |     await recorderPage.click('[title="Resume (F8)"]');
  132 |     await scriptPromise;
  133 |   });
  134 | 
  135 |   it('should pause on next pause', async ({ page, recorderPageGetter }) => {
  136 |     const scriptPromise = (async () => {
  137 |       // @ts-ignore
  138 |       await page.pause({ __testHookKeepTestTimeout: true });  // 1
  139 |       // @ts-ignore
  140 |       await page.pause({ __testHookKeepTestTimeout: true });  // 2
  141 |     })();
  142 |     const recorderPage = await recorderPageGetter();
  143 |     const source = await recorderPage.textContent('.source-line-paused');
  144 |     expect(source).toContain('page.pause({ __testHookKeepTestTimeout: true });  // 1');
  145 |     await recorderPage.click('[title="Resume (F8)"]');
  146 |     await recorderPage.waitForSelector('.source-line-paused:has-text("page.pause({ __testHookKeepTestTimeout: true });  // 2")');
  147 |     await recorderPage.click('[title="Resume (F8)"]');
  148 |     await scriptPromise;
  149 |   });
  150 | 
  151 |   it('should step', async ({ page, recorderPageGetter }) => {
  152 |     await page.setContent('<button>Submit</button>');
  153 |     const scriptPromise = (async () => {
  154 |       // @ts-ignore
  155 |       await page.pause({ __testHookKeepTestTimeout: true });
  156 |       await page.click('button');
  157 |     })();
  158 |     const recorderPage = await recorderPageGetter();
  159 |     const source = await recorderPage.textContent('.source-line-paused');
  160 |     expect(source).toContain('page.pause({ __testHookKeepTestTimeout: true });');
  161 | 
  162 |     await recorderPage.click('[title="Step over (F10)"]');
  163 |     await recorderPage.waitForSelector('.source-line-paused :has-text("page.click")');
```