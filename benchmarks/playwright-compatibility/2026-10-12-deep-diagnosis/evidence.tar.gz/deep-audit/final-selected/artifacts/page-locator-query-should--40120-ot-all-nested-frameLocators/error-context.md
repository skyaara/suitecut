# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/locator-query.spec.ts >> should allow some, but not all nested frameLocators
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/locator-query.spec.ts:243:3

# Error details

```
Error: page.setContent: Page crashed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  144 |   await expect(page.locator('div', { hasText: /^first\/".*"second\\$/si })).toHaveClass('test');
  145 | });
  146 | 
  147 | it('should support has:locator', async ({ page, trace }) => {
  148 |   it.skip(trace === 'on');
  149 | 
  150 |   await page.setContent(`<div><span>hello</span></div><div><span>world</span></div>`);
  151 |   await expect(page.locator(`div`, {
  152 |     has: page.locator(`text=world`)
  153 |   })).toHaveCount(1);
  154 |   expect(await page.locator(`div`, {
  155 |     has: page.locator(`text=world`)
  156 |   }).evaluate(e => e.outerHTML)).toBe(`<div><span>world</span></div>`);
  157 |   await expect(page.locator(`div`, {
  158 |     has: page.locator(`text="hello"`)
  159 |   })).toHaveCount(1);
  160 |   expect(await page.locator(`div`, {
  161 |     has: page.locator(`text="hello"`)
  162 |   }).evaluate(e => e.outerHTML)).toBe(`<div><span>hello</span></div>`);
  163 |   await expect(page.locator(`div`, {
  164 |     has: page.locator(`xpath=./span`)
  165 |   })).toHaveCount(2);
  166 |   await expect(page.locator(`div`, {
  167 |     has: page.locator(`span`)
  168 |   })).toHaveCount(2);
  169 |   await expect(page.locator(`div`, {
  170 |     has: page.locator(`span`, { hasText: 'wor' })
  171 |   })).toHaveCount(1);
  172 |   expect(await page.locator(`div`, {
  173 |     has: page.locator(`span`, { hasText: 'wor' })
  174 |   }).evaluate(e => e.outerHTML)).toBe(`<div><span>world</span></div>`);
  175 |   await expect(page.locator(`div`, {
  176 |     has: page.locator(`span`),
  177 |     hasText: 'wor',
  178 |   })).toHaveCount(1);
  179 | });
  180 | 
  181 | it('should support locator.filter', async ({ page, trace }) => {
  182 |   it.skip(trace === 'on');
  183 | 
  184 |   await page.setContent(`<section><div><span>hello</span></div><div><span>world</span></div></section>`);
  185 |   await expect(page.locator(`div`).filter({ hasText: 'hello' })).toHaveCount(1);
  186 |   await expect(page.locator(`div`, { hasText: 'hello' }).filter({ hasText: 'hello' })).toHaveCount(1);
  187 |   await expect(page.locator(`div`, { hasText: 'hello' }).filter({ hasText: 'world' })).toHaveCount(0);
  188 |   await expect(page.locator(`section`, { hasText: 'hello' }).filter({ hasText: 'world' })).toHaveCount(1);
  189 |   await expect(page.locator(`div`).filter({ hasText: 'hello' }).locator('span')).toHaveCount(1);
  190 |   await expect(page.locator(`div`).filter({ has: page.locator('span', { hasText: 'world' }) })).toHaveCount(1);
  191 |   await expect(page.locator(`div`).filter({ has: page.locator('span') })).toHaveCount(2);
  192 |   await expect(page.locator(`div`).filter({
  193 |     has: page.locator('span'),
  194 |     hasText: 'world',
  195 |   })).toHaveCount(1);
  196 |   await expect(page.locator(`div`).filter({ hasNot: page.locator('span', { hasText: 'world' }) })).toHaveCount(1);
  197 |   await expect(page.locator(`div`).filter({ hasNot: page.locator('section') })).toHaveCount(2);
  198 |   await expect(page.locator(`div`).filter({ hasNot: page.locator('span') })).toHaveCount(0);
  199 |   await expect(page.locator(`div`).filter({ hasNotText: 'hello' })).toHaveCount(1);
  200 |   await expect(page.locator(`div`).filter({ hasNotText: 'foo' })).toHaveCount(2);
  201 | });
  202 | 
  203 | it('should support locator.and', async ({ page }) => {
  204 |   await page.setContent(`
  205 |     <div data-testid=foo>hello</div><div data-testid=bar>world</div>
  206 |     <span data-testid=foo>hello2</span><span data-testid=bar>world2</span>
  207 |   `);
  208 |   await expect(page.locator('div').and(page.locator('div'))).toHaveCount(2);
  209 |   await expect(page.locator('div').and(page.getByTestId('foo'))).toHaveText(['hello']);
  210 |   await expect(page.locator('div').and(page.getByTestId('bar'))).toHaveText(['world']);
  211 |   await expect(page.getByTestId('foo').and(page.locator('div'))).toHaveText(['hello']);
  212 |   await expect(page.getByTestId('bar').and(page.locator('span'))).toHaveText(['world2']);
  213 |   await expect(page.locator('span').and(page.getByTestId(/bar|foo/))).toHaveCount(2);
  214 | });
  215 | 
  216 | it('should support locator.or', async ({ page }) => {
  217 |   await page.setContent(`<div>hello</div><span>world</span>`);
  218 |   await expect(page.locator('div').or(page.locator('span'))).toHaveCount(2);
  219 |   await expect(page.locator('div').or(page.locator('span'))).toHaveText(['hello', 'world']);
  220 |   await expect(page.locator('span').or(page.locator('article')).or(page.locator('div'))).toHaveText(['hello', 'world']);
  221 |   await expect(page.locator('article').or(page.locator('something'))).toHaveCount(0);
  222 |   await expect(page.locator('article').or(page.locator('div'))).toHaveText('hello');
  223 |   await expect(page.locator('article').or(page.locator('span'))).toHaveText('world');
  224 |   await expect(page.locator('div').or(page.locator('article'))).toHaveText('hello');
  225 |   await expect(page.locator('span').or(page.locator('article'))).toHaveText('world');
  226 | });
  227 | 
  228 | it('should support locator.locator with and/or', async ({ page }) => {
  229 |   await page.setContent(`
  230 |     <div>one <span>two</span> <button>three</button> </div>
  231 |     <span>four</span>
  232 |     <button>five</button>
  233 |   `);
  234 | 
  235 |   await expect(page.locator('div').locator(page.locator('button'))).toHaveText(['three']);
  236 |   await expect(page.locator('div').locator(page.locator('button').or(page.locator('span')))).toHaveText(['two', 'three']);
  237 |   await expect(page.locator('button').or(page.locator('span'))).toHaveText(['two', 'three', 'four', 'five']);
  238 | 
  239 |   await expect(page.locator('div').locator(page.locator('button').and(page.getByRole('button')))).toHaveText(['three']);
  240 |   await expect(page.locator('button').and(page.getByRole('button'))).toHaveText(['three', 'five']);
  241 | });
  242 | 
  243 | it('should allow some, but not all nested frameLocators', async ({ page }) => {
> 244 |   await page.setContent(`<iframe srcdoc="<span id=target>world</span>"></iframe><span>hello</span>`);
      |              ^ Error: page.setContent: Page crashed
  245 |   await expect(page.frameLocator('iframe').locator('span').or(page.frameLocator('iframe').locator('article'))).toHaveText('world');
  246 |   await expect(page.frameLocator('iframe').locator('article').or(page.frameLocator('iframe').locator('span'))).toHaveText('world');
  247 |   await expect(page.frameLocator('iframe').locator('span').and(page.frameLocator('iframe').locator('#target'))).toHaveText('world');
  248 |   const error1 = await expect(page.frameLocator('iframe').locator('div').or(page.frameLocator('#iframe').locator('span'))).toHaveText('world').catch(e => e);
  249 |   expect(error1.message).toContain(`Frame locators are not allowed inside composite locators, while querying "locator('iframe').contentFrame().locator('div').or(locator('#iframe').contentFrame().locator('span'))`);
  250 |   const error2 = await expect(page.frameLocator('iframe').locator('div').and(page.frameLocator('#iframe').locator('span'))).toHaveText('world').catch(e => e);
  251 |   expect(error2.message).toContain(`Frame locators are not allowed inside composite locators, while querying "locator('iframe').contentFrame().locator('div').and(locator('#iframe').contentFrame().locator('span'))`);
  252 | });
  253 | 
  254 | it('should enforce same frame for has/leftOf/rightOf/above/below/near', async ({ page, server }) => {
  255 |   await page.goto(server.PREFIX + '/frames/two-frames.html');
  256 |   const child = page.frames()[1];
  257 |   for (const option of ['has']) {
  258 |     let error;
  259 |     try {
  260 |       page.locator('div', { [option]: child.locator('span') });
  261 |     } catch (e) {
  262 |       error = e;
  263 |     }
  264 |     expect(error.message).toContain(`Inner "${option}" locator must belong to the same frame.`);
  265 |   }
  266 | });
  267 | 
  268 | it('alias methods coverage', async ({ page }) => {
  269 |   await page.setContent(`<div><button>Submit</button></div>`);
  270 |   await expect(page.locator('button')).toHaveCount(1);
  271 |   await expect(page.locator('div').locator('button')).toHaveCount(1);
  272 |   await expect(page.locator('div').getByRole('button')).toHaveCount(1);
  273 |   await expect(page.mainFrame().locator('button')).toHaveCount(1);
  274 | });
  275 | 
  276 | it('count() should not throw during navigation', async ({ playwright, page, server }) => {
  277 |   const createDummySelector = () => ({
  278 |     query(root, selector) {
  279 |       window.location.href = './frames/one-frame.html';
  280 |       return document.querySelector(selector);
  281 |     },
  282 |     queryAll(root: HTMLElement, selector: string) {
  283 |       window.location.href = './frames/one-frame.html';
  284 |       return Array.from(document.querySelectorAll(selector));
  285 |     }
  286 |   });
  287 |   await playwright.selectors.register('locatorCountHelper', createDummySelector);
  288 |   await page.goto(server.PREFIX + '/frames/one-frame.html');
  289 |   await page.frames()[1].setContent(`<div>A</div>`);
  290 |   expect(await page.frameLocator('locatorCountHelper=iframe').locator('locatorCountHelper=div').count()).toBe(0);
  291 | });
  292 | 
```