# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-mouse.spec.ts >> should track hover across iframe boundaries
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-mouse.spec.ts:341:3

# Error details

```
Error: page.setContent: Page crashed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  244 |   await page.evaluate(() => delete window.Node);
  245 |   await page.hover('#button-6');
  246 |   expect(await page.evaluate(() => document.querySelector('button:hover').id)).toBe('button-6');
  247 | });
  248 | 
  249 | it('should set modifier keys on click', async ({ page, server, browserName, isMac }) => {
  250 |   await page.goto(server.PREFIX + '/input/scrollable.html');
  251 |   await page.evaluate(() => document.querySelector('#button-3').addEventListener('mousedown', e => window['lastEvent'] = e, true));
  252 |   const modifiers = { 'Shift': 'shiftKey', 'Control': 'ctrlKey', 'Alt': 'altKey', 'Meta': 'metaKey' };
  253 |   // In Firefox, the Meta modifier only exists on Mac
  254 |   if (browserName === 'firefox' && !isMac)
  255 |     delete modifiers['Meta'];
  256 |   for (const modifier in modifiers) {
  257 |     await page.keyboard.down(modifier);
  258 |     await page.click('#button-3');
  259 |     if (!(await page.evaluate(mod => window['lastEvent'][mod], modifiers[modifier])))
  260 |       throw new Error(modifiers[modifier] + ' should be true');
  261 |     await page.keyboard.up(modifier);
  262 |   }
  263 |   await page.click('#button-3');
  264 |   for (const modifier in modifiers) {
  265 |     if ((await page.evaluate(mod => window['lastEvent'][mod], modifiers[modifier])))
  266 |       throw new Error(modifiers[modifier] + ' should be false');
  267 |   }
  268 | });
  269 | 
  270 | it('should tween mouse movement', async ({ page, browserName, isAndroid, headless }) => {
  271 |   it.skip(isAndroid, 'Bad rounding');
  272 |   it.skip(!headless, 'actual mouse interferes with the exact mousemove events');
  273 | 
  274 |   // The test becomes flaky on WebKit without next line.
  275 |   if (browserName === 'webkit')
  276 |     await page.evaluate(() => new Promise(requestAnimationFrame));
  277 |   await page.mouse.move(100, 100);
  278 |   await page.evaluate(() => {
  279 |     window['result'] = [];
  280 |     document.addEventListener('mousemove', event => {
  281 |       window['result'].push([event.clientX, event.clientY]);
  282 |     });
  283 |   });
  284 |   await page.mouse.move(200, 300, { steps: 5 });
  285 |   expect(await page.evaluate('result')).toEqual([
  286 |     [120, 140],
  287 |     [140, 180],
  288 |     [160, 220],
  289 |     [180, 260],
  290 |     [200, 300]
  291 |   ]);
  292 | });
  293 | 
  294 | it('should always round down', async ({ page }) => {
  295 |   await page.evaluate(() => {
  296 |     document.addEventListener('mousedown', event => {
  297 |       window['result'] = [event.clientX, event.clientY];
  298 |     });
  299 |   });
  300 |   await page.mouse.click(50.1, 50.9);
  301 |   expect(await page.evaluate('result')).toEqual([50, 50]);
  302 | });
  303 | 
  304 | it('should not crash on mouse drag with any button', async ({ page }) => {
  305 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/16609' });
  306 |   await page.evaluate(() => {
  307 |     // Do not show contextmenu on right click since it is poorly supported.
  308 |     window.addEventListener('contextmenu', e => e.preventDefault(), false);
  309 |   });
  310 |   for (const button of ['left', 'middle', 'right'] as const) {
  311 |     await page.mouse.move(50, 50);
  312 |     await page.mouse.down({ button });
  313 |     await page.mouse.move(100, 100);
  314 |   }
  315 | });
  316 | 
  317 | it('should dispatch mouse move after context menu was opened', async ({ page, browserName, isWindows }) => {
  318 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/20823' });
  319 |   it.fixme(browserName === 'chromium' && isWindows, 'context menu support is best-effort for Linux and MacOS');
  320 |   await page.evaluate(() => {
  321 |     window['contextMenuPromise'] = new Promise(x => {
  322 |       window.addEventListener('contextmenu', x, false);
  323 |     });
  324 |   });
  325 |   const CX = 100;
  326 |   const CY = 100;
  327 |   await page.mouse.move(CX, CY);
  328 |   await page.mouse.down({ button: 'right' });
  329 |   await page.evaluate(() => window['contextMenuPromise']);
  330 |   const N = 20;
  331 |   for (const radius of [10, 30, 60, 90]) {
  332 |     for (let i = 0; i < N; ++i) {
  333 |       const angle = 2 * Math.PI * i / N;
  334 |       const x = CX + Math.round(radius * Math.cos(angle));
  335 |       const y = CY + Math.round(radius * Math.sin(angle));
  336 |       await page.mouse.move(x, y);
  337 |     }
  338 |   }
  339 | });
  340 | 
  341 | it('should track hover across iframe boundaries', async ({ page, headless }) => {
  342 |   it.skip(!headless, 'headed messes up with hover');
  343 | 
> 344 |   await page.setContent(`
      |              ^ Error: page.setContent: Page crashed
  345 |     <style>
  346 |       body, html { margin: 0; padding: 0; }
  347 |       #parentBox { position: absolute; left: 10px; top: 10px; width: 100px; height: 100px; }
  348 |       iframe { position: absolute; left: 200px; top: 10px; width: 200px; height: 200px; border: none; }
  349 |     </style>
  350 |     <div id="parentBox"></div>
  351 |     <iframe srcdoc="
  352 |       <style>body, html { margin: 0; padding: 0; } #childBox { width: 180px; height: 180px; }</style>
  353 |       <div id='childBox'></div>
  354 |       <script>
  355 |         const box = document.querySelector('#childBox');
  356 |         box.addEventListener('mouseenter', () => window.top.__log.push('child:enter'));
  357 |         box.addEventListener('mouseleave', () => window.top.__log.push('child:leave'));
  358 |       </script>
  359 |     "></iframe>
  360 |     <script>
  361 |       window.__log = [];
  362 |       const box = document.querySelector('#parentBox');
  363 |       box.addEventListener('mouseenter', () => window.__log.push('parent:enter'));
  364 |       box.addEventListener('mouseleave', () => window.__log.push('parent:leave'));
  365 |     </script>
  366 |   `);
  367 |   await page.waitForSelector('iframe');
  368 |   await page.frames()[1].waitForSelector('#childBox');
  369 |   const log = () => page.evaluate(() => window['__log']);
  370 |   const parentBox = (await page.locator('#parentBox').boundingBox())!;
  371 |   const iframeBox = (await page.locator('iframe').boundingBox())!;
  372 |   const parentCenter = { x: parentBox.x + parentBox.width / 2, y: parentBox.y + parentBox.height / 2 };
  373 |   const childCenter = { x: iframeBox.x + 90, y: iframeBox.y + 90 };
  374 | 
  375 |   await page.mouse.move(parentCenter.x, parentCenter.y);
  376 |   await expect.poll(log).toEqual(['parent:enter']);
  377 | 
  378 |   // Crossing into the iframe leaves the parent element and enters the child.
  379 |   await page.mouse.move(childCenter.x, childCenter.y);
  380 |   await expect.poll(log).toEqual(['parent:enter', 'parent:leave', 'child:enter']);
  381 | 
  382 |   // Crossing back out leaves the child element and re-enters the parent.
  383 |   await page.mouse.move(parentCenter.x, parentCenter.y);
  384 |   await expect.poll(log).toEqual(['parent:enter', 'parent:leave', 'child:enter', 'child:leave', 'parent:enter']);
  385 | });
  386 | 
```