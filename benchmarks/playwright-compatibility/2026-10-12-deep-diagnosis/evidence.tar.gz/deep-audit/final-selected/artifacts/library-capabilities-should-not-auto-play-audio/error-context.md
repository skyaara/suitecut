# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/capabilities.spec.ts >> should not auto play audio
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/capabilities.spec.ts:441:3

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('#log')
Expected: "State: suspended"
Received: "State: running"
Timeout:  10000ms

Call log:
  - Expect "toHaveText" with timeout 10000ms
  - waiting for locator('#log')
    6 × locator resolved to <div id="log"></div>
      - unexpected value ""
    18 × locator resolved to <div id="log">State: running</div>
       - unexpected value "State: running"

```

```yaml
- text: "State: running"
```

# Test source

```ts
  377 | 
  378 |   await page.goto(server.PREFIX + '/main.html');
  379 |   const iframe = page.frames()[1];
  380 |   await iframe.evaluate(() => window['activationPromise']);
  381 | 
  382 |   const response = await iframe.evaluate(async () => {
  383 |     const response = await fetch('foo.txt');
  384 |     return response.text();
  385 |   });
  386 |   expect(response).toBe('responseFromServiceWorker');
  387 | });
  388 | 
  389 | it('should be able to render avif images', {
  390 |   annotation: {
  391 |     type: 'issue',
  392 |     description: 'https://github.com/microsoft/playwright/issues/32673',
  393 |   }
  394 | }, async ({ page, server, browserName, platform, isFrozenWebkit }) => {
  395 |   it.skip(browserName === 'webkit' && platform === 'win32');
  396 |   it.skip(isFrozenWebkit);
  397 |   await page.goto(server.EMPTY_PAGE);
  398 |   await page.setContent(`<img src="${server.PREFIX}/rgb.avif" onerror="window.error = true">`);
  399 |   await expect.poll(() => page.locator('img').boundingBox()).toEqual(expect.objectContaining({
  400 |     width: 128,
  401 |     height: 128,
  402 |   }));
  403 |   expect(await page.evaluate(() => (window as any).error)).toBe(undefined);
  404 | });
  405 | 
  406 | it('should not crash when clicking a label with a <input type="file"/>', {
  407 |   annotation: {
  408 |     type: 'issue',
  409 |     description: 'https://github.com/microsoft/playwright/issues/33257'
  410 |   }
  411 | }, async ({ page }) => {
  412 |   await page.setContent(`
  413 |     <form>
  414 |       <label>
  415 |         A second file
  416 |         <input type="file" />
  417 |       </label>
  418 |     </form>
  419 |   `);
  420 |   const fileChooserPromise = page.waitForEvent('filechooser');
  421 |   await page.getByText('A second file').click();
  422 |   const fileChooser = await fileChooserPromise;
  423 |   expect(fileChooser.page()).toBe(page);
  424 | });
  425 | 
  426 | it('should not crash when clicking a color input', {
  427 |   annotation: {
  428 |     type: 'issue',
  429 |     description: 'https://github.com/microsoft/playwright/issues/33864'
  430 |   }
  431 | }, async ({ page }) => {
  432 | 
  433 |   await page.setContent('<input type="color">');
  434 |   const input = page.locator('input');
  435 | 
  436 |   await expect(input).toBeVisible();
  437 |   await input.click();
  438 |   await expect(input).toBeVisible();
  439 | });
  440 | 
  441 | it('should not auto play audio', {
  442 |   annotation: {
  443 |     type: 'issue',
  444 |     description: 'https://github.com/microsoft/playwright/issues/33590'
  445 |   }
  446 | }, async ({ page, browserName, isWindows }) => {
  447 |   it.skip(browserName === 'webkit' && isWindows, 'audio does not play at all');
  448 |   it.skip(process.env.PW_CLOCK === 'frozen', 'no way to inject real setTimeout');
  449 |   await page.route('**/*', async route => {
  450 |     await route.fulfill({
  451 |       status: 200,
  452 |       contentType: 'text/html',
  453 |       body: `
  454 |       <script>
  455 |         async function onLoad() {
  456 |           const log = document.getElementById('log');
  457 |           const audioContext = new AudioContext();
  458 |           const gainNode = new GainNode(audioContext);
  459 |           gainNode.connect(audioContext.destination);
  460 |           gainNode.gain.value = 0.025;
  461 |           const sineNode = new OscillatorNode(audioContext);
  462 |           sineNode.connect(gainNode);
  463 |           sineNode.start();
  464 |           await new Promise((resolve) => setTimeout(resolve, 1000));
  465 |           log.innerHTML = 'State: ' + audioContext.state;
  466 |         }
  467 |       </script>
  468 |       <body onload="onLoad()">
  469 |       <div id="log"></div>
  470 |       </body>`,
  471 |     });
  472 |   });
  473 |   await page.goto('http://127.0.0.1/audio.html');
  474 |   if (browserName === 'webkit')
  475 |     await expect(page.locator('#log')).toHaveText(/State: (interrupted|suspended)/);
  476 |   else
> 477 |     await expect(page.locator('#log')).toHaveText('State: suspended');
      |                                        ^ Error: expect(locator).toHaveText(expected) failed
  478 | });
  479 | 
  480 | it('should not crash on feature detection for PublicKeyCredential', {
  481 |   annotation: {
  482 |     type: 'issue',
  483 |     description: 'https://github.com/microsoft/playwright/issues/35433'
  484 |   }
  485 | }, async ({ page, server }) => {
  486 |   await page.goto(server.EMPTY_PAGE);
  487 |   await page.evaluate(async () => {
  488 |     await PublicKeyCredential.getClientCapabilities();
  489 |     await PublicKeyCredential.isConditionalMediationAvailable();
  490 |     await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  491 |   });
  492 | });
  493 | 
```