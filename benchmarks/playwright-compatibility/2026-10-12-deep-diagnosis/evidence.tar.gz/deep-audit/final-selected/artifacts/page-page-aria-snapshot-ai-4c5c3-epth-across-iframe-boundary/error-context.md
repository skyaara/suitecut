# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-aria-snapshot-ai.spec.ts >> should limit depth across iframe boundary
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-aria-snapshot-ai.spec.ts:85:3

# Error details

```
Error: page.setContent: Page crashed
Call log:
  - setting frame content, waiting until "load"

```

# Test source

```ts
  1   | /**
  2   |  * Copyright (c) Microsoft Corporation.
  3   |  *
  4   |  * Licensed under the Apache License, Version 2.0 (the "License");
  5   |  * you may not use this file except in compliance with the License.
  6   |  * You may obtain a copy of the License at
  7   |  *
  8   |  * http://www.apache.org/licenses/LICENSE-2.0
  9   |  *
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | 
  18  | import { test as it, expect } from './pageTest';
  19  | import { unshift } from '../config/utils';
  20  | import type { Page } from 'playwright-core';
  21  | 
  22  | async function snapshotForAI(page: Page, options?: Omit<Parameters<Page['ariaSnapshot']>[0], 'mode'>): Promise<string> {
  23  |   return await page.ariaSnapshot({ ...options, mode: 'ai' });
  24  | }
  25  | 
  26  | it('should generate refs', async ({ page }) => {
  27  |   await page.setContent(`
  28  |     <button>One</button>
  29  |     <button>Two</button>
  30  |     <button>Three</button>
  31  |   `);
  32  | 
  33  |   const snapshot1 = await snapshotForAI(page);
  34  |   expect(snapshot1).toContainYaml(`
  35  |     - generic [active] [ref=e1]:
  36  |       - button "One" [ref=e2]
  37  |       - button "Two" [ref=e3]
  38  |       - button "Three" [ref=e4]
  39  |   `);
  40  |   await expect(page.locator('aria-ref=e2')).toHaveText('One');
  41  |   await expect(page.locator('aria-ref=e3')).toHaveText('Two');
  42  |   await expect(page.locator('aria-ref=e4')).toHaveText('Three');
  43  | 
  44  |   await page.locator('aria-ref=e3').evaluate((e: HTMLElement) => {
  45  |     e.textContent = 'Not Two';
  46  |   });
  47  | 
  48  |   const snapshot2 = await snapshotForAI(page);
  49  |   expect(snapshot2).toContainYaml(`
  50  |     - generic [active] [ref=e1]:
  51  |       - button "One" [ref=e2]
  52  |       - button "Not Two" [ref=e5]
  53  |       - button "Three" [ref=e4]
  54  |   `);
  55  | });
  56  | 
  57  | it('should list iframes', async ({ page }) => {
  58  |   await page.setContent(`
  59  |     <h1>Hello</h1>
  60  |     <iframe name="foo" src="data:text/html,<h1>World</h1>">
  61  |   `);
  62  | 
  63  |   const snapshot1 = await snapshotForAI(page);
  64  |   expect(snapshot1).toContain('- iframe');
  65  | 
  66  |   const frameSnapshot = await page.frameLocator(`iframe`).locator('body').ariaSnapshot();
  67  |   expect(frameSnapshot).toEqual('- heading "World" [level=1]');
  68  | });
  69  | 
  70  | it('should snapshot a locator inside an iframe', async ({ page }) => {
  71  |   await page.setContent(`
  72  |     <h1>Main Page</h1>
  73  |     <iframe srcdoc="<ul><li>Item 1</li><li>Item 2</li></ul>"></iframe>
  74  |   `);
  75  | 
  76  |   const list = page.frames()[1].locator('ul');
  77  |   const snapshot = await list.ariaSnapshot({ mode: 'ai' });
  78  |   expect(snapshot).toContainYaml(`
  79  |     - list [ref=f1e1]:
  80  |       - listitem [ref=f1e2]: Item 1
  81  |       - listitem [ref=f1e3]: Item 2
  82  |   `);
  83  | });
  84  | 
  85  | it('should limit depth across iframe boundary', async ({ page }) => {
> 86  |   await page.setContent(`
      |              ^ Error: page.setContent: Page crashed
  87  |     <nav>
  88  |       <iframe srcdoc="<ul><li><button>Deep</button></li></ul>"></iframe>
  89  |     </nav>
  90  |   `);
  91  | 
  92  |   const snapshot = await snapshotForAI(page, { depth: 3 });
  93  |   expect(snapshot).toContainYaml(`
  94  |     - navigation [ref=e2]:
  95  |       - iframe [ref=e3]:
  96  |         - list [ref=f1e2]:
  97  |           - listitem [ref=f1e3]
  98  |   `);
  99  |   expect(snapshot).not.toContain('button');
  100 | });
  101 | 
  102 | it('should stitch all frame snapshots', async ({ page, server }) => {
  103 |   await page.goto(server.PREFIX + '/frames/nested-frames.html');
  104 |   const snapshot = await snapshotForAI(page);
  105 |   expect(snapshot).toContainYaml(`
  106 |     - generic [active] [ref=e1]:
  107 |       - iframe [ref=e2]:
  108 |         - generic [ref=f1e1]:
  109 |           - iframe [ref=f1e2]:
  110 |             - generic [ref=f3e1]: Hi, I'm frame
  111 |           - iframe [ref=f1e3]:
  112 |             - generic [ref=f4e1]: Hi, I'm frame
  113 |       - iframe [ref=e3]:
  114 |         - generic [ref=f2e1]: Hi, I'm frame
  115 |   `);
  116 | 
  117 |   const href = await page.locator('aria-ref=e1').evaluate(e => e.ownerDocument.defaultView.location.href);
  118 |   expect(href).toBe(server.PREFIX + '/frames/nested-frames.html');
  119 | 
  120 |   const href2 = await page.locator('aria-ref=f1e2').evaluate(e => e.ownerDocument.defaultView.location.href);
  121 |   expect(href2).toBe(server.PREFIX + '/frames/two-frames.html');
  122 | 
  123 |   const href3 = await page.locator('aria-ref=f4e2').evaluate(e => e.ownerDocument.defaultView.location.href);
  124 |   expect(href3).toBe(server.PREFIX + '/frames/frame.html');
  125 | 
  126 |   {
  127 |     const resolved = await page.locator('aria-ref=e1').normalize();
  128 |     expect(resolved.toString()).toBe(`locator('body')`);
  129 |   }
  130 |   {
  131 |     const resolved = await page.locator('aria-ref=f4e2').normalize();
  132 |     expect(resolved.toString()).toBe(`locator('iframe[name="2frames"]').contentFrame().locator('iframe[name="dos"]').contentFrame().getByText('Hi, I\\'m frame')`);
  133 |   }
  134 |   {
  135 |     // Should tolerate .describe().
  136 |     const resolved = await page.locator('aria-ref=f3e2').describe('foo bar').normalize();
  137 |     expect(resolved.toString()).toBe(`locator('iframe[name=\"2frames\"]').contentFrame().locator('iframe[name=\"uno\"]').contentFrame().getByText('Hi, I\\'m frame')`);
  138 |   }
  139 |   {
  140 |     const error = await page.locator('aria-ref=e1000').normalize().catch(e => e);
  141 |     expect(error.message).toContain(`No element matching aria-ref=e1000`);
  142 |   }
  143 | });
  144 | 
  145 | it('should re-number refs across navigations but not same-document navigations', async ({ page, server }) => {
  146 |   server.setRoute('/one.html', (req, res) => {
  147 |     res.setHeader('Content-Type', 'text/html');
  148 |     res.end('<button>One</button>');
  149 |   });
  150 |   server.setRoute('/two.html', (req, res) => {
  151 |     res.setHeader('Content-Type', 'text/html');
  152 |     res.end('<button>Two</button>');
  153 |   });
  154 | 
  155 |   // The first committed document keeps the base seq, so the main frame has no prefix.
  156 |   await page.goto(server.PREFIX + '/one.html');
  157 |   const oneRef = (await snapshotForAI(page)).match(/button "One" \[ref=(e\d+)\]/)![1];
  158 |   await expect(page.locator(`aria-ref=${oneRef}`)).toHaveText('One');
  159 | 
  160 |   // Cross-document navigation re-numbers the main frame, so its refs gain a frame prefix.
  161 |   await page.goto(server.PREFIX + '/two.html');
  162 |   const twoRef = (await snapshotForAI(page)).match(/button "Two" \[ref=(f\d+e\d+)\]/)![1];
  163 |   await expect(page.locator(`aria-ref=${twoRef}`)).toHaveText('Two');
  164 | 
  165 |   // The stale ref from the previous document must not resolve against the new one.
  166 |   const error = await page.locator(`aria-ref=${oneRef}`).normalize().catch(e => e);
  167 |   expect(error.message).toContain(`No element matching aria-ref=${oneRef}`);
  168 | 
  169 |   // Same-document navigation keeps refs intact.
  170 |   await page.evaluate(() => history.pushState({}, '', '/pushed.html'));
  171 |   expect(await snapshotForAI(page)).toContain(`button "Two" [ref=${twoRef}]`);
  172 |   await expect(page.locator(`aria-ref=${twoRef}`)).toHaveText('Two');
  173 | });
  174 | 
  175 | it('should persist iframe references', async ({ page }) => {
  176 |   await page.setContent(`
  177 |     <ul>
  178 |       <li><iframe srcdoc="<button>button1</button>"></iframe></li>
  179 |       <li><iframe srcdoc="<button>button2</button>"></iframe></li>
  180 |     </ul>
  181 |   `);
  182 |   expect(await snapshotForAI(page)).toContainYaml(`
  183 |     - list [ref=e2]:
  184 |       - listitem [ref=e3]:
  185 |         - iframe [ref=e4]:
  186 |           - button "button1" [ref=f1e2]
```