import os,pathlib,json,subprocess
base=pathlib.Path('/tmp/suitecut-deep-audit');out=base/'stock-control';out.mkdir(exist_ok=True)
env=dict(os.environ,**json.load(open(base/'runtime-env.json')))
with (out/'results.jsonl').open('w') as log:
 r=subprocess.run(['node',str(base/'stock-control.mjs')],env=env,stdout=log,stderr=(out/'node.log').open('w'),timeout=30)
print(r.returncode)
