# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/heap.spec.ts >> should not leak fixtures w/o page
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/heap.spec.ts:178:5

# Error details

```
Error: listen EADDRINUSE: address already in use :::8907
```

# Test source

```ts
  18  | import fs from 'fs';
  19  | import type http from 'http';
  20  | import mime from 'mime';
  21  | import type net from 'net';
  22  | import path from 'path';
  23  | import util from 'util';
  24  | import type stream from 'stream';
  25  | import { WebSocket, WebSocketServer } from 'ws';
  26  | import zlib, { gzip } from 'zlib';
  27  | import { utils } from '../../../packages/playwright-core/lib/coreBundle';
  28  | 
  29  | const { createHttpServer, createHttpsServer } = utils;
  30  | 
  31  | const fulfillSymbol = Symbol('fulfil callback');
  32  | const rejectSymbol = Symbol('reject callback');
  33  | 
  34  | const gzipAsync = util.promisify(gzip.bind(zlib));
  35  | 
  36  | type UpgradeActions = {
  37  |   doUpgrade: () => void;
  38  |   socket: stream.Duplex;
  39  | };
  40  | 
  41  | type IncomingMessageWithBody = http.IncomingMessage & { postBody: Promise<Buffer> };
  42  | 
  43  | export class TestServer {
  44  |   private _server: http.Server;
  45  |   private _wsServer: WebSocketServer;
  46  |   private _dirPath: string;
  47  |   readonly debugServer: any;
  48  |   private _startTime: Date;
  49  |   private _cachedPathPrefix: string | null;
  50  |   private _routes = new Map<string, (arg0: IncomingMessageWithBody, arg1: http.ServerResponse) => any>();
  51  |   private _auths = new Map<string, { username: string; password: string; }>();
  52  |   private _csp = new Map<string, string>();
  53  |   private _extraHeaders = new Map<string, object>();
  54  |   private _gzipRoutes = new Set<string>();
  55  |   private _requestSubscribers = new Map<string, Promise<any>>();
  56  |   private _upgradeCallback: (actions: UpgradeActions) => void | undefined;
  57  |   readonly PORT: number;
  58  |   readonly PREFIX: string;
  59  |   readonly CROSS_PROCESS_PREFIX: string;
  60  |   readonly EMPTY_PAGE: string;
  61  |   readonly HOST: string;
  62  |   readonly HOSTNAME: string;
  63  |   readonly HELLO_WORLD: string;
  64  | 
  65  |   static async create(dirPath: string, port: number, loopback?: string): Promise<TestServer> {
  66  |     const server = new TestServer(dirPath, port, loopback);
  67  |     await server.waitUntilReady();
  68  |     return server;
  69  |   }
  70  | 
  71  |   static async certOptions() {
  72  |     return {
  73  |       key: await fs.promises.readFile(path.join(__dirname, 'key.pem')),
  74  |       cert: await fs.promises.readFile(path.join(__dirname, 'cert.pem')),
  75  |       passphrase: 'aaaa',
  76  |     };
  77  |   }
  78  | 
  79  |   static async createHTTPS(dirPath: string, port: number, loopback?: string): Promise<TestServer> {
  80  |     const server = new TestServer(dirPath, port, loopback, await this.certOptions());
  81  |     await server.waitUntilReady();
  82  |     return server;
  83  |   }
  84  | 
  85  |   constructor(dirPath: string, port: number, loopback?: string, sslOptions?: object) {
  86  |     if (sslOptions)
  87  |       this._server = createHttpsServer(sslOptions, this._onRequest.bind(this));
  88  |     else
  89  |       this._server = createHttpServer(this._onRequest.bind(this));
  90  |     this._server.on('connection', socket => this._onSocket(socket));
  91  |     this._wsServer = new WebSocketServer({ noServer: true });
  92  |     this._server.on('upgrade', async (request, socket, head) => {
  93  |       const doUpgrade = () => {
  94  |         this._wsServer.handleUpgrade(request, socket, head, ws => {
  95  |           // Next emit is only for our internal 'connection' listeners.
  96  |           this._wsServer.emit('connection', ws, request);
  97  |         });
  98  |       };
  99  |       if (this._upgradeCallback) {
  100 |         this._upgradeCallback({ doUpgrade, socket });
  101 |         return;
  102 |       }
  103 |       const pathname = new URL(request.url, 'http://localhost').pathname;
  104 |       if (pathname === '/ws-401') {
  105 |         socket.write('HTTP/1.1 401 Unauthorized\r\n\r\nUnauthorized body');
  106 |         socket.destroy();
  107 |         return;
  108 |       }
  109 |       if (pathname === '/ws-slow')
  110 |         await new Promise(f => setTimeout(f, 2000));
  111 |       if (!['/ws', '/ws-slow'].includes(pathname)) {
  112 |         socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
  113 |         socket.destroy();
  114 |         return;
  115 |       }
  116 |       doUpgrade();
  117 |     });
> 118 |     this._server.listen(port);
      |                  ^ Error: listen EADDRINUSE: address already in use :::8907
  119 |     this._dirPath = dirPath;
  120 |     this.debugServer = require('debug')('pw:testserver');
  121 | 
  122 |     this._startTime = new Date();
  123 |     this._cachedPathPrefix = null;
  124 | 
  125 |     const cross_origin = loopback || '127.0.0.1';
  126 |     const same_origin = loopback || 'localhost';
  127 |     const protocol = sslOptions ? 'https' : 'http';
  128 |     this.PORT = port;
  129 |     this.PREFIX = `${protocol}://${same_origin}:${port}`;
  130 |     this.CROSS_PROCESS_PREFIX = `${protocol}://${cross_origin}:${port}`;
  131 |     this.EMPTY_PAGE = `${protocol}://${same_origin}:${port}/empty.html`;
  132 |     this.HOST = new URL(this.EMPTY_PAGE).host;
  133 |     this.HOSTNAME = new URL(this.EMPTY_PAGE).hostname;
  134 |     this.HELLO_WORLD = `${this.PREFIX}/hello-world`;
  135 |   }
  136 | 
  137 |   async waitUntilReady() {
  138 |     await new Promise(x => this._server.once('listening', x));
  139 |   }
  140 | 
  141 |   _onSocket(socket: net.Socket) {
  142 |     // ECONNRESET and HPE_INVALID_EOF_STATE are legit errors given
  143 |     // that tab closing aborts outgoing connections to the server.
  144 |     // HPE_INVALID_METHOD is a legit error when a client (e.g. Chromium which
  145 |     // makes https requests to http sites) makes a https connection to a http server.
  146 |     socket.on('error', error => {
  147 |       if (!['ECONNRESET', 'HPE_INVALID_EOF_STATE', 'HPE_INVALID_METHOD'].includes((error as any).code))
  148 |         throw error;
  149 |     });
  150 |   }
  151 | 
  152 |   enableHTTPCache(pathPrefix: string) {
  153 |     this._cachedPathPrefix = pathPrefix;
  154 |   }
  155 | 
  156 |   setAuth(path: string, username: string, password: string) {
  157 |     this.debugServer(`set auth for ${path} to ${username}:${password}`);
  158 |     this._auths.set(path, { username, password });
  159 |   }
  160 | 
  161 |   enableGzip(path: string) {
  162 |     this._gzipRoutes.add(path);
  163 |   }
  164 | 
  165 |   setCSP(path: string, csp: string) {
  166 |     this._csp.set(path, csp);
  167 |   }
  168 | 
  169 |   setExtraHeaders(path: string, object: Record<string, string>) {
  170 |     this._extraHeaders.set(path, object);
  171 |   }
  172 | 
  173 |   async stop() {
  174 |     this.reset();
  175 |     await new Promise(x => this._server.close(x));
  176 |   }
  177 | 
  178 |   setContent(path: string, content: string, mimeType: string) {
  179 |     this.setRoute(path, (req, res) => {
  180 |       res.writeHead(200, { 'Content-Type': mimeType });
  181 |       res.end(mimeType === 'text/html' ? `<!DOCTYPE html>${content}` : content);
  182 |     });
  183 |   }
  184 | 
  185 |   setRoute(path: string, handler: (arg0: IncomingMessageWithBody, arg1: http.ServerResponse) => any) {
  186 |     this._routes.set(path, handler);
  187 |   }
  188 | 
  189 |   setRedirect(from: string, to: string) {
  190 |     this.setRoute(from, (req, res) => {
  191 |       const headers = this._extraHeaders.get(req.url!) || {};
  192 |       res.writeHead(302, { ...headers, location: to });
  193 |       res.end();
  194 |     });
  195 |   }
  196 | 
  197 |   waitForRequest(path: string): Promise<IncomingMessageWithBody> {
  198 |     let promise = this._requestSubscribers.get(path);
  199 |     if (promise)
  200 |       return promise;
  201 |     let fulfill;
  202 |     let reject;
  203 |     promise = new Promise((f, r) => {
  204 |       fulfill = f;
  205 |       reject = r;
  206 |     });
  207 |     promise[fulfillSymbol] = fulfill;
  208 |     const error = new Error(`Request ${path} was not received before the test finished.`);
  209 |     promise[rejectSymbol] = () => reject(error);
  210 |     this._requestSubscribers.set(path, promise);
  211 |     return promise;
  212 |   }
  213 | 
  214 |   reset() {
  215 |     this._routes.clear();
  216 |     this._auths.clear();
  217 |     this._csp.clear();
  218 |     this._extraHeaders.clear();
```