# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/suitecut-deep-diagnostic.spec.ts >> bulk handles 1500
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/suitecut-deep-diagnostic.spec.ts:3:7

# Error details

```
Error: page.$$: Frame has been detached.
```

# Test source

```ts
  1  | import { contextTest as test, expect } from '../config/browserTest';
  2  | for (const count of [200,600,1000,1500,2000]) {
  3  |   test('bulk handles '+count, async ({page,server,toImpl}) => {
  4  |     await page.goto(server.EMPTY_PAGE);
  5  |     await page.setContent('<div><span>hi</span></div>'.repeat(count));
  6  |     const impl=toImpl(page); const delegate=impl.delegate;
  7  |     const original=delegate._sessionForFrame.bind(delegate);
  8  |     delegate._sessionForFrame=(frame)=>{
  9  |       try{return original(frame);}catch(error){console.log('FRAME-DIAGNOSTIC',JSON.stringify({frame:frame._id,parent:frame._parentFrame?._id,sessions:[...delegate._sessions.keys()],frames:impl.frameManager.frames().map(f=>[f._id,f._parentFrame?._id])}),new Error().stack);throw error;}
  10 |     };
> 11 |     expect((await page.$$('div')).length).toBe(count);
     |                        ^ Error: page.$$: Frame has been detached.
  12 |   });
  13 | }
  14 | 
```