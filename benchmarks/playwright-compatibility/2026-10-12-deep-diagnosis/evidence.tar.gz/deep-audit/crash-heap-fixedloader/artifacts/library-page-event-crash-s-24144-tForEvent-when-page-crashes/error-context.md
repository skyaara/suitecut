# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/page-event-crash.spec.ts >> should cancel waitForEvent when page crashes
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/page-event-crash.spec.ts:74:1

# Error details

```
Error: Native browser exited unexpectedly (127)
```

# Test source

```ts
  186 |         // Observers cannot prevent terminal process cleanup.
  187 |       }
  188 |     }
  189 |     failures.clear()
  190 |     for (const request of pending.values()) {
  191 |       clearTimeout(request.timer)
  192 |       request.reject(error)
  193 |     }
  194 |     pending.clear()
  195 |     if (!exited) child.kill('SIGKILL')
  196 |   }
  197 |   const decoder = new NativePacketDecoder((header, payload) => {
  198 |     if (terminal) return
  199 |     if (header.type === 'ready') {
  200 |       if (clockOffset !== undefined) throw new Error('Duplicate native handshake')
  201 |       clockOffset = performance.now() - header.timestampMs
  202 |       cefVersion = header.cefVersion
  203 |       frameSubscriptions = header.frameSubscriptions === true
  204 |       audioSubscriptions = header.audioSubscriptions === true
  205 |       nativeMedia = header.nativeMedia === true
  206 |       resolveReady()
  207 |       return
  208 |     }
  209 |     if (clockOffset === undefined) throw new Error('Native packet before handshake')
  210 |     if (header.type === 'event') {
  211 |       const message = JSON.parse(payload.toString('utf8')) as UntrustedInput
  212 |       for (const listener of protocolEvents) listener(message, payload.length)
  213 |       return
  214 |     }
  215 |     if (header.type === 'error') {
  216 |       fail(new Error(`Native browser: ${header.error}`))
  217 |       return
  218 |     }
  219 |     if (header.type === 'response') {
  220 |       const request = pending.get(header.id)
  221 |       if (!request) return // A timed-out command may complete later.
  222 |       const result =
  223 |         header.ok && payload.length
  224 |           ? (JSON.parse(payload.toString('utf8')) as UntrustedInput)
  225 |           : undefined
  226 |       pending.delete(header.id)
  227 |       clearTimeout(request.timer)
  228 |       if (header.ok) request.resolve(result)
  229 |       else request.reject(new Error(header.error ?? 'Native command failed'))
  230 |       return
  231 |     }
  232 |     if (stopping) return
  233 |     if (header.type === 'frame') {
  234 |       if (
  235 |         header.pixelFormat !== config.pixelFormat ||
  236 |         header.width !== Math.round(config.width * config.deviceScaleFactor) ||
  237 |         header.height !== Math.round(config.height * config.deviceScaleFactor)
  238 |       ) {
  239 |         fail(new Error('Native frame dimensions changed unexpectedly'))
  240 |         return
  241 |       }
  242 |       if (frames.size === 0 && frameSubscriptions) return
  243 |       // The ready packet's one-way transit time can overestimate the clock
  244 |       // offset. A captured video frame cannot arrive from the future. Refine
  245 |       // that upper bound without moving the clock forward on delayed packets.
  246 |       clockOffset = Math.min(clockOffset ?? 0, performance.now() - header.timestampMs)
  247 |       lastFrame = {
  248 |         data: payload,
  249 |         pixelFormat: header.pixelFormat,
  250 |         width: header.width,
  251 |         height: header.height,
  252 |         timestampMs: header.timestampMs + clockOffset,
  253 |         droppedFrames: header.dropped,
  254 |       }
  255 |       for (const listener of frames) listener(lastFrame)
  256 |     } else {
  257 |       const packet = {
  258 |         data: payload,
  259 |         frames: header.frames,
  260 |         timestampMs: header.timestampMs + clockOffset,
  261 |       }
  262 |       for (const listener of audio) listener(packet)
  263 |     }
  264 |   })
  265 |   child.stdout.on('data', (chunk: Buffer) => {
  266 |     if (terminal) return
  267 |     try {
  268 |       decoder.push(chunk)
  269 |     } catch {
  270 |       fail(new Error('Native browser protocol or subscriber failure'))
  271 |     }
  272 |   })
  273 |   // Drain Chromium diagnostics without exposing page URLs or credentials to logs.
  274 |   child.stderr.resume()
  275 |   child.stdin.on('error', () => {
  276 |     if (!stopping) fail(new Error('Native browser command pipe failed'))
  277 |   })
  278 |   child.once('error', () => fail(new Error('Could not launch the native browser executable')))
  279 |   child.once('close', (code) => {
  280 |     exited = true
  281 |     try {
  282 |       decoder.end()
  283 |     } catch {
  284 |       if (!stopping) fail(new Error('Native browser output was truncated'))
  285 |     }
> 286 |     if (!stopping) fail(new Error(`Native browser exited unexpectedly (${String(code)})`))
      |                         ^ Error: Native browser exited unexpectedly (127)
  287 |     frames.clear()
  288 |     audio.clear()
  289 |     protocolEvents.clear()
  290 |     lastFrame = undefined
  291 |     config.signal?.removeEventListener('abort', abort)
  292 |     const finish = () => {
  293 |       fullyClosed = true
  294 |       resolveClosed()
  295 |       for (const listener of closes) {
  296 |         try {
  297 |           listener()
  298 |         } catch {
  299 |           // Closing all subscriptions takes precedence over observer errors.
  300 |         }
  301 |       }
  302 |       closes.clear()
  303 |       failures.clear()
  304 |     }
  305 |     void rm(profile, { recursive: true, force: true }).then(finish, () => {
  306 |       fail(new Error('Could not remove the native browser temporary profile'))
  307 |       finish()
  308 |     })
  309 |   })
  310 |   const request = (
  311 |     command: string,
  312 |     fields: Record<string, UntrustedInput> = {},
  313 |   ): Promise<UntrustedInput> => {
  314 |     if (terminal || stopping || exited)
  315 |       return Promise.reject(terminal ?? new Error('Native browser is closed'))
  316 |     if (pending.size >= 64) return Promise.reject(new Error('Too many pending native commands'))
  317 |     const id = ++nextId
  318 |     const message =
  319 |       JSON.stringify({ ...fields, version: NATIVE_PROTOCOL_VERSION, id, command }) + '\n'
  320 |     if (Buffer.byteLength(message) > 4_194_304)
  321 |       return Promise.reject(new Error('Native command exceeds 4 MiB'))
  322 |     return new Promise((resolve, reject) => {
  323 |       const timer = setTimeout(
  324 |         () => {
  325 |           pending.delete(id)
  326 |           reject(new Error('Native browser command timed out'))
  327 |         },
  328 |         command === 'media.render' || command === 'media.cut' ? 3_600_000 : 30_000,
  329 |       )
  330 |       pending.set(id, { resolve, reject, timer })
  331 |       child.stdin.write(message)
  332 |     })
  333 |   }
  334 |   const close = (): Promise<void> => {
  335 |     if (closing) return closing
  336 |     stopping = true
  337 |     closing = (async () => {
  338 |       for (const item of pending.values()) {
  339 |         clearTimeout(item.timer)
  340 |         item.reject(new Error('Native browser is closing'))
  341 |       }
  342 |       pending.clear()
  343 |       if (!exited) child.stdin.end()
  344 |       const timer = setTimeout(() => child.kill('SIGKILL'), 15000)
  345 |       try {
  346 |         await closed
  347 |       } finally {
  348 |         clearTimeout(timer)
  349 |       }
  350 |     })()
  351 |     return closing
  352 |   }
  353 |   const abort = (): void => {
  354 |     fail(new Error('Native browser aborted'))
  355 |     void close()
  356 |   }
  357 |   config.signal?.addEventListener('abort', abort, { once: true })
  358 |   if (config.signal?.aborted) abort()
  359 |   try {
  360 |     await raceWithAbort(
  361 |       Promise.race([ready, failure]),
  362 |       AbortSignal.timeout(config.startupTimeoutMs),
  363 |     )
  364 |     if (frameSubscriptions) await request('frames', { enabled: false })
  365 |     if (audioSubscriptions) await request('audio', { enabled: false })
  366 |   } catch (error) {
  367 |     await close()
  368 |     throw error
  369 |   }
  370 |   return {
  371 |     get state() {
  372 |       return terminal ? 'failed' : exited ? 'closed' : stopping ? 'closing' : 'running'
  373 |     },
  374 |     pixelFormat: config.pixelFormat,
  375 |     width: Math.round(config.width * config.deviceScaleFactor),
  376 |     height: Math.round(config.height * config.deviceScaleFactor),
  377 |     framesPerSecond: config.framesPerSecond,
  378 |     cefVersion,
  379 |     nativeMedia,
  380 |     command: request,
  381 |     onProtocolEvent: (listener) => {
  382 |       protocolEvents.add(listener)
  383 |       return () => {
  384 |         protocolEvents.delete(listener)
  385 |       }
  386 |     },
```