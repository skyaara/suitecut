# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/client-certificates.spec.ts >> browser >> should pass with matching certificates and when a http proxy is used from env
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/client-certificates.spec.ts:450:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 3
+ Received  + 1

- Array [
-   "127.0.0.1:34293",
- ]
+ Array []
```

# Test source

```ts
  366 |     }
  367 |     await page.close();
  368 |   });
  369 | 
  370 |   test('should fail with no client certificates', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  371 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  372 |     const page = await browser.newPage({
  373 |       ignoreHTTPSErrors: true,
  374 |       clientCertificates: [{
  375 |         origin: 'https://not-matching.com',
  376 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  377 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  378 |       }],
  379 |     });
  380 |     await page.goto(serverURL);
  381 |     await expect(page.getByTestId('message')).toHaveText('Sorry, but you need to provide a client certificate to continue.');
  382 |     await page.close();
  383 |   });
  384 | 
  385 |   test('should fail with self-signed client certificates', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  386 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  387 |     const page = await browser.newPage({
  388 |       ignoreHTTPSErrors: true,
  389 |       clientCertificates: [{
  390 |         origin: new URL(serverURL).origin,
  391 |         certPath: asset('client-certificates/client/self-signed/cert.pem'),
  392 |         keyPath: asset('client-certificates/client/self-signed/key.pem'),
  393 |       }],
  394 |     });
  395 |     await page.goto(serverURL);
  396 |     await expect(page.getByTestId('message')).toHaveText('Sorry Bob, certificates from Bob are not welcome here.');
  397 |     await page.close();
  398 |   });
  399 | 
  400 |   test('should pass with matching certificates', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  401 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  402 |     const page = await browser.newPage({
  403 |       ignoreHTTPSErrors: true,
  404 |       clientCertificates: [{
  405 |         origin: new URL(serverURL).origin,
  406 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  407 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  408 |       }],
  409 |     });
  410 |     await page.goto(serverURL);
  411 |     await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  412 |     await page.close();
  413 |   });
  414 | 
  415 |   test('should pass with matching certificates when passing as content', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  416 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  417 |     const page = await browser.newPage({
  418 |       ignoreHTTPSErrors: true,
  419 |       clientCertificates: [{
  420 |         origin: new URL(serverURL).origin,
  421 |         cert: await fs.promises.readFile(asset('client-certificates/client/trusted/cert.pem')),
  422 |         key: await fs.promises.readFile(asset('client-certificates/client/trusted/key.pem')),
  423 |       }],
  424 |     });
  425 |     await page.goto(serverURL);
  426 |     await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  427 |     await page.close();
  428 |   });
  429 | 
  430 |   test('should pass with matching certificates and when a http proxy is used', async ({ browser, startCCServer, asset, browserName, proxyServer, isMac }) => {
  431 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  432 |     proxyServer.forwardTo(parseInt(new URL(serverURL).port, 10), { allowConnectRequests: true });
  433 |     const page = await browser.newPage({
  434 |       ignoreHTTPSErrors: true,
  435 |       clientCertificates: [{
  436 |         origin: new URL(serverURL).origin,
  437 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  438 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  439 |       }],
  440 |       proxy: { server: `localhost:${proxyServer.PORT}` }
  441 |     });
  442 |     expect(proxyServer.connectHosts).toEqual([]);
  443 |     await page.goto(serverURL);
  444 |     const host = browserName === 'webkit' && isMac ? 'localhost' : '127.0.0.1';
  445 |     expect([...new Set(proxyServer.connectHosts)]).toEqual([`${host}:${new URL(serverURL).port}`]);
  446 |     await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  447 |     await page.close();
  448 |   });
  449 | 
  450 |   test('should pass with matching certificates and when a http proxy is used from env', async ({ mode, browser, startCCServer, asset, browserName, proxyServer, isMac }) => {
  451 |     test.skip(mode !== 'default', 'Out of process transport does not allow us to set env vars dynamically');
  452 |     process.env.HTTPS_PROXY = `http://localhost:${proxyServer.PORT}`;
  453 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  454 |     proxyServer.forwardTo(parseInt(new URL(serverURL).port, 10), { allowConnectRequests: true });
  455 |     const page = await browser.newPage({
  456 |       ignoreHTTPSErrors: true,
  457 |       clientCertificates: [{
  458 |         origin: new URL(serverURL).origin,
  459 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  460 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  461 |       }],
  462 |     });
  463 |     expect(proxyServer.connectHosts).toEqual([]);
  464 |     await page.goto(serverURL);
  465 |     const host = browserName === 'webkit' && isMac ? 'localhost' : '127.0.0.1';
> 466 |     expect([...new Set(proxyServer.connectHosts)]).toEqual([`${host}:${new URL(serverURL).port}`]);
      |                                                    ^ Error: expect(received).toEqual(expected) // deep equality
  467 |     await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  468 |     await page.close();
  469 |     delete process.env.HTTPS_PROXY;
  470 |   });
  471 | 
  472 |   test('should pass with matching certificates and when a http proxy is used from config but env is there', async ({ browser, startCCServer, asset, browserName, proxyServer, isMac }) => {
  473 |     process.env.HTTPS_PROXY = `http://this-should-not-taken-into-account:4242`;
  474 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  475 |     proxyServer.forwardTo(parseInt(new URL(serverURL).port, 10), { allowConnectRequests: true });
  476 |     const page = await browser.newPage({
  477 |       ignoreHTTPSErrors: true,
  478 |       clientCertificates: [{
  479 |         origin: new URL(serverURL).origin,
  480 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  481 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  482 |       }],
  483 |       proxy: { server: `localhost:${proxyServer.PORT}` }
  484 |     });
  485 |     expect(proxyServer.connectHosts).toEqual([]);
  486 |     await page.goto(serverURL);
  487 |     const host = browserName === 'webkit' && isMac ? 'localhost' : '127.0.0.1';
  488 |     expect([...new Set(proxyServer.connectHosts)]).toEqual([`${host}:${new URL(serverURL).port}`]);
  489 |     await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  490 |     await page.close();
  491 |     delete process.env.HTTPS_PROXY;
  492 |   });
  493 | 
  494 |   test('should pass with matching certificates and when a socks proxy is used', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  495 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  496 |     const serverPort = parseInt(new URL(serverURL).port, 10);
  497 |     const { proxyServerAddr, closeProxyServer, connectHosts } = await setupSocksForwardingServer({
  498 |       port: test.info().workerIndex + 2048 + 2,
  499 |       forwardPort: serverPort,
  500 |       allowedTargetPort: serverPort,
  501 |     });
  502 |     const page = await browser.newPage({
  503 |       ignoreHTTPSErrors: true,
  504 |       clientCertificates: [{
  505 |         origin: new URL(serverURL).origin,
  506 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  507 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  508 |       }],
  509 |       proxy: { server: proxyServerAddr }
  510 |     });
  511 |     expect(connectHosts).toEqual([]);
  512 |     await page.goto(serverURL);
  513 |     const host = browserName === 'webkit' && isMac ? 'localhost' : '127.0.0.1';
  514 |     expect(connectHosts).toEqual([`${host}:${serverPort}`]);
  515 |     await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  516 |     await page.close();
  517 |     await closeProxyServer();
  518 |   });
  519 | 
  520 |   test('should not hang on tls errors during TLS 1.2 handshake', async ({ browser, asset, platform, browserName }) => {
  521 |     for (const tlsVersion of ['TLSv1.3', 'TLSv1.2'] as const) {
  522 |       await test.step(`TLS version: ${tlsVersion}`, async () => {
  523 |         const server = tls.createServer({
  524 |           key: fs.readFileSync(asset('client-certificates/server/server_key.pem')),
  525 |           cert: fs.readFileSync(asset('client-certificates/server/server_cert.pem')),
  526 |           ca: [
  527 |             fs.readFileSync(asset('client-certificates/server/server_cert.pem')),
  528 |           ],
  529 |           requestCert: true,
  530 |           rejectUnauthorized: true,
  531 |           minVersion: tlsVersion,
  532 |           maxVersion: tlsVersion,
  533 |           SNICallback: (servername, cb) => {
  534 |             // Always reject the connection by passing an error
  535 |             cb(new Error('Connection rejected'), null);
  536 |           }
  537 |         }, () => {
  538 |           // Do nothing
  539 |         });
  540 |         const serverURL = await new Promise<string>(resolve => {
  541 |           server.listen(0, 'localhost', () => {
  542 |             const host = browserName === 'webkit' && platform === 'darwin' ? 'local.playwright' : 'localhost';
  543 |             resolve(`https://${host}:${(server.address() as net.AddressInfo).port}/`);
  544 |           });
  545 |         });
  546 |         const page = await browser.newPage({
  547 |           ignoreHTTPSErrors: true,
  548 |           clientCertificates: [{
  549 |             origin: new URL(serverURL).origin,
  550 |             certPath: asset('client-certificates/client/self-signed/cert.pem'),
  551 |             keyPath: asset('client-certificates/client/self-signed/key.pem'),
  552 |           }],
  553 |         });
  554 |         await page.goto(serverURL);
  555 |         await expect(page.getByText('Playwright client-certificate error: Client network socket disconnected before secure TLS connection was established')).toBeVisible();
  556 |         await page.close();
  557 |         await new Promise<void>(resolve => server.close(() => resolve()));
  558 |       });
  559 |     }
  560 |   });
  561 | 
  562 |   test('should pass with matching certificates in pfx format', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  563 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  564 |     const page = await browser.newPage({
  565 |       ignoreHTTPSErrors: true,
  566 |       clientCertificates: [{
```