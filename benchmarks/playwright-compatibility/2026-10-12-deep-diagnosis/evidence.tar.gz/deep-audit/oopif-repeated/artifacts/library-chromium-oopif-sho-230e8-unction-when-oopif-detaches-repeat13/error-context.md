# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/chromium/oopif.spec.ts >> should not throw on exposeFunction when oopif detaches
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/oopif.spec.ts:353:3

# Error details

```
Error: page.exposeFunction: Protocol error (Page.addScriptToEvaluateOnNewDocument): Session with given id not found.
```

# Test source

```ts
  257 | });
  258 | 
  259 | it('ElementHandle.boundingBox() should work', async function({ page, browser, server }) {
  260 |   await page.goto(server.PREFIX + '/dynamic-oopif.html');
  261 |   await page.$eval('iframe', iframe => {
  262 |     iframe.style.width = '520px';
  263 |     iframe.style.height = '520px';
  264 |     iframe.style.marginLeft = '42px';
  265 |     iframe.style.marginTop = '17px';
  266 |   });
  267 |   await page.frames()[1].goto(page.frames()[1].url());
  268 | 
  269 |   await assertOOPIFCount(browser, 1);
  270 |   const handle1 = await page.frames()[1].$('.box:nth-of-type(13)');
  271 |   await expect.poll(() => handle1!.boundingBox()).toEqual({ x: 100 + 42, y: 50 + 17, width: 50, height: 50 });
  272 | 
  273 |   await Promise.all([
  274 |     page.frames()[1].waitForNavigation(),
  275 |     page.evaluate('goLocal()'),
  276 |   ]);
  277 |   await assertOOPIFCount(browser, 0);
  278 |   const handle2 = await page.frames()[1].$('.box:nth-of-type(13)');
  279 |   await expect.poll(() => handle2!.boundingBox()).toEqual({ x: 100 + 42, y: 50 + 17, width: 50, height: 50 });
  280 | });
  281 | 
  282 | it('should click', async function({ page, browser, server }) {
  283 |   await page.goto(server.PREFIX + '/dynamic-oopif.html');
  284 |   await page.$eval('iframe', iframe => {
  285 |     iframe.style.width = '500px';
  286 |     iframe.style.height = '500px';
  287 |     iframe.style.marginLeft = '102px';
  288 |     iframe.style.marginTop = '117px';
  289 |   });
  290 |   await page.frames()[1].goto(page.frames()[1].url());
  291 | 
  292 |   await assertOOPIFCount(browser, 1);
  293 |   const handle1 = (await page.frames()[1].$('.box:nth-of-type(13)'))!;
  294 |   await handle1.evaluate(div => div.addEventListener('click', () => (window as any)['_clicked'] = true, false));
  295 |   await handle1.click();
  296 |   expect(await handle1.evaluate(() => (window as any)['_clicked'])).toBe(true);
  297 | });
  298 | 
  299 | it('contentFrame should work', async ({ page, browser, server }) => {
  300 |   await page.goto(server.PREFIX + '/dynamic-oopif.html');
  301 |   expect(page.frames().length).toBe(2);
  302 |   await assertOOPIFCount(browser, 1);
  303 |   expect(await page.locator('iframe').contentFrame().locator('div').count()).toBe(200);
  304 |   const oopif = await page.$('iframe');
  305 |   const content = await oopif.contentFrame();
  306 |   expect(await content.locator('div').count()).toBe(200);
  307 | });
  308 | 
  309 | it('should allow cdp sessions on oopifs', async function({ page, browser, server }) {
  310 |   await page.goto(server.PREFIX + '/dynamic-oopif.html');
  311 |   await assertOOPIFCount(browser, 1);
  312 |   expect(page.frames().length).toBe(2);
  313 |   expect(await page.frames()[1].evaluate(() => '' + location.href)).toBe(server.CROSS_PROCESS_PREFIX + '/grid.html');
  314 | 
  315 |   const parentCDP = await page.context().newCDPSession(page.frames()[0]);
  316 |   const parent = await parentCDP.send('DOM.getDocument', { pierce: true, depth: -1 });
  317 |   expect(JSON.stringify(parent)).not.toContain('./digits/1.png');
  318 | 
  319 |   const oopifCDP = await page.context().newCDPSession(page.frames()[1]);
  320 |   const oopif = await oopifCDP.send('DOM.getDocument', { pierce: true, depth: -1 });
  321 |   expect(JSON.stringify(oopif)).toContain('./digits/1.png');
  322 | });
  323 | 
  324 | it('should emit filechooser event for iframe', async ({ page, server, browser }) => {
  325 |   // Add listener before OOPIF is created.
  326 |   const chooserPromise = page.waitForEvent('filechooser');
  327 |   await page.goto(server.PREFIX + '/dynamic-oopif.html');
  328 |   await assertOOPIFCount(browser, 1);
  329 |   expect(page.frames().length).toBe(2);
  330 |   const frame = page.frames()[1];
  331 |   await frame.setContent(`<input type=file>`);
  332 |   const [chooser] = await Promise.all([
  333 |     chooserPromise,
  334 |     frame.click('input'),
  335 |   ]);
  336 |   expect(chooser).toBeTruthy();
  337 | });
  338 | 
  339 | it('should be able to click in iframe', async ({ page, server, browser }) => {
  340 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/28023' });
  341 |   await page.goto(server.PREFIX + '/dynamic-oopif.html');
  342 |   await assertOOPIFCount(browser, 1);
  343 |   expect(page.frames().length).toBe(2);
  344 |   const frame = page.frames()[1];
  345 |   await frame.setContent(`<button onclick="console.log('clicked')">OK</button>`);
  346 |   const [message] = await Promise.all([
  347 |     page.waitForEvent('console'),
  348 |     frame.click('button'),
  349 |   ]);
  350 |   expect(message.text()).toBe('clicked');
  351 | });
  352 | 
  353 | it('should not throw on exposeFunction when oopif detaches', async ({ page, browser, server }) => {
  354 |   await page.goto(server.PREFIX + '/dynamic-oopif.html');
  355 |   await assertOOPIFCount(browser, 1);
  356 |   await Promise.all([
> 357 |     page.exposeFunction('myFunc', () => 2022),
      |          ^ Error: page.exposeFunction: Protocol error (Page.addScriptToEvaluateOnNewDocument): Session with given id not found.
  358 |     page.evaluate(() => document.querySelector('iframe')!.remove()),
  359 |   ]);
  360 |   expect(await page.evaluate(() => (window as any).myFunc())).toBe(2022);
  361 | });
  362 | 
  363 | it('should intercept response body from oopif', async function({ page, browser, server }) {
  364 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/20809' });
  365 |   const [response] = await Promise.all([
  366 |     page.waitForResponse('**/grid.html'),
  367 |     page.goto(server.PREFIX + '/dynamic-oopif.html')
  368 |   ]);
  369 |   expect(await response.text()).toBeTruthy();
  370 | });
  371 | 
  372 | it('should allow to re-connect to OOPIFs with CDP when iframes were there already', async ({ browserType, server }) => {
  373 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36095' });
  374 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/17656' });
  375 |   it.skip(!!process.env.PWTEST_CHANNEL, 'Test default channel only');
  376 | 
  377 |   const cdpPort = 10123 + it.info().parallelIndex * 4;
  378 |   const hostBrowser = await browserType.launch({ channel: 'chromium', args: ['--remote-debugging-port=' + cdpPort] });
  379 |   const hostPage = await hostBrowser.newPage();
  380 |   await hostPage.goto(server.PREFIX + '/dynamic-oopif.html');
  381 | 
  382 |   const browser = await browserType.connectOverCDP(`http://localhost:${cdpPort}`);
  383 |   const page = browser.contexts()[0].pages()[0];
  384 |   expect(page.frames().length).toBe(2);
  385 |   await assertOOPIFCount(browser, 1);
  386 |   expect(await page.frames()[1].evaluate(() => '' + location.href)).toBe(server.CROSS_PROCESS_PREFIX + '/grid.html');
  387 |   await browser.close();
  388 |   await hostBrowser.close();
  389 | });
  390 | 
  391 | async function assertOOPIFCount(browser: Browser, count: number) {
  392 |   if (browser.browserType().name() !== 'chromium')
  393 |     return;
  394 |   expect(await countOOPIFs(browser)).toBe(count);
  395 | }
  396 | 
  397 | async function countOOPIFs(browser: Browser) {
  398 |   const browserSession = await browser.newBrowserCDPSession();
  399 |   const oopifs = [];
  400 |   browserSession.on('Target.targetCreated', async ({ targetInfo }) => {
  401 |     if (targetInfo.type === 'iframe')
  402 |       oopifs.push(targetInfo);
  403 |   });
  404 |   await browserSession.send('Target.setDiscoverTargets', { discover: true });
  405 |   await browserSession.detach();
  406 |   return oopifs.length;
  407 | }
  408 | 
```