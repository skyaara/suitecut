import os,pathlib,subprocess,sys
base=pathlib.Path('/tmp/suitecut-deep-audit'); out=base/sys.argv[1];out.mkdir(exist_ok=True)
env=dict(os.environ,PWTEST_UNDER_TEST='1',COMPAT_BACKEND='cef',COMPAT_DIRECTORY=str(out),MEMORY_DIRECTORY=str(out),SUITECUT_RUNTIME_EXECUTABLE='/tmp/suitecut-cef-full-regression-build/suitecut-browser',pnpm_config_verify_deps_before_run='warn')
selectors=sys.argv[2:] or (base/'selectors.txt').read_text().splitlines()
command=['taskset','-c','0-3','python3','/tmp/suitecut-upstream-full-2026-10-12/runtime.py','exec','pnpm','exec','playwright','test','--config','/tmp/suitecut-playwright-upstream/playwright-1.62.1/suitecut-deep.config.ts',*selectors]
with (out/'run.log').open('w') as log:
 p=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,cwd='/workspace/suitecut')
(out/'exit.txt').write_text(str(p.returncode));print(out, p.returncode)
