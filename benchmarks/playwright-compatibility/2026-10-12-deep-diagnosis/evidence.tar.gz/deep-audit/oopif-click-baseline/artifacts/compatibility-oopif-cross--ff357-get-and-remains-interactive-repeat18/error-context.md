# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compatibility.spec.ts >> oopif: cross-site frame is a separate CDP target and remains interactive
- Location: benchmarks/playwright-compatibility/compatibility.spec.ts:410:1

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator:  locator('iframe').contentFrame().getByRole('button')
Expected: "clicked"
Received: "Click"
Timeout:  5000ms

Call log:
  - Expect "toHaveText" with timeout 5000ms
  - waiting for locator('iframe').contentFrame().getByRole('button')
    13 × locator resolved to <button onclick="this.textContent='clicked'">Click</button>
       - unexpected value "Click"

```

```yaml
- button "Click"
```

# Test source

```ts
  329 |   ).toBe(42)
  330 |   await second.close()
  331 | })
  332 | test('worker: repeated worker contexts release browser target registrations', async ({
  333 |   browser,
  334 | }) => {
  335 |   test.setTimeout(60000)
  336 |   const root = await browser.newBrowserCDPSession()
  337 |   try {
  338 |     for (let i = 0; i < 80; i++) {
  339 |       const c = await browser.newContext()
  340 |       try {
  341 |         const p = await c.newPage()
  342 |         const event = c.waitForEvent('serviceworker', { timeout: 5000 })
  343 |         void event.catch(() => undefined)
  344 |         await register(p)
  345 |         expect(
  346 |           await (await event).evaluate(() => (self as typeof self & { marker: number }).marker),
  347 |         ).toBe(42)
  348 |       } finally {
  349 |         await c.close()
  350 |       }
  351 |     }
  352 |     await expect
  353 |       .poll(
  354 |         async () =>
  355 |           (await root.send('Target.getTargets')).targetInfos.filter(
  356 |             (t) => t.type === 'service_worker',
  357 |           ).length,
  358 |       )
  359 |       .toBe(0)
  360 |   } finally {
  361 |     await root.detach()
  362 |   }
  363 | })
  364 | test('native: worker CDP aliases detach when their context closes', async ({ browser, engine }) => {
  365 |   test.skip(!engine, 'This checks the native shim alias lifecycle')
  366 |   test.setTimeout(60000)
  367 |   const root = await browser.newBrowserCDPSession(),
  368 |     detached = new Set<string>()
  369 |   root.on('Target.detachedFromTarget', (event) => detached.add(event.sessionId))
  370 |   try {
  371 |     for (let i = 0; i < 80; i++) {
  372 |       const c = await browser.newContext()
  373 |       let extra: string | undefined
  374 |       try {
  375 |         const p = await c.newPage()
  376 |         const event = c.waitForEvent('serviceworker', { timeout: 5000 })
  377 |         void event.catch(() => undefined)
  378 |         await register(p)
  379 |         await event
  380 |         const target = required(
  381 |           (await root.send('Target.getTargets')).targetInfos.find(
  382 |             (t) => t.type === 'service_worker',
  383 |           ),
  384 |         )
  385 |         extra = (
  386 |           await root.send('Target.attachToTarget', { targetId: target.targetId, flatten: true })
  387 |         ).sessionId
  388 |       } finally {
  389 |         await c.close()
  390 |       }
  391 |       await expect.poll(() => detached.has(required(extra))).toBe(true)
  392 |     }
  393 |   } finally {
  394 |     await root.detach()
  395 |   }
  396 | })
  397 | test('worker: serviceWorkers block prevents registration', async ({ browser }) => {
  398 |   const c = await browser.newContext({ serviceWorkers: 'block' })
  399 |   try {
  400 |     const p = await c.newPage()
  401 |     await p.goto(origin)
  402 |     await p.evaluate(() => navigator.serviceWorker.register('/sw.js').catch(() => null))
  403 |     expect(
  404 |       await p.evaluate(() => navigator.serviceWorker.getRegistrations().then((r) => r.length)),
  405 |     ).toBe(0)
  406 |   } finally {
  407 |     await c.close()
  408 |   }
  409 | })
  410 | test('oopif: cross-site frame is a separate CDP target and remains interactive', async ({
  411 |   page,
  412 |   context,
  413 | }) => {
  414 |   await page.goto(origin)
  415 |   const session = await context.newCDPSession(page)
  416 |   const attachments: { targetInfo: { type: string } }[] = []
  417 |   session.on('Target.attachedToTarget', (e) => attachments.push(e))
  418 |   await session.send('Target.setAutoAttach', {
  419 |     autoAttach: true,
  420 |     waitForDebuggerOnStart: false,
  421 |     flatten: true,
  422 |   })
  423 |   await page.evaluate((url) => {
  424 |     const f = document.createElement('iframe')
  425 |     f.src = url
  426 |     document.body.append(f)
  427 |   }, cross)
  428 |   await page.frameLocator('iframe').getByRole('button').click()
> 429 |   await expect(page.frameLocator('iframe').getByRole('button')).toHaveText('clicked')
      |                                                                 ^ Error: expect(locator).toHaveText(expected) failed
  430 |   await expect.poll(() => attachments.some((e) => e.targetInfo.type === 'iframe')).toBe(true)
  431 |   await expect.poll(() => page.frames().map((f) => f.url())).toContain(cross + '/')
  432 |   const frame = required(page.frames().find((f) => f.url().startsWith(cross)))
  433 |   expect(await frame.evaluate(() => location.origin)).toBe(cross)
  434 |   await session.detach()
  435 | })
  436 | test('oopif: cross-site navigation, detach and network routing', async ({ page, context }) => {
  437 |   await context.route('**/json', (r) => r.fulfill({ json: { value: 'routed' } }))
  438 |   await page.goto(origin)
  439 |   await page.evaluate((url) => {
  440 |     const f = document.createElement('iframe')
  441 |     f.src = url
  442 |     document.body.append(f)
  443 |   }, cross)
  444 |   const inner = page.frameLocator('iframe')
  445 |   await inner.getByLabel('Name').fill('cross-site')
  446 |   await expect(inner.getByLabel('Name')).toHaveValue('cross-site')
  447 |   const f = required(page.frames().find((f) => f.url().startsWith(cross)))
  448 |   expect(await f.evaluate(() => fetch('/json').then((r) => r.json()))).toEqual({ value: 'routed' })
  449 |   await page
  450 |     .locator('iframe')
  451 |     .evaluate((f, url) => ((f as HTMLIFrameElement).src = url), origin + '/next')
  452 |   await expect.poll(() => page.frames().map((f) => f.url())).toContain(origin + '/next')
  453 |   await inner.getByRole('button').click()
  454 |   await expect(inner.getByRole('button')).toHaveText('clicked')
  455 |   const detached = page.waitForEvent('framedetached')
  456 |   await page.locator('iframe').evaluate((f) => f.remove())
  457 |   await detached
  458 |   expect(page.frames()).toHaveLength(1)
  459 | })
  460 | test('viewport: odd and tiny browser dimensions support screenshots and Playwright video', async ({
  461 |   browser,
  462 | }, info) => {
  463 |   const c = await browser.newContext({
  464 |     viewport: { width: 1904, height: 609 },
  465 |     recordVideo: { dir: info.outputPath('odd-videos'), size: { width: 640, height: 204 } },
  466 |   })
  467 |   try {
  468 |     const p = await c.newPage()
  469 |     await p.goto(origin)
  470 |     expect(await p.evaluate(() => ({ width: innerWidth, height: innerHeight }))).toEqual({
  471 |       width: 1904,
  472 |       height: 609,
  473 |     })
  474 |     const png = await p.screenshot()
  475 |     expect(png.readUInt32BE(16)).toBe(1904)
  476 |     expect(png.readUInt32BE(20)).toBe(609)
  477 |     await p.getByRole('button').click()
  478 |     await expect(p.getByRole('button')).toHaveText('clicked')
  479 |     await p.setViewportSize({ width: 1, height: 1 })
  480 |     const tiny = await p.screenshot()
  481 |     expect(tiny.readUInt32BE(16)).toBe(1)
  482 |     expect(tiny.readUInt32BE(20)).toBe(1)
  483 |   } finally {
  484 |     await c.close()
  485 |   }
  486 | })
  487 | test('locale: popups inherit context language before their first script without cross-context leakage', async ({
  488 |   browser,
  489 | }) => {
  490 |   const french = await browser.newContext({ locale: 'fr-FR' })
  491 |   const german = await browser.newContext({ locale: 'de-DE' })
  492 |   try {
  493 |     for (const [context, expected] of [
  494 |       [french, 'fr-FR'],
  495 |       [german, 'de-DE'],
  496 |       [french, 'fr-FR'],
  497 |     ] as const) {
  498 |       const page = await context.newPage()
  499 |       await page.goto(origin + '/initial-language')
  500 |       expect(await page.evaluate('window.initialLanguage')).toBe(expected)
  501 |       const [popup] = await Promise.all([
  502 |         page.waitForEvent('popup'),
  503 |         page.evaluate((url) => {
  504 |           window.open(url)
  505 |         }, origin + '/initial-language'),
  506 |       ])
  507 |       await popup.waitForLoadState('domcontentloaded')
  508 |       expect(await popup.evaluate('window.initialLanguage')).toBe(expected)
  509 |       await page.close()
  510 |       await popup.close()
  511 |     }
  512 |   } finally {
  513 |     await french.close()
  514 |     await german.close()
  515 |   }
  516 | })
  517 | 
  518 | test('viewport: real browser version metadata preserves 4K windowless dimensions', async ({
  519 |   browser,
  520 | }) => {
  521 |   const context = await browser.newContext({ viewport: { width: 3840, height: 2160 } })
  522 |   try {
  523 |     const page = await context.newPage()
  524 |     await page.goto(origin)
  525 |     expect(await page.evaluate(() => ({ width: innerWidth, height: innerHeight }))).toEqual({
  526 |       width: 3840,
  527 |       height: 2160,
  528 |     })
  529 |     const cdp = await context.newCDPSession(page)
```