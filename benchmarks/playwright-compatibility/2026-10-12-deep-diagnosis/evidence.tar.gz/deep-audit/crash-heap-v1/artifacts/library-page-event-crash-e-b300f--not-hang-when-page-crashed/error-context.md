# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/page-event-crash.spec.ts >> expect should not hang when page crashed
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/page-event-crash.spec.ts:66:1

# Error details

```
Error: Page crashed
```

# Test source

```ts
  28  |   missingAudioSamples: z.number(),
  29  |   activeMissingAudioSamples: z.number().nonnegative().optional(),
  30  |   lateAudioSamples: z.number(),
  31  |   queuedVideoBytes: z.number(),
  32  |   queuedAudioBytes: z.number(),
  33  |   startedMs: z.number(),
  34  |   durationMs: z.number(),
  35  |   maximumEncodeMs: z.number(),
  36  |   bufferedDelayMs: z.number().nonnegative().optional(),
  37  |   audioSyncWaits: z.number().nonnegative().optional(),
  38  |   videoSyncWaits: z.number().nonnegative().optional(),
  39  |   /** Encoder progress difference, not a measurement of perceptual lip sync. */
  40  |   maximumTrackLeadMs: z.number().nonnegative().optional(),
  41  |   videoEncoderThreads: z.number().int().nonnegative().optional(),
  42  |   videoEncoderPreset: z.string().optional(),
  43  |   error: z.string(),
  44  | })
  45  | export type NativeOutputStatus = z.infer<typeof StatusSchema>
  46  | export type NativeVideoCodec =
  47  |   | 'libx264'
  48  |   | 'libx265'
  49  |   | 'libvpx'
  50  |   | 'libvpx-vp9'
  51  |   | 'libsvtav1'
  52  |   | 'libaom-av1'
  53  |   | 'ffv1'
  54  |   | 'h264_nvenc'
  55  |   | 'hevc_nvenc'
  56  |   | 'av1_nvenc'
  57  | export type NativeAudioCodec = 'aac' | 'libopus' | 'flac' | 'pcm_s16le'
  58  | export type NativeOutputContainer = 'mp4' | 'webm' | 'mkv' | 'mov'
  59  | const EncoderInfoSchema = z.strictObject({
  60  |   name: z.string(),
  61  |   kind: z.enum(['video', 'audio']),
  62  |   codec: z.string(),
  63  |   /** Linked encoder availability; hardware still requires a working device/driver. */
  64  |   linked: z.boolean(),
  65  |   hardware: z.boolean(),
  66  |   lossless: z.boolean(),
  67  |   containers: z.array(z.enum(['mp4', 'webm', 'mkv', 'mov', 'flv'])),
  68  | })
  69  | export type NativeEncoderInfo = z.infer<typeof EncoderInfoSchema>
  70  | export interface NativeOutputOptions {
  71  |   destination: string
  72  |   width?: number
  73  |   height?: number
  74  |   fps?: 30 | 60
  75  |   audio?: boolean
  76  |   videoCodec?: NativeVideoCodec
  77  |   audioCodec?: NativeAudioCodec
  78  |   container?: NativeOutputContainer
  79  |   /** Software lossy recording quality; range depends on encoder. */
  80  |   crf?: number
  81  |   bitrateKbps?: number
  82  |   audioBitrateKbps?: number
  83  |   /** Wait for initialized native encoders/muxer and captured video; silent pages are ready. Timeout: 1–60000 ms. */
  84  |   audioStartupTimeoutMs?: number
  85  | }
  86  | export interface NativeOutput {
  87  |   readonly failure: Promise<never>
  88  |   selectTarget(targetId: string): Promise<void>
  89  |   health(): { captureLagMs: number; outputLagMs: number; progressAgeMs: number }
  90  |   status(): Promise<NativeOutputStatus>
  91  |   pause(paused: boolean): Promise<void>
  92  |   stop(): Promise<NativeOutputStatus>
  93  | }
  94  | export interface SuiteCutEngine {
  95  |   readonly browser: Browser
  96  |   readonly source: NativeBrowser
  97  |   encoders(): Promise<NativeEncoderInfo[]>
  98  |   record(page: Page, options: NativeOutputOptions): Promise<NativeOutput>
  99  |   stream(page: Page, options: NativeOutputOptions): Promise<NativeOutput>
  100 |   select(output: NativeOutput, page: Page): Promise<void>
  101 |   render(request: Omit<SuiteCutRenderRequest, 'nativeSource'>): Promise<SuiteCutRenderReport>
  102 |   close(): Promise<void>
  103 | }
  104 | 
  105 | /** Public Playwright transport over private IPC. No debugging TCP port or raw media. */
  106 | export async function connectCEF(source: NativeBrowser): Promise<Browser> {
  107 |   const { chromium } = await import('playwright')
  108 |   if (!source.command || !source.onProtocolEvent)
  109 |     throw new Error('CEF protocol adapter is unavailable')
  110 |   let disconnected = false
  111 |   const transport: ConnectOverCDPTransport = {
  112 |     send(message) {
  113 |       if (disconnected) return
  114 |       commands.enqueue(message, Buffer.byteLength(JSON.stringify(message)))
  115 |     },
  116 |     close() {
  117 |       delivery.close('CEF transport closed')
  118 |     },
  119 |   }
  120 |   const command = source.command.bind(source)
  121 |   const commands = new CDPCommandQueue(
  122 |     async (message) => {
  123 |       await command('cdp', { message: message as Record<string, UntrustedInput> })
  124 |     },
  125 |     (reason) => delivery.close(reason),
  126 |   )
  127 |   const delivery = new CDPDelivery(
> 128 |     (message) => transport.onmessage?.(message),
      |                  ^ Error: Page crashed
  129 |     (reason) => {
  130 |       if (disconnected) return
  131 |       disconnected = true
  132 |       commands.close()
  133 |       unsubscribe()
  134 |       transport.onclose?.(reason)
  135 |     },
  136 |   )
  137 |   const unsubscribe = source.onProtocolEvent((message, bytes) =>
  138 |     delivery.enqueue(message as object, bytes ?? Buffer.byteLength(JSON.stringify(message))),
  139 |   )
  140 |   const unsubscribeClose = source.onClose?.(() => delivery.end('CEF transport closed'))
  141 |   try {
  142 |     const browser = await chromium.connectOverCDP(transport)
  143 |     browser.on('disconnected', () => {
  144 |       delivery.close('CEF transport disconnected')
  145 |       unsubscribe()
  146 |       unsubscribeClose?.()
  147 |     })
  148 |     return browser
  149 |   } catch (error) {
  150 |     delivery.close('CEF transport connection failed')
  151 |     unsubscribe()
  152 |     unsubscribeClose?.()
  153 |     throw error
  154 |   }
  155 | }
  156 | 
  157 | export async function createNativeOutput(
  158 |   source: NativeBrowser,
  159 |   options: NativeOutputOptions,
  160 |   streaming = false,
  161 |   targetId?: string,
  162 | ): Promise<NativeOutput> {
  163 |   if (!source.command || !source.nativeMedia) throw new Error('This helper has no C++ media engine')
  164 |   const command = source.command.bind(source)
  165 |   if ('audioStartup' in options)
  166 |     throw new Error('Audio startup policies were removed; realtime audio readiness is mandatory')
  167 |   const fields = targetId ? { targetId } : {}
  168 |   const config = {
  169 |     ...options,
  170 |     destination: streaming ? options.destination : resolve(options.destination),
  171 |     width: options.width ?? source.width,
  172 |     height: options.height ?? source.height,
  173 |     fps: options.fps ?? source.framesPerSecond,
  174 |     audio: options.audio ?? true,
  175 |     streaming,
  176 |     ...fields,
  177 |   }
  178 |   const started = z
  179 |     .object({
  180 |       outputId: z.number().int().positive(),
  181 |       audioReadinessRequired: z.boolean().optional(),
  182 |       audioReadiness: z.string().optional(),
  183 |     })
  184 |     .parse(await command('media.start', config))
  185 |   const { outputId } = started
  186 |   if (
  187 |     config.audio &&
  188 |     (started.audioReadinessRequired !== true || started.audioReadiness !== 'engine')
  189 |   ) {
  190 |     await command('media.stop', { outputId, ...fields }).catch(() => undefined)
  191 |     throw new Error('Native helper did not confirm silent-safe audio engine readiness')
  192 |   }
  193 |   let latest: NativeOutputStatus | undefined
  194 |   let receivedAt = performance.now()
  195 |   const status = async () => {
  196 |     const result = StatusSchema.parse(await command('media.status', { outputId, ...fields }))
  197 |     latest = result
  198 |     receivedAt = performance.now()
  199 |     return result
  200 |   }
  201 |   let stopped: Promise<NativeOutputStatus> | undefined
  202 |   let rejectFailure: (error: Error) => void = () => undefined
  203 |   const failure = new Promise<never>((_resolve, reject) => {
  204 |     rejectFailure = reject
  205 |   })
  206 |   void failure.catch(() => undefined)
  207 |   let timer: ReturnType<typeof setInterval> | undefined = undefined
  208 |   let unsubscribe: (() => void) | undefined = undefined
  209 |   let unsubscribeClose: (() => void) | undefined = undefined
  210 |   const cleanup = () => {
  211 |     clearInterval(timer)
  212 |     unsubscribe?.()
  213 |     unsubscribeClose?.()
  214 |   }
  215 |   const fail = (error: Error) => {
  216 |     cleanup()
  217 |     rejectFailure(error)
  218 |   }
  219 |   unsubscribe = source.onFailure?.(fail)
  220 |   unsubscribeClose = source.onClose?.(() => {
  221 |     if (!stopped) fail(new Error('Native engine closed during output'))
  222 |   })
  223 |   let polling = false
  224 |   timer = setInterval(() => {
  225 |     if (polling || stopped) return
  226 |     polling = true
  227 |     void status()
  228 |       .then((value) => {
```