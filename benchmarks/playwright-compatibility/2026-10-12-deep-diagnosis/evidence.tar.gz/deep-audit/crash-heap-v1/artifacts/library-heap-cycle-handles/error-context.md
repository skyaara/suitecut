# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/heap.spec.ts >> cycle handles
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/heap.spec.ts:304:5

# Error details

```
Error: page.$$: Frame has been detached.
```

# Test source

```ts
  210 |     await page.close();
  211 |   pages.length = 0;
  212 | 
  213 |   expect(await queryObjectCount(coreServer.Page)).toBe(0);
  214 |   expect(await queryObjectCount(coreServer.RequestDispatcher)).toBe(0);
  215 |   expect(await queryObjectCount(coreServer.ResponseDispatcher)).toBe(0);
  216 | 
  217 |   expect(await queryObjectCount(clientClass.Page)).toBeLessThan(COUNT);
  218 |   expect(await queryObjectCount(coreServer.Page)).toBe(0);
  219 |   expect(await queryObjectCount(clientClass.Request)).toBe(0);
  220 |   expect(await queryObjectCount(clientClass.Response)).toBe(0);
  221 | });
  222 | 
  223 | test('should not leak workers', async ({ page }) => {
  224 |   const before = await queryObjectCount(coreServer.Worker);
  225 |   for (let i = 0; i < 5; ++i) {
  226 |     const [workerHandle, workerObj] = await Promise.all([
  227 |       page.evaluateHandle(index => new Worker(URL.createObjectURL(new Blob([String(index)], { type: 'application/javascript' }))), i),
  228 |       page.waitForEvent('worker'),
  229 |     ]);
  230 |     await Promise.all([
  231 |       workerObj.waitForEvent('close'),
  232 |       workerHandle.evaluate(workerObj => workerObj.terminate()),
  233 |     ]);
  234 |   }
  235 |   expect.soft(await queryObjectCount(coreServer.Worker)).toBe(before);
  236 |   expect.soft(await queryObjectCount(coreServer.WorkerDispatcher)).toBe(0);
  237 | });
  238 | 
  239 | test.describe(() => {
  240 |   test.beforeEach(() => {
  241 |     coreServer.setMaxDispatchersForTest(100);
  242 |   });
  243 | 
  244 |   test('should collect stale handles', async ({ page, server }) => {
  245 |     page.on('request', () => {});
  246 |     const response = await page.goto(server.PREFIX + '/title.html');
  247 |     for (let i = 0; i < 200; ++i) {
  248 |       await page.evaluate(async () => {
  249 |         const response = await fetch('/');
  250 |         await response.text();
  251 |       });
  252 |     }
  253 |     const e = await response.allHeaders().catch(e => e);
  254 |     expect(e.message).toContain('The object has been collected to prevent unbounded heap growth.');
  255 | 
  256 |     const counts = [
  257 |       { count: await queryObjectCount(clientClass.Request), message: 'client.Request' },
  258 |       { count: await queryObjectCount(clientClass.Response), message: 'client.Response' },
  259 |       { count: await queryObjectCount(coreServer.Request), message: 'server.Request' },
  260 |       { count: await queryObjectCount(coreServer.Response), message: 'server.Response' },
  261 |       { count: await queryObjectCount(coreServer.RequestDispatcher), message: 'dispatchers.RequestDispatcher' },
  262 |       { count: await queryObjectCount(coreServer.ResponseDispatcher), message: 'dispatchers.ResponseDispatcher' },
  263 |     ];
  264 |     for (const { count, message } of counts) {
  265 |       expect(count, { message }).toBeGreaterThan(50);
  266 |       expect(count, { message }).toBeLessThan(150);
  267 |     }
  268 |   });
  269 | 
  270 |   test('should collect frames', async ({ page, server }) => {
  271 |     test.slow();
  272 | 
  273 |     const kFrameCount = 310;
  274 | 
  275 |     await page.goto(server.EMPTY_PAGE);
  276 |     let cb;
  277 |     const promise = new Promise(f => cb = f);
  278 |     let counter = 0;
  279 |     page.on('frameattached', async () => {
  280 |       // Make sure we can access page.
  281 |       await page.title();
  282 |       if (++counter === kFrameCount)
  283 |         cb();
  284 |     });
  285 | 
  286 |     page.evaluate(async ({ url, count }) => {
  287 |       for (let i = 0; i < count; i++) {
  288 |         const frame = document.createElement('iframe');
  289 |         frame.src = url;
  290 |         document.body.appendChild(frame);
  291 |         await new Promise(f => window.builtins.setTimeout(f, 10));
  292 |         frame.remove();
  293 |       }
  294 |     }, { url: server.PREFIX + '/one-style.html', count: kFrameCount }).catch(() => {});
  295 |     await promise;
  296 |     await page.waitForTimeout(500);
  297 |   });
  298 | 
  299 |   test.afterEach(() => {
  300 |     coreServer.setMaxDispatchersForTest(null);
  301 |   });
  302 | });
  303 | 
  304 | test('cycle handles', async ({ page, server, trace }) => {
  305 |   test.slow();
  306 |   test.skip(trace === 'on', 'too slow with 2000 snapshots');
  307 | 
  308 |   await page.goto(server.EMPTY_PAGE);
  309 |   await page.setContent(`<div><span>hi</span></div>`.repeat(2000));
> 310 |   const divs = await page.$$('div');
      |                           ^ Error: page.$$: Frame has been detached.
  311 |   for (const div of divs) {
  312 |     const span = await div.$('span');
  313 |     expect(await span.textContent()).toBe('hi');
  314 |   }
  315 | });
  316 | 
```