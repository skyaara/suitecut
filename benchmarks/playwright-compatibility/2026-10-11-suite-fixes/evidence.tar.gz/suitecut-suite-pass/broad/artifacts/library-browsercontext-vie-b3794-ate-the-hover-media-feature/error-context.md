# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-viewport-mobile.spec.ts >> mobile viewport >> should emulate the hover media feature
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-viewport-mobile.spec.ts:156:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: false
Received: true
```

# Test source

```ts
  70  |     await context.close();
  71  |   });
  72  | 
  73  |   it('should support landscape emulation', async ({ playwright, browser, server }) => {
  74  |     const iPhone = playwright.devices['iPhone 6'];
  75  |     const iPhoneLandscape = playwright.devices['iPhone 6 landscape'];
  76  |     const context1 = await browser.newContext({ ...iPhone });
  77  |     const page1 = await context1.newPage();
  78  |     await page1.goto(server.PREFIX + '/mobile.html');
  79  |     expect(await page1.evaluate(() => matchMedia('(orientation: landscape)').matches)).toBe(false);
  80  |     const context2 = await browser.newContext({ ...iPhoneLandscape });
  81  |     const page2 = await context2.newPage();
  82  |     expect(await page2.evaluate(() => matchMedia('(orientation: landscape)').matches)).toBe(true);
  83  |     await context1.close();
  84  |     await context2.close();
  85  |   });
  86  | 
  87  |   it('should support window.orientation emulation', async ({ browser, server }) => {
  88  |     const context = await browser.newContext({ viewport: { width: 300, height: 400 }, isMobile: true });
  89  |     const page = await context.newPage();
  90  |     await page.goto(server.PREFIX + '/mobile.html');
  91  |     expect(await page.evaluate(() => window.orientation)).toBe(0);
  92  |     await page.setViewportSize({ width: 400, height: 300 });
  93  |     expect(await page.evaluate(() => window.orientation)).toBe(90);
  94  |     await context.close();
  95  |   });
  96  | 
  97  |   it('should preserve window.orientation override after navigation', async ({ browser, server, isFrozenWebkit }) => {
  98  |     it.skip(isFrozenWebkit);
  99  | 
  100 |     const context = await browser.newContext({ viewport: { width: 400, height: 300 }, isMobile: true });
  101 |     const page = await context.newPage();
  102 |     await page.goto(server.PREFIX + '/mobile.html');
  103 |     expect(await page.evaluate(() => window.orientation)).toBe(90);
  104 |     await page.goto(server.CROSS_PROCESS_PREFIX + '/mobile.html');
  105 |     expect(await page.evaluate(() => window.orientation)).toBe(90);
  106 |     await context.close();
  107 |   });
  108 | 
  109 |   it('should preserve screen.orientation.type override after navigation', async ({ browser, server, isFrozenWebkit }) => {
  110 |     it.skip(isFrozenWebkit);
  111 | 
  112 |     const context = await browser.newContext({ viewport: { width: 300, height: 400 }, isMobile: true });
  113 |     const page = await context.newPage();
  114 |     await page.goto(server.PREFIX + '/mobile.html');
  115 |     expect(await page.evaluate(() => window.screen.orientation.type)).toBe('portrait-primary');
  116 |     await page.goto(server.CROSS_PROCESS_PREFIX + '/mobile.html');
  117 |     expect(await page.evaluate(() => window.screen.orientation.type)).toBe('portrait-primary');
  118 |     await context.close();
  119 |   });
  120 | 
  121 |   it('should fire orientationchange event', async ({ browser, server }) => {
  122 |     const context = await browser.newContext({ viewport: { width: 300, height: 400 }, isMobile: true });
  123 |     const page = await context.newPage();
  124 |     await page.goto(server.PREFIX + '/mobile.html');
  125 |     await page.evaluate(() => {
  126 |       let counter = 0;
  127 |       window.addEventListener('orientationchange', () => console.log(++counter));
  128 |     });
  129 | 
  130 |     const event1 = page.waitForEvent('console');
  131 |     await page.setViewportSize({ width: 400, height: 300 });
  132 |     expect((await event1).text()).toBe('1');
  133 | 
  134 |     const event2 = page.waitForEvent('console');
  135 |     await page.setViewportSize({ width: 300, height: 400 });
  136 |     expect((await event2).text()).toBe('2');
  137 |     await context.close();
  138 |   });
  139 | 
  140 |   it('default mobile viewports to 980 width', async ({ browser, server }) => {
  141 |     const context = await browser.newContext({ viewport: { width: 320, height: 480 }, isMobile: true });
  142 |     const page = await context.newPage();
  143 |     await page.goto(server.PREFIX + '/empty.html');
  144 |     expect(await page.evaluate(() => window.innerWidth)).toBe(980);
  145 |     await context.close();
  146 |   });
  147 | 
  148 |   it('respect meta viewport tag', async ({ browser, server }) => {
  149 |     const context = await browser.newContext({ viewport: { width: 320, height: 480 }, isMobile: true });
  150 |     const page = await context.newPage();
  151 |     await page.goto(server.PREFIX + '/mobile.html');
  152 |     expect(await page.evaluate(() => window.innerWidth)).toBe(320);
  153 |     await context.close();
  154 |   });
  155 | 
  156 |   it('should emulate the hover media feature', async ({ playwright, browser }) => {
  157 |     const iPhone = playwright.devices['iPhone 6'];
  158 |     const mobilepage = await browser.newPage({ ...iPhone });
  159 |     expect(await mobilepage.evaluate(() => matchMedia('(hover: hover)').matches)).toBe(false);
  160 |     expect(await mobilepage.evaluate(() => matchMedia('(hover: none)').matches)).toBe(true);
  161 |     expect(await mobilepage.evaluate(() => matchMedia('(any-hover: hover)').matches)).toBe(false);
  162 |     expect(await mobilepage.evaluate(() => matchMedia('(any-hover: none)').matches)).toBe(true);
  163 |     expect(await mobilepage.evaluate(() => matchMedia('(pointer: coarse)').matches)).toBe(true);
  164 |     expect(await mobilepage.evaluate(() => matchMedia('(pointer: fine)').matches)).toBe(false);
  165 |     expect(await mobilepage.evaluate(() => matchMedia('(any-pointer: coarse)').matches)).toBe(true);
  166 |     expect(await mobilepage.evaluate(() => matchMedia('(any-pointer: fine)').matches)).toBe(false);
  167 |     await mobilepage.close();
  168 | 
  169 |     const desktopPage = await browser.newPage();
> 170 |     expect(await desktopPage.evaluate(() => matchMedia('(hover: none)').matches)).toBe(false);
      |                                                                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  171 |     expect(await desktopPage.evaluate(() => matchMedia('(hover: hover)').matches)).toBe(true);
  172 |     expect(await desktopPage.evaluate(() => matchMedia('(any-hover: none)').matches)).toBe(false);
  173 |     expect(await desktopPage.evaluate(() => matchMedia('(any-hover: hover)').matches)).toBe(true);
  174 |     expect(await desktopPage.evaluate(() => matchMedia('(pointer: coarse)').matches)).toBe(false);
  175 |     expect(await desktopPage.evaluate(() => matchMedia('(pointer: fine)').matches)).toBe(true);
  176 |     expect(await desktopPage.evaluate(() => matchMedia('(any-pointer: coarse)').matches)).toBe(false);
  177 |     expect(await desktopPage.evaluate(() => matchMedia('(any-pointer: fine)').matches)).toBe(true);
  178 |     await desktopPage.close();
  179 |   });
  180 | 
  181 |   it('mouse should work with mobile viewports and cross process navigations', async ({ browser, server }) => {
  182 |     // @see https://crbug.com/929806
  183 |     const context = await browser.newContext({ viewport: { width: 360, height: 640 }, isMobile: true });
  184 |     const page = await context.newPage();
  185 |     await page.goto(server.EMPTY_PAGE);
  186 |     await page.goto(server.CROSS_PROCESS_PREFIX + '/mobile.html');
  187 |     await page.evaluate(() => {
  188 |       document.addEventListener('click', event => {
  189 |         (window as any)['result'] = { x: event.clientX, y: event.clientY };
  190 |       });
  191 |     });
  192 | 
  193 |     await page.mouse.click(30, 40);
  194 | 
  195 |     expect(await page.evaluate('result')).toEqual({ x: 30, y: 40 });
  196 |     await context.close();
  197 |   });
  198 | 
  199 |   it('should scroll when emulating a mobile viewport', async ({ browser, server, browserName }) => {
  200 |     const context = await browser.newContext({
  201 |       viewport: { 'width': 1000, 'height': 600 },
  202 |       isMobile: true,
  203 |     });
  204 |     const page = await context.newPage();
  205 |     await page.goto(server.PREFIX + '/input/scrollable.html');
  206 |     await page.mouse.move(50, 60);
  207 |     const error = await page.mouse.wheel(0, 100).catch(e => e);
  208 |     if (browserName === 'webkit')
  209 |       expect(error.message).toContain('Mouse wheel is not supported in mobile WebKit');
  210 |     else
  211 |       await page.waitForFunction('window.scrollY === 100');
  212 |     await context.close();
  213 |   });
  214 | 
  215 |   it('should scroll mobile page with background-attachment: fixed', {
  216 |     annotation: [
  217 |       { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/31551' },
  218 |       { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/23573' },
  219 |     ]
  220 |   }, async ({ playwright, browser, server }) => {
  221 |     const iPhone = playwright.devices['iPhone 12'];
  222 |     const context = await browser.newContext({ ...iPhone });
  223 |     const page = await context.newPage();
  224 |     await page.goto(server.PREFIX + '/input/background-fixed.html');
  225 |     await page.getByRole('button').click();
  226 |     expect(await page.evaluate(() => window.scrollY)).toBeGreaterThan(1000);
  227 |     await context.close();
  228 |   });
  229 | 
  230 |   it('view scale should reset after navigation', async ({ browser }) => {
  231 |     it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/26876' });
  232 |     const context = await browser.newContext({
  233 |       viewport: { width: 390, height: 664 },
  234 |       isMobile: true,
  235 |     });
  236 |     const page = await context.newPage();
  237 |     await page.goto(`data:text/html,<meta name='viewport' content='device-width, initial-scale=1'><button>Mobile Viewport</button>`);
  238 |     await page.route('**/button.html', route => {
  239 |       void route.fulfill({
  240 |         body: `<body>
  241 |           <button>Click me</button>
  242 |           <script>
  243 |             window.clicks = [];
  244 |             document.addEventListener('click', e => {
  245 |               const dot = document.createElement('div');
  246 |               dot.style.position = 'absolute';
  247 |               dot.style.width = '10px';
  248 |               dot.style.height = '10px';
  249 |               dot.style.borderRadius = '5px';
  250 |               dot.style.backgroundColor = 'red';
  251 |               dot.style.left = e.pageX + 'px';
  252 |               dot.style.top = e.pageY + 'px';
  253 |               dot.textContent = 'x: ' + e.pageX + ' y: ' + e.pageY;
  254 |               document.body.appendChild(dot);
  255 |               window.clicks.push({ x: e.pageX, y: e.pageY });
  256 |             });
  257 |           </script>
  258 |         </body>`,
  259 |         contentType: 'text/html',
  260 |       });
  261 |     });
  262 |     await page.goto('http://localhost/button.html');
  263 |     await page.getByText('Click me').click({ force: true });
  264 |     const box = (await page.locator('button').boundingBox())!;
  265 |     const clicks = await page.evaluate(() => (window as any).clicks);
  266 |     expect(clicks.length).toBe(1);
  267 |     const [{ x, y }] = clicks;
  268 |     const isClickInsideButton = box.x <= x && x <= box.x + box.width && box.y <= y && y <= box.y + box.height;
  269 |     expect(isClickInsideButton).toBe(true);
  270 |     await context.close();
```