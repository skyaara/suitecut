# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/chromium/session.spec.ts >> should emit close event when session is detached
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/session.spec.ts:161:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: {"_guid": "cdp-session@c95a23c62b6a6b9176cadbfaa27b7a57", "_type": "CDPSession"}
Received: null
```

# Test source

```ts
  66  |   ]);
  67  | });
  68  | 
  69  | it('should be able to detach session', async function({ page }) {
  70  |   const client = await page.context().newCDPSession(page);
  71  |   await client.send('Runtime.enable');
  72  |   const evalResponse = await client.send('Runtime.evaluate', { expression: '1 + 2', returnByValue: true });
  73  |   expect(evalResponse.result.value).toBe(3);
  74  |   await client.detach();
  75  |   let error = null;
  76  |   try {
  77  |     await client.send('Runtime.evaluate', { expression: '3 + 1', returnByValue: true });
  78  |   } catch (e) {
  79  |     error = e;
  80  |   }
  81  |   expect(error.message).toContain('Target page, context or browser has been closed');
  82  | });
  83  | 
  84  | it('should throw nice errors', async function({ page }) {
  85  |   const client = await page.context().newCDPSession(page);
  86  |   const error = await theSourceOfTheProblems().catch(error => error);
  87  |   expect(error.stack).toContain('theSourceOfTheProblems');
  88  |   expect(error.message).toContain('ThisCommand.DoesNotExist');
  89  | 
  90  |   async function theSourceOfTheProblems() {
  91  |     // @ts-expect-error invalid command
  92  |     await client.send('ThisCommand.DoesNotExist');
  93  |   }
  94  | });
  95  | 
  96  | it('should work with main frame', async function({ page }) {
  97  |   const client = await page.context().newCDPSession(page.mainFrame());
  98  | 
  99  |   await Promise.all([
  100 |     client.send('Runtime.enable'),
  101 |     client.send('Runtime.evaluate', { expression: 'window.foo = "bar"' })
  102 |   ]);
  103 |   const foo = await page.evaluate(() => window['foo']);
  104 |   expect(foo).toBe('bar');
  105 | });
  106 | 
  107 | it('should throw if target is part of main', async function({ server, page }){
  108 |   await page.goto(server.PREFIX + '/frames/one-frame.html');
  109 |   expect(page.frames()[0].url()).toContain('/frames/one-frame.html');
  110 |   expect(page.frames()[1].url()).toContain('/frames/frame.html');
  111 | 
  112 |   const error = await page.context().newCDPSession(page.frames()[1]).catch(e => e);
  113 |   expect(error.message).toContain(`This frame does not have a separate CDP session, it is a part of the parent frame's session`);
  114 | });
  115 | 
  116 | browserTest('should not break page.close()', async function({ browser }) {
  117 |   const context = await browser.newContext();
  118 |   const page = await context.newPage();
  119 |   const session = await page.context().newCDPSession(page);
  120 |   await session.detach();
  121 |   await page.close();
  122 |   await context.close();
  123 | });
  124 | 
  125 | browserTest('should detach when page closes', async function({ browser }) {
  126 |   const context = await browser.newContext();
  127 |   const page = await context.newPage();
  128 |   const session = await context.newCDPSession(page);
  129 |   await page.close();
  130 |   let error;
  131 |   await session.detach().catch(e => error = e);
  132 |   expect(error).toBeTruthy();
  133 |   await context.close();
  134 | });
  135 | 
  136 | browserTest('should reject protocol calls when page closes', async function({ browser }) {
  137 |   const context = await browser.newContext();
  138 |   const page = await context.newPage();
  139 |   const session = await context.newCDPSession(page);
  140 |   const promise = session.send('Runtime.evaluate', { expression: 'new Promise(() => {})', awaitPromise: true }).catch(e => e);
  141 |   await page.close();
  142 |   const error1 = await promise;
  143 |   expect(error1.message).toContain(kTargetClosedErrorMessage);
  144 |   const error2 = await session.send('Runtime.evaluate', { expression: 'new Promise(() => {})', awaitPromise: true }).catch(e => e);
  145 |   expect(error2.message).toContain('Target page, context or browser has been closed');
  146 |   await context.close();
  147 | });
  148 | 
  149 | it('should emit event for each CDP event', async function({ page, server }) {
  150 |   const client = await page.context().newCDPSession(page);
  151 |   await client.send('Network.enable');
  152 |   const events = [];
  153 |   client.on('event', event => events.push(event));
  154 |   await page.goto(server.EMPTY_PAGE);
  155 |   expect(events.length).toBeGreaterThan(0);
  156 |   const requestEvent = events.find(e => e.method === 'Network.requestWillBeSent');
  157 |   expect(requestEvent).toBeTruthy();
  158 |   expect(requestEvent.params.request.url).toBe(server.EMPTY_PAGE);
  159 | });
  160 | 
  161 | it('should emit close event when session is detached', async function({ page }) {
  162 |   const client = await page.context().newCDPSession(page);
  163 |   let closedSession: any = null;
  164 |   client.on('close', session => closedSession = session);
  165 |   await client.detach();
> 166 |   expect(closedSession).toBe(client);
      |                         ^ Error: expect(received).toBe(expected) // Object.is equality
  167 | });
  168 | 
  169 | browserTest('should emit close event when page closes', async function({ browser }) {
  170 |   const context = await browser.newContext();
  171 |   const page = await context.newPage();
  172 |   const session = await context.newCDPSession(page);
  173 |   const closePromise = new Promise(f => session.on('close', f));
  174 |   await page.close();
  175 |   const closedSession = await closePromise;
  176 |   expect(closedSession).toBe(session);
  177 |   await context.close();
  178 | });
  179 | 
  180 | browserTest('should work with newBrowserCDPSession', async function({ browser }) {
  181 |   const session = await browser.newBrowserCDPSession();
  182 | 
  183 |   const version = await session.send('Browser.getVersion');
  184 |   expect(version.userAgent).toBeTruthy();
  185 | 
  186 |   let gotEvent = false;
  187 |   session.on('Target.targetCreated', () => gotEvent = true);
  188 |   await session.send('Target.setDiscoverTargets', { discover: true });
  189 |   const page = await browser.newPage();
  190 |   expect(gotEvent).toBe(true);
  191 |   await page.close();
  192 | 
  193 |   await session.detach();
  194 | });
  195 | 
```