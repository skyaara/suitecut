# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/download.spec.ts >> download event >> should close the context without awaiting the failed download
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/download.spec.ts:417:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "download.path: canceled"
Received: "download.path: Target page, context or browser has been closed"
```

# Test source

```ts
  334 |     ]);
  335 |     const path = await download.path();
  336 |     expect(fs.existsSync(path)).toBeTruthy();
  337 |     await download.delete();
  338 |     expect(fs.existsSync(path)).toBeFalsy();
  339 |     await page.close();
  340 |   });
  341 | 
  342 |   it('should expose stream', async ({ browser, server }) => {
  343 |     const page = await browser.newPage();
  344 |     await page.setContent(`<a href="${server.PREFIX}/download">download</a>`);
  345 |     const [download] = await Promise.all([
  346 |       page.waitForEvent('download'),
  347 |       page.click('a')
  348 |     ]);
  349 |     const stream = await download.createReadStream();
  350 |     let content = '';
  351 |     stream.on('data', data => content += data.toString());
  352 |     await new Promise(f => stream.on('end', f));
  353 |     expect(content).toBe('Hello world');
  354 |     await page.close();
  355 |   });
  356 | 
  357 |   it('should delete downloads on context destruction', async ({ browser, server }) => {
  358 |     const page = await browser.newPage();
  359 |     await page.setContent(`<a href="${server.PREFIX}/download">download</a>`);
  360 |     const [download1] = await Promise.all([
  361 |       page.waitForEvent('download'),
  362 |       page.click('a')
  363 |     ]);
  364 |     const [download2] = await Promise.all([
  365 |       page.waitForEvent('download'),
  366 |       page.click('a')
  367 |     ]);
  368 |     const path1 = await download1.path();
  369 |     const path2 = await download2.path();
  370 |     expect(fs.existsSync(path1)).toBeTruthy();
  371 |     expect(fs.existsSync(path2)).toBeTruthy();
  372 |     await page.context().close();
  373 |     expect(fs.existsSync(path1)).toBeFalsy();
  374 |     expect(fs.existsSync(path2)).toBeFalsy();
  375 |   });
  376 | 
  377 |   it('should delete downloads on browser gone', async ({ server, browserType }) => {
  378 |     const browser = await browserType.launch({ artifactsDir: undefined });
  379 |     const page = await browser.newPage();
  380 |     await page.setContent(`<a href="${server.PREFIX}/download">download</a>`);
  381 |     const [download1] = await Promise.all([
  382 |       page.waitForEvent('download'),
  383 |       page.click('a')
  384 |     ]);
  385 |     const [download2] = await Promise.all([
  386 |       page.waitForEvent('download'),
  387 |       page.click('a')
  388 |     ]);
  389 |     const path1 = await download1.path();
  390 |     const path2 = await download2.path();
  391 |     expect(fs.existsSync(path1)).toBeTruthy();
  392 |     expect(fs.existsSync(path2)).toBeTruthy();
  393 |     await browser.close();
  394 |     expect(fs.existsSync(path1)).toBeFalsy();
  395 |     expect(fs.existsSync(path2)).toBeFalsy();
  396 |     expect(fs.existsSync(path.join(path1, '..'))).toBeFalsy();
  397 |   });
  398 | 
  399 |   it('should save downloads to artifactsDir', async ({ server, browserType, isFrozenWebkit }, testInfo) => {
  400 |     it.skip(isFrozenWebkit, 'needs recent webkit');
  401 |     const artifactsDir = testInfo.outputPath('artifacts');
  402 |     const browser = await browserType.launch({ artifactsDir });
  403 |     const page = await browser.newPage();
  404 |     await page.setContent(`<a href="${server.PREFIX}/download">download</a>`);
  405 |     const [download] = await Promise.all([
  406 |       page.waitForEvent('download'),
  407 |       page.click('a')
  408 |     ]);
  409 |     const downloadPath = await download.path();
  410 |     expect(downloadPath.startsWith(artifactsDir)).toBeTruthy();
  411 |     expect(fs.existsSync(downloadPath)).toBeTruthy();
  412 |     await browser.close();
  413 |     // User-provided artifactsDir should not be cleaned up.
  414 |     expect(fs.existsSync(artifactsDir)).toBeTruthy();
  415 |   });
  416 | 
  417 |   it('should close the context without awaiting the failed download', async ({ browser, server, httpsServer, browserName, headless }, testInfo) => {
  418 |     it.skip(browserName !== 'chromium', 'Only Chromium downloads on alt-click');
  419 | 
  420 |     const page = await browser.newPage();
  421 |     await page.goto(server.EMPTY_PAGE);
  422 |     await page.setContent(`<a href="${httpsServer.PREFIX}/downloadWithFilename" download="file.txt">click me</a>`);
  423 |     const [download] = await Promise.all([
  424 |       page.waitForEvent('download'),
  425 |       // Use alt-click to force the download. Otherwise browsers might try to navigate first,
  426 |       // probably because of http -> https link.
  427 |       page.click('a', { modifiers: ['Alt'] })
  428 |     ]);
  429 |     const [downloadError, saveError] = await Promise.all([
  430 |       download.path().catch(e => e),
  431 |       download.saveAs(testInfo.outputPath('download.txt')).catch(e => e),
  432 |       page.context().close(),
  433 |     ]);
> 434 |     expect(downloadError.message).toBe('download.path: canceled');
      |                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  435 |     expect([
  436 |       'download.saveAs: File not found on disk. Check download.failure() for details.',
  437 |       'download.saveAs: canceled',
  438 |     ]).toContain(saveError.message);
  439 |   });
  440 | 
  441 |   it('should close the context without awaiting the download', async ({ browser, server, browserName, platform, channel }, testInfo) => {
  442 |     it.skip(browserName === 'webkit' && (platform === 'linux' || channel === 'webkit-wsl'), 'WebKit on linux does not convert to the download immediately upon receiving headers');
  443 | 
  444 |     server.setRoute('/downloadStall', (req, res) => {
  445 |       res.setHeader('Content-Type', 'application/octet-stream');
  446 |       res.setHeader('Content-Disposition', 'attachment; filename=file.txt');
  447 |       res.writeHead(200);
  448 |       res.flushHeaders();
  449 |       res.write(`Hello world`);
  450 |     });
  451 | 
  452 |     const page = await browser.newPage();
  453 |     await page.goto(server.EMPTY_PAGE);
  454 |     await page.setContent(`<a href="${server.PREFIX}/downloadStall" download="file.txt">click me</a>`);
  455 |     const [download] = await Promise.all([
  456 |       page.waitForEvent('download'),
  457 |       page.click('a')
  458 |     ]);
  459 |     const [downloadError, saveError] = await Promise.all([
  460 |       download.path().catch(e => e),
  461 |       download.saveAs(testInfo.outputPath('download.txt')).catch(e => e),
  462 |       page.context().close(),
  463 |     ]);
  464 |     // The exact error message is racy, because sometimes browser is fast enough
  465 |     // to cancel the download.
  466 |     expect([
  467 |       'download.path: canceled',
  468 |       'download.path: ' + kTargetClosedErrorMessage,
  469 |     ]).toContain(downloadError.message);
  470 |     expect([
  471 |       'download.saveAs: canceled',
  472 |       'download.saveAs: ' + kTargetClosedErrorMessage,
  473 |     ]).toContain(saveError.message);
  474 |   });
  475 | 
  476 |   it('should throw if browser dies', async ({ server, browserType, browserName, platform, channel }, testInfo) => {
  477 |     it.skip(browserName === 'webkit' && (platform === 'linux' || channel === 'webkit-wsl'), 'WebKit on linux does not convert to the download immediately upon receiving headers');
  478 |     server.setRoute('/downloadStall', (req, res) => {
  479 |       res.setHeader('Content-Type', 'application/octet-stream');
  480 |       res.setHeader('Content-Disposition', 'attachment; filename=file.txt');
  481 |       res.writeHead(200);
  482 |       res.flushHeaders();
  483 |       res.write(`Hello world`);
  484 |     });
  485 | 
  486 |     const browser = await browserType.launch();
  487 |     const page = await browser.newPage();
  488 |     await page.setContent(`<a href="${server.PREFIX}/downloadStall">click me</a>`);
  489 |     const [download] = await Promise.all([
  490 |       page.waitForEvent('download'),
  491 |       page.click('a')
  492 |     ]);
  493 |     const [downloadError, saveError] = await Promise.all([
  494 |       download.path().catch(e => e),
  495 |       download.saveAs(testInfo.outputPath('download.txt')).catch(e => e),
  496 |       (browser as any)._channel.killForTests(),
  497 |     ]);
  498 |     expect(downloadError.message).toBe('download.path: ' + kTargetClosedErrorMessage);
  499 |     expect(saveError.message).toContain('download.saveAs: ' + kTargetClosedErrorMessage);
  500 |     await browser.close();
  501 |   });
  502 | 
  503 |   it('should download large binary.zip', async ({ browser, server, browserName }, testInfo) => {
  504 |     const zipFile = testInfo.outputPath('binary.zip');
  505 |     const content = crypto.randomBytes(1 << 20);
  506 |     fs.writeFileSync(zipFile, content);
  507 |     server.setRoute('/binary.zip', (req, res) => server.serveFile(req, res, zipFile));
  508 | 
  509 |     const page = await browser.newPage();
  510 |     await page.goto(server.PREFIX + '/empty.html');
  511 |     await page.setContent(`<a href="${server.PREFIX}/binary.zip" download="binary.zip">download</a>`);
  512 |     const [download] = await Promise.all([
  513 |       page.waitForEvent('download'),
  514 |       page.click('a')
  515 |     ]);
  516 |     const downloadPath = await download.path();
  517 |     const fileContent = fs.readFileSync(downloadPath);
  518 |     expect(fileContent.byteLength).toBe(content.byteLength);
  519 |     expect(fileContent.equals(content)).toBe(true);
  520 | 
  521 |     const stream = await download.createReadStream();
  522 |     const data = await new Promise<Buffer>((fulfill, reject) => {
  523 |       const buffs: Buffer[] = [];
  524 |       stream.on('data', d => buffs.push(d));
  525 |       stream.on('error', reject);
  526 |       stream.on('end', () => fulfill(Buffer.concat(buffs)));
  527 |     });
  528 |     expect(data.byteLength).toBe(content.byteLength);
  529 |     expect(data.equals(content)).toBe(true);
  530 |     await page.close();
  531 |   });
  532 | 
  533 |   it('should be able to cancel pending downloads', async ({ browser, server, browserName, browserVersion }) => {
  534 |     const page = await browser.newPage();
```