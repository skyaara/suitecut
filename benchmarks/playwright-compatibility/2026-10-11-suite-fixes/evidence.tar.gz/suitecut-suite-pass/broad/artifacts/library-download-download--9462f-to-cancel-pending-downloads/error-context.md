# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/download.spec.ts >> download event >> should be able to cancel pending downloads
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/download.spec.ts:533:5

# Error details

```
Error: download.cancel: Protocol error (Browser.cancelDownload): Unsupported CEF browser command: Browser.cancelDownload
```

# Test source

```ts
  440 | 
  441 |   it('should close the context without awaiting the download', async ({ browser, server, browserName, platform, channel }, testInfo) => {
  442 |     it.skip(browserName === 'webkit' && (platform === 'linux' || channel === 'webkit-wsl'), 'WebKit on linux does not convert to the download immediately upon receiving headers');
  443 | 
  444 |     server.setRoute('/downloadStall', (req, res) => {
  445 |       res.setHeader('Content-Type', 'application/octet-stream');
  446 |       res.setHeader('Content-Disposition', 'attachment; filename=file.txt');
  447 |       res.writeHead(200);
  448 |       res.flushHeaders();
  449 |       res.write(`Hello world`);
  450 |     });
  451 | 
  452 |     const page = await browser.newPage();
  453 |     await page.goto(server.EMPTY_PAGE);
  454 |     await page.setContent(`<a href="${server.PREFIX}/downloadStall" download="file.txt">click me</a>`);
  455 |     const [download] = await Promise.all([
  456 |       page.waitForEvent('download'),
  457 |       page.click('a')
  458 |     ]);
  459 |     const [downloadError, saveError] = await Promise.all([
  460 |       download.path().catch(e => e),
  461 |       download.saveAs(testInfo.outputPath('download.txt')).catch(e => e),
  462 |       page.context().close(),
  463 |     ]);
  464 |     // The exact error message is racy, because sometimes browser is fast enough
  465 |     // to cancel the download.
  466 |     expect([
  467 |       'download.path: canceled',
  468 |       'download.path: ' + kTargetClosedErrorMessage,
  469 |     ]).toContain(downloadError.message);
  470 |     expect([
  471 |       'download.saveAs: canceled',
  472 |       'download.saveAs: ' + kTargetClosedErrorMessage,
  473 |     ]).toContain(saveError.message);
  474 |   });
  475 | 
  476 |   it('should throw if browser dies', async ({ server, browserType, browserName, platform, channel }, testInfo) => {
  477 |     it.skip(browserName === 'webkit' && (platform === 'linux' || channel === 'webkit-wsl'), 'WebKit on linux does not convert to the download immediately upon receiving headers');
  478 |     server.setRoute('/downloadStall', (req, res) => {
  479 |       res.setHeader('Content-Type', 'application/octet-stream');
  480 |       res.setHeader('Content-Disposition', 'attachment; filename=file.txt');
  481 |       res.writeHead(200);
  482 |       res.flushHeaders();
  483 |       res.write(`Hello world`);
  484 |     });
  485 | 
  486 |     const browser = await browserType.launch();
  487 |     const page = await browser.newPage();
  488 |     await page.setContent(`<a href="${server.PREFIX}/downloadStall">click me</a>`);
  489 |     const [download] = await Promise.all([
  490 |       page.waitForEvent('download'),
  491 |       page.click('a')
  492 |     ]);
  493 |     const [downloadError, saveError] = await Promise.all([
  494 |       download.path().catch(e => e),
  495 |       download.saveAs(testInfo.outputPath('download.txt')).catch(e => e),
  496 |       (browser as any)._channel.killForTests(),
  497 |     ]);
  498 |     expect(downloadError.message).toBe('download.path: ' + kTargetClosedErrorMessage);
  499 |     expect(saveError.message).toContain('download.saveAs: ' + kTargetClosedErrorMessage);
  500 |     await browser.close();
  501 |   });
  502 | 
  503 |   it('should download large binary.zip', async ({ browser, server, browserName }, testInfo) => {
  504 |     const zipFile = testInfo.outputPath('binary.zip');
  505 |     const content = crypto.randomBytes(1 << 20);
  506 |     fs.writeFileSync(zipFile, content);
  507 |     server.setRoute('/binary.zip', (req, res) => server.serveFile(req, res, zipFile));
  508 | 
  509 |     const page = await browser.newPage();
  510 |     await page.goto(server.PREFIX + '/empty.html');
  511 |     await page.setContent(`<a href="${server.PREFIX}/binary.zip" download="binary.zip">download</a>`);
  512 |     const [download] = await Promise.all([
  513 |       page.waitForEvent('download'),
  514 |       page.click('a')
  515 |     ]);
  516 |     const downloadPath = await download.path();
  517 |     const fileContent = fs.readFileSync(downloadPath);
  518 |     expect(fileContent.byteLength).toBe(content.byteLength);
  519 |     expect(fileContent.equals(content)).toBe(true);
  520 | 
  521 |     const stream = await download.createReadStream();
  522 |     const data = await new Promise<Buffer>((fulfill, reject) => {
  523 |       const buffs: Buffer[] = [];
  524 |       stream.on('data', d => buffs.push(d));
  525 |       stream.on('error', reject);
  526 |       stream.on('end', () => fulfill(Buffer.concat(buffs)));
  527 |     });
  528 |     expect(data.byteLength).toBe(content.byteLength);
  529 |     expect(data.equals(content)).toBe(true);
  530 |     await page.close();
  531 |   });
  532 | 
  533 |   it('should be able to cancel pending downloads', async ({ browser, server, browserName, browserVersion }) => {
  534 |     const page = await browser.newPage();
  535 |     await page.setContent(`<a href="${server.PREFIX}/downloadWithDelay">download</a>`);
  536 |     const [download] = await Promise.all([
  537 |       page.waitForEvent('download'),
  538 |       page.click('a')
  539 |     ]);
> 540 |     await download.cancel();
      |                    ^ Error: download.cancel: Protocol error (Browser.cancelDownload): Unsupported CEF browser command: Browser.cancelDownload
  541 |     const failure = await download.failure();
  542 |     expect(failure).toBe('canceled');
  543 |     await page.close();
  544 |   });
  545 | 
  546 |   it('should not fail explicitly to cancel a download even if that is already finished', async ({ browser, server, browserName, browserVersion }) => {
  547 |     const page = await browser.newPage();
  548 |     await page.setContent(`<a href="${server.PREFIX}/download">download</a>`);
  549 |     const [download] = await Promise.all([
  550 |       page.waitForEvent('download'),
  551 |       page.click('a')
  552 |     ]);
  553 |     const path = await download.path();
  554 |     expect(fs.existsSync(path)).toBeTruthy();
  555 |     expect(fs.readFileSync(path).toString()).toBe('Hello world');
  556 |     await download.cancel();
  557 |     const failure = await download.failure();
  558 |     expect(failure).toBe(null);
  559 |     await page.close();
  560 |   });
  561 | 
  562 |   it('should report downloads with interception', async ({ browser, server }) => {
  563 |     const page = await browser.newPage();
  564 |     await page.route(/.*/, r => r.continue());
  565 |     await page.setContent(`<a href="${server.PREFIX}/download">download</a>`);
  566 |     const [download] = await Promise.all([
  567 |       page.waitForEvent('download'),
  568 |       page.click('a')
  569 |     ]);
  570 |     const path = await download.path();
  571 |     expect(fs.existsSync(path)).toBeTruthy();
  572 |     expect(fs.readFileSync(path).toString()).toBe('Hello world');
  573 |     await page.close();
  574 |   });
  575 | 
  576 |   it('should emit download event from nested iframes', async ({ server, browser, browserName }, testInfo) => {
  577 |     const page = await browser.newPage();
  578 |     server.setRoute('/1', (req, res) => {
  579 |       res.setHeader('Content-Type', 'text/html');
  580 |       res.end(`<iframe src="${server.PREFIX}/2"></iframe>`);
  581 |     });
  582 |     server.setRoute('/2', (req, res) => {
  583 |       res.setHeader('Content-Type', 'text/html');
  584 |       res.end(`<iframe src="${server.PREFIX}/3"></iframe>`);
  585 |     });
  586 |     server.setRoute('/3', (req, res) => {
  587 |       res.setHeader('Content-Type', 'text/html');
  588 |       res.end(` <a href="${server.PREFIX}/download">download</a>`);
  589 |     });
  590 |     await page.goto(server.PREFIX + '/1');
  591 | 
  592 |     const [download] = await Promise.all([
  593 |       page.waitForEvent('download'),
  594 |       page.frame({
  595 |         url: server.PREFIX + '/3'
  596 |       })!.click('text=download')
  597 |     ]);
  598 |     const userPath = testInfo.outputPath('download.txt');
  599 |     await download.saveAs(userPath);
  600 |     expect(fs.existsSync(userPath)).toBeTruthy();
  601 |     expect(fs.readFileSync(userPath).toString()).toBe('Hello world');
  602 |     await page.close();
  603 |   });
  604 | });
  605 | 
  606 | it('should be able to download a PDF file', async ({ browser, server, asset }) => {
  607 |   const page = await browser.newPage();
  608 |   await page.goto(server.EMPTY_PAGE);
  609 |   await page.setContent(`
  610 |     <a href="/empty.pdf" download>download</a>
  611 |   `);
  612 |   const [download] = await Promise.all([
  613 |     page.waitForEvent('download'),
  614 |     page.click('a'),
  615 |   ]);
  616 |   await assertDownloadToPDF(download, asset('empty.pdf'));
  617 |   await page.close();
  618 | });
  619 | 
  620 | it('should be able to download a inline PDF file via response interception', async ({ browser, server, asset, browserName }) => {
  621 |   it.fixme(browserName === 'webkit');
  622 |   const page = await browser.newPage();
  623 |   await page.goto(server.EMPTY_PAGE);
  624 |   await page.route('**/empty.pdf', async route => {
  625 |     const response = await page.context().request.fetch(route.request());
  626 |     await route.fulfill({
  627 |       response,
  628 |       headers: {
  629 |         ...response.headers(),
  630 |         'Content-Disposition': 'attachment',
  631 |       }
  632 |     });
  633 |   });
  634 |   await page.setContent(`
  635 |     <a href="/empty.pdf">open</a>
  636 |   `);
  637 |   const [download] = await Promise.all([
  638 |     page.waitForEvent('download'),
  639 |     page.click('a'),
  640 |   ]);
```