# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/download.spec.ts >> download event >> should report downloads with acceptDownloads: false
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/download.spec.ts:94:5

# Error details

```
Test timeout of 10000ms exceeded.
```