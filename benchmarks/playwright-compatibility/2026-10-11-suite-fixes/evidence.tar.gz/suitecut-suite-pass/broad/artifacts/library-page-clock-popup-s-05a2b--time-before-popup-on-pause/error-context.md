# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/page-clock.spec.ts >> popup >> should not run time before popup on pause
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/page-clock.spec.ts:343:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1000
Received: 1791736289317
```

# Test source

```ts
  259 |     });
  260 |     await page.clock.runFor(1000);
  261 |     expect(calls).toEqual([]);
  262 |   });
  263 | 
  264 |   it('replaces global performance.now', async ({ page }) => {
  265 |     const promise = page.evaluate(async () => {
  266 |       const prev = performance.now();
  267 |       await new Promise(f => setTimeout(f, 1000));
  268 |       const next = performance.now();
  269 |       return { prev, next };
  270 |     });
  271 |     await page.clock.runFor(1000);
  272 |     expect(await promise).toEqual({ prev: 1000, next: 2000 });
  273 |   });
  274 | 
  275 |   it('fakes Date constructor', async ({ page }) => {
  276 |     const now = await page.evaluate(() => new Date().getTime());
  277 |     expect(now).toBe(1000);
  278 |   });
  279 | });
  280 | 
  281 | it.describe('stubTimers', () => {
  282 |   it('replaces global performance.timeOrigin', async ({ page }) => {
  283 |     await page.clock.install({ time: 1000 });
  284 |     await page.clock.pauseAt(2000);
  285 |     const promise = page.evaluate(async () => {
  286 |       const prev = performance.now();
  287 |       await new Promise(f => setTimeout(f, 1000));
  288 |       const next = performance.now();
  289 |       return { prev, next };
  290 |     });
  291 |     await page.clock.runFor(1000);
  292 |     expect(await page.evaluate(() => performance.timeOrigin)).toBe(1000);
  293 |     expect(await promise).toEqual({ prev: 1000, next: 2000 });
  294 |   });
  295 | });
  296 | 
  297 | it.describe('popup', () => {
  298 |   it('should tick after popup', async ({ page }) => {
  299 |     await page.clock.install({ time: 0 });
  300 |     const now = new Date('2015-09-25');
  301 |     await page.clock.pauseAt(now);
  302 |     const [popup] = await Promise.all([
  303 |       page.waitForEvent('popup'),
  304 |       page.evaluate(() => window.open('about:blank')),
  305 |     ]);
  306 |     const popupTime = await popup.evaluate(() => Date.now());
  307 |     expect(popupTime).toBe(now.getTime());
  308 |     await page.clock.runFor(1000);
  309 |     const popupTimeAfter = await popup.evaluate(() => Date.now());
  310 |     expect(popupTimeAfter).toBe(now.getTime() + 1000);
  311 |   });
  312 | 
  313 |   it('should tick before popup', async ({ page }) => {
  314 |     await page.clock.install({ time: 0 });
  315 |     const now = new Date('2015-09-25');
  316 |     await page.clock.pauseAt(now);
  317 |     await page.clock.runFor(1000);
  318 | 
  319 |     const [popup] = await Promise.all([
  320 |       page.waitForEvent('popup'),
  321 |       page.evaluate(() => window.open('about:blank')),
  322 |     ]);
  323 |     const popupTime = await popup.evaluate(() => Date.now());
  324 |     expect(popupTime).toBe(now.getTime() + 1000);
  325 |   });
  326 | 
  327 |   it('should run time before popup', async ({ page, server }) => {
  328 |     server.setRoute('/popup.html', async (req, res) => {
  329 |       res.setHeader('Content-Type', 'text/html');
  330 |       res.end(`<script>window.time = Date.now()</script>`);
  331 |     });
  332 |     await page.goto(server.EMPTY_PAGE);
  333 |     // Wait for 2 second in real life to check that it is past in popup.
  334 |     await page.waitForTimeout(2000);
  335 |     const [popup] = await Promise.all([
  336 |       page.waitForEvent('popup'),
  337 |       page.evaluate(url => window.open(url), server.PREFIX + '/popup.html'),
  338 |     ]);
  339 |     const popupTime = await popup.evaluate('time');
  340 |     expect(popupTime).toBeGreaterThanOrEqual(2000);
  341 |   });
  342 | 
  343 |   it('should not run time before popup on pause', async ({ page, server }) => {
  344 |     server.setRoute('/popup.html', async (req, res) => {
  345 |       res.setHeader('Content-Type', 'text/html');
  346 |       res.end(`<script>window.time = Date.now()</script>`);
  347 |     });
  348 |     await page.clock.install({ time: 0 });
  349 |     await page.clock.pauseAt(1000);
  350 |     await page.goto(server.EMPTY_PAGE);
  351 |     // Wait for 2 second in real life to check that it is past in popup.
  352 |     await page.waitForTimeout(2000);
  353 |     const [popup] = await Promise.all([
  354 |       page.waitForEvent('popup'),
  355 |       page.evaluate(url => window.open(url), server.PREFIX + '/popup.html'),
  356 |     ]);
  357 |     await popup.waitForLoadState();
  358 |     const popupTime = await popup.evaluate('time');
> 359 |     expect(popupTime).toBe(1000);
      |                       ^ Error: expect(received).toBe(expected) // Object.is equality
  360 |   });
  361 | });
  362 | 
  363 | it.describe('setFixedTime', () => {
  364 |   it('does not fake methods', async ({ page }) => {
  365 |     await page.clock.setFixedTime(0);
  366 | 
  367 |     // Should not stall.
  368 |     await page.evaluate(() => {
  369 |       return new Promise(f => setTimeout(f, 1));
  370 |     });
  371 |   });
  372 | 
  373 |   it('allows setting time multiple times', async ({ page }) => {
  374 |     await page.clock.setFixedTime(100);
  375 |     expect(await page.evaluate(() => Date.now())).toBe(100);
  376 |     await page.clock.setFixedTime(200);
  377 |     expect(await page.evaluate(() => Date.now())).toBe(200);
  378 |   });
  379 | 
  380 |   it('fixed time is not affected by clock manipulation', async ({ page }) => {
  381 |     await page.clock.setFixedTime(100);
  382 |     expect(await page.evaluate(() => Date.now())).toBe(100);
  383 |     await page.clock.fastForward(20);
  384 |     expect(await page.evaluate(() => Date.now())).toBe(100);
  385 |   });
  386 | 
  387 |   it('allows installing fake timers after settings time', async ({ page, calls }) => {
  388 |     await page.clock.setFixedTime(100);
  389 |     expect(await page.evaluate(() => Date.now())).toBe(100);
  390 |     await page.clock.setFixedTime(200);
  391 |     await page.evaluate(async () => {
  392 |       setTimeout(() => window.stub(Date.now()));
  393 |     });
  394 |     await page.clock.runFor(0);
  395 |     expect(calls).toEqual([{ params: [200] }]);
  396 |   });
  397 | });
  398 | 
  399 | it.describe('while running', () => {
  400 |   it('should progress time', async ({ page }) => {
  401 |     await page.clock.install({ time: 0 });
  402 |     const startRealTime = Date.now();
  403 |     await page.goto('data:text/html,');
  404 |     await page.waitForTimeout(1000);
  405 |     const now = await page.evaluate(() => Date.now());
  406 |     const realElapsed = Date.now() - startRealTime;
  407 |     expect(now).toBeGreaterThanOrEqual(1000);
  408 |     expect(now).toBeLessThanOrEqual(realElapsed + 1000);
  409 |   });
  410 | 
  411 |   it('should runFor', async ({ page }) => {
  412 |     await page.clock.install({ time: 0 });
  413 |     const startRealTime = Date.now();
  414 |     await page.goto('data:text/html,');
  415 |     await page.clock.runFor(10000);
  416 |     const now = await page.evaluate(() => Date.now());
  417 |     const realElapsed = Date.now() - startRealTime;
  418 |     expect(now).toBeGreaterThanOrEqual(10000);
  419 |     expect(now).toBeLessThanOrEqual(10000 + realElapsed + 1000);
  420 |   });
  421 | 
  422 |   it('should fastForward', async ({ page }) => {
  423 |     await page.clock.install({ time: 0 });
  424 |     const startRealTime = Date.now();
  425 |     await page.goto('data:text/html,');
  426 |     await page.clock.fastForward(10000);
  427 |     const now = await page.evaluate(() => Date.now());
  428 |     const realElapsed = Date.now() - startRealTime;
  429 |     expect(now).toBeGreaterThanOrEqual(10000);
  430 |     expect(now).toBeLessThanOrEqual(10000 + realElapsed + 1000);
  431 |   });
  432 | 
  433 |   it('should pause', async ({ page }) => {
  434 |     await page.clock.install({ time: 0 });
  435 |     await page.goto('data:text/html,');
  436 |     await page.clock.pauseAt(60000);
  437 |     // Internally wait to make sure the clock is paused and not running.
  438 |     await page.waitForTimeout(1111);
  439 |     const now = await page.evaluate(() => Date.now());
  440 |     expect(now).toBe(60000);
  441 |   });
  442 | 
  443 |   it('should reject an invalid target time with an active requestAnimationFrame loop', {
  444 |     annotation: {
  445 |       type: 'issue',
  446 |       description: 'https://github.com/microsoft/playwright-python/issues/3137',
  447 |     }
  448 |   }, async ({ page }) => {
  449 |     await page.clock.install();
  450 |     await page.setContent(`<script>function tick() { requestAnimationFrame(tick); } requestAnimationFrame(tick);</script>`);
  451 |     const invalidTime = await page.evaluate(() => Date.now()) * 1_000_000;
  452 |     await expect(page.clock.pauseAt(invalidTime)).rejects.toThrow(`clock.pauseAt: Invalid date: ${invalidTime}`);
  453 |   });
  454 | 
  455 |   it('should pause and fastForward', async ({ page }) => {
  456 |     await page.clock.install({ time: 0 });
  457 |     await page.goto('data:text/html,');
  458 |     await page.clock.pauseAt(60000);
  459 |     await page.clock.fastForward(1000);
```