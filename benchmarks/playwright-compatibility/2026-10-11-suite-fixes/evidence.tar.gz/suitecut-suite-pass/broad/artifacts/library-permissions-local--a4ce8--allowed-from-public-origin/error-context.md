# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/permissions.spec.ts >> local network request is allowed from public origin
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/permissions.spec.ts:267:3

# Error details

```
Error: browserContext.grantPermissions: Protocol error (Browser.grantPermissions): Unsupported native permission: localNetworkAccess
```

# Test source

```ts
  174 |       // Since https://github.com/WebKit/WebKit/pull/45470 WebKit returns the cached
  175 |       // permission value, if the geolocation API has been accessed.
  176 |       // TODO: We can probably reset the cached state in the Web Process when resetting
  177 |       // permissions.
  178 |       expect(await getPermission(page, 'geolocation')).toBe('denied');
  179 | 
  180 |       // Geolocation API in the new page in the same context has not been accessed yet,
  181 |       // so the permission status should be prompt.
  182 |       const page2 = await context.newPage();
  183 |       await page2.goto(server.EMPTY_PAGE);
  184 |       expect(await getPermission(page2, 'geolocation')).toBe('prompt');
  185 |       await page2.close();
  186 |     } else {
  187 |       expect(await getPermission(page, 'geolocation')).toBe('prompt');
  188 |     }
  189 |     expect(await getPermission(otherPage, 'geolocation')).toBe('granted');
  190 |     await otherContext.close();
  191 |     await context.close();
  192 |   });
  193 | });
  194 | 
  195 | it('should support clipboard read', async ({ page, context, server, browserName, isWindows, isLinux, headless, isHeadlessShell }) => {
  196 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/27475' });
  197 |   it.fail(browserName === 'firefox', 'No such permissions (requires flag) in Firefox');
  198 |   it.fixme(browserName === 'webkit' && isWindows, 'WebPasteboardProxy::allPasteboardItemInfo not implemented for Windows.');
  199 |   it.fixme(browserName === 'webkit' && isLinux && headless, 'WebPasteboardProxy::allPasteboardItemInfo not implemented for WPE.');
  200 | 
  201 |   await page.goto(server.EMPTY_PAGE);
  202 |   // There is no 'clipboard-read' permission in WebKit Web API.
  203 |   if (browserName !== 'webkit')
  204 |     expect(await getPermission(page, 'clipboard-read')).toBe('prompt');
  205 | 
  206 |   if (isHeadlessShell) {
  207 |     // Chromium (but not headless-shell) shows a dialog and does not resolve the promise.
  208 |     const error = await page.evaluate(() => navigator.clipboard.readText()).catch(e => e);
  209 |     expect(error.toString()).toContain('denied');
  210 |   }
  211 | 
  212 |   await context.grantPermissions(['clipboard-read']);
  213 |   if (browserName !== 'webkit')
  214 |     expect(await getPermission(page, 'clipboard-read')).toBe('granted');
  215 |   // There is no 'clipboard-write' permission in WebKit Web API.
  216 |   if (browserName === 'chromium')
  217 |     await context.grantPermissions(['clipboard-write']);
  218 |   await page.evaluate(() => navigator.clipboard.writeText('test content'));
  219 |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe('test content');
  220 | });
  221 | 
  222 | it('storage access', {
  223 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/31227' }
  224 | }, async ({ page, context, server, browserName }) => {
  225 |   it.skip(browserName !== 'chromium', 'chromium-only api');
  226 | 
  227 |   await context.grantPermissions(['storage-access']);
  228 |   expect(await getPermission(page, 'storage-access')).toBe('granted');
  229 |   server.setRoute('/set-cookie.html', (req, res) => {
  230 |     res.setHeader('Set-Cookie', 'name=value; Path=/; SameSite=Strict; Secure');
  231 |     res.end();
  232 |   });
  233 |   server.setRoute('/my-frame.html', (req, res) => {
  234 |     res.setHeader('Content-type', 'text/html');
  235 |     res.end(`<iframe src="${server.CROSS_PROCESS_PREFIX + '/empty.html'}"></iframe>`);
  236 |   });
  237 | 
  238 |   // Navigate once to the domain as top level.
  239 |   await page.goto(server.CROSS_PROCESS_PREFIX + '/set-cookie.html');
  240 |   await page.goto(server.PREFIX + '/my-frame.html');
  241 | 
  242 |   const frame = page.frames()[1];
  243 |   expect(await getPermission(frame, 'storage-access')).toBe('granted');
  244 |   const access = await frame.evaluate(() => document.requestStorageAccess().then(() => true, () => false));
  245 |   expect(access).toBe(true);
  246 |   expect(await frame.evaluate(() => document.hasStorageAccess())).toBe(true);
  247 | });
  248 | 
  249 | it.describe(() => {
  250 |   // Secure context
  251 |   it.use({ ignoreHTTPSErrors: true, });
  252 | 
  253 |   it('should be able to use the local-fonts API', async ({ page, context, httpsServer, browserName, channel, headless }) => {
  254 |     it.skip(browserName !== 'chromium', 'chromium-only api');
  255 |     it.skip(!!channel && channel.startsWith('msedge'), 'always times out in edge');
  256 |     it.fixme(!headless, 'times out in headed');
  257 |     it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/36113' });
  258 | 
  259 |     await page.goto(httpsServer.EMPTY_PAGE);
  260 |     expect(await getPermission(page, 'local-fonts')).toBe('prompt');
  261 |     await context.grantPermissions(['local-fonts']);
  262 |     expect(await getPermission(page, 'local-fonts')).toBe('granted');
  263 |     expect(await page.evaluate(async () => (await (window as any).queryLocalFonts()).length > 0)).toBe(true);
  264 |   });
  265 | });
  266 | 
  267 | it('local network request is allowed from public origin', {
  268 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/37861' }
  269 | }, async ({ page, context, server, browserName, channel, browserMajorVersion }) => {
  270 |   it.skip(browserName === 'webkit');
  271 |   it.skip(browserName === 'chromium' && browserMajorVersion < 145, 'local-network-access permission support has changed between versions');
  272 | 
  273 |   if (browserName === 'chromium' || browserName === 'firefox')
> 274 |     await context.grantPermissions(['local-network-access']);
      |                   ^ Error: browserContext.grantPermissions: Protocol error (Browser.grantPermissions): Unsupported native permission: localNetworkAccess
  275 |   const serverRequests = [];
  276 |   server.setRoute('/cors', (req, res) => {
  277 |     serverRequests.push(`${req.method} ${req.url}`);
  278 |     if (req.method === 'OPTIONS') {
  279 |       res.writeHead(204, {
  280 |         'Access-Control-Allow-Origin': '*',
  281 |         'Access-Control-Allow-Methods': 'GET, POST, PUT, OPTIONS',
  282 |         'Access-Control-Allow-Headers': '*',
  283 |       });
  284 |       res.end();
  285 |       return;
  286 |     }
  287 |     res.writeHead(200, { 'Content-type': 'text/plain', 'Access-Control-Allow-Origin': '*' });
  288 |     res.end('Hello there!');
  289 |   });
  290 |   const clientRequests = [];
  291 |   // Has to be a public origin.
  292 |   await page.goto('https://demo.playwright.dev/todomvc/');
  293 |   page.on('request', request => {
  294 |     clientRequests.push(`${request.method()} ${request.url()}`);
  295 |   });
  296 |   const response = await page.evaluate(async url => {
  297 |     const response = await fetch(url, {
  298 |       method: 'POST',
  299 |       body: '',
  300 |       headers: {
  301 |         'Content-Type': 'application/json',
  302 |         'X-Custom-Header': 'test-value'
  303 |       }
  304 |     });
  305 |     return await response.text();
  306 |   }, server.CROSS_PROCESS_PREFIX + '/cors').catch(e => e.message);
  307 |   expect(response).toBe('Hello there!');
  308 |   expect(serverRequests).toEqual([
  309 |     'OPTIONS /cors',
  310 |     'POST /cors',
  311 |   ]);
  312 |   expect(clientRequests).toEqual([
  313 |     `POST ${server.CROSS_PROCESS_PREFIX}/cors`,
  314 |   ]);
  315 | });
  316 | 
  317 | it('can request screen-wake-lock', {
  318 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/39115' }
  319 | }, async ({ page, context }) => {
  320 |   await context.grantPermissions(['screen-wake-lock']);
  321 |   await page.route('**/*', route => route.fulfill({ status: 200, body: '<div>Hello there!</div>', contentType: 'text/html' }));
  322 |   await page.goto('https://example.com');
  323 |   await page.evaluate(() => navigator.wakeLock.request('screen'));
  324 | });
  325 | 
  326 | it.describe('camera and microphone', () => {
  327 |   // WebKit exposes deterministic mock capture devices; capture is gated on the
  328 |   // 'camera'/'microphone' permissions. Chromium needs --use-fake-device-for-media-stream
  329 |   // and Firefox has no camera/microphone permission mapping, so scope to WebKit.
  330 |   it.skip(({ browserName }) => browserName !== 'webkit', 'WebKit mock-capture-device based test');
  331 |   // Native Windows WebKit is built without a media-capture backend, so getUserMedia is
  332 |   // unavailable there; WSL runs the Linux build, which does have mock capture.
  333 |   it.skip(({ isWindows, channel }) => isWindows && channel !== 'webkit-wsl', 'WebKit has no media capture on Windows');
  334 | 
  335 |   async function getUserMedia(page, constraints) {
  336 |     return await page.evaluate(async constraints => {
  337 |       try {
  338 |         const stream = await navigator.mediaDevices.getUserMedia(constraints);
  339 |         const tracks = stream.getTracks().map(track => ({ kind: track.kind, live: track.readyState === 'live' }));
  340 |         stream.getTracks().forEach(track => track.stop());
  341 |         tracks.sort((a, b) => a.kind.localeCompare(b.kind));
  342 |         return { tracks };
  343 |       } catch (error) {
  344 |         return { error: error.name };
  345 |       }
  346 |     }, constraints);
  347 |   }
  348 | 
  349 |   it('should capture when camera and microphone are granted', {
  350 |     annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/2973' }
  351 |   }, async ({ page, context, server, isFrozenWebkit }) => {
  352 |     it.skip(isFrozenWebkit, 'Mock capture device support requires a newer WebKit build');
  353 | 
  354 |     await context.grantPermissions(['camera', 'microphone'], { origin: server.PREFIX });
  355 |     await page.goto(server.EMPTY_PAGE);
  356 |     expect(await getUserMedia(page, { video: true, audio: true })).toEqual({
  357 |       tracks: [
  358 |         { kind: 'audio', live: true },
  359 |         { kind: 'video', live: true },
  360 |       ],
  361 |     });
  362 |   });
  363 | 
  364 |   it('should reject when no permission is granted', {
  365 |     annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/2973' }
  366 |   }, async ({ page, server, isFrozenWebkit }) => {
  367 |     it.skip(isFrozenWebkit, 'Mock capture device support requires a newer WebKit build');
  368 | 
  369 |     await page.goto(server.EMPTY_PAGE);
  370 |     expect(await getUserMedia(page, { video: true, audio: true })).toEqual({ error: 'NotAllowedError' });
  371 |   });
  372 | 
  373 |   it('should gate audio and video independently', {
  374 |     annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/2973' }
```