# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/beforeunload.spec.ts >> should run beforeunload if asked for @smoke
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/beforeunload.spec.ts:55:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: ""
Received: "Leave this page?"
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2017 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { contextTest as it, expect } from '../config/browserTest';
  19  | 
  20  | it('should close browser with beforeunload page', async ({ server, browserType }) => {
  21  |   const browser = await browserType.launch();
  22  |   const page = await browser.newPage();
  23  |   await page.goto(server.PREFIX + '/beforeunload.html');
  24  |   // We have to interact with a page so that 'beforeunload' handlers
  25  |   // fire.
  26  |   await page.click('body');
  27  |   await browser.close();
  28  | });
  29  | 
  30  | it('should close browsercontext with beforeunload page', async ({ server, page, context }) => {
  31  |   await page.goto(server.PREFIX + '/beforeunload.html');
  32  |   // We have to interact with a page so that 'beforeunload' handlers
  33  |   // fire.
  34  |   await page.click('body');
  35  |   await context.close();
  36  | });
  37  | 
  38  | it('should be able to navigate away from page with beforeunload', async ({ server, page, context }) => {
  39  |   await page.goto(server.PREFIX + '/beforeunload.html');
  40  |   // We have to interact with a page so that 'beforeunload' handlers
  41  |   // fire.
  42  |   await page.click('body');
  43  |   await page.goto(server.EMPTY_PAGE);
  44  | });
  45  | 
  46  | it('should close page with beforeunload listener', async ({ context, server }) => {
  47  |   const newPage = await context.newPage();
  48  |   await newPage.goto(server.PREFIX + '/beforeunload.html');
  49  |   // We have to interact with a page so that 'beforeunload' handlers
  50  |   // fire.
  51  |   await newPage.click('body');
  52  |   await newPage.close();
  53  | });
  54  | 
  55  | it('should run beforeunload if asked for @smoke', async ({ context, server, browserName }) => {
  56  |   const newPage = await context.newPage();
  57  |   await newPage.goto(server.PREFIX + '/beforeunload.html');
  58  |   // We have to interact with a page so that 'beforeunload' handlers
  59  |   // fire.
  60  |   await newPage.click('body');
  61  |   const [dialog] = await Promise.all([
  62  |     newPage.waitForEvent('dialog'),
  63  |     newPage.close({ runBeforeUnload: true })
  64  |   ]);
  65  |   expect(dialog.type()).toBe('beforeunload');
  66  |   expect(dialog.defaultValue()).toBe('');
  67  |   if (browserName === 'chromium')
> 68  |     expect(dialog.message()).toBe('');
      |                              ^ Error: expect(received).toBe(expected) // Object.is equality
  69  |   else if (browserName === 'webkit')
  70  |     expect(dialog.message()).toBe('Leave?');
  71  |   else
  72  |     expect(dialog.message()).toContain('This page is asking you to confirm that you want to leave');
  73  |   await Promise.all([
  74  |     dialog.accept(),
  75  |     newPage.waitForEvent('close'),
  76  |   ]);
  77  | });
  78  | 
  79  | it('should access page after beforeunload', async ({ page, server }) => {
  80  |   await page.goto(server.PREFIX + '/beforeunload.html');
  81  |   // We have to interact with a page so that 'beforeunload' handlers
  82  |   // fire.
  83  |   await page.click('body');
  84  |   const [dialog] = await Promise.all([
  85  |     page.waitForEvent('dialog'),
  86  |     page.close({ runBeforeUnload: true }),
  87  |   ]);
  88  |   await dialog.dismiss();
  89  |   await page.evaluate(() => document.title);
  90  | });
  91  | 
  92  | it('should not stall on evaluate when dismissing beforeunload', async ({ page, server }) => {
  93  |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/23141' });
  94  | 
  95  |   await page.goto(server.PREFIX + '/beforeunload.html');
  96  |   // We have to interact with a page so that 'beforeunload' handlers fire.
  97  |   await page.click('body');
  98  | 
  99  |   await Promise.all([
  100 |     page.waitForEvent('dialog').then(dialog => dialog.dismiss()),
  101 |     page.evaluate(() => {
  102 |       window.location.reload();
  103 |     }),
  104 |   ]);
  105 | });
  106 | 
  107 | it('should not stall on click when dismissing beforeunload', async ({ page, server }) => {
  108 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/33806' });
  109 | 
  110 |   await page.goto(server.EMPTY_PAGE);
  111 |   await page.setContent(`<a href="${server.PREFIX}/frames/one-frame.html">click me</a>`);
  112 | 
  113 |   await page.evaluate(() => {
  114 |     window.onbeforeunload = () => false;
  115 |   });
  116 |   page.on('dialog', async dialog => {
  117 |     await dialog.dismiss();
  118 |   });
  119 | 
  120 |   await page.getByRole('link').click({ noWaitAfter: true });
  121 |   await page.evaluate(() => {
  122 |     window.onbeforeunload = null;
  123 |   });
  124 | 
  125 |   // This line should not timeout.
  126 |   await page.getByRole('link').click({ timeout: 5000 });
  127 |   await expect(page).toHaveURL(server.PREFIX + '/frames/one-frame.html');
  128 | });
  129 | 
  130 | it('should support dismissing the dialog multiple times', async ({ page, server }) => {
  131 |   await page.goto(server.PREFIX + '/beforeunload.html');
  132 | 
  133 |   // We have to interact with a page so that 'beforeunload' handlers
  134 |   // fire (in Firefox).
  135 |   await page.click('body');
  136 | 
  137 |   const [dialog] = await Promise.all([
  138 |     page.waitForEvent('dialog'),
  139 |     page.close({ runBeforeUnload: true })
  140 |   ]);
  141 | 
  142 |   await dialog.dismiss();
  143 | 
  144 |   const [dialog2] = await Promise.all([
  145 |     page.waitForEvent('dialog'),
  146 |     page.close({ runBeforeUnload: true })
  147 |   ]);
  148 | 
  149 |   await dialog2.dismiss();
  150 | });
  151 | 
  152 | it('should support closing the page after a previous dismiss', async ({ page, server }) => {
  153 |   await page.goto(server.PREFIX + '/beforeunload.html');
  154 | 
  155 |   // We have to interact with a page so that 'beforeunload' handlers
  156 |   // fire (in Firefox).
  157 |   await page.click('body');
  158 | 
  159 |   const [dialog] = await Promise.all([
  160 |     page.waitForEvent('dialog'),
  161 |     page.close({ runBeforeUnload: true })
  162 |   ]);
  163 | 
  164 |   await dialog.dismiss();
  165 | 
  166 |   await page.close();
  167 |   await expect(page.isClosed()).toBe(true);
  168 | });
```