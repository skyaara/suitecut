// SPDX-License-Identifier: MIT
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <csignal>
#include <cstring>
#include <deque>
#include <functional>
#include <mutex>
#include "memory_bounds.h"
#include <map>
#include <set>
#if SUITECUT_WITH_MEDIA
#include "media_engine.h"
#include "media_file.h"
#include "media_render.h"
#endif
#include <optional>
#include <string>
#include <thread>
#include <vector>
#include <fcntl.h>
#include <poll.h>
#include <unistd.h>

#include "include/cef_app.h"
#include "include/cef_audio_handler.h"
#include "include/cef_client.h"
#include "include/cef_parser.h"
#include "include/cef_request_context.h"
#include "include/cef_cookie.h"
#include "include/cef_permission_handler.h"
#include "include/cef_task.h"
#include "include/cef_version.h"
#include "audio_clock.h"
#include "audio_trace.h"
#include "cdp_json.h"
#include "libyuv/convert_from_argb.h"
#include "libyuv/convert.h"

namespace {
using Clock = std::chrono::steady_clock;
const auto started = Clock::now();
double EpochNow() {return std::chrono::duration<double,std::milli>(std::chrono::system_clock::now().time_since_epoch()).count();}
double Now() { return std::chrono::duration<double, std::milli>(Clock::now() - started).count(); }
using Dict = CefRefPtr<CefDictionaryValue>;
double Number(Dict value, const char* key) {
  if(value->GetType(key)==VTYPE_INT) return value->GetInt(key);
  return value->GetDouble(key);
}
Dict Header(const char* type) {
  auto value = CefDictionaryValue::Create();
  value->SetInt("version", 1);
  value->SetString("type", type);
  return value;
}
std::string Json(Dict dict) {
  auto value = CefValue::Create();
  value->SetDictionary(dict);
  return CefWriteJSON(value, JSON_WRITER_DEFAULT).ToString();
}
// Opt-in diagnostic metadata only: never log credentials, script arguments,
// response bodies, URLs or encoded video frames. The trace has a fixed cap.
void TraceCDP(const char* stage,int id,const std::string& session,
              const std::string& method,const std::string& target,Dict params=nullptr) {
  static const bool enabled=std::getenv("SUITECUT_CDP_TRACE")!=nullptr;
  static size_t count=0;
  if(!enabled || count>=100000)return;
  const bool relevant=method.starts_with("Target.") || method.starts_with("Page.") ||
    method.starts_with("Inspector.") || method=="Runtime.evaluate" ||
    method=="Runtime.runIfWaitingForDebugger" || method=="Runtime.executionContextCreated";
  if(!relevant)return;
  ++count;auto entry=CefDictionaryValue::Create();
  entry->SetDouble("atMs",Now());entry->SetString("stage",stage);entry->SetInt("id",id);
  entry->SetString("session",session);entry->SetString("method",method);entry->SetString("target",target);
  if(params) {
    for(const char* key:{"sessionId","frameId","targetId","browserContextId"})
      if(params->GetType(key)==VTYPE_STRING)entry->SetString(key,params->GetString(key));
    if(auto info=params->GetDictionary("targetInfo")) {
      entry->SetString("targetType",info->GetString("type"));entry->SetString("targetId",info->GetString("targetId"));
    }
    if(method=="Page.screencastFrame")entry->SetInt("frameAckId",params->GetInt("sessionId"));
  }
  std::fprintf(stderr,"suitecut-cdp %s\n",Json(entry).c_str());
}
struct Packet { std::string header; std::vector<uint8_t> data; bool video = false, audio = false; double queued = 0; };

// Never block a CEF callback on Node or an encoder. Retain one pending video
// frame and at most 100 audio packets. Control responses have a separate cap.
// Chromium's policy permits proxied UDP, or falls back to TCP when the
// configured proxy does not support UDP. It does not create network access.
bool ConfigureWebRTC(CefRefPtr<CefRequestContext> context, std::string& error) {
  const auto policy = CefCommandLine::GetGlobalCommandLine()->GetSwitchValue("suitecut-webrtc-policy").ToString();
  if (policy.empty() || policy == "default") return true;
  auto value = CefValue::Create();
  value->SetString("disable_non_proxied_udp");
  CefString cef_error;
  if (!context->SetPreference("webrtc.ip_handling_policy", value, cef_error)) {
    error = "CEF WebRTC network policy failed: " + cef_error.ToString();
    return false;
  }
  return true;
}

class Writer {
 public:
  explicit Writer(int output, bool diagnostics = false) : output_(output), diagnostics_(diagnostics) {
    fcntl(output_, F_SETFL, fcntl(output_, F_GETFL) | O_NONBLOCK);
    thread_ = std::thread([this] { Run(); });
    if (diagnostics_) monitor_ = std::thread([this] {
      std::unique_lock lock(monitor_mutex_);
      while (!monitor_cv_.wait_for(lock, std::chrono::seconds(1), [this] { return stopping_.load(); })) Report();
      Report();
    });
  }
  ~Writer() { Stop(); close(output_); }
  void Stop() {
    stopping_ = true;
    cv_.notify_all();
    monitor_cv_.notify_all();
    if (thread_.joinable()) thread_.join();
    if (monitor_.joinable()) monitor_.join();
  }
  // Opt-in benchmark counters only: no page content, URL, PCM or pixels.
  void Captured(bool video, double at, double pts = 0) {
    if (!diagnostics_) return;
    std::lock_guard lock(mutex_);
    auto& count = video ? paints_ : audio_callbacks_;
    auto& last = video ? last_paint_ : last_audio_;
    auto& gap = video ? paint_gap_ : audio_gap_;
    if (count) gap = std::max(gap, at - last);
    ++count; last = at;
    if (!video) last_audio_pts_ = pts;
  }
  void Send(Dict header, std::vector<uint8_t> data = {}) {
    header->SetInt("bytes", static_cast<int>(data.size()));
    std::lock_guard lock(mutex_);
    if (stopping_) return;
    const auto type = header->GetString("type").ToString();
    if (type == "frame") {
      if (frame_) ++dropped_;
      header->SetDouble("dropped", static_cast<double>(dropped_));
      frame_ = Packet{Json(header), std::move(data), true, false, diagnostics_ ? Now() : 0};
    } else if (type == "audio") {
      if (audio_.size() >= 100) { audio_.pop_front(); ++audio_dropped_; }
      audio_.push_back({Json(header), std::move(data), false, true, diagnostics_ ? Now() : 0});
      audio_peak_ = std::max(audio_peak_, audio_.size());
    } else {
      auto text=Json(header);
      if(control_.size()>=4096 || control_bytes_+text.size()+data.size()>16777216) {
        control_.clear();control_bytes_=0;auto error=Header("error");error->SetInt("bytes",0);error->SetString("error","Native control backpressure limit exceeded");text=Json(error);data.clear();
      }
      control_bytes_+=text.size()+data.size();control_.push_back({std::move(text),std::move(data)});
    }
    cv_.notify_one();
  }
  void Reply(int id, bool ok, const std::string& error = "", std::vector<uint8_t> data = {}) {
    auto header = Header("response");
    header->SetInt("id", id);
    header->SetBool("ok", ok);
    if (!error.empty()) header->SetString("error", error.substr(0, 4096));
    Send(header, std::move(data));
  }
  void Error(const char* message) {
    auto header = Header("error");
    header->SetString("error", message);
    Send(header);
  }
 private:
  void Report() {
    char line[4096];
    int length;
    {
    std::lock_guard lock(mutex_);
    const double now = Now();
    length = snprintf(line, sizeof(line), "SUITECUT_DIAGNOSTIC {\"hostMs\":%.3f,\"paints\":%llu,\"audioCallbacks\":%llu,\"lastPaintMs\":%.3f,\"lastAudioMs\":%.3f,\"lastAudioPtsMs\":%.3f,\"maxPaintGapMs\":%.3f,\"maxAudioGapMs\":%.3f,\"videoReplaced\":%llu,\"audioDropped\":%llu,\"audioQueued\":%zu,\"audioQueuePeak\":%zu,\"videoWritten\":%llu,\"audioWritten\":%llu,\"writingVideo\":%s,\"writingAudio\":%s,\"currentWriteMs\":%.3f,\"maxVideoWriteMs\":%.3f,\"maxAudioWriteMs\":%.3f,\"maxVideoQueueMs\":%.3f,\"maxAudioQueueMs\":%.3f}\n",
      now, (unsigned long long)paints_, (unsigned long long)audio_callbacks_, last_paint_, last_audio_, last_audio_pts_, paint_gap_, audio_gap_,
      (unsigned long long)dropped_, (unsigned long long)audio_dropped_, audio_.size(), audio_peak_,
      (unsigned long long)video_written_, (unsigned long long)audio_written_, writing_video_ ? "true" : "false", writing_audio_ ? "true" : "false",
      writing_at_ ? now - writing_at_ : 0, video_write_max_, audio_write_max_, video_queue_max_, audio_queue_max_);
    }
    // Do not hold the media queue lock while writing diagnostics.
    if (length > 0 && static_cast<size_t>(length) < sizeof(line)) {
      const auto ignored = write(STDERR_FILENO, line, static_cast<size_t>(length));
      (void)ignored;
    }
  }
  bool Write(const void* data, size_t size) {
    auto bytes = static_cast<const uint8_t*>(data);
    while (size && !stopping_) {
      pollfd fd{output_, POLLOUT, 0};
      if (poll(&fd, 1, 100) <= 0) continue;
      const auto n = write(output_, bytes, size);
      if (n < 0 && (errno == EAGAIN || errno == EINTR)) continue;
      if (n <= 0) return false;
      bytes += n;
      size -= static_cast<size_t>(n);
    }
    return size == 0;
  }
  void Run() {
    while (!stopping_) {
      Packet packet;
      {
        std::unique_lock lock(mutex_);
        cv_.wait(lock, [this] { return stopping_ || !control_.empty() || !audio_.empty() || frame_; });
        if (stopping_) break;
        if (!control_.empty()) { packet = std::move(control_.front()); control_bytes_-=packet.header.size()+packet.data.size();control_.pop_front(); }
        else if (!audio_.empty()) { packet = std::move(audio_.front()); audio_.pop_front(); }
        else { packet = std::move(*frame_); frame_.reset(); }
        if (diagnostics_) {
          writing_at_ = Now(); writing_video_ = packet.video; writing_audio_ = packet.audio;
          if (packet.video) video_queue_max_ = std::max(video_queue_max_, writing_at_ - packet.queued);
          if (packet.audio) audio_queue_max_ = std::max(audio_queue_max_, writing_at_ - packet.queued);
        }
      }
      const uint32_t size = static_cast<uint32_t>(packet.header.size());
      const uint8_t prefix[] = {uint8_t(size), uint8_t(size >> 8), uint8_t(size >> 16), uint8_t(size >> 24)};
      const bool ok = Write(prefix, 4) && Write(packet.header.data(), size) && Write(packet.data.data(), packet.data.size());
      if (diagnostics_) {
        std::lock_guard lock(mutex_);
        const double elapsed = Now() - writing_at_;
        if (packet.video) { video_write_max_ = std::max(video_write_max_, elapsed); if (ok) ++video_written_; }
        if (packet.audio) { audio_write_max_ = std::max(audio_write_max_, elapsed); if (ok) ++audio_written_; }
        writing_at_ = 0; writing_video_ = writing_audio_ = false;
      }
      if (!ok) break;
    }
  }
  std::mutex mutex_;
  int output_;
  std::condition_variable cv_;
  std::deque<Packet> control_, audio_;
  size_t control_bytes_=0;
  std::optional<Packet> frame_;
  uint64_t dropped_ = 0;
  const bool diagnostics_;
  uint64_t audio_dropped_ = 0, paints_ = 0, audio_callbacks_ = 0, video_written_ = 0, audio_written_ = 0;
  size_t audio_peak_ = 0;
  double last_paint_ = 0, last_audio_ = 0, last_audio_pts_ = 0, paint_gap_ = 0, audio_gap_ = 0;
  double writing_at_ = 0, video_write_max_ = 0, audio_write_max_ = 0, video_queue_max_ = 0, audio_queue_max_ = 0;
  bool writing_video_ = false, writing_audio_ = false;
  std::mutex monitor_mutex_;
  std::condition_variable monitor_cv_;
  std::atomic<bool> stopping_{false};
  std::thread thread_;
  std::thread monitor_;
};

class Task : public CefTask {
 public:
  explicit Task(std::function<void()> callback) : callback_(std::move(callback)) {}
  void Execute() override { callback_(); }
 private:
  std::function<void()> callback_;
  IMPLEMENT_REFCOUNTING(Task);
};

class CookieVisitor : public CefCookieVisitor {
 public:
  explicit CookieVisitor(std::function<void(CefRefPtr<CefListValue>)> result):result_(std::move(result)),cookies_(CefListValue::Create()) {}
  ~CookieVisitor() override {result_(cookies_);}
  bool Visit(const CefCookie& cookie,int,int,bool&) override {
    auto value=CefDictionaryValue::Create();value->SetString("name",CefString(&cookie.name));value->SetString("value",CefString(&cookie.value));value->SetString("domain",CefString(&cookie.domain));value->SetString("path",CefString(&cookie.path));
    value->SetBool("secure",cookie.secure);value->SetBool("httpOnly",cookie.httponly);value->SetBool("session",!cookie.has_expires);
    value->SetDouble("expires",cookie.has_expires ? (cookie.expires.val-11644473600000000LL)/1000000.0 : -1);
    value->SetString("sameSite",cookie.same_site==CEF_COOKIE_SAME_SITE_STRICT_MODE ? "Strict" : cookie.same_site==CEF_COOKIE_SAME_SITE_NO_RESTRICTION ? "None" : "Lax");
    value->SetInt("size",CefString(&cookie.name).length()+CefString(&cookie.value).length());value->SetString("priority","Medium");value->SetBool("sameParty",false);value->SetString("sourceScheme",cookie.secure ? "Secure" : "NonSecure");value->SetInt("sourcePort",-1);
    cookies_->SetDictionary(cookies_->GetSize(),value);return true;
  }
 private:
  std::function<void(CefRefPtr<CefListValue>)> result_;CefRefPtr<CefListValue> cookies_;
  IMPLEMENT_REFCOUNTING(CookieVisitor);
};
class CookieSetCallback : public CefSetCookieCallback {
 public: explicit CookieSetCallback(std::function<void(bool)> result):result_(std::move(result)) {}
  void OnComplete(bool success) override {result_(success);}
 private: std::function<void(bool)> result_;IMPLEMENT_REFCOUNTING(CookieSetCallback);
};
class CookieDeleteCallback : public CefDeleteCookiesCallback {
 public: explicit CookieDeleteCallback(std::function<void()> result):result_(std::move(result)) {}
  void OnComplete(int) override {result_();}
 private: std::function<void()> result_;IMPLEMENT_REFCOUNTING(CookieDeleteCallback);
};

class Source : public CefClient, public CefLifeSpanHandler, public CefRenderHandler,
               public CefAudioHandler, public CefLoadHandler, public CefRequestHandler,
               public CefDevToolsMessageObserver, public CefJSDialogHandler,
               public CefDownloadHandler, public CefContextMenuHandler, public CefPermissionHandler {
 public:
  Source(Writer& writer, int width, int height, double scale, bool i420, bool subscriptions, Source* root = nullptr, std::string context = "default", std::string opener = "")
      : root_owner_(root), root_(root ? root : this), context_id_(std::move(context)), opener_id_(std::move(opener)),
        writer_(writer), width_(width), height_(height), scale_(scale), i420_(i420), frame_subscriptions_(subscriptions) {if(root) {emit_frames_=false;emit_audio_=false;}}
  CefRefPtr<CefLifeSpanHandler> GetLifeSpanHandler() override { return this; }
  CefRefPtr<CefPermissionHandler> GetPermissionHandler() override {return this;}
  struct Permission {uint32_t prompt;cef_content_setting_types_t setting;};
  static const std::map<std::string,Permission>& Permissions() {
    static const std::map<std::string,Permission> permissions={
      {"geolocation",{CEF_PERMISSION_TYPE_GEOLOCATION,CEF_CONTENT_SETTING_TYPE_GEOLOCATION}},
      {"notifications",{CEF_PERMISSION_TYPE_NOTIFICATIONS,CEF_CONTENT_SETTING_TYPE_NOTIFICATIONS}},
      {"audioCapture",{CEF_PERMISSION_TYPE_MIC_STREAM,CEF_CONTENT_SETTING_TYPE_MEDIASTREAM_MIC}},
      {"videoCapture",{CEF_PERMISSION_TYPE_CAMERA_STREAM,CEF_CONTENT_SETTING_TYPE_MEDIASTREAM_CAMERA}},
      {"midiSysex",{CEF_PERMISSION_TYPE_MIDI_SYSEX,CEF_CONTENT_SETTING_TYPE_MIDI_SYSEX}},
      {"clipboardReadWrite",{CEF_PERMISSION_TYPE_CLIPBOARD,CEF_CONTENT_SETTING_TYPE_CLIPBOARD_READ_WRITE}},
      {"clipboardSanitizedWrite",{CEF_PERMISSION_TYPE_CLIPBOARD,CEF_CONTENT_SETTING_TYPE_CLIPBOARD_READ_WRITE}},
      {"sensors",{CEF_PERMISSION_TYPE_SENSORS,CEF_CONTENT_SETTING_TYPE_SENSORS}},
      {"idleDetection",{CEF_PERMISSION_TYPE_IDLE_DETECTION,CEF_CONTENT_SETTING_TYPE_IDLE_DETECTION}},
      {"windowManagement",{CEF_PERMISSION_TYPE_WINDOW_MANAGEMENT,CEF_CONTENT_SETTING_TYPE_WINDOW_MANAGEMENT}},
      {"localFonts",{CEF_PERMISSION_TYPE_LOCAL_FONTS,CEF_CONTENT_SETTING_TYPE_LOCAL_FONTS}},
      {"cameraPanTiltZoom",{CEF_PERMISSION_TYPE_CAMERA_PAN_TILT_ZOOM,CEF_CONTENT_SETTING_TYPE_CAMERA_PAN_TILT_ZOOM}},
      {"storageAccess",{CEF_PERMISSION_TYPE_STORAGE_ACCESS,CEF_CONTENT_SETTING_TYPE_STORAGE_ACCESS}},
#if CEF_API_ADDED(15000)
      {"localNetworkAccess",{CEF_PERMISSION_TYPE_LOCAL_NETWORK_ACCESS_DEPRECATED,CEF_CONTENT_SETTING_TYPE_LOCAL_NETWORK_ACCESS}},
#else
      {"localNetworkAccess",{CEF_PERMISSION_TYPE_LOCAL_NETWORK_ACCESS,CEF_CONTENT_SETTING_TYPE_LOCAL_NETWORK_ACCESS}},
#endif
      {"localNetwork",{CEF_PERMISSION_TYPE_LOCAL_NETWORK,CEF_CONTENT_SETTING_TYPE_LOCAL_NETWORK}},
      {"loopbackNetwork",{CEF_PERMISSION_TYPE_LOOPBACK_NETWORK,CEF_CONTENT_SETTING_TYPE_LOOPBACK_NETWORK}},
      // Wake locks have a content setting but no CEF permission-prompt bit.
      {"wakeLockScreen",{0,CEF_CONTENT_SETTING_TYPE_WAKE_LOCK_SCREEN}}
    };
    return permissions;
  }
  std::set<std::string> GrantedNames(const std::string& origin) {
    std::set<std::string> granted;auto found=root_->pending_permissions_.find(context_id_);
    if(found!=root_->pending_permissions_.end()) for(auto& policy:found->second) {
      const auto scope=policy->GetString("origin").ToString();if(!scope.empty() && scope!=origin) continue;
      auto list=policy->GetList("permissions");if(list) for(size_t i=0;i<list->GetSize();++i) granted.insert(list->GetString(i).ToString());
    }
    return granted;
  }
  uint32_t Granted(const std::string& origin) {
    uint32_t bits=0;for(const auto& name:GrantedNames(origin)) if(auto found=Permissions().find(name);found!=Permissions().end()) bits|=found->second.prompt;
    return bits;
  }
  static std::string Origin(const std::string& url) {
    CefURLParts parts;if(!CefParseURL(url,parts)) return "";
    const auto scheme=CefString(&parts.scheme).ToString(),host=CefString(&parts.host).ToString(),port=CefString(&parts.port).ToString();
    if(host.empty() || (scheme!="http" && scheme!="https")) return "";
    return scheme+"://"+host+((port.empty() || (scheme=="http" && port=="80") || (scheme=="https" && port=="443")) ? "" : ":"+port);
  }
  void ApplyPermissions(const std::string& origin) {
    if(!browser_) return;
    const auto granted=GrantedNames(origin);bool overridden=false;auto found=root_->pending_permissions_.find(context_id_);
    if(found!=root_->pending_permissions_.end()) for(auto& policy:found->second) if(policy->GetString("origin").empty() || policy->GetString("origin").ToString()==origin) overridden=true;
    // Multiple protocol names can share a content setting (clipboard). Merge
    // them before writing so an ungranted alias cannot revoke a granted one.
    std::map<cef_content_setting_types_t,bool> settings;
    for(const auto& [name,permission]:Permissions()) settings[permission.setting]|=granted.contains(name);
    for(const auto& [setting,allowed]:settings) browser_->GetHost()->GetRequestContext()->SetContentSetting(origin,"",setting,!overridden ? CEF_CONTENT_SETTING_VALUE_DEFAULT : allowed ? CEF_CONTENT_SETTING_VALUE_ALLOW : CEF_CONTENT_SETTING_VALUE_BLOCK);
  }
  void RefreshPermissions(const std::string& key) {
    for(auto& [target,source]:targets_) if(source->context_id_==key) {
      source->ApplyPermissions("");
      for(auto& origin:source->permission_origins_) source->ApplyPermissions(origin);
    }
  }
  bool OnBeforeBrowse(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,CefRefPtr<CefRequest> request,bool,bool) override {
    const auto origin=Origin(request->GetURL());if(!origin.empty()) {
      if(permission_origins_.size()<128 || permission_origins_.contains(origin)) permission_origins_.insert(origin);
      ApplyPermissions(origin);
    }
    return false;
  }
  bool OnShowPermissionPrompt(CefRefPtr<CefBrowser>,uint64_t,const CefString& origin,uint32_t requested,CefRefPtr<CefPermissionPromptCallback> callback) override {
    callback->Continue(requested && !(requested & ~Granted(origin.ToString())) ? CEF_PERMISSION_RESULT_ACCEPT : CEF_PERMISSION_RESULT_DENY);return true;
  }
  bool OnRequestMediaAccessPermission(CefRefPtr<CefBrowser>,CefRefPtr<CefFrame>,const CefString& origin,uint32_t requested,CefRefPtr<CefMediaAccessCallback> callback) override {
    const auto allowed=Granted(origin.ToString());uint32_t media=0;
    if(allowed&CEF_PERMISSION_TYPE_MIC_STREAM) media|=CEF_MEDIA_PERMISSION_DEVICE_AUDIO_CAPTURE;
    if(allowed&CEF_PERMISSION_TYPE_CAMERA_STREAM) media|=CEF_MEDIA_PERMISSION_DEVICE_VIDEO_CAPTURE;
    callback->Continue(requested&media);return true;
  }

  CefRefPtr<CefRenderHandler> GetRenderHandler() override { return this; }
  CefRefPtr<CefAudioHandler> GetAudioHandler() override { return this; }
  CefRefPtr<CefLoadHandler> GetLoadHandler() override { return this; }
  CefRefPtr<CefRequestHandler> GetRequestHandler() override { return this; }
  CefRefPtr<CefJSDialogHandler> GetJSDialogHandler() override { return this; }
  CefRefPtr<CefDownloadHandler> GetDownloadHandler() override { return this; }
  CefRefPtr<CefContextMenuHandler> GetContextMenuHandler() override { return this; }
  bool CanDownload(CefRefPtr<CefBrowser>, const CefString&, const CefString&) override {
    return download_ids_.size()<64 && (root_->auto_attach_ || root_->download_paths_.contains(context_id_));
  }
  bool OnBeforeDownload(CefRefPtr<CefBrowser>, CefRefPtr<CefDownloadItem> item,const CefString& name,CefRefPtr<CefBeforeDownloadCallback> callback) override {
    if(download_ids_.size()>=64) return true;  // Dropping the callback cancels.
    const auto guid="cef-"+target_id_+"-"+std::to_string(item->GetId());download_ids_[item->GetId()]=guid;
    auto params=CefDictionaryValue::Create();params->SetString("guid",guid);params->SetString("frameId",target_id_);params->SetString("url",item->GetURL());params->SetString("suggestedFilename",name);
    root_->Event("Browser.downloadWillBegin",params);
    auto found=root_->download_paths_.find(context_id_);
    // Even denied downloads must be observable. Returning handled without
    // retaining the callback cancels in CEF before a destination file is made.
    if(found!=root_->download_paths_.end()) callback->Continue(found->second+"/"+guid,false);
    return true;
  }
  void OnDownloadUpdated(CefRefPtr<CefBrowser>,CefRefPtr<CefDownloadItem> item,CefRefPtr<CefDownloadItemCallback> callback) override {
    const auto key=item->GetId();auto found=download_ids_.find(key);if(found==download_ids_.end()) return;
    const bool terminal=item->IsComplete() || item->IsCanceled();
    if(!terminal) {
      download_callbacks_[key]=callback;
      if(cancel_downloads_.erase(key)) callback->Cancel();
    }
    auto params=CefDictionaryValue::Create();params->SetString("guid",found->second);params->SetDouble("totalBytes",item->GetTotalBytes());params->SetDouble("receivedBytes",item->GetReceivedBytes());
    params->SetString("state",item->IsComplete() ? "completed" : item->IsCanceled() ? "canceled" : "inProgress");
    if(item->IsComplete()) params->SetString("filePath",item->GetFullPath());
    root_->Event("Browser.downloadProgress",params);
    if(terminal) {download_ids_.erase(key);download_callbacks_.erase(key);cancel_downloads_.erase(key);}
  }
  bool OnJSDialog(CefRefPtr<CefBrowser>, const CefString& origin, JSDialogType type, const CefString& text,
                  const CefString& prompt, CefRefPtr<CefJSDialogCallback> callback, bool& suppress) override {
    if(!root_->auto_attach_) {suppress=true;return false;}
    dialog_=callback;auto params=CefDictionaryValue::Create();params->SetString("url",origin);params->SetString("message",text);params->SetString("defaultPrompt",prompt);params->SetBool("hasBrowserHandler",true);
    params->SetString("type",type==JSDIALOGTYPE_ALERT ? "alert" : type==JSDIALOGTYPE_CONFIRM ? "confirm" : "prompt");
    PageEvent("Page.javascriptDialogOpening",params);return true;
  }
  bool OnBeforeUnloadDialog(CefRefPtr<CefBrowser>, const CefString&, bool,
                            CefRefPtr<CefJSDialogCallback> callback) override {
    if(root_->auto_attach_) {
      dialog_=callback;auto params=CefDictionaryValue::Create();params->SetString("type","beforeunload");params->SetString("message","");params->SetString("url",browser_->GetMainFrame()->GetURL());params->SetBool("hasBrowserHandler",true);
      PageEvent("Page.javascriptDialogOpening",params);
    } else callback->Continue(true,CefString());
    return true;
  }
  void OnBeforeContextMenu(CefRefPtr<CefBrowser>, CefRefPtr<CefFrame>,
                           CefRefPtr<CefContextMenuParams>, CefRefPtr<CefMenuModel> model) override {
    model->Clear();
  }
  void GetViewRect(CefRefPtr<CefBrowser>, CefRect& rect) override { rect = CefRect(0, 0, width_, height_); }
  bool GetScreenInfo(CefRefPtr<CefBrowser>, CefScreenInfo& info) override {
    info.device_scale_factor = static_cast<float>(scale_);
    info.rect = info.available_rect = CefRect(0, 0, width_, height_);
    return true;
  }
  void OnAfterCreated(CefRefPtr<CefBrowser> browser) override {
    browser_ = browser;
    ApplyPermissions("");
    browser_->GetHost()->WasHidden(false);
    std::erase_if(root_->pending_popups_,[this](const auto& entry){return entry.second.get()==this;});
    observer_ = browser->GetHost()->AddDevToolsMessageObserver(this);
    { std::lock_guard lock(audio_mutex_); target_id_ = "page-"+std::to_string(browser->GetIdentifier()); }
    root_->targets_[target_id_] = this;
    DispatchCDP(-1,"Target.getTargetInfo",CefDictionaryValue::Create(),"",true);
  }
  void OnBeforeClose(CefRefPtr<CefBrowser>) override {
    CefRefPtr<Source> keep_alive=this;
    stopped_ = true;
    if (reader_.joinable()) reader_.join();
#if SUITECUT_WITH_MEDIA
    for (auto& [key,cancelled] : job_cancels_) *cancelled=true;
    decltype(outputs_) outputs;
    { std::lock_guard lock(outputs_mutex_); outputs.swap(outputs_); }
    // A pending Pause may own an output and wait for the encoder. Stop before
    // joining jobs; never destroy/join an encoder while holding outputs_mutex_.
    for (auto& [key,output] : outputs) output->Stop();
    for (auto& worker : media_workers_) if (worker.first.joinable()) worker.first.join();
#endif
    for(const auto& [key,guid]:download_ids_) {
      if(auto found=download_callbacks_.find(key);found!=download_callbacks_.end()) found->second->Cancel();
      auto params=CefDictionaryValue::Create();params->SetString("guid",guid);params->SetString("state","canceled");
      params->SetDouble("totalBytes",0);params->SetDouble("receivedBytes",0);root_->Event("Browser.downloadProgress",params);
    }
    download_ids_.clear();download_callbacks_.clear();cancel_downloads_.clear();
    observer_ = nullptr;
    browser_ = nullptr;
    for(auto found=root_->worker_debuggers_.begin();found!=root_->worker_debuggers_.end();) {
      std::erase_if(found->second,[this](const auto& debugger){return debugger.source.get()==this;});
      if(found->second.empty())found=root_->worker_debuggers_.erase(found);else ++found;
    }
    for(auto found=root_->pending_popups_.begin();found!=root_->pending_popups_.end();) {
      if(found->first.first==this) {
        auto pending=found->second;
        std::erase_if(root_->children_,[&](const auto& child){return child==pending;});
        found=root_->pending_popups_.erase(found);
      } else ++found;
    }
    root_->targets_.erase(target_id_);
    if(auto opener=root_->targets_.find(opener_id_);opener!=root_->targets_.end() && opener->second->browser_ && !opener->second->closing_ && !opener->second->stopped_) {
      opener->second->browser_->GetHost()->WasHidden(false);
      opener->second->browser_->GetHost()->Invalidate(PET_VIEW);
    }
    for(auto found=root_->nested_targets_.begin();found!=root_->nested_targets_.end();) {
      if(found->second.source==this) {
        if(found->second.info->GetString("type")=="service_worker") {
          auto params=CefDictionaryValue::Create();params->SetString("sessionId",Session()+"::"+found->second.session);params->SetString("targetId",found->first);root_->Event("Target.detachedFromTarget",params);
        }
        auto destroyed=CefDictionaryValue::Create();destroyed->SetString("targetId",found->first);root_->DiscoveryEvent("Target.targetDestroyed",destroyed);
        found=root_->nested_targets_.erase(found);
      } else ++found;
    }
    {auto destroyed=CefDictionaryValue::Create();destroyed->SetString("targetId",target_id_);root_->DiscoveryEvent("Target.targetDestroyed",destroyed);}
    for(auto found=root_->sessions_.begin();found!=root_->sessions_.end();) {
      if(found->second==this) {const auto alias=root_->nested_aliases_.find(found->first);root_->DetachEvent(found->first+(alias==root_->nested_aliases_.end() ? "" : "::"+alias->second),root_->session_parents_[found->first]);root_->nested_aliases_.erase(found->first);root_->session_parents_.erase(found->first);found=root_->sessions_.erase(found);} else ++found;
    }
    view_.clear();view_.shrink_to_fit();popup_.clear();popup_.shrink_to_fit();
    if(this!=root_) std::erase_if(root_->children_,[this](const auto& child) {return child.get()==this;});
    if (root_->auto_attach_) {auto params=CefDictionaryValue::Create();params->SetString("sessionId",Session());params->SetString("targetId",target_id_);root_->Event("Target.detachedFromTarget",params);}
    if (root_->targets_.empty()) CefQuitMessageLoop();
  }
  bool OnBeforePopup(CefRefPtr<CefBrowser>, CefRefPtr<CefFrame>, int popup_id, const CefString&,
                     const CefString&, CefLifeSpanHandler::WindowOpenDisposition, bool, const CefPopupFeatures&,
                     CefWindowInfo& window, CefRefPtr<CefClient>& client, CefBrowserSettings& settings,
                     CefRefPtr<CefDictionaryValue>&, bool*) override {
    if(root_->children_.size()>=64) return true;
    window.SetAsWindowless(0);settings.windowless_frame_rate=browser_->GetHost()->GetWindowlessFrameRate();
    CefRefPtr<Source> child=new Source(writer_,width_,height_,scale_,i420_,true,root_,context_id_,target_id_);
    root_->children_.push_back(child);root_->pending_popups_[{this,popup_id}]=child;client=child;return false;
  }
  void OnBeforePopupAborted(CefRefPtr<CefBrowser>,int popup_id) override {
    const auto found=root_->pending_popups_.find({this,popup_id});
    if(found==root_->pending_popups_.end()) return;
    auto pending=found->second;root_->pending_popups_.erase(found);
    std::erase_if(root_->children_,[&](const auto& child){return child==pending;});
  }
  void OnPaint(CefRefPtr<CefBrowser>, PaintElementType type, const RectList&,
               const void* buffer, int width, int height) override {
    const double captured = Now();
    writer_.Captured(true, captured);
    if (!buffer || width <= 0 || height <= 0 || width > 3840 || height > 2160) return;
    const auto bytes = static_cast<const uint8_t*>(buffer);
    if (type == PET_VIEW) {
      frame_width_ = width;
      frame_height_ = height;
      view_.assign(bytes, bytes + static_cast<size_t>(width) * height * 4);
    } else {
      popup_width_ = width;
      popup_height_ = height;
      popup_.assign(bytes, bytes + static_cast<size_t>(width) * height * 4);
    }
    EmitFrame(captured);
  }
  void OnPopupShow(CefRefPtr<CefBrowser>, bool show) override {
    show_popup_ = show;
    if (!show) { popup_.clear(); EmitFrame(); }
  }
  void OnPopupSize(CefRefPtr<CefBrowser>, const CefRect& rect) override { popup_rect_ = rect; }
  bool GetAudioParameters(CefRefPtr<CefBrowser>, CefAudioParameters& params) override {
    audio_lifecycle_trace_.Open("audio-lifecycle-"+target_id_, "at_ms,event,frames_per_buffer,channels,sample_rate");
    audio_lifecycle_trace_.Row("%.6f,parameters,%d,%d,%d\n",Now(),params.frames_per_buffer,2,params.sample_rate);
    audio_requested_ = true;
#if SUITECUT_WITH_MEDIA
    {std::lock_guard lock(outputs_mutex_);for(auto& [key,output]:outputs_) output->AudioState(true);}
#endif
    params.channel_layout = CEF_CHANNEL_LAYOUT_STEREO;
    params.sample_rate = 48000;
    // Match OBS Browser Source and Chromium's 128-sample WebAudio quantum.
    // Buffer size is a capture block size, not end-to-end A/V latency.
    params.frames_per_buffer = 1024;
    return true;
  }
  void OnAudioStreamStarted(CefRefPtr<CefBrowser>, const CefAudioParameters& params, int channels) override {
    std::lock_guard lock(audio_mutex_);
    audio_clock_.Reset();
    audio_lifecycle_trace_.Open("audio-lifecycle-"+target_id_, "at_ms,event,frames_per_buffer,channels,sample_rate");
    audio_lifecycle_trace_.Row("%.6f,started,%d,%d,%d\n", Now(),params.frames_per_buffer,channels,params.sample_rate);
    audio_trace_.Open("cef-"+target_id_, "received_ms,pts_ms,mapped_ms,frames,rms,steady_ticks_ms,raw_mapped_ms", true);
    audio_valid_ = params.sample_rate == 48000 && channels == 2;
#if SUITECUT_WITH_MEDIA
    {std::lock_guard lock(outputs_mutex_);for(auto& [key,output]:outputs_) output->AudioState(audio_valid_);}
#endif
    if (!audio_valid_) writer_.Error("Unsupported native audio format");
  }
  void OnAudioStreamPacket(CefRefPtr<CefBrowser>, const float** data, int frames, int64_t pts) override {
    std::lock_guard lock(audio_mutex_);
    if (!audio_valid_ || !data || !data[0] || !data[1] || frames < 1 || frames > 4096) return;
    const auto tick = Clock::now();
    const double received = std::chrono::duration<double,std::milli>(tick-started).count();
    const double steady = std::chrono::duration<double,std::milli>(tick.time_since_epoch()).count();
    writer_.Captured(false, received, static_cast<double>(pts));
    ++audio_packets_;last_audio_packet_ms_ = received;
    const double raw_timestamp = audio_clock_.Map(static_cast<double>(pts), received, EpochNow(), steady);
    const double timestamp = audio_clock_.NormalizePacket(raw_timestamp,frames);
    std::vector<uint8_t> pcm(static_cast<size_t>(frames) * 4);
    for (int frame = 0; frame < frames; ++frame) {
      for (int channel = 0; channel < 2; ++channel) {
        const float value = std::isfinite(data[channel][frame]) ? data[channel][frame] : 0;
        const int sample = static_cast<int>(std::clamp(value, -1.0f, 1.0f) * 32767);
        const auto offset = static_cast<size_t>(frame * 2 + channel) * 2;
        pcm[offset] = static_cast<uint8_t>(sample & 255);
        pcm[offset + 1] = static_cast<uint8_t>((sample >> 8) & 255);
      }
    }
    auto samples = std::make_shared<std::vector<int16_t>>(static_cast<size_t>(frames)*2);
    std::memcpy(samples->data(), pcm.data(), pcm.size());
    if (audio_trace_.Enabled()) {
      double energy = 0;
      for (auto sample : *samples) energy += static_cast<double>(sample)*sample;
      audio_trace_.Row("%.6f,%lld,%.6f,%d,%.9f,%.6f,%.6f\n", received, static_cast<long long>(pts), timestamp, frames,
                       std::sqrt(energy/samples->size())/32768, steady, raw_timestamp);
      audio_trace_.PCM(samples->data(), samples->size()*sizeof(int16_t));
    }
#if SUITECUT_WITH_MEDIA
    { std::lock_guard lock(outputs_mutex_); for (auto& [key, output] : outputs_) output->Audio(samples, timestamp); }
#endif
    if (!emit_audio_) return;
    auto header = Header("audio");
    header->SetDouble("timestampMs", timestamp);
    header->SetInt("frames", frames);
    writer_.Send(header, std::move(pcm));
  }
  void OnAudioStreamStopped(CefRefPtr<CefBrowser>) override {
    std::lock_guard lock(audio_mutex_);
    audio_valid_ = false;audio_requested_ = false;
#if SUITECUT_WITH_MEDIA
    {std::lock_guard lock(outputs_mutex_);for(auto& [key,output]:outputs_) output->AudioState(false);}
#endif
    audio_lifecycle_trace_.Row("%.6f,stopped,0,0,0\n",Now());
  }
  void OnAudioStreamError(CefRefPtr<CefBrowser>, const CefString&) override {
    std::lock_guard audio_lock(audio_mutex_);
    audio_lifecycle_trace_.Row("%.6f,error,0,0,0\n",Now());
    audio_valid_=false;audio_requested_=false;if(closing_ || stopped_) return;
    // A closing/inactive page must not terminate other browser contexts. Active
    // outputs receive an explicit failure instead of silently filling with PCM.
#if SUITECUT_WITH_MEDIA
    std::lock_guard lock(outputs_mutex_);for(auto& [key,output]:outputs_) output->Fail("Native page audio capture failed");
#endif
    if(emit_audio_) writer_.Error("Native audio capture failed");
  }
  void OnLoadEnd(CefRefPtr<CefBrowser>, CefRefPtr<CefFrame> frame, int status) override {
    if (frame->IsMain() && !ready_) {
      // Handshake only after the initial blank document loads, so its load-end
      // cannot accidentally resolve the operator's first navigation command.
      ready_ = true;
      if (this != root_) {EmitFrame();return;}
      auto header = Header("ready");
      header->SetDouble("timestampMs", Now());
      header->SetString("cefVersion", CEF_VERSION);
      header->SetBool("nativeMedia", SUITECUT_WITH_MEDIA != 0);
      header->SetBool("audioSubscriptions", true);
      if (frame_subscriptions_) header->SetBool("frameSubscriptions", true);
      writer_.Send(header);
      reader_ = std::thread([this] { ReadCommands(); });
      EmitFrame();
      return;
    }
    if (frame->IsMain() && navigation_) {
      writer_.Reply(navigation_, status < 400, status < 400 ? "" : "HTTP navigation failed");
      navigation_ = 0;
    }
  }
  void OnLoadError(CefRefPtr<CefBrowser>, CefRefPtr<CefFrame> frame, ErrorCode code,
                   const CefString&, const CefString&) override {
    if (frame->IsMain() && navigation_ && code != ERR_ABORTED) {
      writer_.Reply(navigation_, false, "Native navigation failed");
      navigation_ = 0;
    }
  }
  void OnRenderProcessTerminated(CefRefPtr<CefBrowser>, TerminationStatus, int, const CefString&) override {
    writer_.Error("Browser renderer terminated");
  }
  bool OnDevToolsMessage(CefRefPtr<CefBrowser>, const void* data, size_t size) override {
    if(size>16777216) return false;
    auto value=CefParseJSON(static_cast<const char*>(data),size,JSON_PARSER_RFC);
    const bool opaque=!value;
    const std::string raw=opaque ? std::string(static_cast<const char*>(data),size) : std::string();
    if(opaque)value=CefParseJSON(suitecut::CDPMetadataJSON(raw),JSON_PARSER_RFC);
    auto message=value ? value->GetDictionary() : nullptr;
    if(!message) return false;
    if(message->HasKey("id")) {
      auto found=devtools_pending_.find(message->GetInt("id"));
      if(found==devtools_pending_.end()) return false;
      const auto pending=found->second;devtools_pending_.erase(found);
      TraceCDP(message->HasKey("error") ? "agent-error" : "agent-reply",pending.id,pending.session,pending.method,target_id_);
      if(pending.method=="Browser.getVersion") {
        if(auto result=message->GetDictionary("result")) result->SetBool("suitecutWindowless",true);
      }
      if(pending.method=="Page.getFrameTree") {
        auto result=message->GetDictionary("result");auto tree=result ? result->GetDictionary("frameTree") : nullptr;
        auto frame=tree ? tree->GetDictionary("frame") : nullptr;
        if(frame) {auto state=CefDictionaryValue::Create();state->SetString("frameId",frame->GetString("id"));state->SetString("targetId",frame->GetString("url").empty() ? "empty-url" : frame->GetString("url")=="about:blank" ? "blank-url" : frame->GetString("url")==":" ? "initial-url" : "other-url");TraceCDP("frame-tree",pending.id,pending.session,pending.method,target_id_,state);}
      }
      if(pending.id==-1) {
        auto result=message->GetDictionary("result");auto info=result ? result->GetDictionary("targetInfo") : nullptr;
        if(!info) {writer_.Error("CEF target discovery failed");return true;}
        root_->targets_.erase(target_id_);
        { std::lock_guard lock(audio_mutex_); target_id_=info->GetString("targetId").ToString(); }
        root_->targets_[target_id_]=this;
        {auto created=CefDictionaryValue::Create();created->SetDictionary("targetInfo",TargetInfo());root_->DiscoveryEvent("Target.targetCreated",created);}
        if(root_->auto_attach_) Attach();
        if(create_reply_) {auto response=CefDictionaryValue::Create();response->SetInt("id",create_reply_);auto value=CefDictionaryValue::Create();value->SetString("targetId",target_id_);response->SetDictionary("result",value);root_->CDPMessage(response);create_reply_=0;}
      } else if(pending.id==-2) { if(auto error=message->GetDictionary("error")) writer_.Error(("CEF context policy failed: "+error->GetString("message").ToString()).c_str());
      } else if(pending.id==-3) {
        if(auto error=message->GetDictionary("error")) {root_->pending_worker_targets_.erase(pending.target);std::fprintf(stderr,"CEF service worker attachment failed: %s\n",error->GetString("message").ToString().c_str());}
      } else if(pending.id==-4) { /* A disappearing target can invalidate best-effort debugger cleanup. */
      } else if(pending.native) {
        auto result=message->GetDictionary("result");auto error=message->GetDictionary("error");
        writer_.Reply(pending.id,!error,error ? error->GetString("message").ToString() : "",result ? Bytes(opaque ? suitecut::CDPRawField(raw,"result") : Json(result)) : std::vector<uint8_t>{});
      } else if(opaque) {
        root_->CDPRawMessage(RawCDPSession(suitecut::CDPReplaceField(raw,"id",std::to_string(pending.id)),pending.session));
      } else {message->SetInt("id",pending.id);message->SetString("sessionId",pending.session);root_->CDPMessage(message);}
    } else {
      const auto method=message->GetString("method").ToString();
      auto params=message->GetDictionary("params");
      // The CEF JS-dialog callback owns acceptance and emits this event once.
      // Also forwarding Chromium's notification races two Dialog objects and
      // makes the second dismissal fail after the first has closed the dialog.
      if(method=="Page.javascriptDialogOpening")return true;
      const auto agent=message->GetString("sessionId").ToString();
      if(params && auth_only_agents_.contains(agent)) {
        if(method=="Fetch.requestPaused" || method=="Fetch.authRequired") {
          auto continued=CefDictionaryValue::Create();continued->SetString("requestId",params->GetString("requestId"));
          if(method=="Fetch.authRequired") {auto answer=CefDictionaryValue::Create();answer->SetString("response","CancelAuth");continued->SetDictionary("authChallengeResponse",answer);}
          DeferCDP(-4,method=="Fetch.authRequired" ? "Fetch.continueWithAuth" : "Fetch.continueRequest",continued,agent.empty() ? Session() : Session()+"::"+agent,true);
          return true;
        }
      }
      if(params && method=="Target.attachedToTarget") {
        auto info=params->GetDictionary("targetInfo");
        if(info) {
          const auto target=info->GetString("targetId").ToString(),nested=params->GetString("sessionId").ToString();
          const bool worker=info->GetString("type")=="service_worker";
          auto pending_worker=root_->pending_worker_targets_.find(target);
          if(worker && this!=root_) {
            // Use the long-lived engine agent for worker commands so closing
            // the page that first discovered a worker cannot orphan it.
            if(!root_->nested_targets_.contains(target) && pending_worker==root_->pending_worker_targets_.end()) {
              if(root_->nested_targets_.size()+root_->pending_worker_targets_.size()>=256) {writer_.Error("CEF nested target limit exceeded");return true;}
              auto normalized=info->Copy(false);normalized->SetString("browserContextId",context_id_);root_->pending_worker_targets_[target]=normalized;
              auto attach=CefDictionaryValue::Create();attach->SetString("targetId",target);attach->SetBool("flatten",true);root_->DeferCDP(-3,"Target.attachToTarget",attach,"",true);
            }
            if(!root_->nested_targets_.contains(target) || root_->worker_debuggers_.contains(target)) {
              auto& debuggers=root_->worker_debuggers_[target];
              if(debuggers.size()>=64) {writer_.Error("CEF worker debugger limit exceeded");return true;}
              debuggers.push_back({this,nested});
            } else {auto detach=CefDictionaryValue::Create();detach->SetString("sessionId",nested);DeferCDP(-4,"Target.detachFromTarget",detach,"",true);}
            // Keep the original auto-attach pause until Playwright has enabled
            // Network/Fetch on the stable engine session. Resuming here loses
            // the main worker-script request before routing can observe it.
            return true;
          }
          auto existing=root_->nested_targets_.find(target);
          if(worker && existing!=root_->nested_targets_.end()) {
            // Multiple page agents can discover the same service worker. Keep
            // one browser-level identity and release the redundant debugger.
            if(existing->second.source!=this || existing->second.session!=nested) {
              DeferCDP(-4,"Runtime.runIfWaitingForDebugger",CefDictionaryValue::Create(),Session()+"::"+nested,true);
              auto detach=CefDictionaryValue::Create();detach->SetString("sessionId",nested);DeferCDP(-4,"Target.detachFromTarget",detach,"",true);
            }
            return true;
          }
          if(root_->nested_targets_.size()>=256) {writer_.Error("CEF nested target limit exceeded");return true;}
          auto normalized=info->Copy(false);normalized->SetString("browserContextId",pending_worker==root_->pending_worker_targets_.end() ? context_id_ : pending_worker->second->GetString("browserContextId").ToString());
          if(pending_worker!=root_->pending_worker_targets_.end())root_->pending_worker_targets_.erase(pending_worker);
          const auto context=normalized->GetString("browserContextId").ToString();
          if(worker && context!="default" && !root_->contexts_.contains(context)) {
            auto detach=CefDictionaryValue::Create();detach->SetString("sessionId",nested);DeferCDP(-4,"Target.detachFromTarget",detach,"",true);return true;
          }
          root_->nested_targets_[target]={this,nested,normalized};
          {auto created=CefDictionaryValue::Create();created->SetDictionary("targetInfo",normalized->Copy(false));root_->DiscoveryEvent("Target.targetCreated",created);}
          if(worker && root_->auto_attach_) {
            // Playwright expects service workers on the browser session. CEF
            // reports them underneath a page; forwarding there makes Playwright
            // discard the target before its worker API can observe it.
            auto promoted=params->Copy(false);promoted->SetString("sessionId",Session()+"::"+nested);promoted->SetDictionary("targetInfo",normalized->Copy(false));
            root_->Event("Target.attachedToTarget",promoted);return true;
          }
        }
      }
      if(params && method=="Target.detachedFromTarget") {
        auth_only_agents_.erase(params->GetString("sessionId").ToString());client_fetch_agents_.erase(params->GetString("sessionId").ToString());
        auto found=root_->nested_targets_.find(params->GetString("targetId").ToString());
        if(found!=root_->nested_targets_.end() && found->second.source==this && found->second.session==params->GetString("sessionId").ToString()) {
          const bool worker=found->second.info->GetString("type")=="service_worker";root_->nested_targets_.erase(found);
          const auto nested=params->GetString("sessionId").ToString();
          for(auto alias=root_->sessions_.begin();alias!=root_->sessions_.end();) {
            auto linked=root_->nested_aliases_.find(alias->first);
            if(alias->second==this && linked!=root_->nested_aliases_.end() && linked->second==nested) {
              root_->DetachEvent(alias->first+"::"+nested,root_->session_parents_[alias->first]);root_->session_parents_.erase(alias->first);root_->nested_aliases_.erase(linked);alias=root_->sessions_.erase(alias);
            } else ++alias;
          }
          {auto destroyed=CefDictionaryValue::Create();destroyed->SetString("targetId",params->GetString("targetId"));root_->DiscoveryEvent("Target.targetDestroyed",destroyed);}
          if(worker) {auto detached=params->Copy(false);detached->SetString("sessionId",Session()+"::"+params->GetString("sessionId").ToString());root_->Event("Target.detachedFromTarget",detached);return true;}
        }
      }
      // CEF exposes one page agent. Explicit Playwright CDP sessions attach to
      // that same agent; their commands already receive replies on their alias.
      // Deliver agent notifications on those aliases too, including nested
      // worker session IDs. Otherwise raw sessions can never observe console,
      // network, or tracing completion events despite successful commands.
      std::vector<std::string> recipients{Session()};
      for(const auto& [alias,source]:root_->sessions_) if(source==this) recipients.push_back(alias);
      for(const auto& recipient:recipients) {
        auto event=message->Copy(false);
        if(event->HasKey("sessionId")) event->SetString("sessionId",recipient+"::"+event->GetString("sessionId").ToString());
        else event->SetString("sessionId",recipient);
        auto params=event->GetDictionary("params");
        const auto method=event->GetString("method").ToString();
        if(params && (method=="Target.attachedToTarget" || method=="Target.detachedFromTarget"))
          params->SetString("sessionId",recipient+"::"+params->GetString("sessionId").ToString());
        if(opaque)root_->CDPRawMessage(RawCDPSession(raw,event->GetString("sessionId").ToString()));
        else root_->CDPMessage(event);
      }
    }
    return true;
  }
 private:
  void CloseTargets(const std::string& context="") {
    std::vector<std::string> pending_debuggers;
    for(const auto& [target,debuggers]:worker_debuggers_)if(context.empty() || (!debuggers.empty() && debuggers.front().source->context_id_==context))pending_debuggers.push_back(target);
    for(const auto& target:pending_debuggers)ReleaseWorkerDebuggers(target);
    std::vector<std::pair<CefRefPtr<Source>,std::string>> workers;
    for(const auto& [target,nested]:nested_targets_) if(nested.info->GetString("type")=="service_worker" && (context.empty() || nested.info->GetString("browserContextId")==context)) {
      workers.emplace_back(nested.source,nested.session);
    }
    for(const auto& [source,session]:workers) {auto detach=CefDictionaryValue::Create();detach->SetString("sessionId",session);source->DispatchCDP(-2,"Target.detachFromTarget",detach,"",true);}
    std::vector<CefRefPtr<CefBrowser>> browsers;
    for(auto& [key,source]:targets_) if(context.empty() || source->context_id_==context) {source->closing_=true;browsers.push_back(source->browser_);}
    for(auto& browser:browsers) browser->GetHost()->CloseBrowser(true);
  }
  struct PendingDevTools {int id;bool native;std::string session;std::string target;std::string method;};
  void ReleaseWorkerDebuggers(const std::string& target) {
    auto found=worker_debuggers_.find(target);if(found==worker_debuggers_.end())return;
    auto debuggers=std::move(found->second);worker_debuggers_.erase(found);
    for(const auto& debugger:debuggers) {auto params=CefDictionaryValue::Create();params->SetString("sessionId",debugger.session);debugger.source->DeferCDP(-4,"Target.detachFromTarget",params,"",true);}
  }
  void ScreencastPulse() {
    if(screencast_pulse_pending_ || !screencast_active_ || !browser_ || closing_ || stopped_)return;
    screencast_pulse_pending_=true;
    CefPostDelayedTask(TID_UI,new Task([self=CefRefPtr<Source>(this)] {
      self->screencast_pulse_pending_=false;
      if(!self->screencast_active_ || !self->browser_ || self->closing_ || self->stopped_)return;
      // Static windowless surfaces still need compositor work for DevTools
      // screencast frames and requestAnimationFrame to make progress.
      self->browser_->GetHost()->WasHidden(false);
      self->browser_->GetHost()->Invalidate(PET_VIEW);
      self->ScreencastPulse();
    }),33);
  }
  std::string Session() const {return "session-"+target_id_;}
  Dict TargetInfo() {
    auto result=CefDictionaryValue::Create();result->SetString("targetId",target_id_);result->SetString("type","page");
    result->SetString("title","");result->SetString("url",browser_->GetMainFrame()->GetURL());
    result->SetString("browserContextId",context_id_);result->SetBool("attached",true);
    if(!opener_id_.empty()) result->SetString("openerId",opener_id_);
    return result;
  }
  void CDPMessage(Dict message) {TraceCDP("client-event",message->GetInt("id"),message->GetString("sessionId"),message->GetString("method"),target_id_,message->GetDictionary("params"));auto header=Header("event");header->SetString("topic","cdp");writer_.Send(header,Bytes(Json(message)));}
  void PageEvent(const char* method,Dict params) {
    std::vector<std::string> recipients{Session()};
    for(const auto& [alias,source]:root_->sessions_)if(source==this && !root_->nested_aliases_.contains(alias))recipients.push_back(alias);
    for(const auto& session:recipients) {auto event=CefDictionaryValue::Create();event->SetString("method",method);event->SetString("sessionId",session);event->SetDictionary("params",params->Copy(false));root_->CDPMessage(event);}
  }
  void CDPRawMessage(const std::string& message) {auto header=Header("event");header->SetString("topic","cdp");writer_.Send(header,Bytes(message));}
  static std::string RawCDPSession(std::string message,const std::string& session) {
    auto encoded=CefDictionaryValue::Create();encoded->SetString("sessionId",session);
    return suitecut::CDPReplaceField(std::move(message),"sessionId",suitecut::CDPRawField(Json(encoded),"sessionId"));
  }
  void Event(const char* method,Dict params) {auto message=CefDictionaryValue::Create();message->SetString("method",method);message->SetDictionary("params",params);CDPMessage(message);}
  void DiscoveryEvent(const char* method,Dict params) {
    for(const auto& session:discover_sessions_) {auto event=CefDictionaryValue::Create();event->SetString("method",method);if(!session.empty())event->SetString("sessionId",session);event->SetDictionary("params",params->Copy(false));CDPMessage(event);}
  }
  void DetachEvent(const std::string& key,const std::string& parent) {
    auto message=CefDictionaryValue::Create();message->SetString("method","Target.detachedFromTarget");if(!parent.empty())message->SetString("sessionId",parent);
    auto params=CefDictionaryValue::Create();params->SetString("sessionId",key);message->SetDictionary("params",params);CDPMessage(message);
  }
  void Attach() {auto params=CefDictionaryValue::Create();params->SetString("sessionId",Session());params->SetDictionary("targetInfo",TargetInfo());params->SetBool("waitingForDebugger",false);root_->Event("Target.attachedToTarget",params);}
  void CookieCommand(int id,const std::string& session,const std::string& method,Dict params,CefRefPtr<CefRequestContext> context) {
    auto reply=[self=CefRefPtr<Source>(this),id,session](Dict result,std::string error="") {
      auto message=CefDictionaryValue::Create();message->SetInt("id",id);if(!session.empty())message->SetString("sessionId",session);
      if(error.empty()) message->SetDictionary("result",result ? result : CefDictionaryValue::Create());
      else {auto detail=CefDictionaryValue::Create();detail->SetInt("code",-32000);detail->SetString("message",error);message->SetDictionary("error",detail);}self->CDPMessage(message);
    };
    auto manager=context->GetCookieManager(nullptr);
    if(!manager) {reply(nullptr,"CEF cookie manager unavailable");return;}
    if(method=="Storage.getCookies") {
      manager->VisitAllCookies(new CookieVisitor([reply](CefRefPtr<CefListValue> cookies) {auto result=CefDictionaryValue::Create();result->SetList("cookies",cookies);reply(result);}));return;
    }
    if(method=="Storage.clearCookies") {if(!manager->DeleteCookies("","",new CookieDeleteCallback([reply] {reply(nullptr);})))reply(nullptr,"CEF could not clear cookies");return;}
    auto cookies=params->GetList("cookies");if(!cookies || cookies->GetSize()>500) {reply(nullptr,"Invalid cookie batch");return;}
    struct Batch {size_t pending;bool success=true;};auto batch=std::make_shared<Batch>();batch->pending=cookies->GetSize();
    if(!batch->pending) {reply(nullptr);return;}
    auto complete=[batch,reply](bool success) {batch->success &= success;if(--batch->pending==0)reply(nullptr,batch->success ? "" : "CEF rejected a cookie");};
    for(size_t i=0;i<cookies->GetSize();++i) {
      auto item=cookies->GetDictionary(i);if(!item || item->HasKey("partitionKey")) {complete(false);continue;}
      CefCookie cookie;CefString(&cookie.name)=item->GetString("name");CefString(&cookie.value)=item->GetString("value");CefString(&cookie.path)=item->HasKey("path") ? item->GetString("path") : "/";
      // CDP distinguishes host cookies (plain domain / URL) from domain
      // cookies (leading dot). CEF treats any nonempty domain as a domain
      // cookie, so pass an empty CEF domain for host-only cookies.
      const auto domain=item->GetString("domain").ToString();
      if(domain.starts_with("."))CefString(&cookie.domain)=domain;
      cookie.secure=item->GetBool("secure");cookie.httponly=item->GetBool("httpOnly");cookie.priority=CEF_COOKIE_PRIORITY_MEDIUM;
      const auto site=item->GetString("sameSite").ToString();cookie.same_site=site=="Strict" ? CEF_COOKIE_SAME_SITE_STRICT_MODE : site=="None" ? CEF_COOKIE_SAME_SITE_NO_RESTRICTION : CEF_COOKIE_SAME_SITE_LAX_MODE;
      // Chromium ignores insecure SameSite=None cookies while the CDP batch
      // succeeds. Do not create that cookie or fail unrelated valid entries.
      if(site=="None" && !cookie.secure) {complete(true);continue;}
      if(item->HasKey("expires") && Number(item,"expires")>=0) {cookie.has_expires=true;cookie.expires.val=static_cast<int64_t>(Number(item,"expires")*1000000)+11644473600000000LL;}
      auto url=item->GetString("url").ToString();if(url.empty()) {auto domain=item->GetString("domain").ToString();if(domain.starts_with("."))domain.erase(0,1);url=std::string(cookie.secure ? "https://" : "http://")+domain+item->GetString("path").ToString();}
      if(!manager->SetCookie(url,cookie,new CookieSetCallback(complete))) complete(false);
    }
  }
  void CDP(Dict message,const std::string& raw_params="") {
    if(!message || message->GetInt("id")<1 || message->GetString("method").empty()) {writer_.Error("Invalid CEF protocol command");return;}
    const int id=message->GetInt("id");const auto method=message->GetString("method").ToString();
    auto params=message->GetDictionary("params");if(!params) params=CefDictionaryValue::Create();
    const auto session=message->GetString("sessionId").ToString();
    auto reply=[&](Dict result,std::string error="") {
      auto response=CefDictionaryValue::Create();response->SetInt("id",id);if(!session.empty()) response->SetString("sessionId",session);
      if(error.empty()) response->SetDictionary("result",result ? result : CefDictionaryValue::Create());
      else {auto detail=CefDictionaryValue::Create();detail->SetInt("code",-32000);detail->SetString("message",error);response->SetDictionary("error",detail);}
      CDPMessage(response);
    };
    auto result=CefDictionaryValue::Create();
    if(method=="Browser.getWindowForTarget" || method=="Browser.getWindowBounds" || method=="Browser.setWindowBounds") {
      Source* selected=nullptr;
      if(method=="Browser.getWindowForTarget") {
        const auto target=params->GetString("targetId").ToString();
        if(!target.empty()) {auto found=targets_.find(target);if(found!=targets_.end()) selected=found->second;}
        else if(sessions_.contains(session)) selected=sessions_[session];
        else if(session.empty() || browser_sessions_.contains(session)) selected=this;
        else for(auto& [key,source]:targets_) if(source->Session()==session) {selected=source;break;}
      } else for(auto& [key,source]:targets_) if(source->browser_ && source->browser_->GetIdentifier()==params->GetInt("windowId")) {selected=source;break;}
      if(!selected || !selected->browser_ || selected->closing_) {reply(nullptr,"Unknown CEF window target");return;}
      if(method=="Browser.setWindowBounds") {
        const auto bounds=params->GetDictionary("bounds");
        if(!bounds) {reply(nullptr,"Window bounds are required");return;}
        const auto state=bounds->GetString("windowState").ToString();
        if((!state.empty() && state!="normal") ||
           (bounds->HasKey("left") && bounds->GetInt("left")!=0) ||
           (bounds->HasKey("top") && bounds->GetInt("top")!=0)) {
          reply(nullptr,"Windowless CEF supports resizing at origin (0,0) with normal window state");return;
        }
        const int width=bounds->HasKey("width") ? bounds->GetInt("width") : selected->width_;
        const int height=bounds->HasKey("height") ? bounds->GetInt("height") : selected->height_;
        // Ordinary browser surfaces may be odd-sized. Encoded I420 input is
        // padded in EmitFrame; fixed raw I420 subscribers retain their contract.
        if(width<1 || height<1 || width>3840/selected->scale_ || height>2160/selected->scale_ ||
           (selected->i420_ && selected->emit_frames_ && (width%2 || height%2))) {reply(nullptr,"Window bounds exceed native capture dimensions");return;}
        if(selected->emit_frames_ && (width!=selected->width_ || height!=selected->height_)) {
          reply(nullptr,"Cannot resize a source with fixed-size raw frame subscriptions");return;
        }
        selected->width_=width;selected->height_=height;selected->browser_->GetHost()->WasResized();
        reply(result);return;
      }
      auto bounds=CefDictionaryValue::Create();bounds->SetInt("left",0);bounds->SetInt("top",0);
      bounds->SetInt("width",selected->width_);bounds->SetInt("height",selected->height_);bounds->SetString("windowState","normal");
      result->SetDictionary("bounds",bounds);
      if(method=="Browser.getWindowForTarget") result->SetInt("windowId",selected->browser_->GetIdentifier());
      reply(result);return;
    }
    if(session.empty() || browser_sessions_.contains(session)) {
      if(method=="Browser.getVersion") {
        // Forward Chromium's real UA/version. The explicit capability keeps
        // clients from inferring native window decorations from UA text.
        DispatchCDP(id,method,params,session,false);return;
      }
      if(method=="Target.setAutoAttach") {auto_attach_=params->GetBool("autoAttach");reply(result);if(auto_attach_) for(auto& [key,source]:targets_) source->Attach();return;}
      if(method=="Target.setDiscoverTargets") {
        if(params->HasKey("filter")) {reply(nullptr,"CEF target discovery filters are not implemented");return;}
        discover_sessions_.erase(session);const bool discover=params->GetBool("discover");if(discover)discover_sessions_.insert(session);reply(result);
        if(discover) {
          auto emit=[this,&session](Dict info) {auto event=CefDictionaryValue::Create();event->SetString("method","Target.targetCreated");if(!session.empty())event->SetString("sessionId",session);auto params=CefDictionaryValue::Create();params->SetDictionary("targetInfo",info);event->SetDictionary("params",params);CDPMessage(event);};
          for(const auto& [target,source]:targets_) {emit(source->TargetInfo());}
          for(const auto& [target,nested]:nested_targets_) {emit(nested.info->Copy(false));}
        }
        return;
      }
      if(method=="Target.getTargetInfo") {const auto key=params->GetString("targetId").ToString();if(auto nested=nested_targets_.find(key);nested!=nested_targets_.end())result->SetDictionary("targetInfo",nested->second.info->Copy(false));else {auto found=targets_.find(key);auto* source=found==targets_.end() ? this : found->second;result->SetDictionary("targetInfo",source->TargetInfo());}reply(result);return;}
      if(method=="Target.getTargets") {auto list=CefListValue::Create();for(auto& [key,source]:targets_) list->SetDictionary(list->GetSize(),source->TargetInfo());for(auto& [key,nested]:nested_targets_)list->SetDictionary(list->GetSize(),nested.info->Copy(false));result->SetList("targetInfos",list);reply(result);return;}
      if(method=="Target.attachToBrowserTarget") {if(browser_sessions_.size()>=256){reply(nullptr,"CEF session limit exceeded");return;}const auto key="browser-"+std::to_string(++context_index_);browser_sessions_.insert(key);result->SetString("sessionId",key);reply(result);return;}
      if(method=="Target.attachToTarget") {
        if(sessions_.size()>=256) {reply(nullptr,"CEF session limit exceeded");return;}
        if(auto found=nested_targets_.find(params->GetString("targetId").ToString());found!=nested_targets_.end()) {
          const auto alias="extra-"+std::to_string(++context_index_);sessions_[alias]=found->second.source;session_parents_[alias]=session;nested_aliases_[alias]=found->second.session;result->SetString("sessionId",alias+"::"+found->second.session);reply(result);return;
        }
        auto found=targets_.find(params->GetString("targetId").ToString());if(found==targets_.end()){reply(nullptr,"Unknown CEF target");return;}
        const auto alias="extra-"+std::to_string(++context_index_);sessions_[alias]=found->second;session_parents_[alias]=session;result->SetString("sessionId",alias);reply(result);return;
      }
      if(method=="Target.detachFromTarget") {
        const auto key=params->GetString("sessionId").ToString();const auto separator=key.find("::");const auto main=key.substr(0,separator);
        if(separator!=std::string::npos && !sessions_.contains(main)) {
          for(const auto& [target,nested]:nested_targets_) if(key==nested.source->Session()+"::"+nested.session) {
            auto detach=params->Copy(false);detach->SetString("sessionId",nested.session);nested.source->DispatchCDP(id,method,detach,session,false);return;
          }
        }
        sessions_.erase(main);nested_aliases_.erase(main);browser_sessions_.erase(key);discover_sessions_.erase(key);session_parents_.erase(main);reply(result);DetachEvent(key,session);return;
      }
      if(method=="Target.createBrowserContext") {
        if(contexts_.size()>=64) {reply(nullptr,"CEF context limit exceeded");return;}
        const auto key="context-"+std::to_string(++context_index_);CefRequestContextSettings settings;
        // Context language must exist before a popup's first renderer script.
        // This bridge extension avoids changing sibling pages through CDP's
        // otherwise target-scoped Emulation.setUserAgentOverride command.
        if(params->HasKey("suitecutLocale")) {
          const auto locale=params->GetString("suitecutLocale").ToString();
          if(locale.empty() || locale.size()>128 || !std::all_of(locale.begin(),locale.end(),[](unsigned char c){return (c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9') || c=='-';})) {reply(nullptr,"Invalid SuiteCut context locale");return;}
          CefString(&settings.accept_language_list)=locale;
        }
        contexts_[key]=CefRequestContext::CreateContext(settings,nullptr);
        if(params->HasKey("proxyServer")) {auto proxy=CefDictionaryValue::Create();proxy->SetString("mode","fixed_servers");proxy->SetString("server",params->GetString("proxyServer"));proxy->SetString("bypass_list",params->GetString("proxyBypassList"));auto value=CefValue::Create();value->SetDictionary(proxy);CefString error;if(!contexts_[key]->SetPreference("proxy",value,error)) {contexts_.erase(key);reply(nullptr,"CEF proxy configuration failed: "+error.ToString());return;}}
        std::string rtc_error; if(!ConfigureWebRTC(contexts_[key],rtc_error)) {contexts_.erase(key);reply(nullptr,rtc_error);return;}
        result->SetString("browserContextId",key);reply(result);return;
      }
      if(method=="Target.createTarget") {
        if(children_.size()>=64) {reply(nullptr,"CEF target limit exceeded");return;}
        const auto key=params->GetString("browserContextId").ToString();auto context=contexts_.find(key);
        if(!key.empty() && context==contexts_.end()) {reply(nullptr,"Unknown browser context");return;}
        CefWindowInfo window;window.SetAsWindowless(0);CefBrowserSettings settings;settings.windowless_frame_rate=browser_->GetHost()->GetWindowlessFrameRate();
        CefRefPtr<Source> child=new Source(writer_,width_,height_,scale_,i420_,true,this,key.empty() ? "default" : key);
        child->create_reply_=id;children_.push_back(child);
        auto created=CefBrowserHost::CreateBrowserSync(window,child,params->GetString("url"),settings,nullptr,context==contexts_.end() ? browser_->GetHost()->GetRequestContext() : context->second);
        if(!created) {child->create_reply_=0;std::erase_if(children_,[&](const auto& item){return item==child;});reply(nullptr,"CEF could not create target");return;}return;
      }
      if(method=="Target.disposeBrowserContext") {const auto key=params->GetString("browserContextId").ToString();CloseTargets(key);contexts_.erase(key);std::erase_if(pending_worker_targets_,[&key](const auto& item){return item.second->GetString("browserContextId")==key;});pending_permissions_.erase(key);download_paths_.erase(key);reply(result);return;}
      if(method=="Target.closeTarget") {auto found=targets_.find(params->GetString("targetId").ToString());const bool exists=found!=targets_.end();if(exists) {found->second->closing_=true;found->second->browser_->GetHost()->CloseBrowser(true);}result->SetBool("success",exists);reply(result);return;}
      if(method=="Browser.setDownloadBehavior") {
        const auto key=params->GetString("browserContextId").ToString();const auto behavior=params->GetString("behavior").ToString();
        if(behavior=="deny") download_paths_.erase(key.empty() ? "default" : key);
        else if(behavior=="allowAndName" && params->GetString("downloadPath").ToString().starts_with("/")) download_paths_[key.empty() ? "default" : key]=params->GetString("downloadPath").ToString();
        else {reply(nullptr,"Unsupported CEF download behavior");return;}reply(nullptr);return;
      }
      if(method=="Browser.cancelDownload") {
        const auto guid=params->GetString("guid").ToString();
        const auto supplied=params->GetString("browserContextId").ToString();const auto context=supplied.empty() ? "default" : supplied;
        for(const auto& [target,source]:targets_) if(source->context_id_==context) {
          for(const auto& [key,value]:source->download_ids_) if(value==guid) {
            if(auto found=source->download_callbacks_.find(key);found!=source->download_callbacks_.end()) found->second->Cancel();
            else source->cancel_downloads_.insert(key);
          }
        }
        // Chromium treats cancel after completion as a successful no-op.
        reply(result);return;
      }
      if(method=="Browser.close") {reply(nullptr);CloseTargets();return;}
      if(method=="Storage.getCookies" || method=="Storage.setCookies" || method=="Storage.clearCookies") {
        const auto key=params->GetString("browserContextId").ToString();auto found=contexts_.find(key);auto context=key.empty() || key=="default" ? browser_->GetHost()->GetRequestContext() : found==contexts_.end() ? nullptr : found->second;
        if(!context) {reply(nullptr,"Unknown browser context");return;}CookieCommand(id,session,method,params,context);return;
      }
      if(method=="Browser.grantPermissions" || method=="Browser.resetPermissions") {
        const auto supplied=params->GetString("browserContextId").ToString();const auto key=supplied.empty() ? "default" : supplied;
        if(key!="default" && !contexts_.contains(key)) {reply(nullptr,"Unknown browser context");return;}
        if(method=="Browser.resetPermissions") {pending_permissions_.erase(key);RefreshPermissions(key);reply(result);return;}
        auto permissions=params->GetList("permissions");if(!permissions) {reply(nullptr,"Permission list is required");return;}
        for(size_t i=0;i<permissions->GetSize();++i) if(!Permissions().contains(permissions->GetString(i).ToString())) {reply(nullptr,"Unsupported native permission: "+permissions->GetString(i).ToString());return;}
        if(pending_permissions_[key].size()>=128) {reply(nullptr,"Context permission limit exceeded");return;}
        const auto origin=params->GetString("origin").ToString();auto& policies=pending_permissions_[key];
        policies.erase(std::remove_if(policies.begin(),policies.end(),[&](const auto& policy){return policy->GetString("origin").ToString()==origin;}),policies.end());
        policies.push_back(params->Copy(false));RefreshPermissions(key);reply(result);return;
      }
      if(method.starts_with("Storage.")) {reply(nullptr,"Unsupported native storage command: "+method);return;}
      reply(nullptr,"Unsupported CEF browser command: "+method);return;
    }
    const auto separator=session.find("::");const auto main=session.substr(0,separator);
    Source* selected=sessions_.contains(main) ? sessions_[main] : nullptr;for(auto& [key,source]:targets_) if(source->Session()==main) {selected=source;break;}
    if(!selected) {reply(nullptr,"Unknown CEF session");return;}
    if(separator==std::string::npos && (method=="Page.startScreencast" || method=="Page.stopScreencast")) {
      selected->screencast_active_=method=="Page.startScreencast";
      selected->ScreencastPulse();
    }
    if(method=="Page.handleJavaScriptDialog" && selected->dialog_) {selected->dialog_->Continue(params->GetBool("accept"),params->GetString("promptText"));selected->dialog_=nullptr;reply(result);return;}
    if(method=="Target.getTargetInfo" && separator==std::string::npos) {result->SetDictionary("targetInfo",selected->TargetInfo());reply(result);return;}
    if(method=="Target.detachFromTarget" && params->HasKey("sessionId")) {
      params=params->Copy(false);const auto nested=params->GetString("sessionId").ToString();const auto split=nested.find("::");if(split!=std::string::npos)params->SetString("sessionId",nested.substr(split+2));
    }
    bool rewritten=false;
    if(method=="Fetch.continueWithAuth") {
      const auto challenge=params->GetDictionary("authChallengeResponse");
      if(challenge && challenge->GetString("response")=="Default") {
        // A windowless browser has no native credential prompt. Explicitly
        // cancel the challenge so the real HTTP 401 response remains available
        // instead of delegating to CEF's unavailable prompt implementation.
        params=params->Copy(false);params->GetDictionary("authChallengeResponse")->SetString("response","CancelAuth");rewritten=true;
      }
    }
    if(method=="Emulation.setDeviceMetricsOverride" && separator==std::string::npos) {const int width=params->GetInt("width"),height=params->GetInt("height");if(width>0 && height>0 && width<=3840 && height<=2160) {selected->width_=width;selected->height_=height;selected->browser_->GetHost()->WasResized();}}
    auto auth_only=[] {
      auto options=CefDictionaryValue::Create();options->SetBool("handleAuthRequests",true);
      auto pattern=CefDictionaryValue::Create();pattern->SetString("urlPattern","*");pattern->SetString("requestStage","Request");auto patterns=CefListValue::Create();patterns->SetDictionary(0,pattern);options->SetList("patterns",patterns);return options;
    };
    const auto agent=separator==std::string::npos ? std::string() : session.substr(separator+2);
    // Never retain arbitrary client-supplied nested session names. Registered
    // targets are bounded, and their detach event releases these domain flags.
    const bool known_agent=agent.empty() || std::any_of(nested_targets_.begin(),nested_targets_.end(),[&](const auto& item) {return item.second.source==selected && item.second.session==agent;});
    if(method=="Fetch.enable" && known_agent) {selected->auth_only_agents_.erase(agent);selected->client_fetch_agents_.insert(agent);}
    if(method=="Fetch.disable" && auto_attach_ && known_agent) {
      // Disable request interception while keeping credential challenges under
      // CDP control. CEF cannot present a windowless native auth prompt.
      selected->client_fetch_agents_.erase(agent);selected->auth_only_agents_.insert(agent);
      selected->DispatchCDP(id,"Fetch.enable",auth_only(),session,false);
    } else {
      selected->DispatchCDP(id,method,params,session,false,rewritten ? "" : raw_params);
      if(method=="Network.enable" && auto_attach_ && known_agent && !selected->client_fetch_agents_.contains(agent)) {
        selected->auth_only_agents_.insert(agent);selected->DispatchCDP(-4,"Fetch.enable",auth_only(),session,true);
      }
    }
    if(method=="Runtime.runIfWaitingForDebugger" && separator!=std::string::npos) {
      const auto nested_session=session.substr(separator+2);
      for(const auto& [target,nested]:nested_targets_)if(nested.source==selected && nested.session==nested_session) {ReleaseWorkerDebuggers(target);break;}
    }
  }
  void DispatchCDP(int id,const std::string& method,Dict params,const std::string& session,bool native,const std::string& raw_params="") {
    if(devtools_pending_.size()>=256) {if(native) writer_.Reply(id,false,"CEF command capacity exceeded");else {auto response=CefDictionaryValue::Create();response->SetInt("id",id);if(!session.empty())response->SetString("sessionId",session);auto error=CefDictionaryValue::Create();error->SetInt("code",-32000);error->SetString("message","CEF command capacity exceeded");response->SetDictionary("error",error);root_->CDPMessage(response);}return;}
    do {devtools_index_=suitecut::NextCommandID(devtools_index_);} while(devtools_pending_.contains(devtools_index_));
    const int internal=devtools_index_;devtools_pending_[internal]={id,native,session,params->GetString("targetId").ToString(),method};
    TraceCDP("agent-send",id,session,method,target_id_,params);
    auto message=CefDictionaryValue::Create();message->SetInt("id",internal);message->SetString("method",method);message->SetDictionary("params",params);
    const auto separator=session.find("::");if(separator!=std::string::npos) message->SetString("sessionId",session.substr(separator+2));
    auto data=Json(message);if(!raw_params.empty())data=suitecut::CDPReplaceField(std::move(data),"params",raw_params);
    if(!browser_->GetHost()->SendDevToolsMessage(data.data(),data.size())) {devtools_pending_.erase(internal);writer_.Reply(id,false,"CEF DevTools dispatch failed");}
  }
  void DeferCDP(int id,const std::string& method,Dict params,const std::string& session,bool native) {
    // Never issue another DevTools command inside CEF's observer callback.
    // Retain the client through the posted task and tolerate shutdown racing it.
    CefPostTask(TID_UI,new Task([self=CefRefPtr<Source>(this),id,method,params=params->Copy(false),session,native] {
      if(id==-3 && !self->pending_worker_targets_.contains(params->GetString("targetId").ToString()))return;
      if(self->browser_ && !self->closing_ && !self->stopped_)self->DispatchCDP(id,method,params,session,native);
    }));
  }
  static std::vector<uint8_t> Bytes(const std::string& text) {return {text.begin(),text.end()};}
#if SUITECUT_WITH_MEDIA
  static std::string StatusJson(const suitecut::MediaStatus& status) {
    auto dict=CefDictionaryValue::Create();
    dict->SetBool("ready",status.ready);dict->SetBool("stopped",status.stopped);dict->SetBool("paused",status.paused);
    dict->SetDouble("videoFrames",status.video_frames);dict->SetDouble("audioSamples",status.audio_frames);
    dict->SetDouble("repeatedFrames",status.repeated_frames);dict->SetDouble("droppedAudioSamples",status.audio_dropped);
    dict->SetDouble("missingAudioSamples",status.audio_missing);dict->SetDouble("lateAudioSamples",status.audio_late);
    dict->SetDouble("activeMissingAudioSamples",status.active_audio_missing);
    dict->SetDouble("queuedVideoBytes",status.queued_video_bytes);dict->SetDouble("queuedAudioBytes",status.queued_audio_bytes);
    dict->SetDouble("startedMs",status.started_ms);dict->SetDouble("durationMs",status.duration_ms);
    dict->SetDouble("maximumEncodeMs",status.maximum_encode_ms);dict->SetString("error",status.error);
    dict->SetDouble("bufferedDelayMs",status.buffered_delay_ms);
    dict->SetDouble("audioSyncWaits",status.audio_sync_waits);dict->SetDouble("videoSyncWaits",status.video_sync_waits);
    dict->SetDouble("maximumTrackLeadMs",status.maximum_track_lead_ms);
    dict->SetInt("videoEncoderThreads",status.video_encoder_threads);
    dict->SetString("videoEncoderPreset",status.video_encoder_preset);
    return Json(dict);
  }
#endif
  void EmitFrame(double timestamp = Now()) {
    if (!ready_ || view_.empty()) return;
    bool has_outputs = false;
#if SUITECUT_WITH_MEDIA
    { std::lock_guard lock(outputs_mutex_); has_outputs = !outputs_.empty(); }
#endif
    if (!emit_frames_ && !has_outputs) return;
    std::vector<uint8_t> output;
    const uint8_t* pixels = view_.data();
    if (show_popup_ && !popup_.empty()) {
      output = view_;
      suitecut::CompositeBGRA(output,frame_width_,frame_height_,popup_,popup_width_,popup_height_,
                             popup_rect_.x*scale_,popup_rect_.y*scale_);
      pixels = output.data();
    }
    auto header = Header("frame");
    header->SetString("pixelFormat", i420_ ? "i420" : "bgra");
    if (i420_ || has_outputs) {
      const int yuv_width=(frame_width_+1)&~1,yuv_height=(frame_height_+1)&~1;
      std::vector<uint8_t> padded;
      if(yuv_width!=frame_width_ || yuv_height!=frame_height_) {
        padded.resize(static_cast<size_t>(yuv_width)*yuv_height*4);
        for(int y=0;y<yuv_height;++y) {auto* row=padded.data()+static_cast<size_t>(y)*yuv_width*4;const auto* from=pixels+static_cast<size_t>(std::min(y,frame_height_-1))*frame_width_*4;std::memcpy(row,from,static_cast<size_t>(frame_width_)*4);if(yuv_width!=frame_width_) std::memcpy(row+frame_width_*4,from+(frame_width_-1)*4,4);}
        pixels=padded.data();
      }
      const size_t y_size = static_cast<size_t>(yuv_width) * yuv_height;
      std::vector<uint8_t> planes(y_size * 3 / 2);
      // libyuv's ARGB name describes registers; in little-endian memory its
      // input is BGRA, matching CEF. Use explicit limited-range BT.709.
      if (libyuv::ARGBToI420Matrix(pixels, yuv_width * 4,
          planes.data(), yuv_width, planes.data() + y_size, yuv_width / 2,
          planes.data() + y_size * 5 / 4, yuv_width / 2,
          &libyuv::kArgbH709Constants, yuv_width, yuv_height) != 0) {
        writer_.Error("Native pixel conversion failed");
        return;
      }
#if SUITECUT_WITH_MEDIA
      if (has_outputs) {
        auto shared = std::make_shared<const std::vector<uint8_t>>(std::move(planes));
        std::lock_guard lock(outputs_mutex_);
        for (auto& [key, encoder] : outputs_) encoder->Video(shared, yuv_width, yuv_height, timestamp);
        if (i420_ && emit_frames_ && (yuv_width!=frame_width_ || yuv_height!=frame_height_)) {writer_.Error("Raw I420 subscriptions require an even viewport");return;}
        if (i420_ && emit_frames_) output = *shared;
      } else
#endif
      output = std::move(planes);
    } else if (output.empty()) output = view_;
    if (!emit_frames_) return;
    if (!i420_ && output.empty()) output = view_;
    header->SetDouble("timestampMs", timestamp);
    header->SetInt("width", frame_width_);
    header->SetInt("height", frame_height_);
    writer_.Send(header, std::move(output));
  }
  void Command(const std::string& line) {
    if (!browser_) return;
#if SUITECUT_WITH_MEDIA
    std::erase_if(job_cancels_,[](const auto& entry) {return entry.second.use_count()==1;});
    for(auto found=media_workers_.begin();found!=media_workers_.end();) {
      if(found->second->load()) {found->first.join();found=media_workers_.erase(found);} else ++found;
    }
#endif
    auto value = CefParseJSON(line, JSON_PARSER_RFC);
    const bool opaque=!value;
    if(opaque)value=CefParseJSON(suitecut::CDPMetadataJSON(line),JSON_PARSER_RFC);
    auto message = value ? value->GetDictionary() : nullptr;
    if (!message || message->GetInt("version") != 1 || message->GetInt("id") < 1) {
      writer_.Error("Invalid native command");
      return;
    }
    const int id = message->GetInt("id");
    const auto command = message->GetString("command").ToString();
    if (command == "cdp") {writer_.Reply(id,true);root_->CDP(message->GetDictionary("message"),opaque ? suitecut::CDPRawField(suitecut::CDPRawField(line,"message"),"params") : "");return;}
#if !SUITECUT_WITH_MEDIA
    if (command.starts_with("media.")) {
      writer_.Reply(id,false,"Native media is unavailable in the CEF-only build");return;
    }
#endif
#if SUITECUT_WITH_MEDIA
    if(this==root_ && (command=="media.status" || command=="media.pause" || command=="media.stop" || command=="media.select")) {
      Source* owner=nullptr;const int output_id=message->GetInt("outputId");
      for(auto& [key,source]:targets_) {std::lock_guard lock(source->outputs_mutex_);if(source->outputs_.contains(output_id)) {owner=source;break;}}
      if(!owner) {writer_.Reply(id,false,"Unknown native output");return;}
      if(command=="media.select") {
        auto selected=targets_.find(message->GetString("targetId").ToString());if(selected==targets_.end()) {writer_.Reply(id,false,"Unknown CEF target");return;}
        if(owner!=selected->second) {
          std::scoped_lock lock(owner->outputs_mutex_,selected->second->outputs_mutex_);
          if(owner->output_jobs_.contains(output_id)) {writer_.Reply(id,false,"Native output lifecycle operation is pending");return;}
          selected->second->outputs_[output_id]=owner->outputs_[output_id];owner->outputs_.erase(output_id);selected->second->outputs_[output_id]->AudioState(selected->second->audio_requested_);
        }
        selected->second->EmitFrame();writer_.Reply(id,true);return;
      }
      if(owner!=this) {message->Remove("targetId");owner->Command(Json(message));return;}
      message->Remove("targetId");
    }
#endif
    if(message->HasKey("targetId") && this==root_) {
      auto found=targets_.find(message->GetString("targetId").ToString());
      if(found==targets_.end()) {writer_.Reply(id,false,"Unknown CEF target");return;}
      if(found->second!=this) {message->Remove("targetId");found->second->Command(Json(message));return;}
    }
#if SUITECUT_WITH_MEDIA
    if(command=="media.cancel") {auto found=job_cancels_.find(message->GetString("jobKey").ToString());if(found!=job_cancels_.end()) *found->second=true;writer_.Reply(id,true);return;}
    if(command=="media.render") {
      if(media_workers_.size()>=8) {writer_.Reply(id,false,"Native file job limit exceeded");return;}
      const auto job_key=message->GetString("jobKey").ToString();auto cancelled=std::make_shared<std::atomic<bool>>(false);job_cancels_[job_key]=cancelled;
      auto done=std::make_shared<std::atomic<bool>>(false);
      media_workers_.emplace_back(std::thread([this,message,id,done,cancelled] {
        try {
          suitecut::RenderOptions config;auto inputs=message->GetList("inputs");if(!inputs) throw std::runtime_error("Native render inputs are required");
          for(size_t i=0;i<inputs->GetSize();++i) config.inputs.push_back(inputs->GetString(i).ToString());
          config.destination=message->GetString("destination").ToString();config.graph=message->GetString("graph").ToString();
          config.fps=message->GetInt("fps");config.duration_ms=Number(message,"durationMs");config.audio=message->GetBool("audio");
          config.container=message->GetString("container").ToString();config.video_codec=message->GetString("videoCodec").ToString();
          config.audio_codec=message->GetString("audioCodec").ToString();config.pixel_format=message->GetString("pixelFormat").ToString();
          config.full_range=message->GetBool("fullRange");config.audio_bitrate=message->GetInt("audioBitrate");
          auto encoder_options=message->GetDictionary("videoOptions");if(encoder_options) {CefDictionaryValue::KeyList keys;encoder_options->GetKeys(keys);for(const auto& key:keys) config.video_options[key.ToString()]=encoder_options->GetString(key).ToString();}
          const auto status=suitecut::RenderMedia(config,[this,cancelled] {return stopped_.load() || cancelled->load();});auto result=CefDictionaryValue::Create();result->SetDouble("videoFrames",status.video_frames);result->SetDouble("audioSamples",status.audio_samples);writer_.Reply(id,true,"",Bytes(Json(result)));
        } catch(const std::exception& error) {writer_.Reply(id,false,error.what());}
        *done=true;
      }),done);return;
    }
    if(command=="media.encoder") {
      auto value=CefDictionaryValue::Create();value->SetBool("available",suitecut::EncoderAvailable(message->GetString("name").ToString()));
      writer_.Reply(id,true,"",Bytes(Json(value)));return;
    }
    if(command=="media.encoders") {
      auto value=CefListValue::Create();
      for(const auto& encoder:suitecut::ListMediaEncoders()) {
        auto item=CefDictionaryValue::Create();item->SetString("name",encoder.name);item->SetString("kind",encoder.kind);item->SetString("codec",encoder.codec);
        item->SetBool("linked",encoder.linked);item->SetBool("hardware",encoder.hardware);item->SetBool("lossless",encoder.lossless);
        auto containers=CefListValue::Create();for(const auto& name:encoder.containers) containers->SetString(containers->GetSize(),name);
        item->SetList("containers",containers);value->SetDictionary(value->GetSize(),item);
      }
      auto result=CefDictionaryValue::Create();result->SetList("encoders",value);
      writer_.Reply(id,true,"",Bytes(Json(result)));return;
    }
    if(command=="media.probe" || command=="media.cut") {
      if(media_workers_.size()>=8) {writer_.Reply(id,false,"Native file job limit exceeded");return;}
      const auto input=message->GetString("input").ToString();auto done=std::make_shared<std::atomic<bool>>(false);
      media_workers_.emplace_back(std::thread([this,message,input,id,command,done] {
        try {
          if(command=="media.probe") {auto probe=suitecut::ProbeMedia(input);auto value=CefDictionaryValue::Create();value->SetDouble("durationMs",probe.duration_ms);value->SetInt("width",probe.width);value->SetInt("height",probe.height);value->SetBool("audio",probe.audio);value->SetString("formatName",probe.format);auto streams=CefListValue::Create();
            for(const auto& stream:probe.streams) {auto item=CefDictionaryValue::Create();item->SetString("kind",stream.kind);item->SetString("codec",stream.codec);item->SetDouble("durationMs",stream.duration_ms);
              if(stream.kind=="audio") {item->SetInt("channels",stream.channels);item->SetInt("sampleRate",stream.sample_rate);}
              else {item->SetInt("width",stream.width);item->SetInt("height",stream.height);item->SetDouble("frameRate",stream.frame_rate);item->SetBool("hasVariableFrameRate",stream.variable);item->SetString("timeBase",stream.time_base);
                if(!stream.pixel_format.empty()) item->SetString("pixelFormat",stream.pixel_format);
                if(!stream.color_range.empty()) item->SetString("colorRange",stream.color_range);
                if(!stream.color_space.empty()) item->SetString("colorSpace",stream.color_space);
                if(!stream.color_transfer.empty()) item->SetString("colorTransfer",stream.color_transfer);
                if(!stream.color_primaries.empty()) item->SetString("colorPrimaries",stream.color_primaries);
              }streams->SetDictionary(streams->GetSize(),item);
            }value->SetList("streams",streams);writer_.Reply(id,true,"",Bytes(Json(value)));}
          else {suitecut::MediaOptions config;config.destination=message->GetString("destination").ToString();config.width=message->GetInt("width");config.height=message->GetInt("height");config.fps=message->GetInt("fps");config.video_codec="libvpx-vp9";
            auto status=suitecut::CutVideo(input,config,Number(message,"startMs"),Number(message,"durationMs"));writer_.Reply(id,true,"",Bytes(StatusJson(status)));}
        } catch(const std::exception& error) {writer_.Reply(id,false,error.what());}
        *done=true;
      }),done);return;
    }
#endif
    if (command == "audio.status") {
      auto value=CefDictionaryValue::Create();value->SetBool("requested",audio_requested_);value->SetBool("active",audio_valid_);
      value->SetDouble("packets",audio_packets_);value->SetDouble("lastPacketMs",last_audio_packet_ms_);
      writer_.Reply(id,true,"",Bytes(Json(value)));return;
    }
#if SUITECUT_WITH_MEDIA
    if (command == "media.start") {
      try {
        suitecut::MediaOptions config;
        config.destination = message->GetString("destination").ToString();
        config.width = message->GetInt("width"); config.height = message->GetInt("height");
        config.fps = message->GetInt("fps"); config.streaming = message->GetBool("streaming");
        if (message->HasKey("audio") && message->GetType("audio")!=VTYPE_BOOL)
          throw std::runtime_error("Native audio enabled must be a boolean");
        config.audio = !message->HasKey("audio") || message->GetBool("audio");
        if (message->HasKey("audioStartup")) {
          throw std::runtime_error("Audio startup policies were removed; realtime audio readiness is mandatory");
        }
        if (message->HasKey("audioStartupTimeoutMs")) {
          if(message->GetType("audioStartupTimeoutMs")!=VTYPE_INT) throw std::runtime_error("Native audio startup timeout must be an integer");
          config.audio_startup_timeout_ms = message->GetInt("audioStartupTimeoutMs");
        }
        if (message->HasKey("videoCodec")) config.video_codec = message->GetString("videoCodec").ToString();
        if (message->HasKey("audioCodec")) config.audio_codec = message->GetString("audioCodec").ToString();
        if (message->HasKey("container")) {
          if(message->GetType("container")!=VTYPE_STRING) throw std::runtime_error("Native container must be a string");
          config.container = message->GetString("container").ToString();
        }
        if (message->HasKey("crf")) {
          if(message->GetType("crf")!=VTYPE_INT && message->GetType("crf")!=VTYPE_DOUBLE)
            throw std::runtime_error("Native CRF must be a number");
          config.crf = Number(message,"crf");
        }
        if (message->HasKey("bitrateKbps")) config.bitrate_kbps = message->GetInt("bitrateKbps");
        if (message->HasKey("audioBitrateKbps")) config.audio_bitrate_kbps = message->GetInt("audioBitrateKbps");
        {std::lock_guard lock(outputs_mutex_);if(outputs_.size()>=8) throw std::runtime_error("Native output limit exceeded");}
        auto output = std::make_shared<suitecut::MediaOutput>(config, Now);
        output->AudioState(audio_requested_);
        { std::lock_guard lock(outputs_mutex_);
          outputs_.emplace(id, output); }
        auto started = CefDictionaryValue::Create();
        started->SetInt("outputId",id);started->SetBool("audioReadinessRequired",config.audio);started->SetString("audioReadiness","engine");
        writer_.Reply(id,true,"",Bytes(Json(started)));
        EmitFrame();
      } catch (const std::exception& error) { writer_.Reply(id, false, error.what()); }
    } else if (command == "media.status" || command == "media.pause" || command == "media.stop") {
      std::shared_ptr<suitecut::MediaOutput> output;
      { std::lock_guard lock(outputs_mutex_); auto found=outputs_.find(message->GetInt("outputId"));
        if (found!=outputs_.end()) output=found->second; }
      if (!output) {writer_.Reply(id,false,"Unknown native output");return;}
      if (command == "media.stop" || command == "media.pause") {
        if(media_workers_.size()>=8) {writer_.Reply(id,false,"Native file job limit exceeded");return;}
        auto done=std::make_shared<std::atomic<bool>>(false);
        const int output_id=message->GetInt("outputId");
        const bool stop=command=="media.stop",paused=message->GetBool("paused");
        {std::lock_guard lock(outputs_mutex_);++output_jobs_[output_id];}
        media_workers_.emplace_back(std::thread([self=CefRefPtr<Source>(this), output, output_id, id, done, stop, paused] {
          try {
          suitecut::MediaStatus status;
          if(stop) {
            status=output->Stop();
            std::lock_guard lock(self->outputs_mutex_);self->outputs_.erase(output_id);
          } else {
            output->Pause(paused);status=output->Status();
            if (!paused) CefPostTask(TID_UI,new Task([self] {if(!self->stopped_) self->EmitFrame();}));
          }
          self->writer_.Reply(id,status.error.empty(),status.error,Bytes(StatusJson(status)));
          } catch(const std::exception& error) {self->writer_.Reply(id,false,error.what());}
          {std::lock_guard lock(self->outputs_mutex_);if(--self->output_jobs_[output_id]==0) self->output_jobs_.erase(output_id);}
          *done=true;
        }),done);
      } else writer_.Reply(id,true,"",Bytes(StatusJson(output->Status())));
    } else
#endif
    if (command == "audio") {
      if (message->GetType("enabled") != VTYPE_BOOL) {writer_.Reply(id,false,"Audio subscription requires a boolean");return;}
      emit_audio_=message->GetBool("enabled");writer_.Reply(id,true);
    } else if (command == "frames") {
      if (message->GetType("enabled") != VTYPE_BOOL) {
        writer_.Reply(id, false, "Frame subscription requires a boolean"); return;
      }
      emit_frames_ = message->GetBool("enabled");
      writer_.Reply(id, true);
      if (emit_frames_) EmitFrame();
    } else if (command == "navigate") {
      const auto url = message->GetString("url").ToString();
      if (!url.starts_with("https://") && !url.starts_with("http://")) {
        writer_.Reply(id, false, "Navigation requires HTTP(S)"); return;
      }
      if (navigation_) { writer_.Reply(id, false, "Navigation already in progress"); return; }
      navigation_ = id;
      browser_->GetMainFrame()->LoadURL(url);
    } else if (command == "devtools") {
      DispatchCDP(id,message->GetString("method").ToString(),message->GetDictionary("params"),"",true,opaque ? suitecut::CDPRawField(line,"params") : "");
    } else writer_.Reply(id, false, "Unknown native command");
  }
  void ReadCommands() {
    std::string pending;
    char buffer[4096];
    while (!stopped_) {
      pollfd fd{STDIN_FILENO, POLLIN, 0};
      if (poll(&fd, 1, 100) <= 0) continue;
      const auto size = read(STDIN_FILENO, buffer, sizeof(buffer));
      if (size < 0 && errno == EINTR) continue;
      if (size <= 0) break;
      for (ssize_t i = 0; i < size; ++i) {
        if (buffer[i] == '\n') {
          // Bound both the input bytes and outstanding UI work under a flooding client.
          if (queued_commands_.fetch_add(1) >= 64 || queued_command_bytes_.fetch_add(pending.size()) + pending.size() > 16777216) {stopped_=true;break;}
          CefPostTask(TID_UI, new Task([self = CefRefPtr<Source>(this), line = std::move(pending)] {
            self->queued_commands_--;self->queued_command_bytes_-=line.size();
            self->Command(line);
          }));
          pending.clear();
        } else {
          pending += buffer[i];
          if (pending.size() >= 4194304) { stopped_ = true; break; }
        }
      }
    }
    CefPostTask(TID_UI, new Task([self = CefRefPtr<Source>(this)] {
      self->CloseTargets();
    }));
  }
  CefRefPtr<CefJSDialogCallback> dialog_;
  std::map<std::string,std::string> download_paths_;
  std::map<std::string,std::vector<Dict>> pending_permissions_;
  std::map<uint32_t,std::string> download_ids_;
  std::map<uint32_t,CefRefPtr<CefDownloadItemCallback>> download_callbacks_;
  std::set<uint32_t> cancel_downloads_;
  // Child CEF callbacks may outlive the opener's OnBeforeClose. Hold the
  // protocol owner until this client's last callback/reference is released.
  // children_/pending_popups_ remove their child references on close/abort.
  CefRefPtr<Source> root_owner_;
  Source* root_;
  std::string context_id_,opener_id_,target_id_;
  std::set<std::string> permission_origins_;
  std::map<std::string,Source*> targets_, sessions_;
  struct NestedTarget {Source* source;std::string session;Dict info;};
  std::map<std::string,NestedTarget> nested_targets_;
  std::map<std::string,Dict> pending_worker_targets_;
  struct WorkerDebugger {CefRefPtr<Source> source;std::string session;};
  std::map<std::string,std::vector<WorkerDebugger>> worker_debuggers_;
  std::map<std::string,std::string> nested_aliases_;
  std::map<std::string,std::string> session_parents_;
  std::set<std::string> browser_sessions_;
  std::set<std::string> discover_sessions_;
  std::set<std::string> auth_only_agents_,client_fetch_agents_;
  std::map<std::string,CefRefPtr<CefRequestContext>> contexts_;
  std::vector<CefRefPtr<Source>> children_;
  std::map<std::pair<Source*,int>,CefRefPtr<Source>> pending_popups_;
  std::map<int,PendingDevTools> devtools_pending_;
  int devtools_index_=0,create_reply_=0;
  uint64_t context_index_=0;
  bool auto_attach_=false;
#if SUITECUT_WITH_MEDIA
  std::map<std::string,std::shared_ptr<std::atomic<bool>>> job_cancels_;
  std::mutex outputs_mutex_;
  std::map<int, std::shared_ptr<suitecut::MediaOutput>> outputs_;
  std::map<int,size_t> output_jobs_;
  std::vector<std::pair<std::thread,std::shared_ptr<std::atomic<bool>>>> media_workers_;
#endif
  std::atomic<bool> emit_audio_{true};
  Writer& writer_;
  int width_, height_;
  double scale_;
  bool i420_;
  bool frame_subscriptions_;
  int frame_width_ = 0, frame_height_ = 0, popup_width_ = 0, popup_height_ = 0, navigation_ = 0;
  bool show_popup_ = false, ready_ = false, emit_frames_ = true;
  bool screencast_active_=false,screencast_pulse_pending_=false;
  CefRect popup_rect_;
  std::vector<uint8_t> view_, popup_;
  std::atomic<bool> stopped_{false}, audio_valid_{false}, closing_{false};
  std::atomic<bool> audio_requested_{false};
  std::atomic<uint64_t> audio_packets_{0};
  std::atomic<double> last_audio_packet_ms_{-1};
  SuiteCutAudioClock audio_clock_;
  std::mutex audio_mutex_;
  SuiteCutAudioTrace audio_trace_, audio_lifecycle_trace_;
  std::atomic<int> queued_commands_{0};
  std::atomic<size_t> queued_command_bytes_{0};
  std::thread reader_;
  CefRefPtr<CefBrowser> browser_;
  CefRefPtr<CefRegistration> observer_;
  IMPLEMENT_REFCOUNTING(Source);
};

class App : public CefApp, public CefBrowserProcessHandler {
 public:
  explicit App(Writer& writer) : writer_(writer) {}
  CefRefPtr<CefBrowserProcessHandler> GetBrowserProcessHandler() override { return this; }
  void OnBeforeCommandLineProcessing(const CefString&, CefRefPtr<CefCommandLine> command) override {
    // Each source uses a fresh profile. Chrome's first-run UI can block
    // initialization before the windowless browser is created on Linux.
    command->AppendSwitch("no-first-run");
    command->AppendSwitchWithValue("autoplay-policy", "no-user-gesture-required");
    command->AppendSwitch("disable-background-timer-throttling");
    command->AppendSwitch("disable-renderer-backgrounding");
    // Match Playwright's automation semantics: origin-based storage-state
    // restoration and navigation interception must not be bypassed by the
    // browser's storage partitioning or back/forward cache.
    command->AppendSwitch("disable-back-forward-cache");
    command->AppendSwitch("disable-backgrounding-occluded-windows");
    command->AppendSwitch("allow-pre-commit-input");
    command->AppendSwitchWithValue("disable-features", "ThirdPartyStoragePartitioning,PaintHolding,BlockOriginHeaderModificationOnRedirect,BoundaryEventDispatchTracksNodeRemoval,AvoidUnnecessaryBeforeUnloadCheckSync");
    if (command->GetSwitchValue("suitecut-graphics") == "swiftshader") {
      // Explicit operator opt-in: modern Chromium blocks automatic software
      // WebGL fallback for security reasons. Keep normal graphics defaults intact.
      command->AppendSwitchWithValue("use-gl", "angle");
      command->AppendSwitchWithValue("use-angle", "swiftshader");
      command->AppendSwitch("enable-unsafe-swiftshader");
    }
  }
  void OnContextInitialized() override {
    auto command = CefCommandLine::GetGlobalCommandLine();
    const int width = std::atoi(command->GetSwitchValue("suitecut-width").ToString().c_str());
    const int height = std::atoi(command->GetSwitchValue("suitecut-height").ToString().c_str());
    const int fps = std::atoi(command->GetSwitchValue("suitecut-fps").ToString().c_str());
    const double scale = std::atof(command->GetSwitchValue("suitecut-scale").ToString().c_str());
    const auto pixel_format = command->GetSwitchValue("suitecut-pixel-format").ToString();
    if (width < 2 || height < 2 || (scale != 1 && scale != 2) ||
        width * scale > 3840 || height * scale > 2160 || (fps != 30 && fps != 60)) {
      CefQuitMessageLoop(); return;
    }
    if ((pixel_format != "bgra" && pixel_format != "i420") ||
        (pixel_format == "i420" && ((width % 2) || (height % 2)))) {
      CefQuitMessageLoop(); return;
    }
    std::string rtc_error;
    if (!ConfigureWebRTC(CefRequestContext::GetGlobalContext(), rtc_error)) {
      writer_.Error(rtc_error.c_str()); CefQuitMessageLoop(); return;
    }
    CefWindowInfo window;
    window.SetAsWindowless(0);
    CefBrowserSettings settings;
    settings.windowless_frame_rate = fps;
    settings.background_color = CefColorSetARGB(255, 0, 0, 0);
    source_ = new Source(writer_, width, height, scale, pixel_format == "i420",
                         command->HasSwitch("suitecut-frame-subscriptions"));
    if (!CefBrowserHost::CreateBrowser(window, source_, "about:blank", settings, nullptr, nullptr)) CefQuitMessageLoop();
  }
  void ReleaseSource() { source_ = nullptr; }
 private:
  Writer& writer_;
  CefRefPtr<Source> source_;
  IMPLEMENT_REFCOUNTING(App);
};
}  // namespace

int RunSuiteCutBrowser(int argc, char** argv) {
  signal(SIGPIPE, SIG_IGN);
  CefMainArgs args(argc, argv);
  // CEF and subprocess libraries may print diagnostics to stdout. Reserve a
  // close-on-exec descriptor for media, then redirect ordinary stdout to stderr.
  const int output = dup(STDOUT_FILENO);
  if (output < 0 || fcntl(output, F_SETFD, FD_CLOEXEC) < 0 || dup2(STDERR_FILENO, STDOUT_FILENO) < 0) return 1;
  auto command = CefCommandLine::CreateCommandLine();
  command->InitFromArgv(argc, argv);
  Writer writer(output, command->HasSwitch("suitecut-diagnostics"));
  const auto graphics = command->GetSwitchValue("suitecut-graphics").ToString();
  if (!graphics.empty() && graphics != "auto" && graphics != "swiftshader") return 1;
  const auto rtc_policy = command->GetSwitchValue("suitecut-webrtc-policy").ToString();
  if (!rtc_policy.empty() && rtc_policy != "default" && rtc_policy != "disable-non-proxied-udp") return 1;
  CefRefPtr<App> app = new App(writer);
  CefSettings settings;
  const auto profile = command->GetSwitchValue("suitecut-profile").ToString();
  if (profile.empty() || profile.front() != '/') return 1;
  CefString(&settings.root_cache_path) = profile;
  settings.windowless_rendering_enabled = true;
  settings.log_severity = LOGSEVERITY_DISABLE;
  settings.persist_session_cookies = false;
  // An isolated temporary root; the cache path stays empty (incognito). No
  // remote debugging listener, certificate bypass, or sandbox bypass.
  if (!CefInitialize(args, settings, app, nullptr)) return 1;
  CefRunMessageLoop();
  app->ReleaseSource();
  app = nullptr;
  CefShutdown();
  writer.Stop();
  return 0;
}
