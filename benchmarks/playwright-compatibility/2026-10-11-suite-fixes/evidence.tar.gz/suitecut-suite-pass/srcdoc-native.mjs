import {launchNativeBrowser} from '/workspace/suitecut/dist/native-browser.js';
import {createServer} from 'node:http';
import {setTimeout as delay} from 'node:timers/promises';
const html='<h1>Main Page</h1><iframe srcdoc="<ul><li>Item 1</li><li>Item 2</li></ul>"></iframe>';
const server=createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end(req.url==='/fixture'?html:'<h1>blank</h1>')});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
for(const mode of ['navigation','document-write']) {
 let source;
 try {
  source=await launchNativeBrowser({executablePath:process.env.SUITECUT_NATIVE_EXECUTABLE,width:640,height:360,framesPerSecond:30});
  source.onFailure?.(e=>console.log(mode,'failure',e.message));
  await source.navigate(`http://127.0.0.1:${server.address().port}/${mode==='navigation'?'fixture':'blank'}`);
  if(mode==='document-write')await source.sendDevToolsCommand('Runtime.evaluate',{expression:`document.open();document.write(${JSON.stringify(html)});document.close();`});
  await delay(500);
  console.log(mode,await source.sendDevToolsCommand('Runtime.evaluate',{expression:'document.querySelector("iframe").contentDocument.body.innerText',returnByValue:true}));
 } catch(e){console.log(mode,'error',e.message)}finally{await source?.close()}
}
server.closeAllConnections();await new Promise(r=>server.close(r));
