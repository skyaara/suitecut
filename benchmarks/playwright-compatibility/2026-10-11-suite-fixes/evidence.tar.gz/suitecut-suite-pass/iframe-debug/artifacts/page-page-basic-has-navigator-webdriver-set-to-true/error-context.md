# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-basic.spec.ts >> has navigator.webdriver set to true
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-basic.spec.ts:185:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  88  | it('page.title should not throw during navigation', async ({ page, server }) => {
  89  |   await page.setContent('<title>hello</title>');
  90  |   const promise = page.goto(server.PREFIX + '/title.html');
  91  |   const [titleOrError] = await Promise.all([
  92  |     page.title().catch(e => e),
  93  |     promise,
  94  |   ]);
  95  |   expect(typeof titleOrError).toBe('string');
  96  |   expect(titleOrError).toMatch(/^(hello|Loading http.*title.html||Woof-Woof)$/);
  97  |   await expect(page).toHaveTitle('Woof-Woof');
  98  | });
  99  | 
  100 | it('page.close should work with window.close', async function({ page }) {
  101 |   const newPagePromise = page.waitForEvent('popup');
  102 |   await page.evaluate(() => window['newPage'] = window.open('about:blank'));
  103 |   const newPage = await newPagePromise;
  104 |   const closedPromise = new Promise(x => newPage.on('close', x));
  105 |   await page.evaluate(() => window['newPage'].close());
  106 |   await closedPromise;
  107 | });
  108 | 
  109 | it('page.frame should respect name', async function({ page, isBidi }) {
  110 |   it.skip(isBidi, 'page.frame({ name }) is racy with BiDi');
  111 | 
  112 |   await page.setContent(`<iframe name=target></iframe>`);
  113 |   expect(page.frame({ name: 'bogus' })).toBe(null);
  114 |   const frame = page.frame({ name: 'target' });
  115 |   expect(frame).toBeTruthy();
  116 |   expect(frame === page.mainFrame().childFrames()[0]).toBeTruthy();
  117 | });
  118 | 
  119 | it('page.frame should respect url', async function({ page, server }) {
  120 |   await page.setContent(`<iframe src="${server.EMPTY_PAGE}"></iframe>`);
  121 |   expect(page.frame({ url: /bogus/ })).toBe(null);
  122 |   expect(page.frame({ url: /empty/ }).url()).toBe(server.EMPTY_PAGE);
  123 | });
  124 | 
  125 | it('should have sane user agent', async ({ page, browserName, isElectron, isAndroid }) => {
  126 |   it.skip(isAndroid);
  127 |   it.skip(isElectron);
  128 | 
  129 |   const userAgent = await page.evaluate(() => navigator.userAgent);
  130 |   const [
  131 |     part1,
  132 |     /* part2 */,
  133 |     part3,
  134 |     part4,
  135 |     part5,
  136 |   ] = userAgent.split(/[()]/).map(part => part.trim());
  137 |   // First part is always "Mozilla/5.0"
  138 |   expect(part1).toBe('Mozilla/5.0');
  139 |   // Second part in parenthesis is platform - ignore it.
  140 | 
  141 |   // Third part for Firefox is the last one and encodes engine and browser versions.
  142 |   if (browserName === 'firefox') {
  143 |     const [engine, browser] = part3.split(' ');
  144 |     expect(engine.startsWith('Gecko')).toBe(true);
  145 |     expect(browser.startsWith('Firefox')).toBe(true);
  146 |     expect(part4).toBe(undefined);
  147 |     expect(part5).toBe(undefined);
  148 |     return;
  149 |   }
  150 |   // For both options.CHROMIUM and options.WEBKIT, third part is the AppleWebKit version.
  151 |   expect(part3.startsWith('AppleWebKit/')).toBe(true);
  152 |   expect(part4).toBe('KHTML, like Gecko');
  153 |   // 5th part encodes real browser name and engine version.
  154 |   const tokens = part5.split(' ');
  155 |   const engine = tokens[0];
  156 |   const browser = tokens.find(t => t.startsWith('Safari/'));
  157 |   expect(browser?.startsWith('Safari/')).toBe(true);
  158 |   if (browserName === 'chromium')
  159 |     expect(engine.includes('Chrome/')).toBe(true);
  160 |   else
  161 |     expect(engine.startsWith('Version/')).toBe(true);
  162 | });
  163 | 
  164 | it('page.press should work', async ({ page, server }) => {
  165 |   await page.goto(server.PREFIX + '/input/textarea.html');
  166 |   await page.press('textarea', 'a');
  167 |   expect(await page.evaluate(() => document.querySelector('textarea').value)).toBe('a');
  168 | });
  169 | 
  170 | it('page.press should work for Enter', async ({ page }) => {
  171 |   await page.setContent(`<input onkeypress="console.log('press')"></input>`);
  172 |   const messages = [];
  173 |   page.on('console', message => messages.push(message));
  174 |   await page.press('input', 'Enter');
  175 |   expect(messages[0].text()).toBe('press');
  176 | });
  177 | 
  178 | it('frame.press should work', async ({ page, server }) => {
  179 |   await page.setContent(`<iframe name=inner src="${server.PREFIX}/input/textarea.html"></iframe>`);
  180 |   const frame = page.frame('inner');
  181 |   await frame.press('textarea', 'a');
  182 |   expect(await frame.evaluate(() => document.querySelector('textarea').value)).toBe('a');
  183 | });
  184 | 
  185 | it('has navigator.webdriver set to true', async ({ page, isAndroid }) => {
  186 |   it.fixme(isAndroid);
  187 | 
> 188 |   expect(await page.evaluate(() => navigator.webdriver)).toBe(true);
      |                                                          ^ Error: expect(received).toBe(expected) // Object.is equality
  189 | });
  190 | 
  191 | it('should iterate over page properties', async ({ page }) => {
  192 |   const props = [];
  193 |   for (const prop in page) {
  194 |     if (page[prop] && typeof page[prop] === 'object')
  195 |       props.push(page[prop][Symbol.iterator]);
  196 |   }
  197 | });
  198 | 
```