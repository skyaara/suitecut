# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-emulate-media.spec.ts >> should report hover and fine pointer for desktop
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-emulate-media.spec.ts:196:3

# Error details

```
Error: Expected "(hover: hover)" to match, but it did not
```

# Test source

```ts
  99  | 
  100 | it('should change the actual colors in css', async ({ page }) => {
  101 |   await page.setContent(`
  102 |     <style>
  103 |       @media (prefers-color-scheme: dark) {
  104 |         div {
  105 |           background: black;
  106 |           color: white;
  107 |         }
  108 |       }
  109 |       @media (prefers-color-scheme: light) {
  110 |         div {
  111 |           background: white;
  112 |           color: black;
  113 |         }
  114 |       }
  115 | 
  116 |     </style>
  117 |     <div>Hello</div>
  118 |   `);
  119 |   function getBackgroundColor() {
  120 |     return page.$eval('div', div => window.getComputedStyle(div).backgroundColor);
  121 |   }
  122 | 
  123 |   await page.emulateMedia({ colorScheme: 'light' });
  124 |   expect(await getBackgroundColor()).toBe('rgb(255, 255, 255)');
  125 | 
  126 |   await page.emulateMedia({ colorScheme: 'dark' });
  127 |   expect(await getBackgroundColor()).toBe('rgb(0, 0, 0)');
  128 | 
  129 |   await page.emulateMedia({ colorScheme: 'light' });
  130 |   expect(await getBackgroundColor()).toBe('rgb(255, 255, 255)');
  131 | });
  132 | 
  133 | it('should emulate reduced motion', async ({ page }) => {
  134 |   expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: no-preference)').matches)).toBe(true);
  135 |   await page.emulateMedia({ reducedMotion: 'reduce' });
  136 |   expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches)).toBe(true);
  137 |   expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: no-preference)').matches)).toBe(false);
  138 |   await page.emulateMedia({ reducedMotion: 'no-preference' });
  139 |   expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches)).toBe(false);
  140 |   expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: no-preference)').matches)).toBe(true);
  141 |   await page.emulateMedia({ reducedMotion: null });
  142 | });
  143 | 
  144 | it('should keep reduced motion and color emulation after reload', async ({ page, server }) => {
  145 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/31328' });
  146 | 
  147 |   // Pre-conditions
  148 |   expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches)).toEqual(false);
  149 |   expect(await page.evaluate(() => matchMedia('(forced-colors: active)').matches)).toBe(false);
  150 | 
  151 |   // Emulation
  152 |   await page.emulateMedia({ forcedColors: 'active', reducedMotion: 'reduce' });
  153 |   expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches)).toEqual(true);
  154 |   expect(await page.evaluate(() => matchMedia('(forced-colors: active)').matches)).toBe(true);
  155 | 
  156 |   // Force CanonicalBrowsingContext replacement in Firefox.
  157 |   server.setRoute('/empty.html', (req, res) => {
  158 |     res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  159 |     // Note: without 'onload', Firefox sometimes does not fire the load event
  160 |     // over the protocol. The reason is unclear.
  161 |     res.end(`
  162 |       <div>Hello there!</div>
  163 |       <script>window.onload = () => console.log('onload')</script>
  164 |     `);
  165 |   });
  166 |   await page.goto(server.EMPTY_PAGE);
  167 | 
  168 |   expect(await page.evaluate(() => matchMedia('(prefers-reduced-motion: reduce)').matches)).toEqual(true);
  169 |   expect(await page.evaluate(() => matchMedia('(forced-colors: active)').matches)).toBe(true);
  170 | });
  171 | 
  172 | it('should emulate forcedColors ', async ({ page, browserName }) => {
  173 |   expect(await page.evaluate(() => matchMedia('(forced-colors: none)').matches)).toBe(true);
  174 |   await page.emulateMedia({ forcedColors: 'none' });
  175 |   expect(await page.evaluate(() => matchMedia('(forced-colors: none)').matches)).toBe(true);
  176 |   expect(await page.evaluate(() => matchMedia('(forced-colors: active)').matches)).toBe(false);
  177 |   await page.emulateMedia({ forcedColors: 'active' });
  178 |   expect(await page.evaluate(() => matchMedia('(forced-colors: none)').matches)).toBe(false);
  179 |   expect(await page.evaluate(() => matchMedia('(forced-colors: active)').matches)).toBe(true);
  180 |   await page.emulateMedia({ forcedColors: null });
  181 |   expect(await page.evaluate(() => matchMedia('(forced-colors: none)').matches)).toBe(true);
  182 | });
  183 | 
  184 | it('should emulate contrast ', async ({ page }) => {
  185 |   await expect(page).toMatchMedia('(prefers-contrast: no-preference)');
  186 |   await page.emulateMedia({ contrast: 'no-preference' });
  187 |   await expect(page).toMatchMedia('(prefers-contrast: no-preference)');
  188 |   await expect(page).not.toMatchMedia('(prefers-contrast: more)');
  189 |   await page.emulateMedia({ contrast: 'more' });
  190 |   await expect(page).not.toMatchMedia('(prefers-contrast: no-preference)');
  191 |   await expect(page).toMatchMedia('(prefers-contrast: more)');
  192 |   await page.emulateMedia({ contrast: null });
  193 |   await expect(page).toMatchMedia('(prefers-contrast: no-preference)');
  194 | });
  195 | 
  196 | it('should report hover and fine pointer for desktop', async ({ page, isAndroid }) => {
  197 |   it.skip(isAndroid);
  198 | 
> 199 |   await expect(page).toMatchMedia('(hover: hover)');
      |                      ^ Error: Expected "(hover: hover)" to match, but it did not
  200 |   await expect(page).toMatchMedia('(pointer: fine)');
  201 | });
  202 | 
```