# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/elementhandle-wait-for-element-state.spec.ts >> should wait for stable position
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/elementhandle-wait-for-element-state.spec.ts:115:3

# Error details

```
Test timeout of 10000ms exceeded.
```

```
Error: elementHandle.waitForElementState: Test timeout of 10000ms exceeded.
Call log:
  - attempting wait for stable action
    2 × element is not stable
    - retrying wait for stable action
    - waiting 20ms
    2 × element is not stable
    - retrying wait for stable action
      - waiting 100ms
    17 × element is not stable
     - retrying wait for stable action
       - waiting 500ms

```

# Page snapshot

```yaml
- button "Click target" [ref=e2]
```

# Test source

```ts
  25  |   const div = await page.$('div');
  26  |   let done = false;
  27  |   const promise = div.waitForElementState('visible').then(() => done = true);
  28  |   await giveItAChanceToResolve(page);
  29  |   expect(done).toBe(false);
  30  |   await div.evaluate(div => div.style.display = 'block');
  31  |   await promise;
  32  | });
  33  | 
  34  | it('should wait for already visible', async ({ page }) => {
  35  |   await page.setContent(`<div>content</div>`);
  36  |   const div = await page.$('div');
  37  |   await div.waitForElementState('visible');
  38  | });
  39  | 
  40  | it('should timeout waiting for visible', async ({ page }) => {
  41  |   await page.setContent(`<div style='display:none'>content</div>`);
  42  |   const div = await page.$('div');
  43  |   const error = await div.waitForElementState('visible', { timeout: 1000 }).catch(e => e);
  44  |   expect(error.message).toContain('Timeout 1000ms exceeded');
  45  | });
  46  | 
  47  | it('should throw waiting for visible when detached', async ({ page }) => {
  48  |   await page.setContent(`<div style='display:none'>content</div>`);
  49  |   const div = await page.$('div');
  50  |   const promise = div.waitForElementState('visible').catch(e => e);
  51  |   await div.evaluate(div => div.remove());
  52  |   const error = await promise;
  53  |   expect(error.message).toContain('Element is not attached to the DOM');
  54  | });
  55  | 
  56  | it('should wait for hidden', async ({ page }) => {
  57  |   await page.setContent(`<div>content</div>`);
  58  |   const div = await page.$('div');
  59  |   let done = false;
  60  |   const promise = div.waitForElementState('hidden').then(() => done = true);
  61  |   await giveItAChanceToResolve(page);
  62  |   expect(done).toBe(false);
  63  |   await div.evaluate(div => div.style.display = 'none');
  64  |   await promise;
  65  | });
  66  | 
  67  | it('should wait for already hidden', async ({ page }) => {
  68  |   await page.setContent(`<div></div>`);
  69  |   const div = await page.$('div');
  70  |   await div.waitForElementState('hidden');
  71  | });
  72  | 
  73  | it('should wait for hidden when detached', async ({ page }) => {
  74  |   await page.setContent(`<div>content</div>`);
  75  |   const div = await page.$('div');
  76  |   let done = false;
  77  |   const promise = div.waitForElementState('hidden').then(() => done = true);
  78  |   await giveItAChanceToResolve(page);
  79  |   expect(done).toBe(false);
  80  |   await div.evaluate(div => div.remove());
  81  |   await promise;
  82  | });
  83  | 
  84  | it('should throw waiting for enabled when detached', async ({ page }) => {
  85  |   await page.setContent(`<button disabled>Target</button>`);
  86  |   const button = await page.$('button');
  87  |   const promise = button.waitForElementState('enabled').catch(e => e);
  88  |   await button.evaluate(button => button.remove());
  89  |   const error = await promise;
  90  |   expect(error.message).toContain('Element is not attached to the DOM');
  91  | });
  92  | 
  93  | it('should wait for aria enabled button', async ({ page }) => {
  94  |   await page.setContent('<button aria-disabled=true><span>Target</span></button>');
  95  |   const span = await page.$('text=Target');
  96  |   let done = false;
  97  |   const promise = span.waitForElementState('enabled').then(() => done = true);
  98  |   await giveItAChanceToResolve(page);
  99  |   expect(done).toBe(false);
  100 |   await span.evaluate(span => span.parentElement.setAttribute('aria-disabled', 'false'));
  101 |   await promise;
  102 | });
  103 | 
  104 | it('should wait for button with an aria-disabled parent', async ({ page }) => {
  105 |   await page.setContent('<div role="group" aria-disabled=true><button><span>Target</span></button></div>');
  106 |   const span = await page.$('text=Target');
  107 |   let done = false;
  108 |   const promise = span.waitForElementState('enabled').then(() => done = true);
  109 |   await giveItAChanceToResolve(page);
  110 |   expect(done).toBe(false);
  111 |   await span.evaluate(span => span.parentElement.parentElement.setAttribute('aria-disabled', 'false'));
  112 |   await promise;
  113 | });
  114 | 
  115 | it('should wait for stable position', async ({ page, server, browserName, platform }) => {
  116 |   await page.goto(server.PREFIX + '/input/button.html');
  117 |   const button = await page.$('button');
  118 |   await page.$eval('button', button => {
  119 |     button.style.transition = 'margin 10000ms linear 0s';
  120 |     button.style.marginLeft = '20000px';
  121 |   });
  122 |   // rafraf for Firefox to kick in the animation.
  123 |   await rafraf(page);
  124 |   let done = false;
> 125 |   const promise = button.waitForElementState('stable').then(() => done = true);
      |                          ^ Error: elementHandle.waitForElementState: Test timeout of 10000ms exceeded.
  126 |   await giveItAChanceToResolve(page);
  127 |   expect(done).toBe(false);
  128 |   await button.evaluate(button => button.style.transition = '');
  129 |   await promise;
  130 | });
  131 | 
  132 | it('should wait for editable input', async ({ page, server }) => {
  133 |   await page.setContent('<input readonly>');
  134 |   const input = await page.$('input');
  135 |   let done = false;
  136 |   const promise = input.waitForElementState('editable').then(() => done = true);
  137 |   await giveItAChanceToResolve(page);
  138 |   expect(done).toBe(false);
  139 |   await input.evaluate(input => input.readOnly = false);
  140 |   await promise;
  141 | });
  142 | 
```