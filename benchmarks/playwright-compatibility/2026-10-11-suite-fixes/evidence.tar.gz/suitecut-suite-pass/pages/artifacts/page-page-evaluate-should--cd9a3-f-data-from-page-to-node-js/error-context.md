# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-evaluate.spec.ts >> should transfer 100Mb of data from page to node.js
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-evaluate.spec.ts:582:3

# Error details

```
Test timeout of 10000ms exceeded.
```

```
Error: page.evaluate: Test timeout of 10000ms exceeded.
```

# Test source

```ts
  486 |   });
  487 |   const a = {} as any;
  488 |   a.b = a;
  489 |   expect(result).toEqual(a);
  490 | });
  491 | 
  492 | it('should be able to throw a tricky error', async ({ page }) => {
  493 |   const windowHandle = await page.evaluateHandle(() => window);
  494 |   const errorText = await windowHandle.jsonValue().catch(e => e.message);
  495 |   const error = await page.evaluate(errorText => {
  496 |     throw new Error(errorText);
  497 |   }, errorText).catch(e => e);
  498 |   expect(error.message).toContain(errorText);
  499 | });
  500 | 
  501 | it('should accept a string', async ({ page }) => {
  502 |   const result = await page.evaluate('1 + 2');
  503 |   expect(result).toBe(3);
  504 | });
  505 | 
  506 | it('should accept a string with semi colons', async ({ page }) => {
  507 |   const result = await page.evaluate('1 + 5;');
  508 |   expect(result).toBe(6);
  509 | });
  510 | 
  511 | it('should accept a string with comments', async ({ page }) => {
  512 |   const result = await page.evaluate('2 + 5;\n// do some math!');
  513 |   expect(result).toBe(7);
  514 | });
  515 | 
  516 | it('should accept element handle as an argument', async ({ page }) => {
  517 |   await page.setContent('<section>42</section>');
  518 |   const element = await page.$('section');
  519 |   const text = await page.evaluate(e => e.textContent, element);
  520 |   expect(text).toBe('42');
  521 | });
  522 | 
  523 | it('should throw if underlying element was disposed', async ({ page }) => {
  524 |   await page.setContent('<section>39</section>');
  525 |   const element = await page.$('section');
  526 |   expect(element).toBeTruthy();
  527 |   await element.dispose();
  528 |   let error = null;
  529 |   await page.evaluate(e => e.textContent, element).catch(e => error = e);
  530 |   expect(error.message).toContain('no object with guid');
  531 | });
  532 | 
  533 | it('should simulate a user gesture', async ({ page }) => {
  534 |   const result = await page.evaluate(() => {
  535 |     document.body.appendChild(document.createTextNode('test'));
  536 |     document.execCommand('selectAll');
  537 |     return document.execCommand('copy');
  538 |   });
  539 |   expect(result).toBe(true);
  540 | });
  541 | 
  542 | it('should throw a nice error after a navigation', async ({ page }) => {
  543 |   const errorPromise = page.evaluate(() => new Promise(f => window['__resolve'] = f)).catch(e => e) as Promise<Error>;
  544 |   await Promise.all([
  545 |     page.waitForNavigation(),
  546 |     page.evaluate(() => {
  547 |       window.location.reload();
  548 |       setTimeout(() => window['__resolve'](42), 1000);
  549 |     })
  550 |   ]);
  551 |   const error = await errorPromise;
  552 |   expect(error.message).toContain('navigation');
  553 | });
  554 | 
  555 | it('should not throw an error when evaluation does a navigation', async ({ page, server }) => {
  556 |   await page.goto(server.PREFIX + '/one-style.html');
  557 |   const result = await page.evaluate(() => {
  558 |     window.location.href = '/empty.html';
  559 |     return [42];
  560 |   });
  561 |   expect(result).toEqual([42]);
  562 | });
  563 | 
  564 | it('should not throw an error when evaluation does a synchronous navigation and returns an object', async ({ page, server, browserName }) => {
  565 |   // It is important to be on about:blank for sync reload.
  566 |   const result = await page.evaluate(() => {
  567 |     window.location.reload();
  568 |     return { a: 42 };
  569 |   });
  570 |   expect(result).toEqual({ a: 42 });
  571 | });
  572 | 
  573 | it('should not throw an error when evaluation does a synchronous navigation and returns undefined', async ({ page }) => {
  574 |   // It is important to be on about:blank for sync reload.
  575 |   const result = await page.evaluate(() => {
  576 |     window.location.reload();
  577 |     return undefined;
  578 |   });
  579 |   expect(result).toBe(undefined);
  580 | });
  581 | 
  582 | it('should transfer 100Mb of data from page to node.js', async ({ mode, page }) => {
  583 |   it.skip(mode !== 'default');
  584 | 
  585 |   // This is too slow with wire.
> 586 |   const a = await page.evaluate(() => Array(100 * 1024 * 1024 + 1).join('a'));
      |                        ^ Error: page.evaluate: Test timeout of 10000ms exceeded.
  587 |   expect(a.length).toBe(100 * 1024 * 1024);
  588 | });
  589 | 
  590 | it('should throw error with detailed information on exception inside promise ', async ({ page }) => {
  591 |   let error = null;
  592 |   await page.evaluate(() => new Promise(() => {
  593 |     throw new Error('Error in promise');
  594 |   })).catch(e => error = e);
  595 |   expect(error.message).toContain('Error in promise');
  596 | });
  597 | 
  598 | it('should work even when JSON is set to null', async ({ page }) => {
  599 |   await page.evaluate(() => { window.JSON.stringify = null; window.JSON = null; });
  600 |   const result = await page.evaluate(() => ({ abc: 123 }));
  601 |   expect(result).toEqual({ abc: 123 });
  602 | });
  603 | 
  604 | it('should await promise from popup', async ({ page, server }) => {
  605 |   // Something is wrong about the way Firefox waits for the chained promise
  606 |   await page.goto(server.EMPTY_PAGE);
  607 |   const result = await page.evaluate(() => {
  608 |     const win = window.open('about:blank');
  609 |     return new win['Promise'](f => f(42));
  610 |   });
  611 |   expect(result).toBe(42);
  612 | });
  613 | 
  614 | it('should work with new Function() and CSP', async ({ page, server }) => {
  615 |   server.setCSP('/empty.html', 'script-src ' + server.PREFIX);
  616 |   await page.goto(server.PREFIX + '/empty.html');
  617 |   expect(await page.evaluate(() => new Function('return true')())).toBe(true);
  618 | });
  619 | 
  620 | it('should work with non-strict expressions', async ({ page, server }) => {
  621 |   expect(await page.evaluate(() => {
  622 |     // @ts-ignore
  623 |     y = 3.14;
  624 |     // @ts-ignore
  625 |     return y;
  626 |   })).toBe(3.14);
  627 | });
  628 | 
  629 | it('should respect use strict expression', async ({ page }) => {
  630 |   const error = await page.evaluate(() => {
  631 |     'use strict';
  632 |     // @ts-ignore
  633 |     variableY = 3.14;
  634 |     // @ts-ignore
  635 |     return variableY;
  636 |   }).catch(e => e);
  637 |   expect(error.message).toContain('variableY');
  638 | });
  639 | 
  640 | it('should not leak utility script', async function({ page }) {
  641 |   expect(await page.evaluate('this === window')).toBe(true);
  642 | });
  643 | 
  644 | it('should not leak handles', async ({ page }) => {
  645 |   const error = await page.evaluate('handles.length').catch(e => e);
  646 |   expect((error as Error).message).toContain(' handles');
  647 | });
  648 | 
  649 | it('should work with CSP', async ({ page, server }) => {
  650 |   server.setCSP('/empty.html', `script-src 'self'`);
  651 |   await page.goto(server.EMPTY_PAGE);
  652 |   expect(await page.evaluate(() => 2 + 2)).toBe(4);
  653 | });
  654 | 
  655 | it('should evaluate exception with a function on the stack', async ({ page }) => {
  656 |   const error = await page.evaluate(() => {
  657 |     return (function functionOnStack() {
  658 |       return new Error('error message');
  659 |     })();
  660 |   });
  661 |   expect(error.message).toBe('error message');
  662 |   expect(error.stack).toContain('functionOnStack');
  663 | });
  664 | 
  665 | it('should evaluate exception', async ({ page }) => {
  666 |   const error = await page.evaluate(() => {
  667 |     function innerFunction() {
  668 |       const e = new Error('error message');
  669 |       e.name = 'foobar';
  670 |       return e;
  671 |     }
  672 |     return innerFunction();
  673 |   });
  674 |   expect(error).toBeInstanceOf(Error);
  675 |   expect((error as Error).message).toBe('error message');
  676 |   expect((error as Error).name).toBe('foobar');
  677 |   expect((error as Error).stack).toContain('innerFunction');
  678 | });
  679 | 
  680 | it('should pass exception argument', async ({ page }) => {
  681 |   function innerFunction() {
  682 |     const e = new Error('error message');
  683 |     e.name = 'foobar';
  684 |     return e;
  685 |   }
  686 |   const received = await page.evaluate(e => {
```