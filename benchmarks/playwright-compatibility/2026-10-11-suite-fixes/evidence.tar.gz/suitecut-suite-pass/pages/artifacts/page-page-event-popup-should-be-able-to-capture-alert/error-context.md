# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-event-popup.spec.ts >> should be able to capture alert
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-event-popup.spec.ts:61:3

# Error details

```
Test timeout of 10000ms exceeded.
```