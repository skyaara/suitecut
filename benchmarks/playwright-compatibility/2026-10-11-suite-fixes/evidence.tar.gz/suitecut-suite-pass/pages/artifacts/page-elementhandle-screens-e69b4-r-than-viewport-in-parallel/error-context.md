# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/elementhandle-screenshot.spec.ts >> element screenshot >> should capture full element when larger than viewport in parallel
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/elementhandle-screenshot.spec.ts:80:5

# Error details

```
Error: expect(Buffer).toMatchSnapshot(expected) failed

  2398 pixels (ratio 0.01 of all image pixels) are different.

  Snapshot: screenshot-element-larger-than-viewport.png

```

# Page snapshot

```yaml
- generic [active] [ref=e1]: oooo
```

# Test source

```ts
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { test as it, expect, rafraf } from './pageTest';
  19  | import { verifyViewport } from '../config/utils';
  20  | import { PNG } from '../../packages/playwright-core/lib/utilsBundle';
  21  | import { utils } from '../../packages/playwright-core/lib/coreBundle';
  22  | import path from 'path';
  23  | import fs from 'fs';
  24  | 
  25  | it.describe('element screenshot', () => {
  26  |   it.skip(({ browserName, headless }) => browserName === 'firefox' && !headless);
  27  |   it.skip(({ isAndroid }) => isAndroid, 'Different dpr. Remove after using 1x scale for screenshots.');
  28  | 
  29  |   it('should work', async ({ page, server }) => {
  30  |     await page.setViewportSize({ width: 500, height: 500 });
  31  |     await page.goto(server.PREFIX + '/grid.html');
  32  |     await page.evaluate(() => window.scrollBy(50, 100));
  33  |     const elementHandle = await page.$('.box:nth-of-type(3)');
  34  |     const screenshot = await elementHandle.screenshot();
  35  |     expect(screenshot).toMatchSnapshot('screenshot-element-bounding-box.png');
  36  |   });
  37  | 
  38  |   it('should work with webp', async ({ page, server }) => {
  39  |     await page.setViewportSize({ width: 500, height: 500 });
  40  |     await page.goto(server.PREFIX + '/grid.html');
  41  |     const elementHandle = await page.$('.box:nth-of-type(3)');
  42  |     const webpImage = utils.decodeWebp(await elementHandle.screenshot({ type: 'webp' }));
  43  |     // The default webp screenshot is lossless, so it must decode to the exact same pixels as png.
  44  |     const pngImage = PNG.sync.read(await elementHandle.screenshot({ type: 'png' }));
  45  |     expect(webpImage.width).toBe(pngImage.width);
  46  |     expect(webpImage.height).toBe(pngImage.height);
  47  |     expect(webpImage.data.equals(pngImage.data)).toBe(true);
  48  |   });
  49  | 
  50  |   it('should work when main world busts JSON.stringify', async ({ page, server }) => {
  51  |     await page.setViewportSize({ width: 500, height: 500 });
  52  |     await page.goto(server.PREFIX + '/grid.html');
  53  |     await page.evaluate(() => {
  54  |       window.scrollBy(50, 100);
  55  |       JSON.stringify = () => undefined;
  56  |     });
  57  |     const elementHandle = await page.$('.box:nth-of-type(3)');
  58  |     const screenshot = await elementHandle.screenshot();
  59  |     expect(screenshot).toMatchSnapshot('screenshot-element-bounding-box.png');
  60  |   });
  61  | 
  62  |   it('should take into account padding and border', async ({ page, isLinux, headless, browserName }) => {
  63  |     await page.setViewportSize({ width: 500, height: 500 });
  64  |     await page.setContent(`
  65  |       <div style="height: 14px">oooo</div>
  66  |       <style>div {
  67  |         border: 2px solid blue;
  68  |         background: green;
  69  |         width: 50px;
  70  |         height: 50px;
  71  |       }
  72  |       </style>
  73  |       <div id="d"></div>
  74  |     `);
  75  |     const elementHandle = await page.$('div#d');
  76  |     const screenshot = await elementHandle.screenshot();
  77  |     expect(screenshot).toMatchSnapshot('screenshot-element-padding-border.png');
  78  |   });
  79  | 
  80  |   it('should capture full element when larger than viewport in parallel', async ({ page, browserName }) => {
  81  |     await page.setViewportSize({ width: 500, height: 500 });
  82  | 
  83  |     await page.setContent(`
  84  |       <div style="height: 14px">oooo</div>
  85  |       <style>
  86  |       div.to-screenshot {
  87  |         border: 1px solid blue;
  88  |         width: 600px;
  89  |         height: 600px;
  90  |         margin-left: 50px;
  91  |       }
  92  |       ::-webkit-scrollbar{
  93  |         display: none;
  94  |       }
  95  |       </style>
  96  |       <div class="to-screenshot"></div>
  97  |       <div class="to-screenshot"></div>
  98  |       <div class="to-screenshot"></div>
  99  |     `);
  100 |     const elementHandles = await page.$$('div.to-screenshot');
  101 |     const promises = elementHandles.map(handle => handle.screenshot());
  102 |     const screenshots = await Promise.all(promises);
> 103 |     expect(screenshots[2]).toMatchSnapshot('screenshot-element-larger-than-viewport.png');
      |                            ^ Error: expect(Buffer).toMatchSnapshot(expected) failed
  104 | 
  105 |     await verifyViewport(page, 500, 500);
  106 |   });
  107 | 
  108 |   it('should capture full element when larger than viewport', async ({ page }) => {
  109 |     await page.setViewportSize({ width: 500, height: 500 });
  110 | 
  111 |     await page.setContent(`
  112 |       <div style="height: 14px">oooo</div>
  113 |       <style>
  114 |       div.to-screenshot {
  115 |         border: 1px solid blue;
  116 |         width: 600px;
  117 |         height: 600px;
  118 |         margin-left: 50px;
  119 |       }
  120 |       ::-webkit-scrollbar{
  121 |         display: none;
  122 |       }
  123 |       </style>
  124 |       <div class="to-screenshot"></div>
  125 |       <div class="to-screenshot"></div>
  126 |       <div class="to-screenshot"></div>
  127 |     `);
  128 |     const elementHandle = await page.$('div.to-screenshot');
  129 |     const screenshot = await elementHandle.screenshot();
  130 |     expect(screenshot).toMatchSnapshot('screenshot-element-larger-than-viewport.png');
  131 | 
  132 |     await verifyViewport(page, 500, 500);
  133 |   });
  134 | 
  135 |   it('should scroll element into view', async ({ page }) => {
  136 |     await page.setViewportSize({ width: 500, height: 500 });
  137 |     await page.setContent(`
  138 |       <div style="height: 14px">oooo</div>
  139 |       <style>div.above {
  140 |         border: 2px solid blue;
  141 |         background: red;
  142 |         height: 1500px;
  143 |       }
  144 |       div.to-screenshot {
  145 |         border: 2px solid blue;
  146 |         background: green;
  147 |         width: 50px;
  148 |         height: 50px;
  149 |       }
  150 |       </style>
  151 |       <div class="above"></div>
  152 |       <div class="to-screenshot"></div>
  153 |     `);
  154 |     const elementHandle = await page.$('div.to-screenshot');
  155 |     const screenshot = await elementHandle.screenshot();
  156 |     expect(screenshot).toMatchSnapshot('screenshot-element-scrolled-into-view.png');
  157 |   });
  158 | 
  159 |   it('should scroll 15000px into view', async ({ page }) => {
  160 |     await page.setViewportSize({ width: 500, height: 500 });
  161 |     await page.setContent(`
  162 |       <div style="height: 14px">oooo</div>
  163 |       <style>div.above {
  164 |         border: 2px solid blue;
  165 |         background: red;
  166 |         height: 15000px;
  167 |       }
  168 |       div.to-screenshot {
  169 |         border: 2px solid blue;
  170 |         background: green;
  171 |         width: 50px;
  172 |         height: 50px;
  173 |       }
  174 |       </style>
  175 |       <div class="above"></div>
  176 |       <div class="to-screenshot"></div>
  177 |     `);
  178 |     const elementHandle = await page.$('div.to-screenshot');
  179 |     const screenshot = await elementHandle.screenshot();
  180 |     expect(screenshot).toMatchSnapshot('screenshot-element-scrolled-into-view.png');
  181 |   });
  182 | 
  183 |   it('should work with a rotated element', async ({ page }) => {
  184 |     await page.setViewportSize({ width: 500, height: 500 });
  185 |     await page.setContent(`<div style="position:absolute;
  186 |                                       top: 100px;
  187 |                                       left: 100px;
  188 |                                       width: 100px;
  189 |                                       height: 100px;
  190 |                                       background: green;
  191 |                                       transform: rotateZ(200deg);">&nbsp;</div>`);
  192 |     const elementHandle = await page.$('div');
  193 |     const screenshot = await elementHandle.screenshot();
  194 |     expect(screenshot).toMatchSnapshot('screenshot-element-rotate.png');
  195 |   });
  196 | 
  197 |   it('should fail to screenshot a detached element', async ({ page, server }) => {
  198 |     await page.setContent('<h1>remove this</h1>');
  199 |     const elementHandle = await page.$('h1');
  200 |     await page.evaluate(element => element.remove(), elementHandle);
  201 |     const screenshotError = await elementHandle.screenshot().catch(error => error);
  202 |     expect(screenshotError.message).toContain('Element is not attached to the DOM');
  203 |   });
```