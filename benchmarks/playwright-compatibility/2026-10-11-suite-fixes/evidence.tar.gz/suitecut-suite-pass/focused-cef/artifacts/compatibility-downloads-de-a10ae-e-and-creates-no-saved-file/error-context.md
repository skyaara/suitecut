# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compatibility.spec.ts >> downloads: denied download reports failure and creates no saved file
- Location: benchmarks/playwright-compatibility/compatibility.spec.ts:949:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 0
Received: 1

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Test source

```ts
  862  |     try {
  863  |       const p = await c.newPage()
  864  |       await p.goto(origin)
  865  |       expect(await p.evaluate(() => fetch('/redirect').then((r) => r.json()))).toEqual({
  866  |         value: 42,
  867  |       })
  868  |       expect(
  869  |         await p.evaluate(() =>
  870  |           fetch('/post', { method: 'POST', body: 'hello' }).then((r) => r.json()),
  871  |         ),
  872  |       ).toEqual({ body: 'hello' })
  873  |     } finally {
  874  |       await c.close()
  875  |     }
  876  |     expect((await stat(path)).size).toBeGreaterThan(100)
  877  |     if (extension === 'har') {
  878  |       const data = HarSchema.parse(JSON.parse(await readFile(path, 'utf8')))
  879  |       expect(data.log.entries.some((e) => e.response.status === 302)).toBe(true)
  880  |       expect(data.log.entries.some((e) => e.response.content.text?.includes('42'))).toBe(true)
  881  |     }
  882  |     const replay = await browser.newContext({ serviceWorkers: 'block' })
  883  |     try {
  884  |       await replay.routeFromHAR(path, { notFound: 'abort' })
  885  |       const p = await replay.newPage()
  886  |       await p.goto(origin)
  887  |       expect(await p.evaluate(() => fetch('/redirect').then((r) => r.json()))).toEqual({
  888  |         value: 42,
  889  |       })
  890  |       expect(
  891  |         await p.evaluate(() =>
  892  |           fetch('/post', { method: 'POST', body: 'hello' }).then((r) => r.json()),
  893  |         ),
  894  |       ).toEqual({ body: 'hello' })
  895  |       await expect(p.goto(origin + '/not-in-har')).rejects.toThrow()
  896  |     } finally {
  897  |       await replay.close()
  898  |     }
  899  |   })
  900  | test('video: Playwright recordVideo creates a decodable WebM after context close', async ({
  901  |   browser,
  902  | }, info) => {
  903  |   const c = await browser.newContext({
  904  |     viewport: { width: 640, height: 360 },
  905  |     recordVideo: { dir: info.outputPath('videos'), size: { width: 320, height: 180 } },
  906  |   })
  907  |   let video: ReturnType<Page['video']>
  908  |   try {
  909  |     const p = await c.newPage()
  910  |     await p.goto(origin)
  911  |     video = p.video()
  912  |     expect(video).not.toBeNull()
  913  |     await delay(1200)
  914  |   } finally {
  915  |     await c.close()
  916  |   }
  917  |   const path = await required(video).path()
  918  |   const data = ProbeSchema.parse(
  919  |     JSON.parse(
  920  |       execFileSync(
  921  |         'ffprobe',
  922  |         ['-v', 'error', '-show_streams', '-show_format', '-of', 'json', path],
  923  |         {
  924  |           encoding: 'utf8',
  925  |         },
  926  |       ),
  927  |     ),
  928  |   )
  929  |   expect(data.streams[0]).toMatchObject({ codec_name: 'vp8', width: 320, height: 180 })
  930  |   expect(Number(data.format.duration)).toBeGreaterThan(0.5)
  931  |   execFileSync('ffmpeg', ['-v', 'error', '-i', path, '-f', 'null', '-'], { timeout: 15000 })
  932  |   await writeFile(info.outputPath('ffprobe.json'), JSON.stringify(data, null, 2))
  933  | })
  934  | 
  935  | test('downloads: repeated cancellation releases requests and capacity', async ({ page }) => {
  936  |   test.setTimeout(60000)
  937  |   await page.goto(origin)
  938  |   await page.setContent(`<a href="${origin}/slow-download">download</a>`)
  939  |   // Exceed the native concurrent-download cap over time. Finished entries
  940  |   // must be reclaimed, and cancellation must close the server connection.
  941  |   for (let i = 0; i < 70; i++) {
  942  |     const [download] = await Promise.all([page.waitForEvent('download'), page.click('a')])
  943  |     await download.cancel()
  944  |     expect(await download.failure()).toBe('canceled')
  945  |     await expect.poll(() => pendingDownloads.size).toBe(0)
  946  |   }
  947  | })
  948  | 
  949  | test('downloads: denied download reports failure and creates no saved file', async ({
  950  |   browser,
  951  | }, info) => {
  952  |   const context = await browser.newContext({ acceptDownloads: false })
  953  |   try {
  954  |     const page = await context.newPage()
  955  |     await page.goto(origin)
  956  |     await page.setContent(`<a href="${origin}/slow-download">download</a>`)
  957  |     const [download] = await Promise.all([page.waitForEvent('download'), page.click('a')])
  958  |     expect(await download.failure()).toContain('acceptDownloads')
  959  |     const destination = info.outputPath('denied.bin')
  960  |     await expect(download.saveAs(destination)).rejects.toThrow('acceptDownloads')
  961  |     await expect(stat(destination)).rejects.toMatchObject({ code: 'ENOENT' })
> 962  |     await expect.poll(() => pendingDownloads.size).toBe(0)
       |                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  963  |   } finally {
  964  |     await context.close()
  965  |   }
  966  | })
  967  | 
  968  | test('cdp: session close event precedes detach completion', async ({ page }) => {
  969  |   const session = await page.context().newCDPSession(page)
  970  |   const events: string[] = []
  971  |   session.on('close', () => events.push('closed'))
  972  |   await session.detach()
  973  |   events.push('detached')
  974  |   expect(events).toEqual(['closed', 'detached'])
  975  |   await expect(session.send('Runtime.evaluate', { expression: '1 + 1' })).rejects.toThrow()
  976  | })
  977  | 
  978  | test('permissions: local network grant resets and stays within its context', async ({
  979  |   browser,
  980  | }) => {
  981  |   const allowed = await browser.newContext()
  982  |   const isolated = await browser.newContext()
  983  |   try {
  984  |     const page = await allowed.newPage()
  985  |     const other = await isolated.newPage()
  986  |     await page.goto(origin)
  987  |     await other.goto(origin)
  988  |     const state = (p: Page) =>
  989  |       p.evaluate(
  990  |         async () =>
  991  |           (await navigator.permissions.query({ name: 'loopback-network' as PermissionName })).state,
  992  |       )
  993  |     expect(await state(page)).toBe('prompt')
  994  |     await allowed.grantPermissions(['local-network-access'], { origin })
  995  |     expect(await state(page)).toBe('granted')
  996  |     expect(await state(other)).toBe('prompt')
  997  |     await allowed.clearPermissions()
  998  |     expect(await state(page)).toBe('prompt')
  999  |     await allowed.grantPermissions([], { origin })
  1000 |     expect(await state(page)).toBe('denied')
  1001 |   } finally {
  1002 |     await allowed.close()
  1003 |     await isolated.close()
  1004 |   }
  1005 | })
  1006 | 
  1007 | test('cdp: explicit page sessions keep debugger domains independent', async ({ page }) => {
  1008 |   const session = await page.context().newCDPSession(page)
  1009 |   try {
  1010 |     await session.send('Debugger.enable')
  1011 |     await page.coverage.startJSCoverage()
  1012 |     await page.coverage.stopJSCoverage()
  1013 |     const parsed = new Promise<void>((resolve) => {
  1014 |       session.on('Debugger.scriptParsed', (event) => {
  1015 |         if (event.url === 'suitecut-independent.js') resolve()
  1016 |       })
  1017 |     })
  1018 |     await Promise.all([parsed, page.evaluate('void 0;\n//# sourceURL=suitecut-independent.js')])
  1019 |     const result = await session.send('Runtime.evaluate', { expression: '21 * 2' })
  1020 |     expect(result.result.value).toBe(42)
  1021 |   } finally {
  1022 |     await session.detach()
  1023 |   }
  1024 | })
  1025 | 
```