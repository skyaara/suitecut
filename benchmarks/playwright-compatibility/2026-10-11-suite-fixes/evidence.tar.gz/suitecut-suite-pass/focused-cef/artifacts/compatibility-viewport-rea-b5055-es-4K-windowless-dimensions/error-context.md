# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compatibility.spec.ts >> viewport: real browser version metadata preserves 4K windowless dimensions
- Location: benchmarks/playwright-compatibility/compatibility.spec.ts:514:1

# Error details

```
Error: cdpSession.send: Protocol error (Browser.getWindowForTarget): Unknown CEF window target
```

# Test source

```ts
  430 |   await session.detach()
  431 | })
  432 | test('oopif: cross-site navigation, detach and network routing', async ({ page, context }) => {
  433 |   await context.route('**/json', (r) => r.fulfill({ json: { value: 'routed' } }))
  434 |   await page.goto(origin)
  435 |   await page.evaluate((url) => {
  436 |     const f = document.createElement('iframe')
  437 |     f.src = url
  438 |     document.body.append(f)
  439 |   }, cross)
  440 |   const inner = page.frameLocator('iframe')
  441 |   await inner.getByLabel('Name').fill('cross-site')
  442 |   await expect(inner.getByLabel('Name')).toHaveValue('cross-site')
  443 |   const f = required(page.frames().find((f) => f.url().startsWith(cross)))
  444 |   expect(await f.evaluate(() => fetch('/json').then((r) => r.json()))).toEqual({ value: 'routed' })
  445 |   await page
  446 |     .locator('iframe')
  447 |     .evaluate((f, url) => ((f as HTMLIFrameElement).src = url), origin + '/next')
  448 |   await expect.poll(() => page.frames().map((f) => f.url())).toContain(origin + '/next')
  449 |   await inner.getByRole('button').click()
  450 |   await expect(inner.getByRole('button')).toHaveText('clicked')
  451 |   const detached = page.waitForEvent('framedetached')
  452 |   await page.locator('iframe').evaluate((f) => f.remove())
  453 |   await detached
  454 |   expect(page.frames()).toHaveLength(1)
  455 | })
  456 | test('viewport: odd and tiny browser dimensions support screenshots and Playwright video', async ({
  457 |   browser,
  458 | }, info) => {
  459 |   const c = await browser.newContext({
  460 |     viewport: { width: 1904, height: 609 },
  461 |     recordVideo: { dir: info.outputPath('odd-videos'), size: { width: 640, height: 204 } },
  462 |   })
  463 |   try {
  464 |     const p = await c.newPage()
  465 |     await p.goto(origin)
  466 |     expect(await p.evaluate(() => ({ width: innerWidth, height: innerHeight }))).toEqual({
  467 |       width: 1904,
  468 |       height: 609,
  469 |     })
  470 |     const png = await p.screenshot()
  471 |     expect(png.readUInt32BE(16)).toBe(1904)
  472 |     expect(png.readUInt32BE(20)).toBe(609)
  473 |     await p.getByRole('button').click()
  474 |     await expect(p.getByRole('button')).toHaveText('clicked')
  475 |     await p.setViewportSize({ width: 1, height: 1 })
  476 |     const tiny = await p.screenshot()
  477 |     expect(tiny.readUInt32BE(16)).toBe(1)
  478 |     expect(tiny.readUInt32BE(20)).toBe(1)
  479 |   } finally {
  480 |     await c.close()
  481 |   }
  482 | })
  483 | test('locale: popups inherit context language before their first script without cross-context leakage', async ({
  484 |   browser,
  485 | }) => {
  486 |   const french = await browser.newContext({ locale: 'fr-FR' })
  487 |   const german = await browser.newContext({ locale: 'de-DE' })
  488 |   try {
  489 |     for (const [context, expected] of [
  490 |       [french, 'fr-FR'],
  491 |       [german, 'de-DE'],
  492 |       [french, 'fr-FR'],
  493 |     ] as const) {
  494 |       const page = await context.newPage()
  495 |       await page.goto(origin + '/initial-language')
  496 |       expect(await page.evaluate('window.initialLanguage')).toBe(expected)
  497 |       const [popup] = await Promise.all([
  498 |         page.waitForEvent('popup'),
  499 |         page.evaluate((url) => {
  500 |           window.open(url)
  501 |         }, origin + '/initial-language'),
  502 |       ])
  503 |       await popup.waitForLoadState('domcontentloaded')
  504 |       expect(await popup.evaluate('window.initialLanguage')).toBe(expected)
  505 |       await page.close()
  506 |       await popup.close()
  507 |     }
  508 |   } finally {
  509 |     await french.close()
  510 |     await german.close()
  511 |   }
  512 | })
  513 | 
  514 | test('viewport: real browser version metadata preserves 4K windowless dimensions', async ({
  515 |   browser,
  516 | }) => {
  517 |   const context = await browser.newContext({ viewport: { width: 3840, height: 2160 } })
  518 |   try {
  519 |     const page = await context.newPage()
  520 |     await page.goto(origin)
  521 |     expect(await page.evaluate(() => ({ width: innerWidth, height: innerHeight }))).toEqual({
  522 |       width: 3840,
  523 |       height: 2160,
  524 |     })
  525 |     const cdp = await context.newCDPSession(page)
  526 |     try {
  527 |       const version = await cdp.send('Browser.getVersion')
  528 |       expect(version.userAgent).toBe(await page.evaluate(() => navigator.userAgent))
  529 |       expect(version.jsVersion).not.toBe('')
> 530 |       const { bounds } = await cdp.send('Browser.getWindowForTarget')
      |                                    ^ Error: cdpSession.send: Protocol error (Browser.getWindowForTarget): Unknown CEF window target
  531 |       expect(bounds.width).toBe(3840)
  532 |       expect(bounds.height).toBe(2160)
  533 |     } finally {
  534 |       await cdp.detach()
  535 |     }
  536 |   } finally {
  537 |     await context.close()
  538 |   }
  539 | })
  540 | 
  541 | test('state: IndexedDB auth export to file and restore into a fresh context', async ({
  542 |   page,
  543 |   context,
  544 |   browser,
  545 | }, info) => {
  546 |   await page.goto(origin)
  547 |   await page.evaluate(async () => {
  548 |     localStorage.setItem('session', 'local-token')
  549 |     document.cookie = 'auth=cookie-token; SameSite=Lax; path=/'
  550 |     const db = await new Promise<IDBDatabase>((r, j) => {
  551 |       const q = indexedDB.open('auth-db', 3)
  552 |       q.onupgradeneeded = () => {
  553 |         const s = q.result.createObjectStore('tokens', { keyPath: 'id' })
  554 |         s.createIndex('byScope', 'scope', { unique: true })
  555 |       }
  556 |       q.onsuccess = () => r(q.result)
  557 |       q.onerror = () => j(new Error(q.error?.message ?? 'IndexedDB failure'))
  558 |     })
  559 |     await new Promise<void>((r, j) => {
  560 |       const t = db.transaction('tokens', 'readwrite')
  561 |       t.objectStore('tokens').put({
  562 |         id: 'user',
  563 |         scope: 'login',
  564 |         token: 'idb-token',
  565 |         bytes: new Uint8Array([0, 1, 254, 255]),
  566 |         created: new Date('2026-01-01'),
  567 |       })
  568 |       t.oncomplete = () => r()
  569 |       t.onerror = () => j(new Error(t.error?.message ?? 'IndexedDB failure'))
  570 |     })
  571 |     db.close()
  572 |   })
  573 |   const path = info.outputPath('state.json')
  574 |   const state = await context.storageState({ path, indexedDB: true })
  575 |   expect(state.origins[0]).toMatchObject({ indexedDB: [{ version: 3 }] })
  576 |   await context.close()
  577 |   const restored = await browser.newContext({ storageState: path })
  578 |   try {
  579 |     const p = await restored.newPage()
  580 |     await p.goto(origin)
  581 |     expect(
  582 |       await p.evaluate(() => ({ cookie: document.cookie, local: localStorage.getItem('session') })),
  583 |     ).toEqual({ cookie: 'auth=cookie-token', local: 'local-token' })
  584 |     expect(
  585 |       await p.evaluate(
  586 |         () =>
  587 |           new Promise((r, j) => {
  588 |             const q = indexedDB.open('auth-db')
  589 |             q.onsuccess = () => {
  590 |               const db = q.result,
  591 |                 t = db.transaction('tokens'),
  592 |                 get = t.objectStore('tokens').index('byScope').get('login')
  593 |               get.onsuccess = () => {
  594 |                 const v = get.result as { token: string; bytes: Uint8Array; created: Date }
  595 |                 r({ token: v.token, bytes: Array.from(v.bytes), created: v.created.toISOString() })
  596 |                 db.close()
  597 |               }
  598 |               get.onerror = () => j(new Error(get.error?.message ?? 'IndexedDB failure'))
  599 |             }
  600 |           }),
  601 |       ),
  602 |     ).toEqual({ token: 'idb-token', bytes: [0, 1, 254, 255], created: '2026-01-01T00:00:00.000Z' })
  603 |     expect(await restored.storageState({ indexedDB: true })).toEqual(state)
  604 |   } finally {
  605 |     await restored.close()
  606 |   }
  607 |   const isolated = await browser.newContext()
  608 |   try {
  609 |     const p = await isolated.newPage()
  610 |     await p.goto(origin)
  611 |     expect(
  612 |       await p.evaluate(() => ({ cookie: document.cookie, local: localStorage.getItem('session') })),
  613 |     ).toEqual({ cookie: '', local: null })
  614 |   } finally {
  615 |     await isolated.close()
  616 |   }
  617 | })
  618 | test('state: lone UTF-16 values survive arguments, console, state export and import', async ({
  619 |   page,
  620 |   context,
  621 |   browser,
  622 | }) => {
  623 |   const values = ['\udafe', '\udc00', '\\udafe', '😀']
  624 |   await page.goto(origin)
  625 |   await page.evaluate((values) => {
  626 |     values.forEach((value, i) => localStorage.setItem(`unicode-${i}`, value))
  627 |   }, values)
  628 |   const consoleEvent = page.waitForEvent('console')
  629 |   await page.evaluate((value) => console.log(value), values[0])
  630 |   expect((await consoleEvent).text()).toBe(values[0])
```