# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: compatibility.spec.ts >> oopif: cross-site frame is a separate CDP target and remains interactive
- Location: benchmarks/playwright-compatibility/compatibility.spec.ts:405:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 5000ms exceeded while waiting on the predicate
```

# Test source

```ts
  326 | })
  327 | test('worker: repeated worker contexts release browser target registrations', async ({
  328 |   browser,
  329 | }) => {
  330 |   test.setTimeout(60000)
  331 |   const root = await browser.newBrowserCDPSession()
  332 |   try {
  333 |     for (let i = 0; i < 80; i++) {
  334 |       const c = await browser.newContext()
  335 |       try {
  336 |         const p = await c.newPage()
  337 |         const event = c.waitForEvent('serviceworker', { timeout: 5000 })
  338 |         void event.catch(() => undefined)
  339 |         await register(p)
  340 |         expect(
  341 |           await (await event).evaluate(() => (self as typeof self & { marker: number }).marker),
  342 |         ).toBe(42)
  343 |       } finally {
  344 |         await c.close()
  345 |       }
  346 |     }
  347 |     await expect
  348 |       .poll(
  349 |         async () =>
  350 |           (await root.send('Target.getTargets')).targetInfos.filter(
  351 |             (t) => t.type === 'service_worker',
  352 |           ).length,
  353 |       )
  354 |       .toBe(0)
  355 |   } finally {
  356 |     await root.detach()
  357 |   }
  358 | })
  359 | test('native: worker CDP aliases detach when their context closes', async ({ browser, engine }) => {
  360 |   test.skip(!engine, 'This checks the native shim alias lifecycle')
  361 |   test.setTimeout(60000)
  362 |   const root = await browser.newBrowserCDPSession(),
  363 |     detached = new Set<string>()
  364 |   root.on('Target.detachedFromTarget', (event) => detached.add(event.sessionId))
  365 |   try {
  366 |     for (let i = 0; i < 80; i++) {
  367 |       const c = await browser.newContext()
  368 |       let extra: string | undefined
  369 |       try {
  370 |         const p = await c.newPage()
  371 |         const event = c.waitForEvent('serviceworker', { timeout: 5000 })
  372 |         void event.catch(() => undefined)
  373 |         await register(p)
  374 |         await event
  375 |         const target = required(
  376 |           (await root.send('Target.getTargets')).targetInfos.find(
  377 |             (t) => t.type === 'service_worker',
  378 |           ),
  379 |         )
  380 |         extra = (
  381 |           await root.send('Target.attachToTarget', { targetId: target.targetId, flatten: true })
  382 |         ).sessionId
  383 |       } finally {
  384 |         await c.close()
  385 |       }
  386 |       await expect.poll(() => detached.has(required(extra))).toBe(true)
  387 |     }
  388 |   } finally {
  389 |     await root.detach()
  390 |   }
  391 | })
  392 | test('worker: serviceWorkers block prevents registration', async ({ browser }) => {
  393 |   const c = await browser.newContext({ serviceWorkers: 'block' })
  394 |   try {
  395 |     const p = await c.newPage()
  396 |     await p.goto(origin)
  397 |     await p.evaluate(() => navigator.serviceWorker.register('/sw.js').catch(() => null))
  398 |     expect(
  399 |       await p.evaluate(() => navigator.serviceWorker.getRegistrations().then((r) => r.length)),
  400 |     ).toBe(0)
  401 |   } finally {
  402 |     await c.close()
  403 |   }
  404 | })
  405 | test('oopif: cross-site frame is a separate CDP target and remains interactive', async ({
  406 |   page,
  407 |   context,
  408 | }) => {
  409 |   await page.goto(origin)
  410 |   const session = await context.newCDPSession(page)
  411 |   const attachments: { targetInfo: { type: string } }[] = []
  412 |   session.on('Target.attachedToTarget', (e) => attachments.push(e))
  413 |   if (process.env.COMPAT_BACKEND === 'chromium')
  414 |     await session.send('Target.setAutoAttach', {
  415 |       autoAttach: true,
  416 |       waitForDebuggerOnStart: false,
  417 |       flatten: true,
  418 |     })
  419 |   await page.evaluate((url) => {
  420 |     const f = document.createElement('iframe')
  421 |     f.src = url
  422 |     document.body.append(f)
  423 |   }, cross)
  424 |   await page.frameLocator('iframe').getByRole('button').click()
  425 |   await expect(page.frameLocator('iframe').getByRole('button')).toHaveText('clicked')
> 426 |   await expect.poll(() => attachments.some((e) => e.targetInfo.type === 'iframe')).toBe(true)
      |                                                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  427 |   await expect.poll(() => page.frames().map((f) => f.url())).toContain(cross + '/')
  428 |   const frame = required(page.frames().find((f) => f.url().startsWith(cross)))
  429 |   expect(await frame.evaluate(() => location.origin)).toBe(cross)
  430 |   await session.detach()
  431 | })
  432 | test('oopif: cross-site navigation, detach and network routing', async ({ page, context }) => {
  433 |   await context.route('**/json', (r) => r.fulfill({ json: { value: 'routed' } }))
  434 |   await page.goto(origin)
  435 |   await page.evaluate((url) => {
  436 |     const f = document.createElement('iframe')
  437 |     f.src = url
  438 |     document.body.append(f)
  439 |   }, cross)
  440 |   const inner = page.frameLocator('iframe')
  441 |   await inner.getByLabel('Name').fill('cross-site')
  442 |   await expect(inner.getByLabel('Name')).toHaveValue('cross-site')
  443 |   const f = required(page.frames().find((f) => f.url().startsWith(cross)))
  444 |   expect(await f.evaluate(() => fetch('/json').then((r) => r.json()))).toEqual({ value: 'routed' })
  445 |   await page
  446 |     .locator('iframe')
  447 |     .evaluate((f, url) => ((f as HTMLIFrameElement).src = url), origin + '/next')
  448 |   await expect.poll(() => page.frames().map((f) => f.url())).toContain(origin + '/next')
  449 |   await inner.getByRole('button').click()
  450 |   await expect(inner.getByRole('button')).toHaveText('clicked')
  451 |   const detached = page.waitForEvent('framedetached')
  452 |   await page.locator('iframe').evaluate((f) => f.remove())
  453 |   await detached
  454 |   expect(page.frames()).toHaveLength(1)
  455 | })
  456 | test('viewport: odd and tiny browser dimensions support screenshots and Playwright video', async ({
  457 |   browser,
  458 | }, info) => {
  459 |   const c = await browser.newContext({
  460 |     viewport: { width: 1904, height: 609 },
  461 |     recordVideo: { dir: info.outputPath('odd-videos'), size: { width: 640, height: 204 } },
  462 |   })
  463 |   try {
  464 |     const p = await c.newPage()
  465 |     await p.goto(origin)
  466 |     expect(await p.evaluate(() => ({ width: innerWidth, height: innerHeight }))).toEqual({
  467 |       width: 1904,
  468 |       height: 609,
  469 |     })
  470 |     const png = await p.screenshot()
  471 |     expect(png.readUInt32BE(16)).toBe(1904)
  472 |     expect(png.readUInt32BE(20)).toBe(609)
  473 |     await p.getByRole('button').click()
  474 |     await expect(p.getByRole('button')).toHaveText('clicked')
  475 |     await p.setViewportSize({ width: 1, height: 1 })
  476 |     const tiny = await p.screenshot()
  477 |     expect(tiny.readUInt32BE(16)).toBe(1)
  478 |     expect(tiny.readUInt32BE(20)).toBe(1)
  479 |   } finally {
  480 |     await c.close()
  481 |   }
  482 | })
  483 | test('locale: popups inherit context language before their first script without cross-context leakage', async ({
  484 |   browser,
  485 | }) => {
  486 |   const french = await browser.newContext({ locale: 'fr-FR' })
  487 |   const german = await browser.newContext({ locale: 'de-DE' })
  488 |   try {
  489 |     for (const [context, expected] of [
  490 |       [french, 'fr-FR'],
  491 |       [german, 'de-DE'],
  492 |       [french, 'fr-FR'],
  493 |     ] as const) {
  494 |       const page = await context.newPage()
  495 |       await page.goto(origin + '/initial-language')
  496 |       expect(await page.evaluate('window.initialLanguage')).toBe(expected)
  497 |       const [popup] = await Promise.all([
  498 |         page.waitForEvent('popup'),
  499 |         page.evaluate((url) => {
  500 |           window.open(url)
  501 |         }, origin + '/initial-language'),
  502 |       ])
  503 |       await popup.waitForLoadState('domcontentloaded')
  504 |       expect(await popup.evaluate('window.initialLanguage')).toBe(expected)
  505 |       await page.close()
  506 |       await popup.close()
  507 |     }
  508 |   } finally {
  509 |     await french.close()
  510 |     await german.close()
  511 |   }
  512 | })
  513 | 
  514 | test('viewport: real browser version metadata preserves 4K windowless dimensions', async ({
  515 |   browser,
  516 | }) => {
  517 |   const context = await browser.newContext({ viewport: { width: 3840, height: 2160 } })
  518 |   try {
  519 |     const page = await context.newPage()
  520 |     await page.goto(origin)
  521 |     expect(await page.evaluate(() => ({ width: innerWidth, height: innerHeight }))).toEqual({
  522 |       width: 3840,
  523 |       height: 2160,
  524 |     })
  525 |     const cdp = await context.newCDPSession(page)
  526 |     try {
```