import { spawn } from 'node:child_process';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { setTimeout as delay } from 'node:timers/promises';
const profile = await mkdtemp('/tmp/suitecut-pipe-probe-');
const child=spawn(process.env.SUITECUT_RUNTIME_EXECUTABLE,[`--suitecut-profile=${profile}`,'--suitecut-width=640','--suitecut-height=360','--suitecut-scale=1','--suitecut-fps=30','--suitecut-pixel-format=i420','--remote-debugging-pipe'],{stdio:['pipe','pipe','pipe','pipe','pipe'],detached:true});
let output='', pending='';const messages=[];
child.stdout.on('data',()=>{});child.stderr.on('data',b=>{output+=b.toString();if(output.length>100000)output=output.slice(-100000)});
child.stdio[3].on('error',e=>messages.push({pipeError:e.message}));
child.stdio[4].on('data',b=>{pending+=b.toString();let n;while((n=pending.indexOf('\0'))>=0){const line=pending.slice(0,n);pending=pending.slice(n+1);try{messages.push(JSON.parse(line))}catch{messages.push({bad:line})}}});
child.stdio[3].write(JSON.stringify({id:1,method:'Browser.getVersion'})+'\0');
child.stdio[3].write(JSON.stringify({id:2,method:'Target.setAutoAttach',params:{autoAttach:true,waitForDebuggerOnStart:true,flatten:true,filter:[{type:'page'},{exclude:true}]}})+'\0');
await delay(4000);
console.log(JSON.stringify({messages,stderr:output,exitCode:child.exitCode},null,2));
child.stdin.end();
await Promise.race([new Promise(r=>child.once('exit',r)),delay(5000)]);
try{process.kill(-child.pid,'SIGKILL')}catch{}
await rm(profile,{recursive:true,force:true});
