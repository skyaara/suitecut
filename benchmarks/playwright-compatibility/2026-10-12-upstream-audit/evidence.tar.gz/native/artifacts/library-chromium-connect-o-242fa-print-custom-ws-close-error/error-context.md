# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/chromium/connect-over-cdp.spec.ts >> should print custom ws close error
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/connect-over-cdp.spec.ts:620:5

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "Browser logs:·
Oh my!
"
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  527 |     args: ['--remote-debugging-port=' + port]
  528 |   });
  529 |   try {
  530 |     async function isPrint(page) {
  531 |       return await page.evaluate(() => matchMedia('print').matches);
  532 |     }
  533 | 
  534 |     const browser1 = await browserType.connectOverCDP(`http://localhost:${port}`);
  535 |     const context1 = await browser1.newContext();
  536 |     const page1 = await context1.newPage();
  537 |     await page1.emulateMedia({ media: 'print' });
  538 |     expect(await isPrint(page1)).toBe(true);
  539 |     const browser2 = await browserType.connectOverCDP(`http://localhost:${port}`, { noDefaults: true });
  540 |     expect(await isPrint(page1)).toBe(true);
  541 |     await Promise.all([
  542 |       browser1.close(),
  543 |       browser2.close()
  544 |     ]);
  545 |   } finally {
  546 |     await browserServer.close();
  547 |   }
  548 | });
  549 | 
  550 | test('should allow tracing over cdp session', async ({ browserType, trace }, testInfo) => {
  551 |   test.skip(trace === 'on');
  552 | 
  553 |   const port = 9339 + testInfo.workerIndex;
  554 |   const browserServer = await browserType.launch({
  555 |     args: ['--remote-debugging-port=' + port]
  556 |   });
  557 |   try {
  558 |     const cdpBrowser = await browserType.connectOverCDP({
  559 |       endpointURL: `http://127.0.0.1:${port}/`,
  560 |     });
  561 |     const [context] = cdpBrowser.contexts();
  562 |     await context.tracing.start({ screenshots: true, snapshots: true });
  563 |     const page = await context.newPage();
  564 |     await page.evaluate(() => 2 + 2);
  565 |     const traceZip = testInfo.outputPath('trace.zip');
  566 |     await context.tracing.stop({ path: traceZip });
  567 |     await cdpBrowser.close();
  568 |     expect(fs.existsSync(traceZip)).toBe(true);
  569 |   } finally {
  570 |     await browserServer.close();
  571 |   }
  572 | });
  573 | 
  574 | test('setInputFiles should preserve lastModified timestamp', async ({ browserType, asset }) => {
  575 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/27452' });
  576 | 
  577 |   const port = 9339 + test.info().workerIndex;
  578 |   const browserServer = await browserType.launch({
  579 |     args: ['--remote-debugging-port=' + port]
  580 |   });
  581 |   try {
  582 |     const cdpBrowser = await browserType.connectOverCDP({
  583 |       endpointURL: `http://127.0.0.1:${port}/`,
  584 |     });
  585 |     const [context] = cdpBrowser.contexts();
  586 |     const page = await context.newPage();
  587 |     await page.setContent(`<input type=file multiple=true/>`);
  588 |     const input = page.locator('input');
  589 |     const files = ['file-to-upload.txt', 'file-to-upload-2.txt'];
  590 |     await input.setInputFiles(files.map(f => asset(f)));
  591 |     expect(await input.evaluate(e => [...(e as HTMLInputElement).files].map(f => f.name))).toEqual(files);
  592 |     const timestamps = await input.evaluate(e => [...(e as HTMLInputElement).files].map(f => f.lastModified));
  593 |     const expectedTimestamps = files.map(file => Math.round(fs.statSync(asset(file)).mtimeMs));
  594 |     // On Linux browser sometimes reduces the timestamp by 1ms: 1696272058110.0715  -> 1696272058109 or even
  595 |     // rounds it to seconds in WebKit: 1696272058110 -> 1696272058000.
  596 |     for (let i = 0; i < timestamps.length; i++)
  597 |       expect(Math.abs(timestamps[i] - expectedTimestamps[i]), `expected: ${expectedTimestamps}; actual: ${timestamps}`).toBeLessThan(1000);
  598 |     await cdpBrowser.close();
  599 |   } finally {
  600 |     await browserServer.close();
  601 |   }
  602 | });
  603 | 
  604 | test('setInputFiles should use local path when isLocal is set', async ({ browserType, toImpl }) => {
  605 |   const port = 9339 + test.info().workerIndex;
  606 |   const browserServer = await browserType.launch({
  607 |     args: ['--remote-debugging-port=' + port]
  608 |   });
  609 |   try {
  610 |     const cdpBrowser1 = await browserType.connectOverCDP(`http://127.0.0.1:${port}/`);
  611 |     expect(toImpl(cdpBrowser1)._isBrowserCollocatedWithServer).toBe(false);
  612 | 
  613 |     const cdpBrowser2 = await browserType.connectOverCDP(`http://127.0.0.1:${port}/`, { isLocal: true });
  614 |     expect(toImpl(cdpBrowser2)._isBrowserCollocatedWithServer).toBe(true);
  615 |   } finally {
  616 |     await browserServer.close();
  617 |   }
  618 | });
  619 | 
  620 | test('should print custom ws close error', async ({ browserType, server }) => {
  621 |   server.onceWebSocketConnection((ws, request) => {
  622 |     ws.on('message', message => {
  623 |       ws.close(4123, 'Oh my!');
  624 |     });
  625 |   });
  626 |   const error = await browserType.connectOverCDP(`ws://localhost:${server.PORT}/ws`).catch(e => e);
> 627 |   expect(error.message).toContain(`Browser logs:\n\nOh my!\n`);
      |                         ^ Error: expect(received).toContain(expected) // indexOf
  628 | });
  629 | 
  630 | test('should not reuse utility worlds between two clients', async ({ browserType, toImpl }, testInfo) => {
  631 |   const port = 9339 + testInfo.workerIndex;
  632 |   const browserServer = await browserType.launch({
  633 |     args: ['--remote-debugging-port=' + port]
  634 |   });
  635 |   try {
  636 |     const browser1 = await browserType.connectOverCDP(`http://127.0.0.1:${port}/`);
  637 |     const context1 = browser1.contexts()[0];
  638 |     expect(context1.pages().length).toBe(0);
  639 |     const page1 = await context1.newPage();
  640 |     const frameImpl1 = toImpl(page1.mainFrame()) as Frame;
  641 |     await frameImpl1.evaluateExpression(nullProgress, 'window.foo = 42', { world: 'utility' });
  642 | 
  643 |     const browser2 = await browserType.connectOverCDP(`http://127.0.0.1:${port}/`);
  644 |     const context2 = browser2.contexts()[0];
  645 |     const page2 = context2.pages()[0];
  646 |     const frameImpl2 = toImpl(page2.mainFrame()) as Frame;
  647 |     const result = await frameImpl2.evaluateExpression(nullProgress, 'window.foo', { world: 'utility' });
  648 | 
  649 |     await browser1.close();
  650 |     await browser2.close();
  651 | 
  652 |     expect(result).toBeUndefined();
  653 |   } finally {
  654 |     await browserServer.close();
  655 |   }
  656 | });
  657 | 
  658 | test('should get title and URL of existing page', async ({ browserType, mode, server }, testInfo) => {
  659 |   const port = 9339 + testInfo.workerIndex;
  660 |   const browserServer = await browserType.launch({
  661 |     args: ['--remote-debugging-port=' + port]
  662 |   });
  663 |   const browsers = [];
  664 |   try {
  665 |     {
  666 |       const cdpBrowser = await browserType.connectOverCDP({
  667 |         endpointURL: `http://127.0.0.1:${port}/`,
  668 |       });
  669 |       browsers.push(cdpBrowser);
  670 |       const [context] = cdpBrowser.contexts();
  671 |       const page = await context.newPage();
  672 |       await page.goto(server.EMPTY_PAGE);
  673 |       await page.evaluate(() => document.title = 'my title');
  674 |     }
  675 | 
  676 |     {
  677 |       const cdpBrowser = await browserType.connectOverCDP({
  678 |         endpointURL: `http://127.0.0.1:${port}/`,
  679 |       });
  680 |       browsers.push(cdpBrowser);
  681 | 
  682 |       const [context] = cdpBrowser.contexts();
  683 |       const [page] = context.pages();
  684 |       expect(page.url()).toBe(server.EMPTY_PAGE);
  685 |       expect(await page.title()).toBe('my title');
  686 |     }
  687 | 
  688 |   } finally {
  689 |     for (const browser of browsers)
  690 |       await browser.close();
  691 |     await browserServer.close();
  692 |   }
  693 | });
  694 | 
  695 | test('should skip default overrides with noDefaults', async ({ browserType, mode, server }, testInfo) => {
  696 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40158' });
  697 |   const port = 9339 + testInfo.workerIndex;
  698 |   const browserServer = await browserType.launch({
  699 |     args: ['--remote-debugging-port=' + port]
  700 |   });
  701 |   try {
  702 |     const browser = await browserType.connectOverCDP({
  703 |       endpointURL: `http://127.0.0.1:${port}/`,
  704 |       noDefaults: true,
  705 |     });
  706 |     const defaultContext = browser.contexts()[0];
  707 |     const page = await defaultContext.newPage();
  708 | 
  709 |     // Browser.setDownloadBehavior was not sent, so no Playwright download event fires.
  710 |     server.setRoute('/download', (req, res) => {
  711 |       res.setHeader('Content-Type', 'application/octet-stream');
  712 |       res.setHeader('Content-Disposition', 'attachment; filename=file.txt');
  713 |       res.end('Hello world');
  714 |     });
  715 |     await page.setContent(`<a href="${server.PREFIX}/download">download</a>`);
  716 |     let sawDownload = false;
  717 |     page.on('download', () => { sawDownload = true; });
  718 |     await page.click('a');
  719 |     await page.waitForTimeout(500);
  720 |     expect(sawDownload).toBe(false);
  721 | 
  722 |     await browser.close();
  723 |   } finally {
  724 |     await browserServer.close();
  725 |   }
  726 | });
  727 | 
```