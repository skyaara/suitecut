# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-connect.spec.ts >> launchServer >> should print custom ws close error
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-connect.spec.ts:131:5

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "browserType.connect: Oh my!"
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  38  | const test = playwrightTest.extend<ExtraFixtures>({
  39  |   connect: async ({ browserType }, use) => {
  40  |     let browser: Browser | undefined;
  41  |     await use(async (wsEndpoint, options = {}, redirectPortForTest): Promise<Browser> => {
  42  |       (options as any).__testHookRedirectPortForwarding = redirectPortForTest;
  43  |       options.headers = {
  44  |         'x-playwright-launch-options': JSON.stringify((browserType as any)._playwright._defaultLaunchOptions || {}),
  45  |         ...options.headers,
  46  |       };
  47  |       browser = await browserType.connect(wsEndpoint, options);
  48  |       return browser;
  49  |     });
  50  |     await browser?.close();
  51  |   },
  52  | 
  53  |   dummyServerPort: async ({}, use) => {
  54  |     const server = createHttpServer((req: http.IncomingMessage, res: http.ServerResponse) => {
  55  |       res.end('<html><body>from-dummy-server</body></html>');
  56  |     });
  57  |     // Only listen on IPv4 to check that we don't try to connect to it via IPv6.
  58  |     await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  59  |     await use((server.address() as net.AddressInfo).port);
  60  |     await new Promise<Error>(resolve => server.close(resolve));
  61  |   },
  62  | 
  63  |   ipV6ServerPort: async ({}, use) => {
  64  |     test.skip(!!process.env.INSIDE_DOCKER, 'docker does not support IPv6 by default');
  65  |     const server = createHttpServer((req: http.IncomingMessage, res: http.ServerResponse) => {
  66  |       res.end('<html><body>from-ipv6-server</body></html>');
  67  |     });
  68  |     await new Promise<void>(resolve => server.listen(0, '::1', resolve));
  69  |     const address = server.address() as net.AddressInfo;
  70  |     await use(address.port);
  71  |     await new Promise<Error>(resolve => server.close(resolve));
  72  |   },
  73  | });
  74  | 
  75  | test.slow(true, 'All connect tests are slow');
  76  | 
  77  | for (const kind of ['launchServer', 'run-server'] as const) {
  78  |   test.describe(kind, () => {
  79  | 
  80  |     test('should connect over wss', async ({ connect, startRemoteServer, httpsServer }) => {
  81  |       const remoteServer = await startRemoteServer(kind);
  82  | 
  83  |       const oldValue = process.env['NODE_TLS_REJECT_UNAUTHORIZED'];
  84  |       // https://stackoverflow.com/a/21961005/552185
  85  |       process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
  86  |       suppressCertificateWarning();
  87  |       try {
  88  |         httpsServer.onceWebSocketConnection((ws, request) => {
  89  |           const headers = Object.fromEntries(Object.entries(request.headers).filter(entry => entry[0].startsWith('x-playwright')));
  90  |           const remote = new WebSocket(remoteServer.wsEndpoint(), [], {
  91  |             perMessageDeflate: false,
  92  |             maxPayload: 256 * 1024 * 1024, // 256Mb,
  93  |             headers,
  94  |           });
  95  |           const remoteReadyPromise = new Promise<void>((f, r) => {
  96  |             remote.once('open', f);
  97  |             remote.once('error', r);
  98  |           });
  99  |           remote.on('close', () => ws.close());
  100 |           remote.on('error', error => ws.close());
  101 |           remote.on('message', message => ws.send(message));
  102 |           ws.on('message', async message => {
  103 |             await remoteReadyPromise;
  104 |             remote.send(message);
  105 |           });
  106 |           ws.on('close', () => remote.close());
  107 |           ws.on('error', () => remote.close());
  108 |         });
  109 |         const browser = await connect(`wss://localhost:${httpsServer.PORT}/ws`);
  110 |         expect(browser.version()).toBeTruthy();
  111 |         await browser.close();
  112 |       } finally {
  113 |         process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = oldValue;
  114 |       }
  115 |     });
  116 | 
  117 |     test('should print HTTP error', async ({ connect, server }) => {
  118 |       const error = await connect(`ws://localhost:${server.PORT}/ws-401`).catch(e => e);
  119 |       expect(error.message).toContain('401');
  120 |       expect(error.message).toContain('Unauthorized body');
  121 |     });
  122 | 
  123 |     test('should print ws error', async ({ connect, server }) => {
  124 |       const error = await connect(`ws://does-not-exist.problem-domain:10987?secret=MYSECRET`).catch(e => e);
  125 |       expect(error.message).toContain('<ws connecting> ws://does-not-exist.problem-domain:10987/');
  126 |       expect(error.message).toContain('<ws error>');
  127 |       expect(error.message).toContain('getaddrinfo');
  128 |       expect(error.message).not.toContain('secret=MYSECRET');
  129 |     });
  130 | 
  131 |     test('should print custom ws close error', async ({ connect, server }) => {
  132 |       server.onceWebSocketConnection((ws, request) => {
  133 |         ws.on('message', message => {
  134 |           ws.close(4123, 'Oh my!');
  135 |         });
  136 |       });
  137 |       const error = await connect(`ws://localhost:${server.PORT}/ws`).catch(e => e);
> 138 |       expect(error.message).toContain('browserType.connect: Oh my!');
      |                             ^ Error: expect(received).toContain(expected) // indexOf
  139 |     });
  140 | 
  141 |     test('should be able to reconnect to a browser', async ({ connect, startRemoteServer, server }) => {
  142 |       const remoteServer = await startRemoteServer(kind);
  143 |       {
  144 |         const browser = await connect(remoteServer.wsEndpoint());
  145 |         const browserContext = await browser.newContext();
  146 |         expect(browserContext.pages().length).toBe(0);
  147 |         const page = await browserContext.newPage();
  148 |         expect(await page.evaluate('11 * 11')).toBe(121);
  149 |         await page.goto(server.EMPTY_PAGE);
  150 |         await browser.close();
  151 |       }
  152 |       {
  153 |         const browser = await connect(remoteServer.wsEndpoint());
  154 |         const browserContext = await browser.newContext();
  155 |         const page = await browserContext.newPage();
  156 |         await page.goto(server.EMPTY_PAGE);
  157 |         await browser.close();
  158 |       }
  159 |     });
  160 | 
  161 |     test('should not crash on malformed json frame', async ({ connect, startRemoteServer }) => {
  162 |       const remoteServer = await startRemoteServer(kind);
  163 |       const ws = new WebSocket(remoteServer.wsEndpoint());
  164 |       await new Promise<void>((resolve, reject) => {
  165 |         ws.once('open', resolve);
  166 |         ws.once('error', reject);
  167 |       });
  168 |       ws.send(']');
  169 |       await new Promise<void>(resolve => ws.once('close', () => resolve()));
  170 |       // Server should still be alive and accept new connections.
  171 |       const browser = await connect(remoteServer.wsEndpoint());
  172 |       const page = await browser.newPage();
  173 |       expect(await page.evaluate('1 + 2')).toBe(3);
  174 |       await browser.close();
  175 |     });
  176 | 
  177 |     test('should be able to visit ipv6', async ({ connect, startRemoteServer, ipV6ServerPort, channel }) => {
  178 |       test.fail(!!process.env.INSIDE_DOCKER, 'docker does not support IPv6 by default');
  179 |       test.fail(channel === 'webkit-wsl', 'WebKit on WSL does not support IPv6: https://github.com/microsoft/WSL/issues/10803');
  180 |       const remoteServer = await startRemoteServer(kind);
  181 |       const browser = await connect(remoteServer.wsEndpoint());
  182 |       const page = await browser.newPage();
  183 |       const ipV6Url = 'http://[::1]:' + ipV6ServerPort;
  184 |       await page.goto(ipV6Url);
  185 |       expect(await page.content()).toContain('from-ipv6-server');
  186 |       await browser.close();
  187 |     });
  188 | 
  189 |     test('should ignore page.pause when headed', async ({ connect, startRemoteServer, browserType, channel }) => {
  190 |       test.skip(channel === 'chromium-headless-shell', 'shell is never headed');
  191 | 
  192 |       const headless = (browserType as any)._playwright._defaultLaunchOptions.headless;
  193 |       (browserType as any)._playwright._defaultLaunchOptions.headless = false;
  194 |       const remoteServer = await startRemoteServer(kind);
  195 |       const browser = await connect(remoteServer.wsEndpoint());
  196 |       const browserContext = await browser.newContext();
  197 |       const page = await browserContext.newPage();
  198 |       // @ts-ignore
  199 |       await page.pause({ __testHookKeepTestTimeout: true });
  200 |       await browser.close();
  201 |       (browserType as any)._playwright._defaultLaunchOptions.headless = headless;
  202 |     });
  203 | 
  204 |     test('should be able to visit ipv6 through localhost', async ({ connect, startRemoteServer, ipV6ServerPort, channel }) => {
  205 |       test.fail(!!process.env.INSIDE_DOCKER, 'docker does not support IPv6 by default');
  206 |       test.skip(channel === 'webkit-wsl', 'WebKit on WSL does not support IPv6: https://github.com/microsoft/WSL/issues/10803');
  207 |       const remoteServer = await startRemoteServer(kind);
  208 |       const browser = await connect(remoteServer.wsEndpoint());
  209 |       const page = await browser.newPage();
  210 |       const ipV6Url = 'http://localhost:' + ipV6ServerPort;
  211 |       await page.goto(ipV6Url);
  212 |       expect(await page.content()).toContain('from-ipv6-server');
  213 |       await browser.close();
  214 |     });
  215 | 
  216 |     test('should be able to connect two browsers at the same time', async ({ connect, startRemoteServer }) => {
  217 |       const remoteServer = await startRemoteServer(kind);
  218 | 
  219 |       const browser1 = await connect(remoteServer.wsEndpoint());
  220 |       expect(browser1.contexts().length).toBe(0);
  221 |       await browser1.newContext();
  222 |       expect(browser1.contexts().length).toBe(1);
  223 | 
  224 |       const browser2 = await connect(remoteServer.wsEndpoint());
  225 |       expect(browser2.contexts().length).toBe(0);
  226 |       await browser2.newContext();
  227 |       expect(browser2.contexts().length).toBe(1);
  228 |       expect(browser1.contexts().length).toBe(1);
  229 | 
  230 |       await browser1.close();
  231 |       expect(browser2.contexts().length).toBe(1);
  232 |       const page2 = await browser2.newPage();
  233 |       expect(await page2.evaluate(() => 7 * 6)).toBe(42); // original browser should still work
  234 | 
  235 |       await browser2.close();
  236 |     });
  237 | 
  238 |     test('should timeout in socket while connecting', async ({ connect, server }) => {
```