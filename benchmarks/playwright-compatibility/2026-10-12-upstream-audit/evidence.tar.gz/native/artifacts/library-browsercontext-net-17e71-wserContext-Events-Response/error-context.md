# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-network-event.spec.ts >> BrowserContext.Events.Response
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-network-event.spec.ts:40:3

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 0

  Array [
    "http://localhost:8995/empty.html",
-   "http://localhost:8995/one-style.html",
-   "http://localhost:8995/one-style.css",
  ]
```

# Page snapshot

```yaml
- link "yo" [active] [ref=e2] [cursor=pointer]:
  - /url: /one-style.html
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2018 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { browserTest as it, expect } from '../config/browserTest';
  19  | import type { Request, Response } from '@playwright/test';
  20  | 
  21  | it('BrowserContext.Events.Request', async ({ context, server }) => {
  22  |   const page = await context.newPage();
  23  |   const requests: Request[] = [];
  24  |   context.on('request', request => requests.push(request));
  25  |   await page.goto(server.EMPTY_PAGE);
  26  |   await page.setContent('<a target=_blank rel=noopener href="/one-style.html">yo</a>');
  27  |   const [page1] = await Promise.all([
  28  |     context.waitForEvent('page'),
  29  |     page.click('a'),
  30  |   ]);
  31  |   await page1.waitForLoadState();
  32  |   const urls = requests.map(r => r.url());
  33  |   expect(urls).toEqual([
  34  |     server.EMPTY_PAGE,
  35  |     `${server.PREFIX}/one-style.html`,
  36  |     `${server.PREFIX}/one-style.css`
  37  |   ]);
  38  | });
  39  | 
  40  | it('BrowserContext.Events.Response', async ({ context, server }) => {
  41  |   const page = await context.newPage();
  42  |   const responses: Response[] = [];
  43  |   context.on('response', response => responses.push(response));
  44  |   await page.goto(server.EMPTY_PAGE);
  45  |   await page.setContent('<a target=_blank rel=noopener href="/one-style.html">yo</a>');
  46  |   const [page1] = await Promise.all([
  47  |     context.waitForEvent('page'),
  48  |     page.click('a'),
  49  |   ]);
  50  |   await page1.waitForLoadState();
  51  |   const urls = responses.map(r => r.url());
> 52  |   expect(urls).toEqual([
      |                ^ Error: expect(received).toEqual(expected) // deep equality
  53  |     server.EMPTY_PAGE,
  54  |     `${server.PREFIX}/one-style.html`,
  55  |     `${server.PREFIX}/one-style.css`
  56  |   ]);
  57  | });
  58  | 
  59  | it('BrowserContext.Events.RequestFailed', async ({ context, server }) => {
  60  |   server.setRoute('/one-style.css', (_, res) => {
  61  |     res.setHeader('Content-Type', 'text/css');
  62  |     res.connection!.destroy();
  63  |   });
  64  |   const page = await context.newPage();
  65  |   const failedRequests: Request[] = [];
  66  |   context.on('requestfailed', request => failedRequests.push(request));
  67  |   await page.goto(server.PREFIX + '/one-style.html');
  68  |   expect(failedRequests.length).toBe(1);
  69  |   expect(failedRequests[0].url()).toContain('one-style.css');
  70  |   expect(await failedRequests[0].response()).toBe(null);
  71  |   expect(failedRequests[0].resourceType()).toBe('stylesheet');
  72  |   expect(failedRequests[0].frame()).toBeTruthy();
  73  | });
  74  | 
  75  | 
  76  | it('BrowserContext.Events.RequestFinished', async ({ context, server }) => {
  77  |   const page = await context.newPage();
  78  |   const [response] = await Promise.all([
  79  |     page.goto(server.EMPTY_PAGE),
  80  |     context.waitForEvent('requestfinished')
  81  |   ]);
  82  |   const request = response!.request();
  83  |   expect(request.url()).toBe(server.EMPTY_PAGE);
  84  |   expect(await request.response()).toBeTruthy();
  85  |   expect(request.frame() === page.mainFrame()).toBe(true);
  86  |   expect(request.frame().url()).toBe(server.EMPTY_PAGE);
  87  |   expect(request.failure()).toBe(null);
  88  | });
  89  | 
  90  | it('should fire events in proper order', async ({ context, server }) => {
  91  |   const page = await context.newPage();
  92  |   const events: string[] = [];
  93  |   context.on('request', () => events.push('request'));
  94  |   context.on('response', () => events.push('response'));
  95  |   context.on('requestfinished', () => events.push('requestfinished'));
  96  |   await Promise.all([
  97  |     page.goto(server.EMPTY_PAGE),
  98  |     context.waitForEvent('requestfinished')
  99  |   ]);
  100 |   expect(events).toEqual([
  101 |     'request',
  102 |     'response',
  103 |     'requestfinished',
  104 |   ]);
  105 | });
  106 | 
  107 | it('should not fire events for favicon or favicon redirects', async ({ context, page, server, browserName, headless, channel }) => {
  108 |   it.skip(headless && browserName !== 'firefox', 'headless browsers, except firefox, do not request favicons');
  109 |   it.skip(!headless && browserName === 'webkit', 'headed webkit does not have a favicon feature');
  110 |   const favicon = `/no-cache/favicon.ico`;
  111 |   const hashedFaviconUrl = `/favicon-hashed.ico`;
  112 |   const imagePath = `/fakeimage.png`;
  113 |   const pagePath = `/page.html`;
  114 |   server.setRedirect(favicon, hashedFaviconUrl);
  115 |   server.setRoute(pagePath, (_, res) => {
  116 |     res.end(`
  117 |       <!DOCTYPE html>
  118 |       <html>
  119 |         <head>
  120 |           <meta charset="utf-8">
  121 |           <link rel="icon" type="image/svg+xml" href="${favicon}">
  122 |           <title>SVG Favicon Test</title>
  123 |         </head>
  124 |         <body>
  125 |           <img src="${imagePath}" alt="my fake image">
  126 |         </body>
  127 |       </html>
  128 | `);
  129 |   });
  130 | 
  131 |   const events: string[] = [];
  132 |   context.on('request', req => events.push(req.url()));
  133 |   context.on('response', res => events.push(res.url()));
  134 |   context.on('requestfinished', req => events.push(req.url()));
  135 | 
  136 |   await Promise.all([
  137 |     server.waitForRequest(favicon),
  138 |     server.waitForRequest(hashedFaviconUrl),
  139 |     page.goto(server.PREFIX + '/page.html'),
  140 |   ]);
  141 | 
  142 |   expect(events).toEqual(expect.arrayContaining([expect.stringContaining(pagePath)]));
  143 |   expect(events).toEqual(expect.arrayContaining([expect.stringContaining(imagePath)]));
  144 |   expect(events).not.toEqual(expect.arrayContaining([expect.stringContaining(favicon)]));
  145 |   expect(events).not.toEqual(expect.arrayContaining([expect.stringContaining(hashedFaviconUrl)]));
  146 | });
  147 | 
  148 | it('should reject response.finished if context closes', async ({ page, server }) => {
  149 |   await page.goto(server.EMPTY_PAGE);
  150 |   server.setRoute('/get', (req, res) => {
  151 |     // In Firefox, |fetch| will be hanging until it receives |Content-Type| header
  152 |     // from server.
```