# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/launcher.spec.ts >> should throw a friendly error if its headed and there is no xserver on linux running
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/launcher.spec.ts:45:3

# Error details

```
Error: expect(received).toMatch(expected)

Expected pattern: /Looks like you launched a headed browser without having a XServer running./
Received string:  "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  1  | /**
  2  |  * Copyright 2017 Google Inc. All rights reserved.
  3  |  * Modifications copyright (c) Microsoft Corporation.
  4  |  *
  5  |  * Licensed under the Apache License, Version 2.0 (the "License");
  6  |  * you may not use this file except in compliance with the License.
  7  |  * You may obtain a copy of the License at
  8  |  *
  9  |  *     http://www.apache.org/licenses/LICENSE-2.0
  10 |  *
  11 |  * Unless required by applicable law or agreed to in writing, software
  12 |  * distributed under the License is distributed on an "AS IS" BASIS,
  13 |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14 |  * See the License for the specific language governing permissions and
  15 |  * limitations under the License.
  16 |  */
  17 | 
  18 | import { inheritAndCleanEnv } from '../config/utils';
  19 | import { playwrightTest as it, expect } from '../config/browserTest';
  20 | 
  21 | it('should have an errors object', async ({ playwright }) => {
  22 |   expect(String(playwright.errors.TimeoutError)).toContain('TimeoutError');
  23 | });
  24 | 
  25 | it('should have a devices object', async ({ playwright }) => {
  26 |   expect(playwright.devices['iPhone 6']).toBeTruthy();
  27 |   expect(playwright.devices['iPhone 6'].defaultBrowserType).toBe('webkit');
  28 | });
  29 | 
  30 | it('should kill browser process on timeout after close', async ({ browserType, mode }) => {
  31 |   it.skip(mode !== 'default', 'Test passes server hooks via options');
  32 | 
  33 |   const launchOptions: any = {};
  34 |   let stalled = false;
  35 |   launchOptions.__testHookGracefullyClose = () => {
  36 |     stalled = true;
  37 |     return new Promise(() => {});
  38 |   };
  39 |   launchOptions.__testHookBrowserCloseTimeout = 1_000;
  40 |   const browser = await browserType.launch(launchOptions);
  41 |   await browser.close();
  42 |   expect(stalled).toBeTruthy();
  43 | });
  44 | 
  45 | it('should throw a friendly error if its headed and there is no xserver on linux running', async ({ mode, browserType, platform, channel }) => {
  46 |   it.skip(platform !== 'linux');
  47 |   it.skip(channel === 'chromium-headless-shell', 'shell is never headed');
  48 |   it.skip(channel === 'chromium-tip-of-tree-headless-shell', 'shell is never headed');
  49 | 
  50 |   const error: Error = await browserType.launch({
  51 |     headless: false,
  52 |     env: inheritAndCleanEnv({ DISPLAY: undefined }),
  53 |   }).catch(e => e);
  54 |   expect(error).toBeInstanceOf(Error);
> 55 |   expect(error.message).toMatch(/Looks like you launched a headed browser without having a XServer running./);
     |                         ^ Error: expect(received).toMatch(expected)
  56 |   expect(error.message).toMatch(/xvfb-run/);
  57 | });
  58 | 
```