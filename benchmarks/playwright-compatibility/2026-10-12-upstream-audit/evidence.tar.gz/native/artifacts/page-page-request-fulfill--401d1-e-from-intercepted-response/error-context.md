# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-request-fulfill.spec.ts >> headerValue should return set-cookie from intercepted response
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-request-fulfill.spec.ts:351:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "a=b"
Received: null
```

# Test source

```ts
  264 |   expect(response.status()).toBe(200);
  265 |   expect(await response.json()).toEqual({ 'foo': 'bar' });
  266 | });
  267 | 
  268 | it('should fulfill with fetch result', async ({ page, server, isElectron, electronMajorVersion, rewriteAndroidLoopbackURL }) => {
  269 |   it.skip(isElectron && electronMajorVersion < 30, 'error: Browser context management is not supported.');
  270 |   await page.route('**/*', async route => {
  271 |     const response = await page.request.get(rewriteAndroidLoopbackURL(server.PREFIX + '/simple.json'));
  272 |     void route.fulfill({ response });
  273 |   });
  274 |   const response = await page.goto(server.EMPTY_PAGE);
  275 |   expect(response.status()).toBe(200);
  276 |   expect(await response.json()).toEqual({ 'foo': 'bar' });
  277 | });
  278 | 
  279 | it('should fulfill with fetch result and overrides', async ({ page, server, isElectron, electronMajorVersion, rewriteAndroidLoopbackURL }) => {
  280 |   it.skip(isElectron && electronMajorVersion < 30, 'error: Browser context management is not supported.');
  281 |   await page.route('**/*', async route => {
  282 |     const response = await page.request.get(rewriteAndroidLoopbackURL(server.PREFIX + '/simple.json'));
  283 |     void route.fulfill({
  284 |       response,
  285 |       status: 201,
  286 |       headers: {
  287 |         'Content-Type': 'application/json', // Case matters for the tested behavior
  288 |         'foo': 'bar'
  289 |       }
  290 |     });
  291 |   });
  292 |   const response = await page.goto(server.EMPTY_PAGE);
  293 |   expect(response.status()).toBe(201);
  294 |   expect((await response.allHeaders()).foo).toEqual('bar');
  295 |   expect(await response.json()).toEqual({ 'foo': 'bar' });
  296 | });
  297 | 
  298 | it('should fetch original request and fulfill', async ({ page, server, isElectron, electronMajorVersion, isAndroid }) => {
  299 |   it.skip(isElectron && electronMajorVersion < 30, 'error: Browser context management is not supported.');
  300 |   it.skip(isAndroid, 'The internal Android localhost (10.0.0.2) != the localhost on the host');
  301 |   await page.route('**/*', async route => {
  302 |     const response = await page.request.fetch(route.request());
  303 |     void route.fulfill({
  304 |       response,
  305 |     });
  306 |   });
  307 |   const response = await page.goto(server.PREFIX + '/title.html');
  308 |   expect(response.status()).toBe(200);
  309 |   expect(await page.title()).toEqual('Woof-Woof');
  310 | });
  311 | 
  312 | it('should fulfill with multiple set-cookie', async ({ page, server, isElectron, electronMajorVersion, isAndroid }) => {
  313 |   it.skip(isElectron && electronMajorVersion < 14, 'Electron 14+ is required');
  314 |   it.skip(isAndroid, 'Android does not have an isolated context per test, so we get cookies from other tests');
  315 | 
  316 |   const cookies = ['a=b', 'c=d'];
  317 |   await page.route('**/multiple-set-cookie.html', async route => {
  318 |     void route.fulfill({
  319 |       status: 200,
  320 |       headers: {
  321 |         'X-Header-1': 'v1',
  322 |         'Set-Cookie': cookies.join('\n'),
  323 |         'X-Header-2': 'v2',
  324 |       },
  325 |       body: ''
  326 |     });
  327 |   });
  328 |   const response = await page.goto(server.PREFIX + '/multiple-set-cookie.html');
  329 |   expect((await page.evaluate(() => document.cookie)).split(';').map(s => s.trim()).sort()).toEqual(cookies);
  330 |   expect(await response.headerValue('X-Header-1')).toBe('v1');
  331 |   expect(await response.headerValue('X-Header-2')).toBe('v2');
  332 | });
  333 | 
  334 | it('should fulfill with fetch response that has multiple set-cookie', async ({ playwright, page, server, isAndroid }) => {
  335 |   it.fixme(isAndroid);
  336 |   server.setRoute('/empty.html', (req, res) => {
  337 |     res.setHeader('Set-Cookie', ['a=b', 'c=d']);
  338 |     res.setHeader('Content-Type', 'text/html');
  339 |     res.end();
  340 |   });
  341 |   await page.route('**/empty.html', async route => {
  342 |     const request = await playwright.request.newContext();
  343 |     const response = await request.fetch(route.request());
  344 |     void route.fulfill({ response });
  345 |   });
  346 |   await page.goto(server.EMPTY_PAGE);
  347 |   const cookie = await page.evaluate(() => document.cookie);
  348 |   expect(cookie.split(';').map(s => s.trim()).sort()).toEqual(['a=b', 'c=d']);
  349 | });
  350 | 
  351 | it('headerValue should return set-cookie from intercepted response', async ({ page, server, browserName }) => {
  352 |   it.fail(browserName === 'chromium', 'Set-Cookie is missing in response after interception');
  353 |   it.skip(browserName === 'webkit', 'Set-Cookie with \n in intercepted response does not pass validation in WebCore, see also https://github.com/microsoft/playwright/pull/9273');
  354 |   await page.route('**/empty.html', async route => {
  355 |     void route.fulfill({
  356 |       status: 200,
  357 |       headers: {
  358 |         'Set-Cookie': 'a=b',
  359 |       },
  360 |       body: ''
  361 |     });
  362 |   });
  363 |   const response = await page.goto(server.EMPTY_PAGE);
> 364 |   expect(await response.headerValue('Set-Cookie')).toBe('a=b');
      |                                                    ^ Error: expect(received).toBe(expected) // Object.is equality
  365 | });
  366 | 
  367 | it('should fulfill with har response', async ({ page, asset }) => {
  368 |   const harPath = asset('har-fulfill.har');
  369 |   const har = JSON.parse(await fs.promises.readFile(harPath, 'utf-8')) as har.HARFile;
  370 |   await page.route('**/*', async route => {
  371 |     const response = findResponse(har, route.request().url());
  372 |     const headers = {};
  373 |     for (const { name, value } of response.headers)
  374 |       headers[name] = value;
  375 |     await route.fulfill({
  376 |       status: response.status,
  377 |       headers,
  378 |       body: Buffer.from(response.content.text || '', (response.content.encoding as 'base64' | undefined) || 'utf-8'),
  379 |     });
  380 |   });
  381 |   await page.goto('http://no.playwright/');
  382 |   // HAR contains a redirect for the script.
  383 |   expect(await page.evaluate('window.value')).toBe('foo');
  384 |   // HAR contains a POST for the css file but we match ignoring the method, so the file should be served.
  385 |   await expect(page.locator('body')).toHaveCSS('background-color', 'rgb(0, 255, 255)');
  386 | });
  387 | 
  388 | function findResponse(har: har.HARFile, url: string): har.Response {
  389 |   let entry;
  390 |   const originalUrl = url;
  391 |   while (url.trim()) {
  392 |     entry = har.log.entries.find(entry => entry.request.url === url);
  393 |     url = entry?.response.redirectURL;
  394 |   }
  395 |   expect(entry, originalUrl).toBeTruthy();
  396 |   return entry?.response;
  397 | }
  398 | 
  399 | it('should fulfill preload link requests', async ({ page, server, browserName }) => {
  400 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/16745' });
  401 |   let intercepted = false;
  402 |   await page.route('**/one-style.css', route => {
  403 |     intercepted = true;
  404 |     void route.fulfill({
  405 |       status: 200,
  406 |       headers: {
  407 |         'content-type': 'text/css; charset=utf-8',
  408 |         'cache-control': 'no-cache, no-store',
  409 |         'custom': 'value'
  410 |       },
  411 |       body: 'body { background-color: green; }'
  412 |     });
  413 |   });
  414 |   const [response] = await Promise.all([
  415 |     page.waitForResponse('**/one-style.css'),
  416 |     page.goto(server.PREFIX + '/preload.html')
  417 |   ]);
  418 |   expect(await response.headerValue('custom')).toBe('value');
  419 |   await page.waitForFunction(() => (window as any).preloadedStyles);
  420 |   expect(intercepted).toBe(true);
  421 |   const color = await page.evaluate(() => window.getComputedStyle(document.body).backgroundColor);
  422 |   expect(color).toBe('rgb(0, 128, 0)');
  423 | });
  424 | 
  425 | it('should fulfill json', async ({ page, server }) => {
  426 |   await page.goto(server.EMPTY_PAGE);
  427 |   await page.route('**/data.json', route => {
  428 |     void route.fulfill({
  429 |       status: 201,
  430 |       headers: {
  431 |         foo: 'bar'
  432 |       },
  433 |       json: { bar: 'baz' },
  434 |     });
  435 |   });
  436 |   const [response, body] = await Promise.all([
  437 |     page.waitForResponse('**/*'),
  438 |     page.evaluate(() => fetch('./data.json').then(r => r.text()))
  439 |   ]);
  440 |   expect(response.status()).toBe(201);
  441 |   expect(response.headers()['content-type']).toBe('application/json');
  442 |   expect(body).toBe(JSON.stringify({ bar: 'baz' }));
  443 | });
  444 | 
  445 | it('should fulfill with gzip and readback', {
  446 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/29261' },
  447 | }, async ({ page, server, isAndroid, isElectron, electronMajorVersion }) => {
  448 |   it.skip(isAndroid, 'The internal Android localhost (10.0.0.2) != the localhost on the host');
  449 |   it.skip(isElectron && electronMajorVersion < 30, 'error: Browser context management is not supported.');
  450 |   server.enableGzip('/one-style.html');
  451 |   await page.route('**/one-style.html', async route => {
  452 |     const response = await route.fetch();
  453 |     expect(response.headers()['content-encoding']).toBe('gzip');
  454 |     await route.fulfill({ response });
  455 |   });
  456 | 
  457 |   const response = await page.goto(server.PREFIX + '/one-style.html');
  458 |   await expect(page.locator('div')).toHaveText('hello, world!');
  459 |   await expect(page.locator('body')).toHaveCSS('background-color', 'rgb(255, 192, 203)');
  460 |   expect(await response.text()).toContain(`<div>hello, world!</div>`);
  461 | });
  462 | 
  463 | it('should not go to the network for fulfilled requests body', {
  464 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/30760' },
```