# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/page-event-crash.spec.ts >> should cancel navigation when page crashes
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/page-event-crash.spec.ts:82:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "page.goto: Page crashed"
Received string:    "page.goto: Target page, context or browser has been closed
Call log:
  - navigating to \"http://localhost:10647/one-style.html\", waiting until \"load\"
"
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2017 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { utils } from '../../packages/playwright-core/lib/coreBundle';
  19  | import { contextTest as testBase, expect } from '../config/browserTest';
  20  | 
  21  | const test = testBase.extend<{ crash: () => void }, { dummy: string }>({
  22  |   crash: async ({ page, toImpl, browserName }, run) => {
  23  |     await run(() => {
  24  |       if (browserName === 'chromium')
  25  |         page.goto('chrome://crash').catch(e => {});
  26  |       else if (browserName === 'webkit')
  27  |         toImpl(page).delegate._session.send('Page.crash', {}).catch(e => {});
  28  |       else if (browserName === 'firefox')
  29  |         toImpl(page).delegate._session.send('Page.crash', {}).catch(e => {});
  30  |     });
  31  |   },
  32  |   // Force a separate worker to avoid messing up with other tests.
  33  |   dummy: ['', { scope: 'worker' }],
  34  | });
  35  | 
  36  | test.beforeEach(({ platform, browserName, channel }) => {
  37  |   test.slow(platform === 'linux' && (browserName === 'webkit'), 'WebKit/Linux tests are consistently slower on some Linux environments. Most likely WebContent process is not getting terminated properly and is causing the slowdown.');
  38  |   test.skip(channel === 'webkit-wsl', 'WebKit on WSL is even slower than above ^^ - skipping for now');
  39  |   test.skip(browserName === 'chromium' && utils.hostPlatform.startsWith('ubuntu24.04'), 'never dispatches the crash event');
  40  | });
  41  | 
  42  | test('should emit crash event when page crashes', async ({ page, crash }) => {
  43  |   await page.setContent(`<div>This page should crash</div>`);
  44  |   crash();
  45  |   const crashedPage = await new Promise(f => page.on('crash', f));
  46  |   expect(crashedPage).toBe(page);
  47  | });
  48  | 
  49  | test('should throw on any action after page crashes', async ({ page, crash, server, browserName }) => {
  50  |   await page.setContent(`<div>This page should crash</div>`);
  51  |   crash();
  52  |   await page.waitForEvent('crash');
  53  |   const expectCrashError = (error: Error | null) => {
  54  |     expect(error, 'action should reject after crash').toBeTruthy();
  55  |     // In Firefox, crashed page is sometimes "closed".
  56  |     if (browserName === 'firefox')
  57  |       expect(error!.message.includes('has been closed') || error!.message.includes('crashed'), error!.message).toBe(true);
  58  |     else
  59  |       expect(error!.message).toContain('crashed');
  60  |   };
  61  |   expectCrashError(await page.evaluate(() => {}).then(() => null, e => e));
  62  |   expectCrashError(await page.goto(server.EMPTY_PAGE).then(() => null, e => e));
  63  |   expectCrashError(await page.reload().then(() => null, e => e));
  64  | });
  65  | 
  66  | test('expect should not hang when page crashed', {
  67  |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/31907' },
  68  | }, async ({ page, crash }) => {
  69  |   const expectPromise = expect(page.getByText('child')).toBeVisible();
  70  |   crash();
  71  |   await expect(expectPromise).rejects.toThrowError();
  72  | });
  73  | 
  74  | test('should cancel waitForEvent when page crashes', async ({ page, crash }) => {
  75  |   await page.setContent(`<div>This page should crash</div>`);
  76  |   const promise = page.waitForEvent('response').catch(e => e);
  77  |   crash();
  78  |   const error = await promise;
  79  |   expect(error.message).toContain('Page crashed');
  80  | });
  81  | 
  82  | test('should cancel navigation when page crashes', async ({ server, page, crash }) => {
  83  |   await page.setContent(`<div>This page should crash</div>`);
  84  |   server.setRoute('/one-style.css', () => {});
  85  |   const promise = page.goto(server.PREFIX + '/one-style.html').catch(e => e);
  86  |   await page.waitForNavigation({ waitUntil: 'domcontentloaded' });
  87  |   crash();
  88  |   const error = await promise;
> 89  |   expect(error.message).toContain('page.goto: Page crashed');
      |                         ^ Error: expect(received).toContain(expected) // indexOf
  90  | });
  91  | 
  92  | test('should be able to close context when page crashes', async ({ isAndroid, page, crash }) => {
  93  |   test.skip(isAndroid);
  94  | 
  95  |   await page.setContent(`<div>This page should crash</div>`);
  96  |   crash();
  97  |   await page.waitForEvent('crash');
  98  |   await page.context().close();
  99  | });
  100 | 
  101 | test('should be able to close page after crash', async ({ page, crash }) => {
  102 |   await page.setContent(`<div>This page should crash</div>`);
  103 |   crash();
  104 |   await page.waitForEvent('crash');
  105 |   await page.close();
  106 |   expect(page.isClosed()).toBe(true);
  107 | });
  108 | 
  109 | test.fixme('should reject in-flight worker.evaluate when page crashes', async ({ page, crash, server }) => {
  110 |   await page.goto(server.EMPTY_PAGE);
  111 |   const [worker] = await Promise.all([
  112 |     page.waitForEvent('worker'),
  113 |     page.evaluate(() => new Worker(URL.createObjectURL(
  114 |         new Blob(['self.onmessage = () => {}'], { type: 'application/javascript' })))),
  115 |   ]);
  116 |   const evalPromise = worker.evaluate(() => new Promise(() => {})).catch((e: Error) => e); // never resolves in-worker
  117 |   crash();
  118 |   const error = await evalPromise as Error;
  119 |   expect(error.message).toContain('crash');
  120 | });
  121 | 
```