# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/chromium/connect-over-cdp.spec.ts >> should keep URL parameters when adding json/version
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/connect-over-cdp.spec.ts:286:5

# Error details

```
Test timeout of 30000ms exceeded.
```