# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/network-post-data.spec.ts >> should get post data for file/blob
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/network-post-data.spec.ts:89:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "file-contents"
Received: null
```

# Test source

```ts
  6   |  * You may obtain a copy of the License at
  7   |  *
  8   |  *     http://www.apache.org/licenses/LICENSE-2.0
  9   |  *
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import { test as it, expect } from './pageTest';
  18  | 
  19  | it('should return correct postData buffer for utf-8 body', async ({ page, server }) => {
  20  |   await page.goto(server.EMPTY_PAGE);
  21  |   const value = 'baẞ';
  22  |   const [request] = await Promise.all([
  23  |     page.waitForRequest('**'),
  24  |     page.evaluate(({ url, value }) => {
  25  |       const request = new Request(url, {
  26  |         method: 'POST',
  27  |         body: JSON.stringify(value),
  28  |       });
  29  |       request.headers.set('content-type', 'application/json;charset=UTF-8');
  30  |       return fetch(request);
  31  |     }, { url: server.PREFIX + '/title.html', value })
  32  |   ]);
  33  |   expect(request.postDataBuffer().equals(Buffer.from(JSON.stringify(value), 'utf-8'))).toBe(true);
  34  |   expect(request.postDataJSON()).toBe(value);
  35  | });
  36  | 
  37  | it('should return post data w/o content-type @smoke', async ({ page, server }) => {
  38  |   await page.goto(server.EMPTY_PAGE);
  39  |   const [request] = await Promise.all([
  40  |     page.waitForRequest('**'),
  41  |     page.evaluate(({ url }) => {
  42  |       const request = new Request(url, {
  43  |         method: 'POST',
  44  |         body: JSON.stringify({ value: 42 }),
  45  |       });
  46  |       request.headers.set('content-type', '');
  47  |       return fetch(request);
  48  |     }, { url: server.PREFIX + '/title.html' })
  49  |   ]);
  50  |   expect(request.postDataJSON()).toEqual({ value: 42 });
  51  | });
  52  | 
  53  | it('should throw on invalid JSON in post data', async ({ page, server }) => {
  54  |   await page.goto(server.EMPTY_PAGE);
  55  |   const [request] = await Promise.all([
  56  |     page.waitForRequest('**'),
  57  |     page.evaluate(({ url }) => {
  58  |       const request = new Request(url, {
  59  |         method: 'POST',
  60  |         body: '<not a json>',
  61  |       });
  62  |       return fetch(request);
  63  |     }, { url: server.PREFIX + '/title.html' })
  64  |   ]);
  65  |   let error;
  66  |   try {
  67  |     request.postDataJSON();
  68  |   } catch (e) {
  69  |     error = e;
  70  |   }
  71  |   expect(error.message).toContain('POST data is not a valid JSON object: <not a json>');
  72  | });
  73  | 
  74  | it('should return post data for PUT requests', async ({ page, server }) => {
  75  |   await page.goto(server.EMPTY_PAGE);
  76  |   const [request] = await Promise.all([
  77  |     page.waitForRequest('**'),
  78  |     page.evaluate(({ url }) => {
  79  |       const request = new Request(url, {
  80  |         method: 'PUT',
  81  |         body: JSON.stringify({ value: 42 }),
  82  |       });
  83  |       return fetch(request);
  84  |     }, { url: server.PREFIX + '/title.html' })
  85  |   ]);
  86  |   expect(request.postDataJSON()).toEqual({ value: 42 });
  87  | });
  88  | 
  89  | it('should get post data for file/blob', async ({ page, server, browserName }) => {
  90  |   it.fail(browserName === 'webkit' || browserName === 'chromium');
  91  |   await page.goto(server.EMPTY_PAGE);
  92  |   const [request] = await Promise.all([
  93  |     page.waitForRequest('**/*'),
  94  |     page.evaluate(() => {
  95  |       const file = new File(['file-contents'], 'filename.txt');
  96  | 
  97  |       void fetch('/data', {
  98  |         method: 'POST',
  99  |         headers: {
  100 |           'content-type': 'application/octet-stream'
  101 |         },
  102 |         body: file
  103 |       });
  104 |     })
  105 |   ]);
> 106 |   expect(request.postData()).toBe('file-contents');
      |                              ^ Error: expect(received).toBe(expected) // Object.is equality
  107 | });
  108 | 
  109 | it('should get post data for navigator.sendBeacon api calls', async ({ page, server, browserName }) => {
  110 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/12231' });
  111 |   it.fail(browserName === 'chromium', 'postData is empty');
  112 |   it.fail(browserName === 'webkit', 'postData is empty');
  113 |   await page.goto(server.EMPTY_PAGE);
  114 |   const [request] = await Promise.all([
  115 |     page.waitForRequest('**/*'),
  116 |     page.evaluate(() => navigator.sendBeacon(window.location.origin + '/api/foo', new Blob([JSON.stringify({ foo: 'bar' })])))
  117 |   ]);
  118 |   expect(request.method()).toBe('POST');
  119 |   expect(request.url()).toBe(server.PREFIX + '/api/foo');
  120 |   expect(request.postDataJSON()).toStrictEqual({ foo: 'bar' });
  121 | });
  122 | 
```