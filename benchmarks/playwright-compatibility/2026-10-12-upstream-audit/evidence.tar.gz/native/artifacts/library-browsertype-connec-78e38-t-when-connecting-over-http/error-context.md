# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-connect.spec.ts >> should timeout after redirect when connecting over http
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-connect.spec.ts:1165:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "Timeout 2000ms exceeded."
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  1072 |         expect(failed).toBe(true);
  1073 |       });
  1074 | 
  1075 |       test('should check proxy pattern on the client', async ({ connect, startRemoteServer, server, dummyServerPort }) => {
  1076 |         let reachedOriginalTarget = false;
  1077 |         server.setRoute('/foo.html', async (req, res) => {
  1078 |           reachedOriginalTarget = true;
  1079 |           res.end('<html><body>from-original-server</body></html>');
  1080 |         });
  1081 |         const remoteServer = await startRemoteServer(kind);
  1082 |         const browser = await connect(remoteServer.wsEndpoint(), {
  1083 |           exposeNetwork: '127.0.0.1',
  1084 |           headers: {
  1085 |             'x-playwright-proxy': '*',
  1086 |           },
  1087 |         }, dummyServerPort);
  1088 |         const page = await browser.newPage();
  1089 | 
  1090 |         // local.playwright should fail on the client side.
  1091 |         let failed = false;
  1092 |         await page.goto(`http://local.playwright:${server.PORT}/foo.html`).catch(e => {
  1093 |           failed = true;
  1094 |         });
  1095 |         expect(failed).toBe(true);
  1096 |         expect(reachedOriginalTarget).toBe(false);
  1097 |       });
  1098 |     });
  1099 |   });
  1100 | }
  1101 | 
  1102 | test.describe('launchServer only', () => {
  1103 |   test('should work with cluster', async ({ connect, startRemoteServer }) => {
  1104 |     const remoteServer = await startRemoteServer('launchServer', { inCluster: true });
  1105 |     const browser = await connect(remoteServer.wsEndpoint());
  1106 |     const page = await browser.newPage();
  1107 |     expect(await page.evaluate('1 + 2')).toBe(3);
  1108 |   });
  1109 | 
  1110 |   test('should properly disconnect when connection closes from the server side', async ({ connect, startRemoteServer, server, platform }) => {
  1111 |     test.skip(platform === 'win32', 'Cannot send signals');
  1112 | 
  1113 |     server.setRoute('/one-style.css', () => {});
  1114 |     const remoteServer = await startRemoteServer('launchServer', { disconnectOnSIGHUP: true });
  1115 |     const browser = await connect(remoteServer.wsEndpoint());
  1116 |     const page = await browser.newPage();
  1117 |     const navigationPromise = page.goto(server.PREFIX + '/one-style.html', { timeout: 60000 }).catch(e => e);
  1118 |     const waitForNavigationPromise = page.waitForNavigation().catch(e => e);
  1119 | 
  1120 |     const disconnectedPromise = new Promise(f => browser.once('disconnected', f));
  1121 |     // This closes the websocket server.
  1122 |     process.kill(remoteServer.child().pid, 'SIGHUP');
  1123 |     await disconnectedPromise;
  1124 |     expect(browser.isConnected()).toBe(false);
  1125 | 
  1126 |     expect((await navigationPromise).message).toContain('has been closed');
  1127 |     expect((await waitForNavigationPromise).message).toContain(kTargetClosedErrorMessage);
  1128 |     expect((await page.goto(server.EMPTY_PAGE).catch(e => e)).message).toContain('has been closed');
  1129 |     expect((await page.waitForNavigation().catch(e => e)).message).toContain(kTargetClosedErrorMessage);
  1130 |   });
  1131 | 
  1132 |   test('should be able to reconnect to a browser 12 times without warnings', async ({ connect, startRemoteServer, server }) => {
  1133 |     test.slow();
  1134 |     const remoteServer = await startRemoteServer('launchServer', { exitOnWarning: true });
  1135 |     for (let i = 0; i < 12; i++) {
  1136 |       await test.step('connect #' + i, async () => {
  1137 |         const browser = await connect(remoteServer.wsEndpoint());
  1138 |         const browserContext = await browser.newContext();
  1139 |         expect(browserContext.pages().length).toBe(0);
  1140 |         const page = await browserContext.newPage();
  1141 |         expect(await page.evaluate('11 * 11')).toBe(121);
  1142 |         await page.goto(server.EMPTY_PAGE);
  1143 |         await browser.close();
  1144 |       });
  1145 |     }
  1146 |   });
  1147 | 
  1148 |   test('cannot launch another browser', async ({ connect, startRemoteServer }) => {
  1149 |     const remoteServer = await startRemoteServer('launchServer');
  1150 |     const browser = await connect(remoteServer.wsEndpoint()) as any;
  1151 |     await expect(browser._parent.launch({ timeout: 0 })).rejects.toThrowError('Launching more browsers is not allowed.');
  1152 |   });
  1153 | });
  1154 | 
  1155 | test('should refuse connecting when versions do not match', async ({ connect, childProcess }) => {
  1156 |   const server = new RunServer();
  1157 |   await server.start(childProcess, { mode: 'default', env: { PW_VERSION_OVERRIDE: '1.2.3' } });
  1158 |   const error = await connect(server.wsEndpoint()).catch(e => e);
  1159 |   await server.close();
  1160 |   expect(error.message).toContain('Playwright version mismatch');
  1161 |   expect(error.message).toContain('server version: v1.2');
  1162 |   expect(error.message).toContain('client version: v' + getPlaywrightVersion(true));
  1163 | });
  1164 | 
  1165 | test('should timeout after redirect when connecting over http', async ({ connect, server }) => {
  1166 |   server.setRedirect('/connect/json', '/connect/slow');
  1167 |   let aborted = false;
  1168 |   server.setRoute('/connect/slow', (req, res) => {
  1169 |     req.socket.on('close', () => aborted = true);
  1170 |   });
  1171 |   const error = await connect(`${server.PREFIX}/connect`, { timeout: 2000, headers: { 'Connection': 'Close' } }).catch(e => e);
> 1172 |   expect(error.message).toContain('Timeout 2000ms exceeded.');
       |                         ^ Error: expect(received).toContain(expected) // indexOf
  1173 |   await expect.poll(() => aborted).toBe(true);
  1174 | });
  1175 | 
```