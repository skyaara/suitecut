# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-launch-server.spec.ts >> launch server >> should validate options
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-launch-server.spec.ts:29:5

# Error details

```
Error: expect(received).rejects.toThrow(expected)

Expected pattern: /channel: expected string, got object/
Received message: "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"

      221 |     if(process.env.COMPAT_BACKEND==='chromium') return use(original);
      222 |     await use(new Proxy(original, { get(target, name) {
    > 223 |       if (['launch', 'launchPersistentContext', 'launchServer', 'connect', 'connectOverCDP'].includes(String(name))) return async () => { throw new Error('SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness'); };
          |                                                                                                                                                 ^
      224 |       const value = Reflect.get(target, name); return typeof value === 'function' ? value.bind(target) : value;
      225 |     }}));
      226 |   }, { scope: 'worker' }],

      at Proxy.launchServer (../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/config/browserTest.ts:223:145)
      at ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-launch-server.spec.ts:30:30
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1644:15
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1133:17
      at TimeoutManager.withRunnable (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:404:9)
      at TestInfoImpl._runWithTimeout (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1131:34)
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1642:22
      at WorkerMain._runTest (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1615:5)
      at WorkerMain.runTestGroup (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1510:9)
      at process.<anonymous> (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/common/index.js:1997:25)
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2017 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { playwrightTest as it, expect } from '../config/browserTest';
  19  | 
  20  | it.describe('launch server', () => {
  21  |   it.skip(({ mode }) => mode !== 'default');
  22  | 
  23  |   it('should work', async ({ browserType }) => {
  24  |     const browserServer = await browserType.launchServer();
  25  |     expect(browserServer.wsEndpoint()).not.toBe(null);
  26  |     await browserServer.close();
  27  |   });
  28  | 
  29  |   it('should validate options', async ({ browserType }) => {
> 30  |     await expect(browserType.launchServer({ channel: null })).rejects.toThrow(/channel: expected string, got object/);
      |                                                                       ^ Error: expect(received).rejects.toThrow(expected)
  31  |   });
  32  | 
  33  |   it('should work with host', async ({ browserType }) => {
  34  |     const host = '0.0.0.0';
  35  |     const browserServer = await browserType.launchServer({ host });
  36  |     expect(browserServer.wsEndpoint()).toContain(String(host));
  37  |     await browserServer.close();
  38  |   });
  39  | 
  40  |   it('should work with port', async ({ browserType }, testInfo) => {
  41  |     const port = 8800 + testInfo.workerIndex;
  42  |     const browserServer = await browserType.launchServer({ port });
  43  |     expect(browserServer.wsEndpoint()).toContain(String(port));
  44  |     await browserServer.close();
  45  |   });
  46  | 
  47  |   it('should work with wsPath', async ({ browserType }) => {
  48  |     const wsPath = '/unguessable-token';
  49  |     const browserServer = await browserType.launchServer({ wsPath });
  50  |     expect(browserServer.wsEndpoint()).toMatch(/:\d+\/unguessable-token$/);
  51  |     await browserServer.close();
  52  |   });
  53  | 
  54  |   it('should work when wsPath is missing leading slash', async ({ browserType }) => {
  55  |     const wsPath = 'unguessable-token';
  56  |     const browserServer = await browserType.launchServer({ wsPath });
  57  |     expect(browserServer.wsEndpoint()).toMatch(/:\d+\/unguessable-token$/);
  58  |     await browserServer.close();
  59  |   });
  60  | 
  61  |   it('should default to random wsPath', async ({ browserType }) => {
  62  |     const browserServer = await browserType.launchServer();
  63  |     expect(browserServer.wsEndpoint()).toMatch(/:\d+\/[a-f\d]{32}$/);
  64  |     await browserServer.close();
  65  |   });
  66  | 
  67  |   it('should provide an error when ws endpoint is incorrect', async ({ browserType }) => {
  68  |     const browserServer = await browserType.launchServer();
  69  |     const error = await browserType.connect(browserServer.wsEndpoint() + '-foo').catch(e => e);
  70  |     await browserServer.close();
  71  |     expect(error.message).toContain('400 Bad Request');
  72  |   });
  73  | 
  74  |   it('should fire "close" event during kill', async ({ browserType }) => {
  75  |     const order = [];
  76  |     const browserServer = await browserType.launchServer();
  77  |     const closedPromise = new Promise<void>(f => browserServer.on('close', () => {
  78  |       order.push('closed');
  79  |       f();
  80  |     }));
  81  |     await Promise.all([
  82  |       browserServer.kill().then(() => order.push('killed')),
  83  |       closedPromise,
  84  |     ]);
  85  |     expect(order).toEqual(['closed', 'killed']);
  86  |   });
  87  | 
  88  |   it('should return child_process instance', async ({ browserType }) => {
  89  |     const browserServer = await browserType.launchServer();
  90  |     expect(browserServer.process().pid).toBeGreaterThan(0);
  91  |     await browserServer.close();
  92  |   });
  93  | 
  94  |   it('should fire close event', async ({ browserType }) => {
  95  |     const browserServer = await browserType.launchServer();
  96  |     const [result] = await Promise.all([
  97  |       // @ts-expect-error The signal parameter is not documented.
  98  |       new Promise(f => browserServer.on('close', (exitCode, signal) => f({ exitCode, signal }))),
  99  |       browserServer.close(),
  100 |     ]);
  101 |     expect(result['exitCode']).toBe(0);
  102 |     expect(result['signal']).toBe(null);
  103 |   });
  104 | 
  105 |   it('should log protocol', async ({ browserType }) => {
  106 |     const logs: string[] = [];
  107 |     const logger = {
  108 |       isEnabled(name: string) {
  109 |         return true;
  110 |       },
  111 |       log(name: string, severity: string, message: string) {
  112 |         logs.push(`${name}:${severity}:${message}`);
  113 |       }
  114 |     };
  115 | 
  116 |     const browserServer = await browserType.launchServer({ logger });
  117 |     await browserServer.close();
  118 | 
  119 |     expect(logs.some(log => log.startsWith('protocol:verbose:SEND ►'))).toBe(true);
  120 |     expect(logs.some(log => log.startsWith('protocol:verbose:◀ RECV'))).toBe(true);
  121 |   });
  122 | });
  123 | 
```