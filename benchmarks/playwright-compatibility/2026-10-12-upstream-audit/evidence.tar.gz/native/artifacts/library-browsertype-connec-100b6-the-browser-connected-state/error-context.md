# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-connect.spec.ts >> launchServer >> should set the browser connected state
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-connect.spec.ts:355:5

# Error details

```
Error: SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness
```

# Test source

```ts
  123 |       }
  124 |       return result;
  125 |     });
  126 |   },
  127 | 
  128 |   contextFactory: async ({ _contextFactory }, run) => {
  129 |     await run(async options => {
  130 |       const { context } = await _contextFactory(options);
  131 |       return context;
  132 |     });
  133 |   },
  134 | 
  135 |   createUserDataDir: async ({ mode }, run) => {
  136 |     const dirs: string[] = [];
  137 |     // We do not put user data dir in testOutputPath,
  138 |     // because we do not want to upload them as test result artifacts.
  139 |     //
  140 |     // Additionally, it is impossible to upload user data dir after test run:
  141 |     // - Firefox removes lock file later, presumably from another watchdog process?
  142 |     // - WebKit has circular symlinks that makes CI go crazy.
  143 |     await run(async () => {
  144 |       const dir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'playwright-test-'));
  145 |       dirs.push(dir);
  146 |       return dir;
  147 |     });
  148 |     await removeFolders(dirs);
  149 |   },
  150 | 
  151 |   launchPersistent: async ({ createUserDataDir, browserType, mode }, run) => {
  152 |     test.skip(mode !== 'default', 'Remote persistent contexts are not supported');
  153 | 
  154 |     let persistentContext: BrowserContext | undefined;
  155 |     await run(async options => {
  156 |       if (persistentContext)
  157 |         throw new Error('can only launch one persistent context');
  158 |       const userDataDir = await createUserDataDir();
  159 |       persistentContext = await browserType.launchPersistentContext(userDataDir, { ...options });
  160 |       const page = persistentContext.pages()[0];
  161 |       return { context: persistentContext, page };
  162 |     });
  163 |     if (persistentContext)
  164 |       await persistentContext.close();
  165 |   },
  166 | 
  167 |   startRemoteServer: async ({ childProcess, browserType, channel, mode }, run) => {
  168 |     test.skip(mode !== 'default', 'Starting remote server is not supported in remote modes');
  169 | 
  170 |     let server: PlaywrightServer | undefined;
  171 |     const fn = async (kind: 'launchServer' | 'run-server', options?: RemoteServerOptions) => {
  172 |       if (server)
  173 |         throw new Error('can only start one remote server');
  174 |       if (kind === 'launchServer') {
  175 |         const remoteServer = new RemoteServer();
  176 |         await remoteServer._start(childProcess, browserType, channel, options);
  177 |         server = remoteServer;
  178 |       } else {
  179 |         const runServer = new RunServer();
  180 |         await runServer.start(childProcess, { artifactsDir: options?.artifactsDir });
  181 |         server = runServer;
  182 |       }
  183 |       return server;
  184 |     };
  185 |     await run(fn as any);
  186 |     if (server) {
  187 |       await server.close();
  188 |       // Give any connected browsers a chance to disconnect to avoid
  189 |       // poisoning next test with quasy-alive browsers.
  190 |       await new Promise(f => setTimeout(f, 1000));
  191 |     }
  192 |   },
  193 |   pageWithHar: async ({ contextFactory }, use, testInfo) => {
  194 |     const pageWithHar = async (options: { outputPath?: string, content?: 'embed' | 'attach' | 'omit', omitContent?: boolean } = {}) => {
  195 |       const harPath = testInfo.outputPath(options.outputPath || 'test.har');
  196 |       const context = await contextFactory({ recordHar: { path: harPath, content: options.content, omitContent: options.omitContent }, ignoreHTTPSErrors: true });
  197 |       const page = await context.newPage();
  198 |       return {
  199 |         page,
  200 |         context,
  201 |         getLog: async () => {
  202 |           await context.close();
  203 |           return JSON.parse(fs.readFileSync(harPath).toString())['log'] as Log;
  204 |         },
  205 |         getZip: async () => {
  206 |           await context.close();
  207 |           return parseHar(harPath);
  208 |         },
  209 |       };
  210 |     };
  211 |     await use(pageWithHar);
  212 |   },
  213 | });
  214 | 
  215 | 
  216 | import { launchEngine } from '/workspace/suitecut/src/engine';
  217 | const suitecutTest = test.extend({
  218 |   isHeadlessShell: [async ({ suitecutEngine }, use) => { await use(!suitecutEngine); }, { scope: 'worker' }],
  219 |   browserType: [async ({ playwright, browserName }, use) => {
  220 |     const original = playwright[browserName];
  221 |     if(process.env.COMPAT_BACKEND==='chromium') return use(original);
  222 |     await use(new Proxy(original, { get(target, name) {
> 223 |       if (['launch', 'launchPersistentContext', 'launchServer', 'connect', 'connectOverCDP'].includes(String(name))) return async () => { throw new Error('SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness'); };
      |                                                                                                                                                 ^ Error: SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness
  224 |       const value = Reflect.get(target, name); return typeof value === 'function' ? value.bind(target) : value;
  225 |     }}));
  226 |   }, { scope: 'worker' }],
  227 |   suitecutEngine: [async ({}, use) => {
  228 |     if(process.env.COMPAT_BACKEND==='chromium') return use(undefined);
  229 |     const engine = await launchEngine({ executablePath: process.env.SUITECUT_NATIVE_EXECUTABLE!, width: 1280, height: 720, framesPerSecond: 30 });
  230 |     engine.source.onFailure?.(error => process.stderr.write(`SuiteCut native failure: ${error.message}\n`));
  231 |     try { await use(engine); } finally { await engine.close(); }
  232 |   }, { scope: 'worker' }],
  233 |   browser: [async ({ suitecutEngine, playwright }, use) => {
  234 |     if(suitecutEngine) return use(suitecutEngine.browser);
  235 |     const browser=await playwright.chromium.launch({headless:true,args:['--site-per-process']});try{await use(browser)}finally{await browser.close()}
  236 |   }, { scope: 'worker' }],
  237 | });
  238 | 
  239 | export const playwrightTest = suitecutTest;
  240 | export const browserTest = suitecutTest;
  241 | export const contextTest = suitecutTest;
  242 | 
  243 | export { expect } from '@playwright/test';
  244 | 
```