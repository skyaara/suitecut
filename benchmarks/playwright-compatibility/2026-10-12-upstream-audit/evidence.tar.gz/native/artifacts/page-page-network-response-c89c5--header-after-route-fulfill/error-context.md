# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-network-response.spec.ts >> should return set-cookie header after route.fulfill
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-network-response.spec.ts:293:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "a=b"
Received: undefined
```

# Test source

```ts
  207 |   for (const { name, value } of headers) {
  208 |     if (!actualHeaders[name])
  209 |       actualHeaders[name] = [];
  210 |     actualHeaders[name].push(value);
  211 |   }
  212 |   delete actualHeaders['Keep-Alive'];
  213 |   delete actualHeaders['keep-alive'];
  214 |   delete actualHeaders['Connection'];
  215 |   delete actualHeaders['connection'];
  216 |   delete actualHeaders['Date'];
  217 |   delete actualHeaders['date'];
  218 |   delete actualHeaders['Transfer-Encoding'];
  219 |   delete actualHeaders['transfer-encoding'];
  220 |   expect(actualHeaders).toEqual(expectedHeaders);
  221 | });
  222 | 
  223 | it('should report multiple set-cookie headers', async ({ page, server, isElectron, browserMajorVersion }) => {
  224 |   it.skip(isElectron && browserMajorVersion < 99, 'This needs Chromium >= 99');
  225 | 
  226 |   server.setRoute('/headers', (req, res) => {
  227 |     res.writeHead(200, {
  228 |       'Set-Cookie': ['a=b', 'c=d']
  229 |     });
  230 |     res.write('\r\n');
  231 |     res.end();
  232 |   });
  233 | 
  234 |   await page.goto(server.EMPTY_PAGE);
  235 |   const [response] = await Promise.all([
  236 |     page.waitForResponse('**/*'),
  237 |     page.evaluate(() => fetch('/headers'))
  238 |   ]);
  239 |   const headers = await response.headersArray();
  240 |   const cookies = headers.filter(({ name }) => name.toLowerCase() === 'set-cookie').map(({ value }) => value);
  241 |   expect(cookies).toEqual(['a=b', 'c=d']);
  242 |   expect(await response.headerValue('not-there')).toEqual(null);
  243 |   expect(await response.headerValue('set-cookie')).toEqual('a=b\nc=d');
  244 |   expect(await response.headerValues('set-cookie')).toEqual(['a=b', 'c=d']);
  245 | });
  246 | 
  247 | it('should behave the same way for headers and allHeaders', async ({ page, server, browserName, platform }) => {
  248 |   it.skip(browserName === 'webkit' && platform === 'win32', 'libcurl does not support non-set-cookie multivalue headers');
  249 |   server.setRoute('/headers', (req, res) => {
  250 |     const headers = {
  251 |       'Set-Cookie': ['a=b', 'c=d'],
  252 |       'header-a': ['a=b', 'c=d'],
  253 |       'Name-A': 'v1',
  254 |       'name-b': 'v4',
  255 |       'Name-a': 'v2',
  256 |       'name-A': 'v3',
  257 |     };
  258 |     // Chromium does not report set-cookie headers immediately, so they are missing from .headers()
  259 |     if (browserName === 'chromium')
  260 |       delete headers['Set-Cookie'];
  261 | 
  262 |     res.writeHead(200, headers);
  263 |     res.write('\r\n');
  264 |     res.end();
  265 |   });
  266 | 
  267 |   await page.goto(server.EMPTY_PAGE);
  268 |   const [response] = await Promise.all([
  269 |     page.waitForResponse('**/*'),
  270 |     page.evaluate(() => fetch('/headers'))
  271 |   ]);
  272 |   const allHeaders = await response.allHeaders();
  273 |   expect(response.headers()).toEqual(allHeaders);
  274 |   expect(allHeaders['header-a']).toEqual('a=b, c=d');
  275 |   expect(allHeaders['name-a']).toEqual('v1, v2, v3');
  276 |   expect(allHeaders['name-b']).toEqual('v4');
  277 | });
  278 | 
  279 | it('should provide a Response with a file URL', async ({ page, asset, isAndroid, isElectron, isWindows, browserName, mode, channel }) => {
  280 |   it.skip(isAndroid, 'No files on Android');
  281 |   it.skip(browserName === 'firefox', 'Firefox does return null for file:// URLs');
  282 |   it.skip(channel === 'webkit-wsl');
  283 | 
  284 |   const fileurl = url.pathToFileURL(asset('frames/two-frames.html')).href;
  285 |   const response = await page.goto(fileurl);
  286 |   if (isElectron || (browserName === 'chromium') || (browserName === 'webkit' && isWindows))
  287 |     expect(response.status()).toBe(200);
  288 |   else
  289 |     expect(response.status()).toBe(0);
  290 |   expect(response.ok()).toBe(true);
  291 | });
  292 | 
  293 | it('should return set-cookie header after route.fulfill', async ({ page, server, browserName }) => {
  294 |   it.fail(browserName === 'webkit' || browserName === 'chromium', 'https://github.com/microsoft/playwright/issues/11035');
  295 |   await page.route('**/*', async route => {
  296 |     await route.fulfill({
  297 |       status: 200,
  298 |       headers: {
  299 |         'set-cookie': 'a=b'
  300 |       },
  301 |       contentType: 'text/plain',
  302 |       body: ''
  303 |     });
  304 |   });
  305 |   const response = await page.goto(server.EMPTY_PAGE);
  306 |   const headers = await response.allHeaders();
> 307 |   expect(headers['set-cookie']).toBe('a=b');
      |                                 ^ Error: expect(received).toBe(expected) // Object.is equality
  308 | });
  309 | 
  310 | it('should return headers after route.fulfill', async ({ page, server }) => {
  311 |   await page.route('**/*', async route => {
  312 |     await route.fulfill({
  313 |       status: 200,
  314 |       headers: {
  315 |         'foo': 'bar',
  316 |         'content-language': 'en'
  317 |       },
  318 |       contentType: 'text/plain',
  319 |       body: 'done'
  320 |     });
  321 |   });
  322 |   const response = await page.goto(server.EMPTY_PAGE);
  323 |   expect(await response.allHeaders()).toEqual({
  324 |     'foo': 'bar',
  325 |     'content-type': 'text/plain',
  326 |     'content-length': '4',
  327 |     'content-language': 'en'
  328 |   });
  329 | });
  330 | 
  331 | it('should report if request was fromServiceWorker', async ({ page, server, isAndroid, isElectron }) => {
  332 |   it.skip(isAndroid || isElectron);
  333 |   {
  334 |     const res = await page.goto(server.PREFIX + '/serviceworkers/fetch/sw.html');
  335 |     expect(res.fromServiceWorker()).toBe(false);
  336 |   }
  337 |   await page.evaluate(() => window['activationPromise']);
  338 |   {
  339 |     const [res] = await Promise.all([
  340 |       page.waitForResponse(/example\.txt/),
  341 |       page.evaluate(() => fetch('/example.txt')),
  342 |     ]);
  343 |     expect(res.fromServiceWorker()).toBe(true);
  344 |   }
  345 | });
  346 | 
  347 | it('should return body for prefetch script', async ({ page, server, browserName }) => {
  348 |   it.skip(browserName === 'webkit', 'No prefetch in WebKit: https://caniuse.com/link-rel-prefetch');
  349 |   const [response] = await Promise.all([
  350 |     page.waitForResponse('**/prefetch.js'),
  351 |     page.goto(server.PREFIX + '/prefetch.html')
  352 |   ]);
  353 |   const body = await response.body();
  354 |   expect(body.toString()).toBe('// Scripts will be pre-fetched');
  355 | });
  356 | 
  357 | it('should bypass disk cache when page interception is enabled', async ({ page, server }) => {
  358 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/30000' });
  359 |   await page.goto(server.PREFIX + '/frames/one-frame.html');
  360 |   await page.route('**/api*', route => route.continue());
  361 |   {
  362 |     const requests = [];
  363 |     server.setRoute('/api', (req, res) => {
  364 |       requests.push(req);
  365 |       res.statusCode = 200;
  366 |       res.setHeader('content-type', 'text/plain');
  367 |       res.setHeader('cache-control', 'public, max-age=31536000');
  368 |       res.end('Hello');
  369 |     });
  370 |     for (let i = 0; i < 3; i++) {
  371 |       await it.step(`main frame iteration ${i}`, async () => {
  372 |         const respPromise = page.waitForResponse('**/api');
  373 |         await page.evaluate(async () => {
  374 |           const response = await fetch('/api');
  375 |           return response.status;
  376 |         });
  377 |         const response = await respPromise;
  378 |         expect(response.status()).toBe(200);
  379 |         expect(requests.length).toBe(i + 1);
  380 |       });
  381 |     }
  382 |   }
  383 | 
  384 |   {
  385 |     const requests = [];
  386 |     server.setRoute('/frame/api', (req, res) => {
  387 |       requests.push(req);
  388 |       res.statusCode = 200;
  389 |       res.setHeader('content-type', 'text/plain');
  390 |       res.setHeader('cache-control', 'public, max-age=31536000');
  391 |       res.end('Hello');
  392 |     });
  393 |     for (let i = 0; i < 3; i++) {
  394 |       await it.step(`subframe iteration ${i}`, async () => {
  395 |         const respPromise = page.waitForResponse('**/frame/api');
  396 |         await page.frame({ url: '**/frame.html' }).evaluate(async () => {
  397 |           const response = await fetch('/frame/api');
  398 |           return response.status;
  399 |         });
  400 |         const response = await respPromise;
  401 |         expect(response.status()).toBe(200);
  402 |         expect(requests.length).toBe(i + 1);
  403 |       });
  404 |     }
  405 |   }
  406 | });
  407 | 
```