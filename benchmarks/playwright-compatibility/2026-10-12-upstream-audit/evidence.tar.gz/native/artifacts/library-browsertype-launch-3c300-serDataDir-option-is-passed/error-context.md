# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-launch.spec.ts >> should throw if userDataDir option is passed
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-launch.spec.ts:34:3

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "userDataDir option is not supported in `browserType.launch`. Use `browserType.launchPersistentContext` instead"
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  1   | /**
  2   |  * Copyright 2017 Google Inc. All rights reserved.
  3   |  * Modifications copyright (c) Microsoft Corporation.
  4   |  *
  5   |  * Licensed under the Apache License, Version 2.0 (the "License");
  6   |  * you may not use this file except in compliance with the License.
  7   |  * You may obtain a copy of the License at
  8   |  *
  9   |  *     http://www.apache.org/licenses/LICENSE-2.0
  10  |  *
  11  |  * Unless required by applicable law or agreed to in writing, software
  12  |  * distributed under the License is distributed on an "AS IS" BASIS,
  13  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14  |  * See the License for the specific language governing permissions and
  15  |  * limitations under the License.
  16  |  */
  17  | 
  18  | import { playwrightTest as it, expect } from '../config/browserTest';
  19  | import type { Browser, BrowserContext, Page } from '@playwright/test';
  20  | import { kTargetClosedErrorMessage } from '../config/errors';
  21  | 
  22  | it('should reject all promises when browser is closed', async ({ browserType }) => {
  23  |   const browser = await browserType.launch();
  24  |   const page = await (await browser.newContext()).newPage();
  25  |   let error: Error | undefined;
  26  |   const neverResolves = page.evaluate(() => new Promise(r => {})).catch(e => error = e);
  27  |   await page.evaluate(() => new Promise(f => window.builtins.setTimeout(f, 0)));
  28  |   await browser.close();
  29  |   await neverResolves;
  30  |   // WebKit under task-set -c 1 is giving browser, rest are giving target.
  31  |   expect(error!.message).toContain(' closed');
  32  | });
  33  | 
  34  | it('should throw if userDataDir option is passed', async ({ browserType }) => {
  35  |   let waitError: Error | undefined;
  36  |   await browserType.launch({ userDataDir: 'random-path' } as any).catch(e => waitError = e);
> 37  |   expect(waitError!.message).toContain('userDataDir option is not supported in `browserType.launch`. Use `browserType.launchPersistentContext` instead');
      |                              ^ Error: expect(received).toContain(expected) // indexOf
  38  | });
  39  | 
  40  | it('should throw if userDataDir is passed as an argument', async ({ browserType }) => {
  41  |   let waitError: Error | undefined;
  42  |   await browserType.launch({ args: ['--user-data-dir=random-path', '--profile=random-path'] } as any).catch(e => waitError = e);
  43  |   expect(waitError!.message).toContain(`Pass userDataDir parameter to 'browserType.launchPersistentContext`);
  44  | });
  45  | 
  46  | it('should throw if port option is passed', async ({ browserType }) => {
  47  |   const error = await browserType.launch({ port: 1234 } as any).catch(e => e);
  48  |   expect(error!.message).toContain('Cannot specify a port without launching as a server.');
  49  | });
  50  | 
  51  | it('should throw if port option is passed for persistent context', async ({ browserType }) => {
  52  |   const error = await browserType.launchPersistentContext('foo', { port: 1234 } as any).catch(e => e);
  53  |   expect(error!.message).toContain('Cannot specify a port without launching as a server.');
  54  | });
  55  | 
  56  | it('should throw if page argument is passed', async ({ browserType, browserName, isBidi }) => {
  57  |   it.skip(browserName === 'firefox' && !isBidi);
  58  | 
  59  |   let waitError: Error | undefined;
  60  |   await browserType.launch({ args: ['http://example.com'] }).catch(e => waitError = e);
  61  |   expect(waitError!.message).toContain('can not specify page');
  62  | });
  63  | 
  64  | it('should reject if launched browser fails immediately', async ({ mode, browserType, asset, channel }) => {
  65  |   const error = await browserType.launch({ executablePath: asset('dummy_bad_browser_executable.js') }).catch(e => e);
  66  |   if (channel === 'webkit-wsl')
  67  |     expect(error.message).toContain('Failed to launch');
  68  |   else
  69  |     expect(error.message).toMatch(/browserType\.launch(.|\n)*(spawn UNKNOWN|spawn EFTYPE|Browser logs:)/gim);
  70  | });
  71  | 
  72  | it('should reject if executable path is invalid', async ({ browserType, mode }) => {
  73  |   let waitError: Error | undefined;
  74  |   await browserType.launch({ executablePath: 'random-invalid-path' }).catch(e => waitError = e);
  75  |   expect(waitError!.message).toContain('Failed to launch');
  76  | });
  77  | 
  78  | it('should handle timeout', async ({ browserType, mode }) => {
  79  |   it.skip(mode !== 'default');
  80  | 
  81  |   const options: any = { timeout: 5000, __testHookBeforeCreateBrowser: () => new Promise(f => setTimeout(f, 6000)) };
  82  |   const error = await browserType.launch(options).catch(e => e);
  83  |   expect(error!.message).toContain(`browserType.launch: Timeout 5000ms exceeded.`);
  84  |   expect(error!.message).toContain(`<launching>`);
  85  |   expect(error!.message).toContain(`<launched> pid=`);
  86  | });
  87  | 
  88  | it('should handle exception and report launch log', async ({ browserType, mode }) => {
  89  |   it.skip(mode !== 'default');
  90  | 
  91  |   const e = new Error('Dummy');
  92  |   const options = { __testHookBeforeCreateBrowser: () => { throw e; }, timeout: 15000 };
  93  |   const error = await browserType.launch(options).catch(e => e);
  94  |   expect(error.message).toContain('Dummy');
  95  |   expect(error.message).toContain('<launching>');
  96  | });
  97  | 
  98  | it('should accept objects as options', async ({ mode,   browserType }) => {
  99  |   // @ts-expect-error process is not a real option.
  100 |   const browser = await browserType.launch({ process });
  101 |   await browser.close();
  102 | });
  103 | 
  104 | it('should fire close event for all contexts', async ({ browserType }) => {
  105 |   const browser = await browserType.launch();
  106 |   const context = await browser.newContext();
  107 |   let closed = false;
  108 |   context.on('close', () => closed = true);
  109 |   await browser.close();
  110 |   expect(closed).toBe(true);
  111 | });
  112 | 
  113 | it('should be callable twice', async ({ browserType }) => {
  114 |   const browser = await browserType.launch();
  115 |   await Promise.all([
  116 |     browser.close(),
  117 |     browser.close(),
  118 |   ]);
  119 |   await browser.close();
  120 | });
  121 | 
  122 | it('should allow await using', async ({ browserType, nodeVersion }) => {
  123 |   it.skip(nodeVersion.major < 18);
  124 | 
  125 |   let b: Browser;
  126 |   let c: BrowserContext;
  127 |   let p: Page;
  128 |   {
  129 |     await using browser = await browserType.launch();
  130 |     b = browser;
  131 |     {
  132 |       await using context = await browser.newContext();
  133 |       c = context;
  134 |       {
  135 |         await using page = await context.newPage();
  136 |         p = page;
  137 |       }
```