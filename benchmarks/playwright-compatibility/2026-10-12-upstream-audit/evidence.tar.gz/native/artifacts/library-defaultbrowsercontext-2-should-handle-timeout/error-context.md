# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/defaultbrowsercontext-2.spec.ts >> should handle timeout
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/defaultbrowsercontext-2.spec.ts:195:3

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "browserType.launchPersistentContext: Timeout 5000ms exceeded."
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  98  |   const context = await browserType.launchPersistentContext(userDataDir);
  99  |   expect(fs.readdirSync(userDataDir).length).toBeGreaterThan(0);
  100 |   await context.close();
  101 |   expect(fs.readdirSync(userDataDir).length).toBeGreaterThan(0);
  102 | });
  103 | 
  104 | it('should accept relative userDataDir', async ({ createUserDataDir, browserType }) => {
  105 |   const userDataDir = await createUserDataDir();
  106 |   const context = await browserType.launchPersistentContext(path.relative(process.cwd(), path.join(userDataDir, 'foobar')));
  107 |   expect(fs.readdirSync(path.join(userDataDir, 'foobar')).length).toBeGreaterThan(0);
  108 |   await context.close();
  109 | });
  110 | 
  111 | it('should restore state from userDataDir', async ({ browserType, server, createUserDataDir, channel }) => {
  112 |   it.slow();
  113 |   it.fixme(channel === 'webkit-wsl', 'Pending local storage writes are lost on close, see https://github.com/microsoft/playwright-browsers/issues/2275');
  114 | 
  115 |   const userDataDir = await createUserDataDir();
  116 |   const browserContext = await browserType.launchPersistentContext(userDataDir);
  117 |   const page = await browserContext.newPage();
  118 |   await page.goto(server.EMPTY_PAGE);
  119 |   await page.evaluate(() => localStorage.hey = 'hello');
  120 |   // Browsers do not persist local storage immediately, they do it asynchronously in another process.
  121 |   // Navigate away to give it a chance to save (best-effort).
  122 |   await page.goto(server.EMPTY_PAGE);
  123 |   await browserContext.close();
  124 | 
  125 |   const browserContext2 = await browserType.launchPersistentContext(userDataDir);
  126 |   const page2 = await browserContext2.newPage();
  127 |   await page2.goto(server.EMPTY_PAGE);
  128 |   expect(await page2.evaluate(() => localStorage.hey)).toBe('hello');
  129 |   await browserContext2.close();
  130 | 
  131 |   const userDataDir2 = await createUserDataDir();
  132 |   const browserContext3 = await browserType.launchPersistentContext(userDataDir2);
  133 |   const page3 = await browserContext3.newPage();
  134 |   await page3.goto(server.EMPTY_PAGE);
  135 |   expect(await page3.evaluate(() => localStorage.hey)).not.toBe('hello');
  136 |   await browserContext3.close();
  137 | });
  138 | 
  139 | it('should create userDataDir if it does not exist', async ({ createUserDataDir, browserType }) => {
  140 |   const userDataDir = path.join(await createUserDataDir(), 'nonexisting');
  141 |   const context = await browserType.launchPersistentContext(userDataDir);
  142 |   await context.close();
  143 |   expect(fs.readdirSync(userDataDir).length).toBeGreaterThan(0);
  144 | });
  145 | 
  146 | it('should goto about:blank on relaunched persistent context', {
  147 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/41216' },
  148 | }, async ({ browserType, createUserDataDir, browserName, isBidi }) => {
  149 |   it.fixme(browserName === 'firefox' && !isBidi);
  150 | 
  151 |   const userDataDir = await createUserDataDir();
  152 | 
  153 |   const context1 = await browserType.launchPersistentContext(userDataDir);
  154 |   await context1.pages()[0].goto('about:blank');
  155 |   await context1.close();
  156 | 
  157 |   // When relaunching with an existing profile, Firefox session restore can race with the user's goto and cause "interrupted by another navigation".
  158 |   // This issue is timing-sensitive and might not fire on every run, so rely on CI's --repeat-each matrix for coverage.
  159 |   const context2 = await browserType.launchPersistentContext(userDataDir);
  160 |   await context2.pages()[0].goto('about:blank');
  161 |   expect(context2.pages()[0].url()).toBe('about:blank');
  162 |   await context2.close();
  163 | });
  164 | 
  165 | it('should have default URL when launching browser', async ({ launchPersistent }) => {
  166 |   const { context } = await launchPersistent();
  167 |   const urls = context.pages().map(page => page.url());
  168 |   expect(urls).toEqual(['about:blank']);
  169 | });
  170 | 
  171 | it('should throw if page argument is passed', async ({ browserType, server, createUserDataDir, browserName, isBidi }) => {
  172 |   it.skip(browserName === 'firefox' && !isBidi);
  173 | 
  174 |   const options = { args: [server.EMPTY_PAGE] };
  175 |   const error = await browserType.launchPersistentContext(await createUserDataDir(), options).catch(e => e);
  176 |   expect(error.message).toContain('can not specify page');
  177 | });
  178 | 
  179 | it('should have passed URL when launching with ignoreDefaultArgs: true', async ({ browserType, server, createUserDataDir, toImpl, browserName }) => {
  180 |   const userDataDir = await createUserDataDir();
  181 |   const args = (await toImpl(browserType).defaultArgs((browserType as any)._playwright._defaultLaunchOptions, 'persistent', userDataDir, 0)).filter(a => a !== 'about:blank');
  182 |   const options = {
  183 |     args: browserName === 'firefox' ? [...args, '-new-tab', server.EMPTY_PAGE] : [...args, server.EMPTY_PAGE],
  184 |     ignoreDefaultArgs: true,
  185 |   };
  186 |   const browserContext = await browserType.launchPersistentContext(userDataDir, options);
  187 |   if (!browserContext.pages().length)
  188 |     await browserContext.waitForEvent('page');
  189 |   await browserContext.pages()[0].waitForLoadState();
  190 |   const gotUrls = browserContext.pages().map(page => page.url());
  191 |   expect(gotUrls).toEqual([server.EMPTY_PAGE]);
  192 |   await browserContext.close();
  193 | });
  194 | 
  195 | it('should handle timeout', async ({ browserType, createUserDataDir }) => {
  196 |   const options: any = { timeout: 5000, __testHookBeforeCreateBrowser: () => new Promise(f => setTimeout(f, 6000)) };
  197 |   const error = await browserType.launchPersistentContext(await createUserDataDir(), options).catch(e => e);
> 198 |   expect(error.message).toContain(`browserType.launchPersistentContext: Timeout 5000ms exceeded.`);
      |                         ^ Error: expect(received).toContain(expected) // indexOf
  199 | });
  200 | 
  201 | it('should handle exception', async ({ browserType, createUserDataDir }) => {
  202 |   const e = new Error('Dummy');
  203 |   const options: any = { __testHookBeforeCreateBrowser: () => { throw e; } };
  204 |   const error = await browserType.launchPersistentContext(await createUserDataDir(), options).catch(e => e);
  205 |   expect(error.message).toContain('Dummy');
  206 | });
  207 | 
  208 | it('should fire close event for a persistent context', async ({ launchPersistent }) => {
  209 |   const { context } = await launchPersistent();
  210 |   let closed = false;
  211 |   context.on('close', () => closed = true);
  212 |   await context.close();
  213 |   expect(closed).toBe(true);
  214 | });
  215 | 
  216 | it('coverage should work', async ({ server, launchPersistent, browserName }) => {
  217 |   it.skip(browserName !== 'chromium');
  218 | 
  219 |   const { page } = await launchPersistent();
  220 |   await page.coverage.startJSCoverage();
  221 |   await page.goto(server.PREFIX + '/jscoverage/simple.html', { waitUntil: 'load' });
  222 |   const coverage = await page.coverage.stopJSCoverage();
  223 |   expect(coverage.length).toBe(1);
  224 |   expect(coverage[0].url).toContain('/jscoverage/simple.html');
  225 |   expect(coverage[0].functions.find(f => f.functionName === 'foo').ranges[0].count).toEqual(1);
  226 | });
  227 | 
  228 | it('should respect selectors', async ({ playwright, launchPersistent }) => {
  229 |   const defaultContextCSS = () => ({
  230 |     query(root, selector) {
  231 |       return root.querySelector(selector);
  232 |     },
  233 |     queryAll(root: HTMLElement, selector: string) {
  234 |       return Array.from(root.querySelectorAll(selector));
  235 |     }
  236 |   });
  237 |   await playwright.selectors.register('defaultContextCSS', defaultContextCSS);
  238 | 
  239 |   const { page } = await launchPersistent();
  240 |   await page.setContent(`<div>hello</div>`);
  241 |   expect(await page.innerHTML('css=div')).toBe('hello');
  242 |   expect(await page.innerHTML('defaultContextCSS=div')).toBe('hello');
  243 | });
  244 | 
  245 | it('should connect to a browser with the default page', async ({ browserType, createUserDataDir }) => {
  246 |   const options: any = { __testHookOnConnectToBrowser: () => new Promise(f => setTimeout(f, 3000)) };
  247 |   const context = await browserType.launchPersistentContext(await createUserDataDir(), options);
  248 |   expect(context.pages().length).toBe(1);
  249 |   await context.close();
  250 | });
  251 | 
  252 | it('should support har option', async ({ launchPersistent, asset }) => {
  253 |   const path = asset('har-fulfill.har');
  254 |   const { page } = await launchPersistent();
  255 |   await page.routeFromHAR(path);
  256 |   await page.goto('http://no.playwright/');
  257 |   // HAR contains a redirect for the script that should be followed automatically.
  258 |   expect(await page.evaluate('window.value')).toBe('foo');
  259 |   // HAR contains a POST for the css file that should not be used.
  260 |   await expect(page.locator('body')).toHaveCSS('background-color', 'rgb(255, 0, 0)');
  261 | });
  262 | 
  263 | it('user agent is up to date', async ({ launchPersistent, browser }) => {
  264 |   const { userAgent } = await (browser as any)._channel.defaultUserAgentForTest();
  265 |   const { context, page } = await launchPersistent();
  266 |   expect(await page.evaluate(() => navigator.userAgent)).toBe(userAgent);
  267 |   await context.close();
  268 | });
  269 | 
  270 | it('dialog.accept should work', {
  271 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/35663' }
  272 | }, async ({ launchPersistent }) => {
  273 |   const { context, page } = await launchPersistent();
  274 |   await page.goto('data:text/html,<html><title>Title</title><button onclick="alert(\'Alert\')">Button</button></html>');
  275 |   let shown = false;
  276 |   page.on('dialog', dialog => {
  277 |     shown = true;
  278 |     void dialog.accept();
  279 |   });
  280 |   await page.getByRole('button', { name: 'Button' }).click();
  281 |   expect(shown).toBe(true);
  282 |   await context.close();
  283 | });
  284 | 
  285 | it('CacheStorage entry should survive page.reload()', {
  286 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/41618' }
  287 | }, async ({ launchPersistent, server }) => {
  288 |   const { context, page } = await launchPersistent();
  289 |   await page.goto(server.EMPTY_PAGE);
  290 |   await page.evaluate(async () => {
  291 |     const cache = await caches.open('repro-cache');
  292 |     await cache.put('/meta', new Response('payload'));
  293 |   });
  294 | 
  295 |   await page.reload();
  296 | 
  297 |   const after = await page.evaluate(async () => {
  298 |     const cache = await caches.open('repro-cache');
```