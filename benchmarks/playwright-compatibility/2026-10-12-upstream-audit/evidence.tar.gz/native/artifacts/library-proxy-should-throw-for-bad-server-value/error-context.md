# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/proxy.spec.ts >> should throw for bad server value
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/proxy.spec.ts:21:3

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "proxy.server: expected string, got number"
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  1   | /**
  2   |  * Copyright (c) Microsoft Corporation.
  3   |  *
  4   |  * Licensed under the Apache License, Version 2.0 (the "License");
  5   |  * you may not use this file except in compliance with the License.
  6   |  * You may obtain a copy of the License at
  7   |  *
  8   |  * http://www.apache.org/licenses/LICENSE-2.0
  9   |  *
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import { setupSocksForwardingServer } from '../config/proxy';
  18  | import { playwrightTest as it, expect } from '../config/browserTest';
  19  | import net from 'net';
  20  | 
  21  | it('should throw for bad server value', async ({ browserType }) => {
  22  |   const error = await browserType.launch({
  23  |     // @ts-expect-error server must be a string
  24  |     proxy: { server: 123 }
  25  |   }).catch(e => e);
> 26  |   expect(error.message).toContain('proxy.server: expected string, got number');
      |                         ^ Error: expect(received).toContain(expected) // indexOf
  27  | });
  28  | 
  29  | it('should use proxy @smoke', async ({ browserType, server, mode }) => {
  30  |   server.setRoute('/target.html', async (req, res) => {
  31  |     res.end('<html><title>Served by the proxy</title></html>');
  32  |   });
  33  |   const browser = await browserType.launch({
  34  |     proxy: { server: server.HOST }
  35  |   });
  36  |   const page = await browser.newPage();
  37  |   await page.goto('http://non-existent.com/target.html');
  38  |   expect(await page.title()).toBe('Served by the proxy');
  39  |   await browser.close();
  40  | });
  41  | 
  42  | it('should use proxy for second page', async ({ browserType, server }) => {
  43  |   server.setRoute('/target.html', async (req, res) => {
  44  |     res.end('<html><title>Served by the proxy</title></html>');
  45  |   });
  46  |   const browser = await browserType.launch({
  47  |     proxy: { server: `localhost:${server.PORT}` }
  48  |   });
  49  | 
  50  |   const page = await browser.newPage();
  51  |   await page.goto('http://non-existent.com/target.html');
  52  |   expect(await page.title()).toBe('Served by the proxy');
  53  | 
  54  |   const page2 = await browser.newPage();
  55  |   await page2.goto('http://non-existent.com/target.html');
  56  |   expect(await page2.title()).toBe('Served by the proxy');
  57  | 
  58  |   await browser.close();
  59  | });
  60  | 
  61  | it('should work with IP:PORT notion', async ({ browserType, server }) => {
  62  |   server.setRoute('/target.html', async (req, res) => {
  63  |     res.end('<html><title>Served by the proxy</title></html>');
  64  |   });
  65  |   const browser = await browserType.launch({
  66  |     proxy: { server: `127.0.0.1:${server.PORT}` }
  67  |   });
  68  |   const page = await browser.newPage();
  69  |   await page.goto('http://non-existent.com/target.html');
  70  |   expect(await page.title()).toBe('Served by the proxy');
  71  |   await browser.close();
  72  | });
  73  | 
  74  | it.describe('should proxy local network requests', () => {
  75  |   for (const additionalBypass of [false, true]) {
  76  |     it.describe(additionalBypass ? 'with other bypasses' : 'by default', () => {
  77  |       for (const params of [
  78  |         {
  79  |           target: 'localhost',
  80  |           description: 'localhost',
  81  |         },
  82  |         {
  83  |           target: '127.0.0.1',
  84  |           description: 'loopback address',
  85  |         },
  86  |         {
  87  |           target: '169.254.3.4',
  88  |           description: 'link-local'
  89  |         }
  90  |       ]) {
  91  |         it(`${params.description}`, async ({ platform, browserName, browserType, server, proxyServer, channel }) => {
  92  |           it.skip(browserName === 'webkit' && platform === 'darwin' && ['localhost', '127.0.0.1'].includes(params.target) && additionalBypass, 'Mac webkit does not proxy localhost when bypass rules are set.');
  93  |           it.skip(channel?.startsWith('msedge'), 'times out while loading the page');
  94  | 
  95  |           const path = `/target-${additionalBypass}-${params.target}.html`;
  96  |           server.setRoute(path, async (req, res) => {
  97  |             res.end('<html><title>Served by the proxy</title></html>');
  98  |           });
  99  | 
  100 |           const url = `http://${params.target}:55555${path}`;
  101 |           proxyServer.forwardTo(server.PORT);
  102 |           const browser = await browserType.launch({
  103 |             proxy: { server: `localhost:${proxyServer.PORT}`, bypass: additionalBypass ? '1.non.existent.domain.for.the.test' : undefined }
  104 |           });
  105 | 
  106 |           const page = await browser.newPage();
  107 |           await page.goto(url);
  108 |           expect(proxyServer.requestUrls).toContain(url);
  109 |           expect(await page.title()).toBe('Served by the proxy');
  110 | 
  111 |           await page.goto('http://1.non.existent.domain.for.the.test/foo.html').catch(() => {});
  112 |           if (additionalBypass)
  113 |             expect(proxyServer.requestUrls).not.toContain('http://1.non.existent.domain.for.the.test/foo.html');
  114 |           else
  115 |             expect(proxyServer.requestUrls).toContain('http://1.non.existent.domain.for.the.test/foo.html');
  116 | 
  117 |           await browser.close();
  118 |         });
  119 |       }
  120 |     });
  121 |   }
  122 | });
  123 | 
  124 | for (const host of ['localhost', '127.0.0.1']) {
  125 |   it(`should allow bypassing ${host} requests`, async ({  browserType, server, proxyServer }) => {
  126 |     server.setRoute(`/proxied/target.html`, async (req, res) => {
```