# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/client-certificates.spec.ts >> browser >> persistentContext >> validate input
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/client-certificates.spec.ts:903:5

# Error details

```
Error: expect(received).rejects.toThrow(expected)

Expected substring: "None of cert, key, passphrase or pfx is specified"
Received message:   "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"

      221 |     if(process.env.COMPAT_BACKEND==='chromium') return use(original);
      222 |     await use(new Proxy(original, { get(target, name) {
    > 223 |       if (['launch', 'launchPersistentContext', 'launchServer', 'connect', 'connectOverCDP'].includes(String(name))) return async () => { throw new Error('SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness'); };
          |                                                                                                                                                 ^
      224 |       const value = Reflect.get(target, name); return typeof value === 'function' ? value.bind(target) : value;
      225 |     }}));
      226 |   }, { scope: 'worker' }],

      at Proxy.launchPersistentContext (../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/config/browserTest.ts:223:145)
      at ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/config/browserTest.ts:159:45
      at ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/client-certificates.spec.ts:906:9
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1644:9
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1133:11
      at TimeoutManager.withRunnable (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:403:14)
      at TestInfoImpl._runWithTimeout (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1131:7)
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1642:7
      at WorkerMain._runTest (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1615:5)
      at WorkerMain.runTestGroup (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1510:9)
      at process.<anonymous> (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/common/index.js:1997:25)
```

# Test source

```ts
  806 |       ignoreHTTPSErrors: true,
  807 |       clientCertificates: [{
  808 |         origin: new URL(serverURL).origin,
  809 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  810 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  811 |       }],
  812 |     });
  813 |     {
  814 |       await page.goto(serverURL.replace('127.0.0.1', 'local.playwright'));
  815 |       await expect(page.getByTestId('message')).toHaveText('Sorry, but you need to provide a client certificate to continue.');
  816 |       await expect(page.getByTestId('alpn-protocol')).toHaveText('h2');
  817 |       await expect(page.getByTestId('servername')).toHaveText('local.playwright');
  818 |     }
  819 |     {
  820 |       await page.goto(serverURL);
  821 |       await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  822 |       await expect(page.getByTestId('alpn-protocol')).toHaveText('h2');
  823 |     }
  824 |     await page.close();
  825 |   });
  826 | 
  827 |   test('support http2 if the browser only supports http1.1', async ({ browserType, browserName, startCCServer, asset }) => {
  828 |     test.skip(browserName !== 'chromium');
  829 |     const serverURL = await startCCServer({ http2: true, enableHTTP1FallbackWhenUsingHttp2: true });
  830 |     const browser = await browserType.launch({ args: ['--disable-http2'] });
  831 |     const page = await browser.newPage({
  832 |       ignoreHTTPSErrors: true,
  833 |       clientCertificates: [{
  834 |         origin: new URL(serverURL).origin,
  835 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  836 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  837 |       }],
  838 |     });
  839 |     {
  840 |       await page.goto(serverURL.replace('127.0.0.1', 'local.playwright'));
  841 |       await expect(page.getByTestId('message')).toHaveText('Sorry, but you need to provide a client certificate to continue.');
  842 |       await expect(page.getByTestId('alpn-protocol')).toHaveText('http/1.1');
  843 |     }
  844 |     {
  845 |       await page.goto(serverURL);
  846 |       await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  847 |       await expect(page.getByTestId('alpn-protocol')).toHaveText('http/1.1');
  848 |     }
  849 |     await browser.close();
  850 |   });
  851 | 
  852 |   test('should return target connection errors when using http2', async ({ browser, startCCServer, asset, browserName, isMac, nodeVersion }) => {
  853 |     test.skip(browserName === 'webkit' && isMac, 'WebKit on macOS does not proxy localhost');
  854 |     test.skip(nodeVersion.major < 20, 'http2.performServerHandshake is not supported in older Node.js versions');
  855 | 
  856 |     const serverURL = await startCCServer({ http2: true });
  857 |     const page = await browser.newPage({
  858 |       clientCertificates: [{
  859 |         origin: new URL(serverURL).origin,
  860 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  861 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  862 |       }],
  863 |     });
  864 |     await page.goto(serverURL);
  865 |     await expect(page.getByText('Playwright client-certificate error: self-signed certificate')).toBeVisible();
  866 |     await page.close();
  867 |   });
  868 | 
  869 |   test('should handle rejected certificate in handshake with HTTP/2', async ({ browser, asset, browserName, platform }) => {
  870 |     const server: http2.Http2SecureServer = createHttp2Server({
  871 |       key: fs.readFileSync(asset('client-certificates/server/server_key.pem')),
  872 |       cert: fs.readFileSync(asset('client-certificates/server/server_cert.pem')),
  873 |       ca: [fs.readFileSync(asset('client-certificates/server/server_cert.pem'))],
  874 |       requestCert: true,
  875 |     }, async (req: http2.Http2ServerRequest, res: http2.Http2ServerResponse) => {
  876 |       res.writeHead(200, { 'Content-Type': 'text/html' });
  877 |       res.end('Hello world');
  878 |     });
  879 | 
  880 |     await new Promise<void>(resolve => server.listen(0, 'localhost', resolve));
  881 |     const port = (server.address() as net.AddressInfo).port;
  882 |     const serverUrl = 'https://' + (browserName === 'webkit' && platform === 'darwin' ? 'local.playwright' : 'localhost') + ':' + port;
  883 | 
  884 |     const context = await browser.newContext({
  885 |       ignoreHTTPSErrors: true,
  886 |       clientCertificates: [{
  887 |         origin: 'https://just-there-that-the-client-certificates-proxy-server-is-getting-launched.com',
  888 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  889 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  890 |       }],
  891 |     });
  892 | 
  893 |     const page = await context.newPage();
  894 | 
  895 |     // This was triggering an unhandled error before.
  896 |     await page.goto(serverUrl).catch(() => {});
  897 | 
  898 |     await context.close();
  899 |     await new Promise<void>(resolve => server.close(() => resolve()));
  900 |   });
  901 | 
  902 |   test.describe('persistentContext', () => {
  903 |     test('validate input', async ({ launchPersistent }) => {
  904 |       test.slow();
  905 |       for (const [contextOptions, expected] of kValidationSubTests)
> 906 |         await expect(launchPersistent(contextOptions)).rejects.toThrow(expected);
      |                                                                ^ Error: expect(received).rejects.toThrow(expected)
  907 |     });
  908 | 
  909 |     test('should pass with matching certificates', async ({ launchPersistent, startCCServer, asset, browserName, isMac }) => {
  910 |       const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  911 |       const { page } = await launchPersistent({
  912 |         ignoreHTTPSErrors: true,
  913 |         clientCertificates: [{
  914 |           origin: new URL(serverURL).origin,
  915 |           certPath: asset('client-certificates/client/trusted/cert.pem'),
  916 |           keyPath: asset('client-certificates/client/trusted/key.pem'),
  917 |         }],
  918 |       });
  919 |       await page.goto(serverURL);
  920 |       await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  921 |     });
  922 |   });
  923 | });
  924 | 
```