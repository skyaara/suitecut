# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/chromium/connect-over-cdp.spec.ts >> should send extra headers with connect request
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/connect-over-cdp.spec.ts:253:5

# Error details

```
Test timeout of 30000ms exceeded.
```