# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsercontext-proxy.spec.ts >> should work when passing the proxy only on the context level
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsercontext-proxy.spec.ts:25:3

# Error details

```
TypeError: Cannot read properties of undefined (reading 'close')
```

# Test source

```ts
  1   | /**
  2   |  * Copyright (c) Microsoft Corporation.
  3   |  *
  4   |  * Licensed under the Apache License, Version 2.0 (the "License");
  5   |  * you may not use this file except in compliance with the License.
  6   |  * You may obtain a copy of the License at
  7   |  *
  8   |  * http://www.apache.org/licenses/LICENSE-2.0
  9   |  *
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import { browserTest as it, expect } from '../config/browserTest';
  18  | 
  19  | it.beforeEach(({ server }) => {
  20  |   server.setRoute('/target.html', async (req, res) => {
  21  |     res.end('<html><title>Served by the proxy</title></html>');
  22  |   });
  23  | });
  24  | 
  25  | it('should work when passing the proxy only on the context level', async ({ browserName, platform, browserType, server, proxyServer }) => {
  26  |   proxyServer.forwardTo(server.PORT);
  27  |   let browser;
  28  |   try {
  29  |     browser = await browserType.launch({
  30  |       proxy: undefined,
  31  |     });
  32  |     const context = await browser.newContext({
  33  |       proxy: { server: proxyServer.HOST }
  34  |     });
  35  | 
  36  |     const page = await context.newPage();
  37  |     await page.goto('http://non-existent.com/target.html');
  38  |     expect(proxyServer.requestUrls).toContain('http://non-existent.com/target.html');
  39  |     expect(await page.title()).toBe('Served by the proxy');
  40  |   } finally {
> 41  |     await browser.close();
      |                   ^ TypeError: Cannot read properties of undefined (reading 'close')
  42  |   }
  43  | });
  44  | 
  45  | it('should throw for bad server value', async ({ contextFactory }) => {
  46  |   const error = await contextFactory({
  47  |     // @ts-expect-error server must be a string
  48  |     proxy: { server: 123 }
  49  |   }).catch(e => e);
  50  |   expect(error.message).toContain('proxy.server: expected string, got number');
  51  | });
  52  | 
  53  | it('should use proxy', async ({ contextFactory, server, proxyServer }) => {
  54  |   proxyServer.forwardTo(server.PORT);
  55  |   const context = await contextFactory({
  56  |     proxy: { server: proxyServer.HOST }
  57  |   });
  58  |   const page = await context.newPage();
  59  |   await page.goto('http://non-existent.com/target.html');
  60  |   expect(proxyServer.requestUrls).toContain('http://non-existent.com/target.html');
  61  |   expect(await page.title()).toBe('Served by the proxy');
  62  |   await context.close();
  63  | });
  64  | 
  65  | it('should send secure cookies to subdomain.localhost', async ({ contextFactory, browserName, server, isWindows, proxyServer, channel }) => {
  66  |   proxyServer.forwardTo(server.PORT);
  67  |   const context = await contextFactory({
  68  |     proxy: { server: proxyServer.HOST },
  69  |   });
  70  |   server.setRoute('/set-cookie.html', async (req, res) => {
  71  |     res.setHeader('Set-Cookie', [`non-secure=1; HttpOnly`, `secure=1; HttpOnly; Secure`]);
  72  |     res.end();
  73  |   });
  74  |   server.setRoute('/read-cookie.html', async (req, res) => {
  75  |     res.setHeader('Content-Type', `text/html`);
  76  |     res.end(`<div>Cookie: ${req.headers.cookie.split(';').map(c => c.trim()).sort().join('; ')}</div>`);
  77  |   });
  78  | 
  79  |   const page = await context.newPage();
  80  | 
  81  |   await page.goto(`http://subdomain.localhost/set-cookie.html`);
  82  | 
  83  |   const cookies = await context.cookies('http://subdomain.localhost');
  84  |   expect(cookies.map(({ name, domain }) => ({ name, domain }))).toEqual([
  85  |     {
  86  |       name: 'non-secure',
  87  |       domain: 'subdomain.localhost',
  88  |     },
  89  |     ...((browserName === 'webkit' && (!isWindows || channel === 'webkit-wsl')) ? [] : [{
  90  |       name: 'secure',
  91  |       domain: 'subdomain.localhost',
  92  |     }]),
  93  |   ]);
  94  | 
  95  |   await page.goto(`http://subdomain.localhost/read-cookie.html`);
  96  |   await expect(page.locator('div')).toHaveText(browserName === 'webkit' ? 'Cookie: non-secure=1' : 'Cookie: non-secure=1; secure=1');
  97  | 
  98  |   await context.close();
  99  | });
  100 | 
  101 | it('should set cookie for top-level domain', {
  102 |   annotation: { type: 'issue', description: 'https://github.com/microsoft/playwright/issues/18362' }
  103 | }, async ({ contextFactory, server, proxyServer, browserName, isLinux, channel }) => {
  104 |   it.fixme(browserName === 'webkit' && (isLinux || channel === 'webkit-wsl'));
  105 | 
  106 |   proxyServer.forwardTo(server.PORT, { allowConnectRequests: true });
  107 |   const context = await contextFactory({
  108 |     proxy: { server: proxyServer.HOST }
  109 |   });
  110 |   server.setRoute('/empty.html', (req, res) => {
  111 |     res.setHeader('Set-Cookie', `name=val; Domain=codes; Path=/;`);
  112 |     res.end();
  113 |   });
  114 | 
  115 |   await context.request.get('http://codes/empty.html');
  116 |   const [cookie] = await context.cookies();
  117 |   expect(cookie).toBeTruthy();
  118 |   expect(cookie.name).toBe('name');
  119 |   expect(cookie.value).toBe('val');
  120 |   await context.close();
  121 | });
  122 | 
  123 | it.describe('should proxy local network requests', () => {
  124 |   for (const additionalBypass of [false, true]) {
  125 |     it.describe(additionalBypass ? 'with other bypasses' : 'by default', () => {
  126 |       for (const params of [
  127 |         {
  128 |           target: 'localhost',
  129 |           description: 'localhost',
  130 |         },
  131 |         {
  132 |           target: '127.0.0.1',
  133 |           description: 'loopback address',
  134 |         },
  135 |         {
  136 |           target: '169.254.3.4',
  137 |           description: 'link-local'
  138 |         }
  139 |       ]) {
  140 |         it(`${params.description}`, async ({ platform, browserName, contextFactory, server, proxyServer }) => {
  141 |           it.skip(browserName === 'webkit' && platform === 'darwin' && ['localhost', '127.0.0.1'].includes(params.target) && additionalBypass, 'Mac webkit does not proxy localhost when bypass rules are set');
```