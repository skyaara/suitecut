# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-goto.spec.ts >> should report raw buffer for main resource
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-goto.spec.ts:745:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "Ü (lowercase ü)"
Received: "Ãœ (lowercase Ã¼)"
```

# Page snapshot

```yaml
- generic [active] [ref=e1]: Ãœ (lowercase Ã¼)
```

# Test source

```ts
  655 |   const url = httpsServer.PREFIX + '/redirect/1.html';
  656 |   let error = null;
  657 |   try {
  658 |     await page.goto(url);
  659 |   } catch (e) {
  660 |     error = e;
  661 |   }
  662 |   expect(error.message).toContain(url);
  663 | });
  664 | 
  665 | it('should be able to navigate to a page controlled by service worker', async ({ page, server, isElectron }) => {
  666 |   it.skip(isElectron);
  667 |   await page.goto(server.PREFIX + '/serviceworkers/fetch/sw.html');
  668 |   await page.evaluate(() => window['activationPromise']);
  669 |   await page.goto(server.PREFIX + '/serviceworkers/fetch/sw.html');
  670 | });
  671 | 
  672 | it('should send referer', async ({ page, server }) => {
  673 |   const [request1, request2] = await Promise.all([
  674 |     server.waitForRequest('/grid.html'),
  675 |     server.waitForRequest('/digits/1.png'),
  676 |     page.goto(server.PREFIX + '/grid.html', {
  677 |       referer: 'http://google.com/',
  678 |     }),
  679 |   ]);
  680 |   expect(request1.headers['referer']).toBe('http://google.com/');
  681 |   // Make sure subresources do not inherit referer.
  682 |   expect(request2.headers['referer']).toBe(server.PREFIX + '/grid.html');
  683 |   expect(page.url()).toBe(server.PREFIX + '/grid.html');
  684 | });
  685 | 
  686 | it('should send referer of cross-origin URL', async ({ page, server }) => {
  687 |   it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/27765' });
  688 |   const [request1, request2] = await Promise.all([
  689 |     server.waitForRequest('/grid.html'),
  690 |     server.waitForRequest('/digits/1.png'),
  691 |     page.goto(server.PREFIX + '/grid.html', {
  692 |       referer: 'https://microsoft.com/xbox/'
  693 |     }),
  694 |   ]);
  695 |   expect(request1.headers['referer']).toBe('https://microsoft.com/xbox/');
  696 |   // Make sure subresources do not inherit referer.
  697 |   expect(request2.headers['referer']).toBe(server.PREFIX + '/grid.html');
  698 |   expect(page.url()).toBe(server.PREFIX + '/grid.html');
  699 | });
  700 | 
  701 | it('should reject referer option when setExtraHTTPHeaders provides referer', async ({ page, server }) => {
  702 |   await page.setExtraHTTPHeaders({ 'referer': 'http://microsoft.com/' });
  703 |   let error;
  704 |   await page.goto(server.PREFIX + '/grid.html', {
  705 |     referer: 'http://google.com/',
  706 |   }).catch(e => error = e);
  707 |   expect(error.message).toContain('"referer" is already specified as extra HTTP header');
  708 |   expect(error.message).toContain(server.PREFIX + '/grid.html');
  709 | });
  710 | 
  711 | it('should override referrer-policy', async ({ page, server }) => {
  712 |   server.setRoute('/grid.html', (req, res) => {
  713 |     res.setHeader('Referrer-Policy', 'no-referrer');
  714 |     server.serveFile(req, res);
  715 |   });
  716 |   const [request1, request2] = await Promise.all([
  717 |     server.waitForRequest('/grid.html'),
  718 |     server.waitForRequest('/digits/1.png'),
  719 |     page.goto(server.PREFIX + '/grid.html', {
  720 |       referer: 'http://microsoft.com/',
  721 |     }),
  722 |   ]);
  723 |   expect(request1.headers['referer']).toBe('http://microsoft.com/');
  724 |   // Make sure subresources do not inherit referer.
  725 |   expect(request2.headers['referer']).toBe(undefined);
  726 |   expect(page.url()).toBe(server.PREFIX + '/grid.html');
  727 | });
  728 | 
  729 | it('should fail when canceled by another navigation', async ({ page, server }) => {
  730 |   server.setRoute('/one-style.html', (req, res) => {});
  731 |   const failed = page.goto(server.PREFIX + '/one-style.html').catch(e => e);
  732 |   await server.waitForRequest('/one-style.html');
  733 |   await page.goto(server.PREFIX + '/empty.html');
  734 |   const error = await failed;
  735 |   expect(error.message).toBeTruthy();
  736 | });
  737 | 
  738 | it('should work with lazy loading iframes', async ({ page, server, isAndroid }) => {
  739 |   it.fixme(isAndroid);
  740 | 
  741 |   await page.goto(server.PREFIX + '/frames/lazy-frame.html');
  742 |   expect(page.frames().length).toBe(2);
  743 | });
  744 | 
  745 | it('should report raw buffer for main resource', async ({ page, server, browserName, platform, channel }) => {
  746 |   it.fail(browserName === 'chromium', 'Chromium sends main resource as text');
  747 |   it.fail(browserName === 'webkit' && platform === 'win32' && channel !== 'webkit-wsl', 'Same here');
  748 | 
  749 |   server.setRoute('/empty.html', (req, res) => {
  750 |     res.statusCode = 200;
  751 |     res.end(Buffer.from('Ü (lowercase ü)', 'utf-8'));
  752 |   });
  753 |   const response = await page.goto(server.PREFIX + '/empty.html');
  754 |   const body = await response.body();
> 755 |   expect(body.toString()).toBe('Ü (lowercase ü)');
      |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  756 | });
  757 | 
  758 | it('should not throw unhandled rejections on invalid url', async ({ page, server }) => {
  759 |   const e = await page.goto('https://www.youtube Panel Title.com/').catch(e => e);
  760 |   expect(e.toString()).toContain('Panel Title');
  761 | });
  762 | 
  763 | it('should not crash when RTCPeerConnection is used', async ({ page, server, browserName, platform }) => {
  764 |   server.setRoute('/rtc.html', (_, res) => {
  765 |     res.end(`
  766 |       <!DOCTYPE html>
  767 |       <html>
  768 |         <body>
  769 |           <script>
  770 |             window.RTCPeerConnection && new window.RTCPeerConnection({
  771 |               iceServers: []
  772 |             });
  773 |           </script>
  774 |         </body>
  775 |       </html>
  776 | `);
  777 |   });
  778 |   await page.goto(server.PREFIX + '/rtc.html');
  779 |   await page.evaluate(() => {
  780 |     // RTCPeerConnection is not present on WebKit Linux
  781 |     window.RTCPeerConnection && new window.RTCPeerConnection({
  782 |       iceServers: []
  783 |     });
  784 |   });
  785 | });
  786 | 
  787 | it('should properly wait for load', async ({ page, server, browserName }) => {
  788 |   server.setRoute('/slow.js', async (req, res) => {
  789 |     await new Promise(x => setTimeout(x, 100));
  790 |     res.writeHead(200, { 'Content-Type': 'application/javascript' });
  791 |     res.end(`window.results.push('slow module');export const foo = 'slow';`);
  792 |   });
  793 |   await page.goto(server.PREFIX + '/load-event/load-event.html');
  794 |   const results = await page.evaluate('window.results');
  795 |   expect(results).toEqual([
  796 |     'script tag after after module',
  797 |     'slow module',
  798 |     'module',
  799 |     'DOMContentLoaded',
  800 |     'load'
  801 |   ]);
  802 | });
  803 | 
  804 | it('should not resolve goto upon window.stop()', async ({ browserName, page, server, isBidi }) => {
  805 |   it.fixme(browserName === 'firefox' && !isBidi, 'load/domcontentloaded events are flaky');
  806 |   it.skip(process.env.PW_CLOCK === 'frozen');
  807 | 
  808 |   let response;
  809 |   server.setRoute('/module.js', (req, res) => {
  810 |     res.writeHead(200, { 'Content-Type': 'text/javascript' });
  811 |     response = res;
  812 |   });
  813 |   let done = false;
  814 |   page.goto(server.PREFIX + '/window-stop.html').then(() => done = true).catch(() => {});
  815 |   await server.waitForRequest('/module.js');
  816 |   expect(done).toBe(false);
  817 |   await page.waitForTimeout(1000);  // give it some time to erroneously resolve
  818 |   response.end('');
  819 |   await page.waitForTimeout(1000);  // give it more time to erroneously resolve
  820 |   expect(done).toBe(false);
  821 | });
  822 | 
  823 | it('should return from goto if new navigation is started', async ({ page, server, browserName, isAndroid }) => {
  824 |   it.fixme(isAndroid);
  825 |   server.setRoute('/slow.js', async (req, res) => void 0);
  826 |   let finished = false;
  827 |   const navigation = page.goto(server.PREFIX + '/load-event/load-event.html').then(r => {
  828 |     finished = true;
  829 |     return r;
  830 |   });
  831 |   await new Promise(r => setTimeout(r, 500));
  832 |   expect(finished).toBeFalsy();
  833 |   await page.goto(server.EMPTY_PAGE);
  834 |   expect((await navigation).status()).toBe(200);
  835 | });
  836 | 
  837 | it('should return when navigation is committed if commit is specified', async ({ page, server }) => {
  838 |   server.setRoute('/script.js', (req, res) => {});
  839 |   server.setRoute('/empty.html', (req, res) => {
  840 |     res.setHeader('content-type', 'text/html');
  841 |     res.end('<title>Hello</title><script src="script.js"></script>');
  842 |   });
  843 |   const response = await page.goto(server.EMPTY_PAGE, { waitUntil: 'commit' });
  844 |   expect(response.status()).toBe(200);
  845 |   expect(await page.title()).toBe('Hello');
  846 | });
  847 | 
  848 | it('should wait for load when iframe attaches and detaches', async ({ page, server }) => {
  849 |   it.skip(process.env.PW_CLOCK === 'frozen');
  850 |   server.setRoute('/empty.html', (req, res) => {
  851 |     res.writeHead(200, { 'content-type': 'text/html' });
  852 |     res.end(`
  853 |       <body>
  854 |         <script>
  855 |           const iframe = document.createElement('iframe');
```