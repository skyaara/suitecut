# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/chromium/launcher.spec.ts >> should throw with remote-debugging-pipe argument
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/launcher.spec.ts:19:3

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "Playwright manages remote debugging connection itself"
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  1  | /**
  2  |  * Copyright 2019 Google Inc. All rights reserved.
  3  |  *
  4  |  * Licensed under the Apache License, Version 2.0 (the "License");
  5  |  * you may not use this file except in compliance with the License.
  6  |  * You may obtain a copy of the License at
  7  |  *
  8  |  *     http://www.apache.org/licenses/LICENSE-2.0
  9  |  *
  10 |  * Unless required by applicable law or agreed to in writing, software
  11 |  * distributed under the License is distributed on an "AS IS" BASIS,
  12 |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13 |  * See the License for the specific language governing permissions and
  14 |  * limitations under the License.
  15 |  */
  16 | 
  17 | import { playwrightTest as it, expect } from '../../config/browserTest';
  18 | 
  19 | it('should throw with remote-debugging-pipe argument', async ({ browserType, mode }) => {
  20 |   it.skip(mode !== 'default');
  21 | 
  22 |   const options: any = {};
  23 |   options.args = ['--remote-debugging-pipe'].concat(options.args || []);
  24 |   const error = await browserType.launchServer(options).catch(e => e);
> 25 |   expect(error.message).toContain('Playwright manages remote debugging connection itself');
     |                         ^ Error: expect(received).toContain(expected) // indexOf
  26 | });
  27 | 
  28 | it('should not throw with remote-debugging-port argument', async ({ browserType, mode }) => {
  29 |   it.skip(mode !== 'default');
  30 | 
  31 |   const options: any = {};
  32 |   options.args = ['--remote-debugging-port=0'].concat(options.args || []);
  33 |   const browser = await browserType.launchServer(options);
  34 |   await browser.close();
  35 | });
  36 | 
  37 | it('should not create pages automatically', async ({ browserType }) => {
  38 |   const browser = await browserType.launch();
  39 |   const browserSession = await browser.newBrowserCDPSession();
  40 |   const targets = [];
  41 |   browserSession.on('Target.targetCreated', async ({ targetInfo }) => {
  42 |     if (targetInfo.type !== 'browser')
  43 |       targets.push(targetInfo);
  44 |   });
  45 |   await browserSession.send('Target.setDiscoverTargets', { discover: true });
  46 |   await browser.newContext();
  47 |   await browser.close();
  48 |   expect(targets.length).toBe(0);
  49 | });
  50 | 
```