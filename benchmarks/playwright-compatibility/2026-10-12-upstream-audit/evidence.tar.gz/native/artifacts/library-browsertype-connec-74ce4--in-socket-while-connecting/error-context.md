# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-connect.spec.ts >> launchServer >> should timeout in socket while connecting
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-connect.spec.ts:238:5

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "browserType.connect: Timeout 1000ms exceeded"
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  142 |       const remoteServer = await startRemoteServer(kind);
  143 |       {
  144 |         const browser = await connect(remoteServer.wsEndpoint());
  145 |         const browserContext = await browser.newContext();
  146 |         expect(browserContext.pages().length).toBe(0);
  147 |         const page = await browserContext.newPage();
  148 |         expect(await page.evaluate('11 * 11')).toBe(121);
  149 |         await page.goto(server.EMPTY_PAGE);
  150 |         await browser.close();
  151 |       }
  152 |       {
  153 |         const browser = await connect(remoteServer.wsEndpoint());
  154 |         const browserContext = await browser.newContext();
  155 |         const page = await browserContext.newPage();
  156 |         await page.goto(server.EMPTY_PAGE);
  157 |         await browser.close();
  158 |       }
  159 |     });
  160 | 
  161 |     test('should not crash on malformed json frame', async ({ connect, startRemoteServer }) => {
  162 |       const remoteServer = await startRemoteServer(kind);
  163 |       const ws = new WebSocket(remoteServer.wsEndpoint());
  164 |       await new Promise<void>((resolve, reject) => {
  165 |         ws.once('open', resolve);
  166 |         ws.once('error', reject);
  167 |       });
  168 |       ws.send(']');
  169 |       await new Promise<void>(resolve => ws.once('close', () => resolve()));
  170 |       // Server should still be alive and accept new connections.
  171 |       const browser = await connect(remoteServer.wsEndpoint());
  172 |       const page = await browser.newPage();
  173 |       expect(await page.evaluate('1 + 2')).toBe(3);
  174 |       await browser.close();
  175 |     });
  176 | 
  177 |     test('should be able to visit ipv6', async ({ connect, startRemoteServer, ipV6ServerPort, channel }) => {
  178 |       test.fail(!!process.env.INSIDE_DOCKER, 'docker does not support IPv6 by default');
  179 |       test.fail(channel === 'webkit-wsl', 'WebKit on WSL does not support IPv6: https://github.com/microsoft/WSL/issues/10803');
  180 |       const remoteServer = await startRemoteServer(kind);
  181 |       const browser = await connect(remoteServer.wsEndpoint());
  182 |       const page = await browser.newPage();
  183 |       const ipV6Url = 'http://[::1]:' + ipV6ServerPort;
  184 |       await page.goto(ipV6Url);
  185 |       expect(await page.content()).toContain('from-ipv6-server');
  186 |       await browser.close();
  187 |     });
  188 | 
  189 |     test('should ignore page.pause when headed', async ({ connect, startRemoteServer, browserType, channel }) => {
  190 |       test.skip(channel === 'chromium-headless-shell', 'shell is never headed');
  191 | 
  192 |       const headless = (browserType as any)._playwright._defaultLaunchOptions.headless;
  193 |       (browserType as any)._playwright._defaultLaunchOptions.headless = false;
  194 |       const remoteServer = await startRemoteServer(kind);
  195 |       const browser = await connect(remoteServer.wsEndpoint());
  196 |       const browserContext = await browser.newContext();
  197 |       const page = await browserContext.newPage();
  198 |       // @ts-ignore
  199 |       await page.pause({ __testHookKeepTestTimeout: true });
  200 |       await browser.close();
  201 |       (browserType as any)._playwright._defaultLaunchOptions.headless = headless;
  202 |     });
  203 | 
  204 |     test('should be able to visit ipv6 through localhost', async ({ connect, startRemoteServer, ipV6ServerPort, channel }) => {
  205 |       test.fail(!!process.env.INSIDE_DOCKER, 'docker does not support IPv6 by default');
  206 |       test.skip(channel === 'webkit-wsl', 'WebKit on WSL does not support IPv6: https://github.com/microsoft/WSL/issues/10803');
  207 |       const remoteServer = await startRemoteServer(kind);
  208 |       const browser = await connect(remoteServer.wsEndpoint());
  209 |       const page = await browser.newPage();
  210 |       const ipV6Url = 'http://localhost:' + ipV6ServerPort;
  211 |       await page.goto(ipV6Url);
  212 |       expect(await page.content()).toContain('from-ipv6-server');
  213 |       await browser.close();
  214 |     });
  215 | 
  216 |     test('should be able to connect two browsers at the same time', async ({ connect, startRemoteServer }) => {
  217 |       const remoteServer = await startRemoteServer(kind);
  218 | 
  219 |       const browser1 = await connect(remoteServer.wsEndpoint());
  220 |       expect(browser1.contexts().length).toBe(0);
  221 |       await browser1.newContext();
  222 |       expect(browser1.contexts().length).toBe(1);
  223 | 
  224 |       const browser2 = await connect(remoteServer.wsEndpoint());
  225 |       expect(browser2.contexts().length).toBe(0);
  226 |       await browser2.newContext();
  227 |       expect(browser2.contexts().length).toBe(1);
  228 |       expect(browser1.contexts().length).toBe(1);
  229 | 
  230 |       await browser1.close();
  231 |       expect(browser2.contexts().length).toBe(1);
  232 |       const page2 = await browser2.newPage();
  233 |       expect(await page2.evaluate(() => 7 * 6)).toBe(42); // original browser should still work
  234 | 
  235 |       await browser2.close();
  236 |     });
  237 | 
  238 |     test('should timeout in socket while connecting', async ({ connect, server }) => {
  239 |       const e = await connect(`ws://localhost:${server.PORT}/ws-slow`, {
  240 |         timeout: 1000,
  241 |       }).catch(e => e);
> 242 |       expect(e.message).toContain('browserType.connect: Timeout 1000ms exceeded');
      |                         ^ Error: expect(received).toContain(expected) // indexOf
  243 |     });
  244 | 
  245 |     test('should timeout in connect while connecting', async ({ connect, server }) => {
  246 |       const e = await connect(`ws://localhost:${server.PORT}/ws`, {
  247 |         timeout: 100,
  248 |       }).catch(e => e);
  249 |       expect(e.message).toContain('browserType.connect: Timeout 100ms exceeded');
  250 |     });
  251 | 
  252 |     test('should send extra headers with connect request', async ({ connect, server }) => {
  253 |       const [request] = await Promise.all([
  254 |         server.waitForWebSocketConnectionRequest(),
  255 |         connect(`ws://localhost:${server.PORT}/ws`, {
  256 |           headers: {
  257 |             'User-Agent': 'Playwright',
  258 |             'foo': 'bar',
  259 |           },
  260 |           timeout: 100,
  261 |         }).catch(() => {})
  262 |       ]);
  263 |       expect(request.headers['user-agent']).toBe('Playwright');
  264 |       expect(request.headers['foo']).toBe('bar');
  265 |     });
  266 | 
  267 |     test('should send extra headers with connect request in object form', async ({ browserType, server }) => {
  268 |       const requestPromise = server.waitForWebSocketConnectionRequest();
  269 |       browserType.connect({
  270 |         wsEndpoint: `ws://localhost:${server.PORT}/ws`,
  271 |         headers: {
  272 |           'User-Agent': 'Playwright',
  273 |           'foo': 'bar',
  274 |         },
  275 |         timeout: 3000,
  276 |       }).catch(() => {});
  277 |       const request = await requestPromise;
  278 |       expect(request.headers['user-agent']).toBe('Playwright');
  279 |       expect(request.headers['foo']).toBe('bar');
  280 |     });
  281 | 
  282 |     test('should send default User-Agent and X-Playwright-Browser headers with connect request', async ({ connect, browserName, server, isFrozenWebkit }) => {
  283 |       test.skip(isFrozenWebkit);
  284 | 
  285 |       const [request] = await Promise.all([
  286 |         server.waitForWebSocketConnectionRequest(),
  287 |         connect(`ws://localhost:${server.PORT}/ws`, {
  288 |           headers: {
  289 |             'foo': 'bar',
  290 |           },
  291 |           timeout: 100,
  292 |         }).catch(() => {})
  293 |       ]);
  294 |       expect(request.headers['user-agent']).toBe(getUserAgent());
  295 |       expect(request.headers['x-playwright-browser']).toBe(browserName);
  296 |       expect(request.headers['foo']).toBe('bar');
  297 |     });
  298 | 
  299 |     test('should support slowmo option', async ({ connect, startRemoteServer }) => {
  300 |       const remoteServer = await startRemoteServer(kind);
  301 | 
  302 |       const browser1 = await connect(remoteServer.wsEndpoint(), { slowMo: 200 });
  303 |       const start = Date.now();
  304 |       await browser1.newContext();
  305 |       await browser1.close();
  306 |       expect(Date.now() - start).toBeGreaterThan(199);
  307 |     });
  308 | 
  309 |     test('disconnected event should be emitted when browser is closed or server is closed', async ({ connect, startRemoteServer }) => {
  310 |       const remoteServer = await startRemoteServer(kind);
  311 | 
  312 |       const browser1 = await connect(remoteServer.wsEndpoint());
  313 |       await browser1.newPage();
  314 | 
  315 |       const browser2 = await connect(remoteServer.wsEndpoint());
  316 |       await browser2.newPage();
  317 | 
  318 |       let disconnected1 = 0;
  319 |       let disconnected2 = 0;
  320 |       browser1.on('disconnected', () => ++disconnected1);
  321 |       browser2.on('disconnected', () => ++disconnected2);
  322 | 
  323 |       await Promise.all([
  324 |         new Promise(f => browser1.on('disconnected', f)),
  325 |         browser1.close(),
  326 |       ]);
  327 |       expect(disconnected1).toBe(1);
  328 |       expect(disconnected2).toBe(0);
  329 | 
  330 |       await Promise.all([
  331 |         new Promise(f => browser2.on('disconnected', f)),
  332 |         remoteServer.close(),
  333 |       ]);
  334 |       expect(disconnected1).toBe(1);
  335 |       expect(disconnected2).toBe(1);
  336 |     });
  337 | 
  338 |     test('disconnected event should have browser as argument', async ({ connect, startRemoteServer }) => {
  339 |       const remoteServer = await startRemoteServer(kind);
  340 |       const browser = await connect(remoteServer.wsEndpoint());
  341 |       const [disconnected] = await Promise.all([
  342 |         new Promise(f => browser.on('disconnected', f)),
```