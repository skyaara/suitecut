# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/page-event-crash.spec.ts >> should cancel waitForEvent when page crashes
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/page-event-crash.spec.ts:74:1

# Error details

```
Error: browser.newContext: Target page, context or browser has been closed
```

# Test source

```ts
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import * as fs from 'fs';
  18  | import * as os from 'os';
  19  | import * as path from 'path';
  20  | import { baseTest } from './baseTest';
  21  | import { RunServer, RemoteServer } from './remoteServer';
  22  | import { utils } from '../../packages/playwright-core/lib/coreBundle';
  23  | import { isBidiChannel, parseHar } from '../config/utils';
  24  | import type { PageTestFixtures, PageWorkerFixtures } from '../page/pageTestApi';
  25  | import type { RemoteServerOptions, PlaywrightServer } from './remoteServer';
  26  | import type { BrowserContext, BrowserContextOptions, BrowserType, Page } from 'playwright-core';
  27  | import type { Log } from '../../packages/trace/src/har';
  28  | 
  29  | const { removeFolders, hostPlatform } = utils;
  30  | 
  31  | export type BrowserTestWorkerFixtures = PageWorkerFixtures & {
  32  |   browserVersion: string;
  33  |   defaultSameSiteCookieValue: string;
  34  |   allowsThirdParty: boolean;
  35  |   browserMajorVersion: number;
  36  |   browserType: BrowserType;
  37  |   isAndroid: boolean;
  38  |   isElectron: boolean;
  39  |   isHeadlessShell: boolean;
  40  |   isFrozenWebkit: boolean;
  41  |   isBidi: boolean;
  42  | };
  43  | 
  44  | interface StartRemoteServer {
  45  |   (kind: 'run-server' | 'launchServer', options?: RemoteServerOptions): Promise<PlaywrightServer>;
  46  |   (kind: 'launchServer', options?: RemoteServerOptions): Promise<RemoteServer>;
  47  | }
  48  | 
  49  | type BrowserTestTestFixtures = PageTestFixtures & {
  50  |   createUserDataDir: () => Promise<string>;
  51  |   launchPersistent: (options?: Parameters<BrowserType['launchPersistentContext']>[1]) => Promise<{ context: BrowserContext, page: Page }>;
  52  |   startRemoteServer: StartRemoteServer;
  53  |   contextFactory: (options?: BrowserContextOptions) => Promise<BrowserContext>;
  54  |   pageWithHar(options?: { outputPath?: string, content?: 'embed' | 'attach' | 'omit', omitContent?: boolean }): Promise<{ context: BrowserContext, page: Page, getLog: () => Promise<Log>, getZip: () => Promise<Map<string, Buffer>> }>
  55  | };
  56  | 
  57  | type ContextFactory = (options?: BrowserContextOptions) => Promise<{ context: BrowserContext, close: () => Promise<void> }>;
  58  | 
  59  | const test = baseTest.extend<BrowserTestTestFixtures & { _contextFactory: ContextFactory }, BrowserTestWorkerFixtures>({
  60  |   browserVersion: [async ({ browser }, run) => {
  61  |     await run(browser.version());
  62  |   }, { scope: 'worker' }],
  63  | 
  64  |   browserType: [async ({ playwright, browserName, mode }, run) => {
  65  |     await run(playwright[browserName]);
  66  |   }, { scope: 'worker' }],
  67  | 
  68  |   allowsThirdParty: [async ({ browserName, channel }, run) => {
  69  |     if (browserName === 'firefox')
  70  |       await run(true);
  71  |     else
  72  |       await run(false);
  73  |   }, { scope: 'worker' }],
  74  | 
  75  |   defaultSameSiteCookieValue: [async ({ browserName, platform, channel, isBidi }, run) => {
  76  |     if (browserName === 'chromium' || isBidi)
  77  |       await run('Lax');
  78  |     else if (browserName === 'webkit' && (platform === 'linux' || channel === 'webkit-wsl'))
  79  |       await run('Lax');
  80  |     else if (browserName === 'webkit')
  81  |       await run('None'); // Windows + older macOS
  82  |     else if (browserName === 'firefox')
  83  |       await run('None');
  84  |     else
  85  |       throw new Error('unknown browser - ' + browserName);
  86  |   }, { scope: 'worker' }],
  87  | 
  88  |   browserMajorVersion: [async ({ browserVersion }, run) => {
  89  |     await run(Number(browserVersion.split('.')[0]));
  90  |   }, { scope: 'worker' }],
  91  | 
  92  |   isBidi: [async ({ channel }, use) => {
  93  |     await use(isBidiChannel(channel));
  94  |   }, { scope: 'worker' }],
  95  | 
  96  |   isAndroid: [false, { scope: 'worker' }],
  97  |   isElectron: [false, { scope: 'worker' }],
  98  |   electronMajorVersion: [0, { scope: 'worker' }],
  99  | 
  100 |   isHeadlessShell: [async ({ browserName, channel, headless }, use) => {
  101 |     const isShell = channel === 'chromium-headless-shell' || (!channel && headless);
  102 |     const isToTShell = channel === 'chromium-tip-of-tree-headless-shell' || (channel === 'chromium-tip-of-tree' && headless);
  103 |     await use(browserName === 'chromium' && (isShell || isToTShell));
  104 |   }, { scope: 'worker' }],
  105 | 
  106 |   isFrozenWebkit: [async ({ browserName, isMac, macVersion }, use) => {
  107 |     await use(browserName === 'webkit' && (hostPlatform.startsWith('debian11') || hostPlatform.startsWith('ubuntu20.04') || (isMac && macVersion < 15)));
  108 |   }, { scope: 'worker' }],
  109 | 
  110 |   _contextFactory: async ({ _contextFactory }, use) => {
  111 |     await use(async options => {
> 112 |       const result = await _contextFactory(options);
      |                      ^ Error: browser.newContext: Target page, context or browser has been closed
  113 |       const { context } = result;
  114 |       if (process.env.PW_CLOCK === 'frozen') {
  115 |         await (context as any)._wrapApiCall(async () => {
  116 |           await context.clock.install({ time: 0 });
  117 |           await context.clock.pauseAt(1000);
  118 |         }, { internal: true });
  119 |       } else if (process.env.PW_CLOCK === 'realtime') {
  120 |         await (context as any)._wrapApiCall(async () => {
  121 |           await context.clock.install({ time: 0 });
  122 |         }, { internal: true });
  123 |       }
  124 |       return result;
  125 |     });
  126 |   },
  127 | 
  128 |   contextFactory: async ({ _contextFactory }, run) => {
  129 |     await run(async options => {
  130 |       const { context } = await _contextFactory(options);
  131 |       return context;
  132 |     });
  133 |   },
  134 | 
  135 |   createUserDataDir: async ({ mode }, run) => {
  136 |     const dirs: string[] = [];
  137 |     // We do not put user data dir in testOutputPath,
  138 |     // because we do not want to upload them as test result artifacts.
  139 |     //
  140 |     // Additionally, it is impossible to upload user data dir after test run:
  141 |     // - Firefox removes lock file later, presumably from another watchdog process?
  142 |     // - WebKit has circular symlinks that makes CI go crazy.
  143 |     await run(async () => {
  144 |       const dir = await fs.promises.mkdtemp(path.join(os.tmpdir(), 'playwright-test-'));
  145 |       dirs.push(dir);
  146 |       return dir;
  147 |     });
  148 |     await removeFolders(dirs);
  149 |   },
  150 | 
  151 |   launchPersistent: async ({ createUserDataDir, browserType, mode }, run) => {
  152 |     test.skip(mode !== 'default', 'Remote persistent contexts are not supported');
  153 | 
  154 |     let persistentContext: BrowserContext | undefined;
  155 |     await run(async options => {
  156 |       if (persistentContext)
  157 |         throw new Error('can only launch one persistent context');
  158 |       const userDataDir = await createUserDataDir();
  159 |       persistentContext = await browserType.launchPersistentContext(userDataDir, { ...options });
  160 |       const page = persistentContext.pages()[0];
  161 |       return { context: persistentContext, page };
  162 |     });
  163 |     if (persistentContext)
  164 |       await persistentContext.close();
  165 |   },
  166 | 
  167 |   startRemoteServer: async ({ childProcess, browserType, channel, mode }, run) => {
  168 |     test.skip(mode !== 'default', 'Starting remote server is not supported in remote modes');
  169 | 
  170 |     let server: PlaywrightServer | undefined;
  171 |     const fn = async (kind: 'launchServer' | 'run-server', options?: RemoteServerOptions) => {
  172 |       if (server)
  173 |         throw new Error('can only start one remote server');
  174 |       if (kind === 'launchServer') {
  175 |         const remoteServer = new RemoteServer();
  176 |         await remoteServer._start(childProcess, browserType, channel, options);
  177 |         server = remoteServer;
  178 |       } else {
  179 |         const runServer = new RunServer();
  180 |         await runServer.start(childProcess, { artifactsDir: options?.artifactsDir });
  181 |         server = runServer;
  182 |       }
  183 |       return server;
  184 |     };
  185 |     await run(fn as any);
  186 |     if (server) {
  187 |       await server.close();
  188 |       // Give any connected browsers a chance to disconnect to avoid
  189 |       // poisoning next test with quasy-alive browsers.
  190 |       await new Promise(f => setTimeout(f, 1000));
  191 |     }
  192 |   },
  193 |   pageWithHar: async ({ contextFactory }, use, testInfo) => {
  194 |     const pageWithHar = async (options: { outputPath?: string, content?: 'embed' | 'attach' | 'omit', omitContent?: boolean } = {}) => {
  195 |       const harPath = testInfo.outputPath(options.outputPath || 'test.har');
  196 |       const context = await contextFactory({ recordHar: { path: harPath, content: options.content, omitContent: options.omitContent }, ignoreHTTPSErrors: true });
  197 |       const page = await context.newPage();
  198 |       return {
  199 |         page,
  200 |         context,
  201 |         getLog: async () => {
  202 |           await context.close();
  203 |           return JSON.parse(fs.readFileSync(harPath).toString())['log'] as Log;
  204 |         },
  205 |         getZip: async () => {
  206 |           await context.close();
  207 |           return parseHar(harPath);
  208 |         },
  209 |       };
  210 |     };
  211 |     await use(pageWithHar);
  212 |   },
```