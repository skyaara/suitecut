# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/chromium/connect-over-cdp.spec.ts >> should report an expected error when the endpointURL returns a non-expected status code
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/connect-over-cdp.spec.ts:410:5

# Error details

```
Error: expect(received).rejects.toThrowError(expected)

Expected substring: "browserType.connectOverCDP: Unexpected status 404 when connecting to http://localhost:9367/json/version/"
Received message:   "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"

      221 |     if(process.env.COMPAT_BACKEND==='chromium') return use(original);
      222 |     await use(new Proxy(original, { get(target, name) {
    > 223 |       if (['launch', 'launchPersistentContext', 'launchServer', 'connect', 'connectOverCDP'].includes(String(name))) return async () => { throw new Error('SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness'); };
          |                                                                                                                                                 ^
      224 |       const value = Reflect.get(target, name); return typeof value === 'function' ? value.bind(target) : value;
      225 |     }}));
      226 |   }, { scope: 'worker' }],

      at Proxy.connectOverCDP (../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/config/browserTest.ts:223:145)
      at ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/connect-over-cdp.spec.ts:417:28
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1644:15
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1133:17
      at TimeoutManager.withRunnable (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:404:9)
      at TestInfoImpl._runWithTimeout (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1131:34)
      at node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1642:22
      at WorkerMain._runTest (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1615:5)
      at WorkerMain.runTestGroup (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/worker/workerProcessEntry.js:1510:9)
      at process.<anonymous> (node_modules/.pnpm/playwright@1.62.1/node_modules/playwright/lib/common/index.js:1997:25)
```

# Test source

```ts
  319 |         timeout: 100,
  320 |       }).catch(() => {})
  321 |     ]);
  322 |     expect(request.headers['user-agent']).toBe(getUserAgent());
  323 |     expect(request.headers['foo']).toBe('bar');
  324 |   }
  325 | });
  326 | 
  327 | test('should report all pages in an existing browser', async ({ browserType }, testInfo) => {
  328 |   const port = 9339 + testInfo.workerIndex;
  329 |   const browserServer = await browserType.launch({
  330 |     args: ['--remote-debugging-port=' + port]
  331 |   });
  332 |   try {
  333 |     const cdpBrowser = await browserType.connectOverCDP({
  334 |       endpointURL: `http://127.0.0.1:${port}/`,
  335 |     });
  336 |     const contexts = cdpBrowser.contexts();
  337 |     expect(contexts.length).toBe(1);
  338 |     for (let i = 0; i < 3; i++)
  339 |       await contexts[0].newPage();
  340 |     await cdpBrowser.close();
  341 | 
  342 |     const cdpBrowser2 = await browserType.connectOverCDP({
  343 |       endpointURL: `http://127.0.0.1:${port}/`,
  344 |     });
  345 |     expect(cdpBrowser2.contexts()[0].pages().length).toBe(3);
  346 | 
  347 |     await cdpBrowser2.close();
  348 |   } finally {
  349 |     await browserServer.close();
  350 |   }
  351 | });
  352 | 
  353 | test('should connect via https', async ({ browserType, httpsServer, mode }, testInfo) => {
  354 |   test.skip(mode !== 'default'); // Out of process transport does not allow us to set env vars dynamically.
  355 | 
  356 |   const port = 9339 + testInfo.workerIndex;
  357 |   const browserServer = await browserType.launch({
  358 |     args: ['--remote-debugging-port=' + port]
  359 |   });
  360 |   const json = await new Promise<string>((resolve, reject) => {
  361 |     http.get(`http://127.0.0.1:${port}/json/version/`, resp => {
  362 |       let data = '';
  363 |       resp.on('data', chunk => data += chunk);
  364 |       resp.on('end', () => resolve(data));
  365 |     }).on('error', reject);
  366 |   });
  367 |   httpsServer.setRoute('/json/version/', (req, res) => {
  368 |     res.writeHead(200);
  369 |     res.end(json);
  370 |   });
  371 |   const oldValue = process.env['NODE_TLS_REJECT_UNAUTHORIZED'];
  372 |   // https://stackoverflow.com/a/21961005/552185
  373 |   process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
  374 |   suppressCertificateWarning();
  375 |   try {
  376 |     const cdpBrowser = await browserType.connectOverCDP(`https://localhost:${httpsServer.PORT}/`);
  377 |     const contexts = cdpBrowser.contexts();
  378 |     expect(contexts.length).toBe(1);
  379 |     for (let i = 0; i < 3; i++)
  380 |       await contexts[0].newPage();
  381 |     await cdpBrowser.close();
  382 |   } finally {
  383 |     process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = oldValue;
  384 |     await browserServer.close();
  385 |   }
  386 | });
  387 | 
  388 | test('should return valid browser from context.browser()', async ({ browserType }, testInfo) => {
  389 |   const port = 9339 + testInfo.workerIndex;
  390 |   const browserServer = await browserType.launch({
  391 |     args: ['--remote-debugging-port=' + port]
  392 |   });
  393 |   try {
  394 |     const cdpBrowser = await browserType.connectOverCDP({
  395 |       endpointURL: `http://127.0.0.1:${port}/`,
  396 |     });
  397 |     const contexts = cdpBrowser.contexts();
  398 |     expect(contexts.length).toBe(1);
  399 |     expect(contexts[0].browser()).toBe(cdpBrowser);
  400 | 
  401 |     const context2 = await cdpBrowser.newContext();
  402 |     expect(context2.browser()).toBe(cdpBrowser);
  403 | 
  404 |     await cdpBrowser.close();
  405 |   } finally {
  406 |     await browserServer.close();
  407 |   }
  408 | });
  409 | 
  410 | test('should report an expected error when the endpointURL returns a non-expected status code', async ({ browserType, server }) => {
  411 |   server.setRoute('/json/version/', (req, resp) => {
  412 |     resp.statusCode = 404;
  413 |     resp.end(JSON.stringify({
  414 |       webSocketDebuggerUrl: 'dont-use-me',
  415 |     }));
  416 |   });
  417 |   await expect(browserType.connectOverCDP({
  418 |     endpointURL: server.PREFIX,
> 419 |   })).rejects.toThrowError(`browserType.connectOverCDP: Unexpected status 404 when connecting to ${server.PREFIX}/json/version/`);
      |               ^ Error: expect(received).rejects.toThrowError(expected)
  420 | });
  421 | 
  422 | test('should report an expected error when the endpoint URL JSON webSocketDebuggerUrl is undefined', async ({ browserType, server }) => {
  423 |   server.setRoute('/json/version/', (req, resp) => {
  424 |     resp.end(JSON.stringify({
  425 |       webSocketDebuggerUrl: undefined,
  426 |     }));
  427 |   });
  428 |   await expect(browserType.connectOverCDP({
  429 |     endpointURL: server.PREFIX,
  430 |   })).rejects.toThrowError('browserType.connectOverCDP: Invalid URL');
  431 | });
  432 | 
  433 | test('should connect to an existing cdp session when passed as a first argument', async ({ browserType }, testInfo) => {
  434 |   const port = 9339 + testInfo.workerIndex;
  435 |   const browserServer = await browserType.launch({
  436 |     args: ['--remote-debugging-port=' + port]
  437 |   });
  438 |   try {
  439 |     const cdpBrowser = await browserType.connectOverCDP(`http://127.0.0.1:${port}/`);
  440 |     const contexts = cdpBrowser.contexts();
  441 |     expect(contexts.length).toBe(1);
  442 |     await cdpBrowser.close();
  443 |   } finally {
  444 |     await browserServer.close();
  445 |   }
  446 | });
  447 | 
  448 | test('should use proxy with connectOverCDP', async ({ browserType, server }, testInfo) => {
  449 |   server.setRoute('/target.html', async (req, res) => {
  450 |     res.end('<html><title>Served by the proxy</title></html>');
  451 |   });
  452 |   const port = 9339 + testInfo.workerIndex;
  453 |   const browserServer = await browserType.launch({
  454 |     args: ['--remote-debugging-port=' + port]
  455 |   });
  456 |   try {
  457 |     const cdpBrowser = await browserType.connectOverCDP(`http://127.0.0.1:${port}/`);
  458 |     const context = await cdpBrowser.newContext({
  459 |       proxy: { server: `localhost:${server.PORT}` }
  460 |     });
  461 |     const page = await context.newPage();
  462 |     await page.goto('http://non-existent.com/target.html');
  463 |     expect(await page.title()).toBe('Served by the proxy');
  464 |     await cdpBrowser.close();
  465 |   } finally {
  466 |     await browserServer.close();
  467 |   }
  468 | });
  469 | 
  470 | test('should use env proxy with connectOverCDP discovery request', async ({ browserType, server, proxyServer, mode }) => {
  471 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40394' });
  472 |   test.skip(mode !== 'default'); // Out of process transport does not allow us to set env vars dynamically.
  473 |   proxyServer.forwardTo(server.PORT);
  474 | 
  475 |   const oldValue = process.env.HTTP_PROXY;
  476 |   try {
  477 |     process.env.HTTP_PROXY = proxyServer.URL;
  478 |     const error = await browserType.connectOverCDP(server.PREFIX).catch(e => e);
  479 |     expect(error.message).toContain(`Unexpected status 404 when connecting to ${server.PREFIX}/json/version/`);
  480 |     expect(proxyServer.requestUrls).toEqual([`${server.PREFIX}/json/version/`]);
  481 |   } finally {
  482 |     if (oldValue === undefined)
  483 |       delete process.env.HTTP_PROXY;
  484 |     else
  485 |       process.env.HTTP_PROXY = oldValue;
  486 |   }
  487 | });
  488 | 
  489 | test('should send target Host header when using env HTTP proxy with connectOverCDP', async ({ browserType, server, proxyServer, mode }) => {
  490 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40811' });
  491 |   test.skip(mode !== 'default'); // Out of process transport does not allow us to set env vars dynamically.
  492 |   proxyServer.forwardTo(server.PORT);
  493 | 
  494 |   const oldValue = process.env.HTTP_PROXY;
  495 |   try {
  496 |     process.env.HTTP_PROXY = proxyServer.URL;
  497 |     const error = await browserType.connectOverCDP(server.PREFIX).catch(e => e);
  498 |     expect(error.message).toContain(`Unexpected status 404 when connecting to ${server.PREFIX}/json/version/`);
  499 |     expect(proxyServer.requestHosts).toEqual([new URL(server.PREFIX).host]);
  500 |   } finally {
  501 |     if (oldValue === undefined)
  502 |       delete process.env.HTTP_PROXY;
  503 |     else
  504 |       process.env.HTTP_PROXY = oldValue;
  505 |   }
  506 | });
  507 | 
  508 | test('should be able to connect via localhost', async ({ browserType }, testInfo) => {
  509 |   const port = 9339 + testInfo.workerIndex;
  510 |   const browserServer = await browserType.launch({
  511 |     args: ['--remote-debugging-port=' + port]
  512 |   });
  513 |   try {
  514 |     const cdpBrowser = await browserType.connectOverCDP(`http://localhost:${port}`);
  515 |     const contexts = cdpBrowser.contexts();
  516 |     expect(contexts.length).toBe(1);
  517 |     await cdpBrowser.close();
  518 |   } finally {
  519 |     await browserServer.close();
```