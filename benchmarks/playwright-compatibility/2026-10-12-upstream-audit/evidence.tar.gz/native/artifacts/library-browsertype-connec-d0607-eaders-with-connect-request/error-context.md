# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-connect.spec.ts >> launchServer >> should send default User-Agent and X-Playwright-Browser headers with connect request
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-connect.spec.ts:282:5

# Error details

```
Test timeout of 90000ms exceeded.
```