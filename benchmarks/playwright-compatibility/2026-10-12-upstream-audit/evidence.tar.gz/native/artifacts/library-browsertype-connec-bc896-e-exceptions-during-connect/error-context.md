# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-connect.spec.ts >> launchServer >> should handle exceptions during connect
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-connect.spec.ts:348:5

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: "Dummy"
Received string:    "SuiteCut CEF upstream adapter: independent browser launching/connecting is outside this harness"
```

# Test source

```ts
  252 |     test('should send extra headers with connect request', async ({ connect, server }) => {
  253 |       const [request] = await Promise.all([
  254 |         server.waitForWebSocketConnectionRequest(),
  255 |         connect(`ws://localhost:${server.PORT}/ws`, {
  256 |           headers: {
  257 |             'User-Agent': 'Playwright',
  258 |             'foo': 'bar',
  259 |           },
  260 |           timeout: 100,
  261 |         }).catch(() => {})
  262 |       ]);
  263 |       expect(request.headers['user-agent']).toBe('Playwright');
  264 |       expect(request.headers['foo']).toBe('bar');
  265 |     });
  266 | 
  267 |     test('should send extra headers with connect request in object form', async ({ browserType, server }) => {
  268 |       const requestPromise = server.waitForWebSocketConnectionRequest();
  269 |       browserType.connect({
  270 |         wsEndpoint: `ws://localhost:${server.PORT}/ws`,
  271 |         headers: {
  272 |           'User-Agent': 'Playwright',
  273 |           'foo': 'bar',
  274 |         },
  275 |         timeout: 3000,
  276 |       }).catch(() => {});
  277 |       const request = await requestPromise;
  278 |       expect(request.headers['user-agent']).toBe('Playwright');
  279 |       expect(request.headers['foo']).toBe('bar');
  280 |     });
  281 | 
  282 |     test('should send default User-Agent and X-Playwright-Browser headers with connect request', async ({ connect, browserName, server, isFrozenWebkit }) => {
  283 |       test.skip(isFrozenWebkit);
  284 | 
  285 |       const [request] = await Promise.all([
  286 |         server.waitForWebSocketConnectionRequest(),
  287 |         connect(`ws://localhost:${server.PORT}/ws`, {
  288 |           headers: {
  289 |             'foo': 'bar',
  290 |           },
  291 |           timeout: 100,
  292 |         }).catch(() => {})
  293 |       ]);
  294 |       expect(request.headers['user-agent']).toBe(getUserAgent());
  295 |       expect(request.headers['x-playwright-browser']).toBe(browserName);
  296 |       expect(request.headers['foo']).toBe('bar');
  297 |     });
  298 | 
  299 |     test('should support slowmo option', async ({ connect, startRemoteServer }) => {
  300 |       const remoteServer = await startRemoteServer(kind);
  301 | 
  302 |       const browser1 = await connect(remoteServer.wsEndpoint(), { slowMo: 200 });
  303 |       const start = Date.now();
  304 |       await browser1.newContext();
  305 |       await browser1.close();
  306 |       expect(Date.now() - start).toBeGreaterThan(199);
  307 |     });
  308 | 
  309 |     test('disconnected event should be emitted when browser is closed or server is closed', async ({ connect, startRemoteServer }) => {
  310 |       const remoteServer = await startRemoteServer(kind);
  311 | 
  312 |       const browser1 = await connect(remoteServer.wsEndpoint());
  313 |       await browser1.newPage();
  314 | 
  315 |       const browser2 = await connect(remoteServer.wsEndpoint());
  316 |       await browser2.newPage();
  317 | 
  318 |       let disconnected1 = 0;
  319 |       let disconnected2 = 0;
  320 |       browser1.on('disconnected', () => ++disconnected1);
  321 |       browser2.on('disconnected', () => ++disconnected2);
  322 | 
  323 |       await Promise.all([
  324 |         new Promise(f => browser1.on('disconnected', f)),
  325 |         browser1.close(),
  326 |       ]);
  327 |       expect(disconnected1).toBe(1);
  328 |       expect(disconnected2).toBe(0);
  329 | 
  330 |       await Promise.all([
  331 |         new Promise(f => browser2.on('disconnected', f)),
  332 |         remoteServer.close(),
  333 |       ]);
  334 |       expect(disconnected1).toBe(1);
  335 |       expect(disconnected2).toBe(1);
  336 |     });
  337 | 
  338 |     test('disconnected event should have browser as argument', async ({ connect, startRemoteServer }) => {
  339 |       const remoteServer = await startRemoteServer(kind);
  340 |       const browser = await connect(remoteServer.wsEndpoint());
  341 |       const [disconnected] = await Promise.all([
  342 |         new Promise(f => browser.on('disconnected', f)),
  343 |         browser.close(),
  344 |       ]);
  345 |       expect(disconnected).toBe(browser);
  346 |     });
  347 | 
  348 |     test('should handle exceptions during connect', async ({ connect, startRemoteServer }) => {
  349 |       const remoteServer = await startRemoteServer(kind);
  350 |       const __testHookBeforeCreateBrowser = () => { throw new Error('Dummy'); };
  351 |       const error = await connect(remoteServer.wsEndpoint(), { __testHookBeforeCreateBrowser } as any).catch(e => e);
> 352 |       expect(error.message).toContain('Dummy');
      |                             ^ Error: expect(received).toContain(expected) // indexOf
  353 |     });
  354 | 
  355 |     test('should set the browser connected state', async ({ connect, startRemoteServer }) => {
  356 |       const remoteServer = await startRemoteServer(kind);
  357 |       const remote = await connect(remoteServer.wsEndpoint());
  358 |       expect(remote.isConnected()).toBe(true);
  359 |       await remote.close();
  360 |       expect(remote.isConnected()).toBe(false);
  361 |     });
  362 | 
  363 |     test('should throw when used after isConnected returns false', async ({ connect, startRemoteServer }) => {
  364 |       const remoteServer = await startRemoteServer(kind);
  365 |       const browser = await connect(remoteServer.wsEndpoint());
  366 |       const page = await browser.newPage();
  367 |       await Promise.all([
  368 |         remoteServer.close(),
  369 |         new Promise(f => browser.once('disconnected', f)),
  370 |       ]);
  371 |       expect(browser.isConnected()).toBe(false);
  372 |       const error = await page.evaluate('1 + 1').catch(e => e) as Error;
  373 |       expect(error.message).toContain('closed');
  374 |     });
  375 | 
  376 |     test('should throw when calling waitForNavigation after disconnect', async ({ connect, startRemoteServer }) => {
  377 |       const remoteServer = await startRemoteServer(kind);
  378 |       const browser = await connect(remoteServer.wsEndpoint());
  379 |       const page = await browser.newPage();
  380 |       await Promise.all([
  381 |         remoteServer.close(),
  382 |         new Promise(f => browser.once('disconnected', f)),
  383 |       ]);
  384 |       expect(browser.isConnected()).toBe(false);
  385 |       const error = await page.waitForNavigation().catch(e => e);
  386 |       expect(error.message).toContain(kTargetClosedErrorMessage);
  387 |     });
  388 | 
  389 |     test('should reject navigation when browser closes', async ({ connect, startRemoteServer, server }) => {
  390 |       const remoteServer = await startRemoteServer(kind);
  391 |       server.setRoute('/one-style.css', () => {});
  392 |       const browser = await connect(remoteServer.wsEndpoint());
  393 |       const page = await browser.newPage();
  394 |       const navigationPromise = page.goto(server.PREFIX + '/one-style.html', { timeout: 60000 }).catch(e => e);
  395 |       await server.waitForRequest('/one-style.css');
  396 |       await browser.close();
  397 |       const error = await navigationPromise;
  398 |       expect(error.message).toContain('has been closed');
  399 |     });
  400 | 
  401 |     test('should reject waitForSelector when browser closes', async ({ connect, startRemoteServer, server }) => {
  402 |       const remoteServer = await startRemoteServer(kind);
  403 |       server.setRoute('/empty.html', () => {});
  404 |       const browser = await connect(remoteServer.wsEndpoint());
  405 |       const page = await browser.newPage();
  406 |       const watchdog = page.waitForSelector('div', { state: 'attached', timeout: 60000 }).catch(e => e);
  407 | 
  408 |       // Make sure the previous waitForSelector has time to make it to the browser before we disconnect.
  409 |       await page.waitForSelector('body', { state: 'attached' });
  410 | 
  411 |       await browser.close();
  412 |       const error = await watchdog;
  413 |       expect(error.message).toContain('has been closed');
  414 |     });
  415 | 
  416 |     test('should emit close events on pages and contexts', async ({ connect, startRemoteServer }) => {
  417 |       const remoteServer = await startRemoteServer(kind);
  418 |       const browser = await connect(remoteServer.wsEndpoint());
  419 |       const context = await browser.newContext();
  420 |       const page = await context.newPage();
  421 |       let pageClosed = false;
  422 |       page.on('close', () => pageClosed = true);
  423 |       await Promise.all([
  424 |         new Promise(f => context.on('close', f)),
  425 |         remoteServer.close()
  426 |       ]);
  427 |       expect(pageClosed).toBeTruthy();
  428 |     });
  429 | 
  430 |     test('should terminate network waiters', async ({ connect, startRemoteServer, server }) => {
  431 |       const remoteServer = await startRemoteServer(kind);
  432 |       const browser = await connect(remoteServer.wsEndpoint());
  433 |       const newPage = await browser.newPage();
  434 |       const results = await Promise.all([
  435 |         newPage.waitForRequest(server.EMPTY_PAGE).catch(e => e),
  436 |         newPage.waitForResponse(server.EMPTY_PAGE).catch(e => e),
  437 |         remoteServer.close(),
  438 |       ]);
  439 |       for (let i = 0; i < 2; i++) {
  440 |         const message = results[i].message;
  441 |         expect(message).toContain(kTargetClosedErrorMessage);
  442 |         expect(message).not.toContain('Timeout');
  443 |       }
  444 |     });
  445 | 
  446 |     test('should reject waitForEvent before browser.close finishes', async ({ connect, startRemoteServer, server }) => {
  447 |       const remoteServer = await startRemoteServer(kind);
  448 |       const browser = await connect(remoteServer.wsEndpoint());
  449 |       const newPage = await browser.newPage();
  450 |       let rejected = false;
  451 |       const promise = newPage.waitForEvent('download').catch(() => rejected = true);
  452 |       await browser.close();
```