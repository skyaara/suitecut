import subprocess,time
from pathlib import Path
b=Path('/tmp/suitecut-upstream-full-2026-10-12')
while True:
 with (b/'report-refresh.log').open('a') as out:
  subprocess.run(['python3',str(b/'build-report.py')],stdout=out,stderr=subprocess.STDOUT)
 if (b/'native-exit.txt').exists() and (b/'stock-exit.txt').exists():break
 time.sleep(30)
