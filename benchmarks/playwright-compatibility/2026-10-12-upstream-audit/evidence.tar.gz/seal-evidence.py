from pathlib import Path
import json,hashlib,tarfile,shutil,subprocess
base=Path('/tmp/suitecut-upstream-full-2026-10-12');out=Path('/workspace/suitecut/benchmarks/playwright-compatibility/2026-10-12-upstream-audit');u=Path('/tmp/suitecut-playwright-upstream/playwright-1.62.1')
assert (base/'native-exit.txt').exists() and (base/'stock-exit.txt').exists(),'Audit is still running'
subprocess.run(['python3',str(base/'build-report.py')],check=True)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while data:=f.read(2**20):h.update(data)
 return h.hexdigest()
def copy(p,d):d.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,d)
# Reporter outcomes and literal execution statuses are both retained.
for backend in ['native','stock']:
 d=json.loads((base/backend/'results.json').read_text());copy(base/backend/'results.json',out/'results'/f'{backend}.json');copy(base/backend/'cases-live.jsonl',out/'results'/f'{backend}-cases.jsonl')
 print(backend,d['stats'])
for name in ['metadata.json','source-file-integrity.json','frozen-sha256.txt','worker-watchdog.jsonl','compressed-artifacts.jsonl','browserTest.audit.ts','suitecut-audit.config.ts','progress-reporter.cjs','runtime.py','run-native.sh','run-stock.py','watch-workers.py','build-report.py','profile-hung-worker.mjs']:
 if (base/name).exists():copy(base/name,out/'reproduction'/name)
for name in ['LICENSE','NOTICE']:
 copy(u/name,out/'reproduction/upstream'/name)
with tarfile.open(u.parent/'source.tar.gz') as source,tarfile.open(out/'upstream-spec-sources.tar.gz','w:gz',compresslevel=9) as dest:
 selected=set()
 d=json.loads((base/'inventory/results.json').read_text())
 def collect(s):
  for x in s.get('specs',[]):selected.add('tests/'+x['file'])
  for c in s.get('suites',[]):collect(c)
 for s in d['suites']:collect(s)
 for m in source:
  rel=m.name.split('/',1)[-1]
  if m.isfile() and rel in selected:
   data=source.extractfile(m);m.name=rel;dest.addfile(m,data)
assert len(selected)==284
# Keep all final outputs, traces, recordings, screenshots and error contexts.
# Ephemeral per-worker staging/profile directories are inventoried but excluded.
manifest=[];excluded=[]
with tarfile.open(out/'evidence.tar.gz','w:gz',compresslevel=6) as tar:
 for p in sorted(base.rglob('*')):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(base)
  if any(part.startswith('.playwright-artifacts-') or part in ['Cache','Code Cache','GPUCache'] for part in rel.parts):
   excluded.append({'path':str(rel),'bytes':p.stat().st_size,'reason':'ephemeral worker staging/cache, not final test output'});continue
  # Refresh logs change while the parent waits; exclude this maintenance log.
  if rel.name=='report-refresh.log':continue
  tar.add(p,arcname=str(rel),recursive=False);manifest.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':sha(p)})
(out/'archive-manifest.json').write_text(json.dumps({'archiveSha256':sha(out/'evidence.tar.gz'),'files':manifest,'excluded':excluded},indent=2)+'\n')
(out/'.gitattributes').write_text('# Preserve raw checksummed evidence and avoid generated snapshot diffs.\n*.csv binary\n*.json binary\nresults/** binary\nreproduction/** binary\n*.tar.gz binary\n')
with (out/'SHA256SUMS').open('w') as f:
 for p in sorted(out.rglob('*')):
  if p.is_file() and p.name!='SHA256SUMS':f.write(sha(p)+'  '+str(p.relative_to(out))+'\n')
shared=Path('/workspace/shared/suitecut-upstream-audit-2026-10-12');shared.mkdir(exist_ok=True)
# Hard links preserve the same bytes without consuming another large archive.
for name in ['report.md','metadata.json','summary.json','cases.csv','missing-cases.csv','skipped-not-run.csv','files.csv','suitecut-mismatches.csv','isolated-serial-cases.csv','evidence.tar.gz','upstream-spec-sources.tar.gz','archive-manifest.json','SHA256SUMS']:
 p=out/name;dest=shared/name
 if p.exists():
  if dest.exists():dest.unlink()
  dest.hardlink_to(p)
print(json.dumps({'files':len(manifest),'excluded':len(excluded),'archiveMiB':(out/'evidence.tar.gz').stat().st_size/2**20,'archiveSha256':sha(out/'evidence.tar.gz'),'sourceSpecFiles':len(selected),'shared':str(shared)},indent=2))
