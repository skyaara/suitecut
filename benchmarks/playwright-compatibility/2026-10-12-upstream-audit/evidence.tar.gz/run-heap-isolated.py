from pathlib import Path
import subprocess,os,json
base=Path('/tmp/suitecut-upstream-full-2026-10-12');summary=[]
for line in [178,184,191,223,244,270,304]:
 out=base/f'heap-isolated-{line}';out.mkdir(exist_ok=True);env=dict(os.environ,COMPAT_DIRECTORY=str(out))
 with (out/'run.log').open('w') as log:
  result=subprocess.run(['pnpm','exec','playwright','test','--config','/tmp/suitecut-playwright-upstream/playwright-1.62.1/suitecut-audit.config.ts',f'library/heap.spec.ts:{line}','--workers=1'],cwd='/workspace/suitecut',env=env,stdout=log,stderr=subprocess.STDOUT)
 summary.append({'line':line,'exitCode':result.returncode,'directory':str(out)})
 (base/'heap-isolated-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary[-1]),flush=True)
