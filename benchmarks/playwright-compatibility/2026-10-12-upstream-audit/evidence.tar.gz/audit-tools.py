from pathlib import Path
from collections import Counter
import json,re,sys,csv,hashlib
base=Path('/tmp/suitecut-upstream-full-2026-10-12')
ansi=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
def clean(s):return ansi.sub('',s or '')
def readlive(backend='native'):
 p=base/backend/'cases-live.jsonl';rows=[]
 if not p.exists():return rows
 for s in p.read_text().splitlines():
  try:rows.append(json.loads(s))
  except json.JSONDecodeError:pass
 return rows
def group(r):
 errors='\n'.join(clean(e.get('message','')) for e in r['errors']);file=r['location']['file'].split('/tests/')[-1]
 if r['outcome']!='unexpected':return r['outcome']
 if 'independent browser launching/connecting is outside this harness' in errors:return 'harness: independent launch/connect'
 if 'Cannot find module' in errors or 'MODULE_NOT_FOUND' in errors:return 'harness/dependency: missing module'
 if 'Protocol error' in errors and ('wasn\'t found' in errors or 'not found' in errors or 'not supported' in errors):return 'protocol method/support error'
 if 'Unsupported CEF permission' in errors or 'permission' in file:return 'permissions'
 if file.startswith('library/inspector/'):return 'Playwright Inspector/codegen/internal fixtures'
 if any(w in file for w in ['popup','browsercontext-events']):return 'popup and context events'
 if 'Renderer terminated' in errors or 'renderer terminated' in errors:return 'renderer crash'
 if 'Failed to find browser context' in errors:return 'native/browser context mapping'
 if 'screenshot' in file:return 'screenshot'
 if 'Timeout' in errors or 'timeout' in errors:return 'timeout: investigate with baseline'
 if any(w in file for w in ['browsertype','defaultbrowsercontext','multiclient','browser-server']):return 'browser lifecycle/launcher/internal fixtures'
 return 'other assertion/API failure'
if __name__=='__main__':
 rows=readlive();fails=[r for r in rows if r['outcome']=='unexpected']
 print(json.dumps(dict(completed=len(rows),outcomes=dict(Counter(r['outcome'] for r in rows)),failureGroups=dict(Counter(group(r) for r in fails)),failureFiles=Counter(r['location']['file'].split('/tests/')[-1] for r in fails).most_common(12)),indent=2))
