# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/video.spec.ts >> screencast >> should work for popups
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/video.spec.ts:356:5

# Error details

```
Error: Expected all pixels to satisfy isAlmostRed, found bad pixel (126, 128, 125, 255)
Actual pixels=[126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255,126,128,125,255]
```

# Page snapshot

```yaml
- generic [ref=e2]:
  - text: hover me
  - button "click me" [active] [ref=e3]
```

# Test source

```ts
  1   | /**
  2   |  * Copyright Microsoft Corporation. All rights reserved.
  3   |  *
  4   |  * Licensed under the Apache License, Version 2.0 (the "License");
  5   |  * you may not use this file except in compliance with the License.
  6   |  * You may obtain a copy of the License at
  7   |  *
  8   |  *     http://www.apache.org/licenses/LICENSE-2.0
  9   |  *
  10  |  * Unless required by applicable law or agreed to in writing, software
  11  |  * distributed under the License is distributed on an "AS IS" BASIS,
  12  |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  13  |  * See the License for the specific language governing permissions and
  14  |  * limitations under the License.
  15  |  */
  16  | 
  17  | import fs from 'fs';
  18  | import path from 'path';
  19  | import { jpegjs } from 'playwright-core/lib/utilsBundle';
  20  | import { expect, browserTest as it } from '../config/browserTest';
  21  | import { ensureSomeFrames, parseTraceRaw } from '../config/utils';
  22  | import { VideoPlayer } from './videoPlayer';
  23  | 
  24  | type Pixel = { r: number, g: number, b: number, alpha: number };
  25  | type PixelPredicate = (pixel: Pixel) => boolean;
  26  | 
  27  | function isAlmostRed({ r, g, b, alpha }: Pixel): boolean {
  28  |   return r > 185 && g < 70 && b < 70 && alpha === 255;
  29  | }
  30  | 
  31  | function isAlmostBlack({ r, g, b, alpha }: Pixel): boolean {
  32  |   return r < 70 && g < 70 && b < 70 && alpha === 255;
  33  | }
  34  | 
  35  | function isAlmostGray({ r, g, b, alpha }: Pixel): boolean {
  36  |   return r > 70 && r < 185 &&
  37  |     g > 70 && g < 185 &&
  38  |     b > 70 && b < 185 &&
  39  |     alpha === 255;
  40  | }
  41  | 
  42  | function findPixel(pixels: Buffer, pixelPredicate: PixelPredicate): Pixel|undefined {
  43  |   for (let i = 0, n = pixels.length; i < n; i += 4) {
  44  |     const pixel = {
  45  |       r: pixels[i],
  46  |       g: pixels[i + 1],
  47  |       b: pixels[i + 2],
  48  |       alpha: pixels[i + 3],
  49  |     };
  50  |     if (pixelPredicate(pixel))
  51  |       return pixel;
  52  |   }
  53  |   return undefined;
  54  | }
  55  | 
  56  | function everyPixel(pixels: Buffer, pixelPredicate: PixelPredicate) {
  57  |   const badPixel = findPixel(pixels, pixel => !pixelPredicate(pixel));
  58  |   return !badPixel;
  59  | }
  60  | 
  61  | function expectAll(pixels: Buffer, pixelPredicate: PixelPredicate) {
  62  |   const badPixel = findPixel(pixels, pixel => !pixelPredicate(pixel));
  63  |   if (!badPixel)
  64  |     return;
  65  |   const rgba = [badPixel.r, badPixel.g, badPixel.b, badPixel.alpha].join(', ');
> 66  |   throw new Error([
      |         ^ Error: Expected all pixels to satisfy isAlmostRed, found bad pixel (126, 128, 125, 255)
  67  |     `Expected all pixels to satisfy ${pixelPredicate.name}, found bad pixel (${rgba})`,
  68  |     `Actual pixels=[${pixels.join(',')}]`,
  69  |   ].join('\n'));
  70  | }
  71  | 
  72  | function findVideos(videoDir: string) {
  73  |   const files = fs.readdirSync(videoDir);
  74  |   return files.filter(file => file.endsWith('webm')).map(file => path.join(videoDir, file));
  75  | }
  76  | 
  77  | function expectRedFrames(videoFile: string, size: { width: number, height: number }) {
  78  |   expectFrames(videoFile, size, isAlmostRed);
  79  | }
  80  | 
  81  | function expectFrames(videoFile: string, size: { width: number, height: number }, pixelPredicate: PixelPredicate) {
  82  |   const videoPlayer = new VideoPlayer(videoFile);
  83  |   const duration = videoPlayer.duration;
  84  |   expect(duration).toBeGreaterThan(0);
  85  | 
  86  |   expect(videoPlayer.videoWidth).toBe(size.width);
  87  |   expect(videoPlayer.videoHeight).toBe(size.height);
  88  | 
  89  |   {
  90  |     const pixels = videoPlayer.seekLastFrame().data;
  91  |     expectAll(pixels, pixelPredicate);
  92  |   }
  93  |   {
  94  |     const pixels = videoPlayer.seekLastFrame({ x: size.width - 20, y: 10 }).data;
  95  |     expectAll(pixels, pixelPredicate);
  96  |   }
  97  | }
  98  | 
  99  | it.skip(({ video }) => video === 'on', 'conflicts with built-in video recording');
  100 | 
  101 | it.describe('screencast', () => {
  102 |   it.slow();
  103 |   it.skip(({ mode }) => mode !== 'default', 'video.path() is not available in remote mode');
  104 | 
  105 |   it('should not have video by default', async ({ page }) => {
  106 |     expect(page.video()).toBeNull();
  107 |   });
  108 | 
  109 |   it('should not throw without recordVideo.dir', async ({ browser }) => {
  110 |     await browser.newContext({ recordVideo: {} });
  111 |   });
  112 | 
  113 |   it('should capture static page', async ({ browser, browserName, trace, headless, isWindows }, testInfo) => {
  114 |     // Firefox does not have a mobile variant and has a large minimum size (500 on windows and 450 elsewhere).
  115 |     const size = browserName === 'firefox' ? { width: 500, height: 400 } : { width: 320, height: 240 };
  116 |     const context = await browser.newContext({
  117 |       recordVideo: {
  118 |         dir: testInfo.outputPath(''),
  119 |         size
  120 |       },
  121 |       viewport: size,
  122 |     });
  123 |     const page = await context.newPage();
  124 | 
  125 |     await page.evaluate(() => document.body.style.backgroundColor = 'red');
  126 |     await ensureSomeFrames(page);
  127 |     await context.close();
  128 | 
  129 |     const videoFile = await page.video().path();
  130 |     expectRedFrames(videoFile, size);
  131 |   });
  132 | 
  133 |   it('should pad a short frame to the video size', async ({ browser }, testInfo) => {
  134 |     const videoSize = { width: 800, height: 600 };
  135 |     const context = await browser.newContext({
  136 |       recordVideo: {
  137 |         dir: testInfo.outputPath(''),
  138 |         size: videoSize,
  139 |       },
  140 |       viewport: { width: 800, height: 396 },
  141 |     });
  142 |     const page = await context.newPage();
  143 |     await ensureSomeFrames(page);
  144 |     await context.close();
  145 | 
  146 |     const videoFile = await page.video().path();
  147 |     const videoPlayer = new VideoPlayer(videoFile);
  148 |     expect(videoPlayer.videoWidth).toBe(videoSize.width);
  149 |     expect(videoPlayer.videoHeight).toBe(videoSize.height);
  150 |   });
  151 | 
  152 |   it('should continue recording main page after popup closes', async ({ browser, browserName }, testInfo) => {
  153 |     it.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/30837' });
  154 |     // Firefox does not have a mobile variant and has a large minimum size (500 on windows and 450 elsewhere).
  155 |     const size = browserName === 'firefox' ? { width: 500, height: 400 } : { width: 320, height: 240 };
  156 |     const context = await browser.newContext({
  157 |       recordVideo: {
  158 |         dir: testInfo.outputPath(''),
  159 |         size
  160 |       },
  161 |       viewport: size,
  162 |     });
  163 |     const page = await context.newPage();
  164 |     await page.setContent('<a target=_blank href="about:blank">clickme</a>');
  165 |     const [popup] = await Promise.all([
  166 |       page.waitForEvent('popup'),
```