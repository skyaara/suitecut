# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/chromium/connect-over-cdp.spec.ts >> should use env proxy with connectOverCDP discovery request
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/chromium/connect-over-cdp.spec.ts:470:5

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 3
+ Received  + 1

- Array [
-   "http://localhost:8911/json/version/",
- ]
+ Array []
```

# Page snapshot

```yaml
- iframe [ref=f1e2]:
  - generic [ref=f2e1]: "Received cookie: frame=value; top-level=value"
```

# Test source

```ts
  380 |       await contexts[0].newPage();
  381 |     await cdpBrowser.close();
  382 |   } finally {
  383 |     process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = oldValue;
  384 |     await browserServer.close();
  385 |   }
  386 | });
  387 | 
  388 | test('should return valid browser from context.browser()', async ({ browserType }, testInfo) => {
  389 |   const port = 9339 + testInfo.workerIndex;
  390 |   const browserServer = await browserType.launch({
  391 |     args: ['--remote-debugging-port=' + port]
  392 |   });
  393 |   try {
  394 |     const cdpBrowser = await browserType.connectOverCDP({
  395 |       endpointURL: `http://127.0.0.1:${port}/`,
  396 |     });
  397 |     const contexts = cdpBrowser.contexts();
  398 |     expect(contexts.length).toBe(1);
  399 |     expect(contexts[0].browser()).toBe(cdpBrowser);
  400 | 
  401 |     const context2 = await cdpBrowser.newContext();
  402 |     expect(context2.browser()).toBe(cdpBrowser);
  403 | 
  404 |     await cdpBrowser.close();
  405 |   } finally {
  406 |     await browserServer.close();
  407 |   }
  408 | });
  409 | 
  410 | test('should report an expected error when the endpointURL returns a non-expected status code', async ({ browserType, server }) => {
  411 |   server.setRoute('/json/version/', (req, resp) => {
  412 |     resp.statusCode = 404;
  413 |     resp.end(JSON.stringify({
  414 |       webSocketDebuggerUrl: 'dont-use-me',
  415 |     }));
  416 |   });
  417 |   await expect(browserType.connectOverCDP({
  418 |     endpointURL: server.PREFIX,
  419 |   })).rejects.toThrowError(`browserType.connectOverCDP: Unexpected status 404 when connecting to ${server.PREFIX}/json/version/`);
  420 | });
  421 | 
  422 | test('should report an expected error when the endpoint URL JSON webSocketDebuggerUrl is undefined', async ({ browserType, server }) => {
  423 |   server.setRoute('/json/version/', (req, resp) => {
  424 |     resp.end(JSON.stringify({
  425 |       webSocketDebuggerUrl: undefined,
  426 |     }));
  427 |   });
  428 |   await expect(browserType.connectOverCDP({
  429 |     endpointURL: server.PREFIX,
  430 |   })).rejects.toThrowError('browserType.connectOverCDP: Invalid URL');
  431 | });
  432 | 
  433 | test('should connect to an existing cdp session when passed as a first argument', async ({ browserType }, testInfo) => {
  434 |   const port = 9339 + testInfo.workerIndex;
  435 |   const browserServer = await browserType.launch({
  436 |     args: ['--remote-debugging-port=' + port]
  437 |   });
  438 |   try {
  439 |     const cdpBrowser = await browserType.connectOverCDP(`http://127.0.0.1:${port}/`);
  440 |     const contexts = cdpBrowser.contexts();
  441 |     expect(contexts.length).toBe(1);
  442 |     await cdpBrowser.close();
  443 |   } finally {
  444 |     await browserServer.close();
  445 |   }
  446 | });
  447 | 
  448 | test('should use proxy with connectOverCDP', async ({ browserType, server }, testInfo) => {
  449 |   server.setRoute('/target.html', async (req, res) => {
  450 |     res.end('<html><title>Served by the proxy</title></html>');
  451 |   });
  452 |   const port = 9339 + testInfo.workerIndex;
  453 |   const browserServer = await browserType.launch({
  454 |     args: ['--remote-debugging-port=' + port]
  455 |   });
  456 |   try {
  457 |     const cdpBrowser = await browserType.connectOverCDP(`http://127.0.0.1:${port}/`);
  458 |     const context = await cdpBrowser.newContext({
  459 |       proxy: { server: `localhost:${server.PORT}` }
  460 |     });
  461 |     const page = await context.newPage();
  462 |     await page.goto('http://non-existent.com/target.html');
  463 |     expect(await page.title()).toBe('Served by the proxy');
  464 |     await cdpBrowser.close();
  465 |   } finally {
  466 |     await browserServer.close();
  467 |   }
  468 | });
  469 | 
  470 | test('should use env proxy with connectOverCDP discovery request', async ({ browserType, server, proxyServer, mode }) => {
  471 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40394' });
  472 |   test.skip(mode !== 'default'); // Out of process transport does not allow us to set env vars dynamically.
  473 |   proxyServer.forwardTo(server.PORT);
  474 | 
  475 |   const oldValue = process.env.HTTP_PROXY;
  476 |   try {
  477 |     process.env.HTTP_PROXY = proxyServer.URL;
  478 |     const error = await browserType.connectOverCDP(server.PREFIX).catch(e => e);
  479 |     expect(error.message).toContain(`Unexpected status 404 when connecting to ${server.PREFIX}/json/version/`);
> 480 |     expect(proxyServer.requestUrls).toEqual([`${server.PREFIX}/json/version/`]);
      |                                     ^ Error: expect(received).toEqual(expected) // deep equality
  481 |   } finally {
  482 |     if (oldValue === undefined)
  483 |       delete process.env.HTTP_PROXY;
  484 |     else
  485 |       process.env.HTTP_PROXY = oldValue;
  486 |   }
  487 | });
  488 | 
  489 | test('should send target Host header when using env HTTP proxy with connectOverCDP', async ({ browserType, server, proxyServer, mode }) => {
  490 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/40811' });
  491 |   test.skip(mode !== 'default'); // Out of process transport does not allow us to set env vars dynamically.
  492 |   proxyServer.forwardTo(server.PORT);
  493 | 
  494 |   const oldValue = process.env.HTTP_PROXY;
  495 |   try {
  496 |     process.env.HTTP_PROXY = proxyServer.URL;
  497 |     const error = await browserType.connectOverCDP(server.PREFIX).catch(e => e);
  498 |     expect(error.message).toContain(`Unexpected status 404 when connecting to ${server.PREFIX}/json/version/`);
  499 |     expect(proxyServer.requestHosts).toEqual([new URL(server.PREFIX).host]);
  500 |   } finally {
  501 |     if (oldValue === undefined)
  502 |       delete process.env.HTTP_PROXY;
  503 |     else
  504 |       process.env.HTTP_PROXY = oldValue;
  505 |   }
  506 | });
  507 | 
  508 | test('should be able to connect via localhost', async ({ browserType }, testInfo) => {
  509 |   const port = 9339 + testInfo.workerIndex;
  510 |   const browserServer = await browserType.launch({
  511 |     args: ['--remote-debugging-port=' + port]
  512 |   });
  513 |   try {
  514 |     const cdpBrowser = await browserType.connectOverCDP(`http://localhost:${port}`);
  515 |     const contexts = cdpBrowser.contexts();
  516 |     expect(contexts.length).toBe(1);
  517 |     await cdpBrowser.close();
  518 |   } finally {
  519 |     await browserServer.close();
  520 |   }
  521 | });
  522 | 
  523 | test('emulate media should not be affected by second connectOverCDP with noDefaults', async ({ browserType }, testInfo) => {
  524 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/24109' });
  525 |   const port = 9339 + testInfo.workerIndex;
  526 |   const browserServer = await browserType.launch({
  527 |     args: ['--remote-debugging-port=' + port]
  528 |   });
  529 |   try {
  530 |     async function isPrint(page) {
  531 |       return await page.evaluate(() => matchMedia('print').matches);
  532 |     }
  533 | 
  534 |     const browser1 = await browserType.connectOverCDP(`http://localhost:${port}`);
  535 |     const context1 = await browser1.newContext();
  536 |     const page1 = await context1.newPage();
  537 |     await page1.emulateMedia({ media: 'print' });
  538 |     expect(await isPrint(page1)).toBe(true);
  539 |     const browser2 = await browserType.connectOverCDP(`http://localhost:${port}`, { noDefaults: true });
  540 |     expect(await isPrint(page1)).toBe(true);
  541 |     await Promise.all([
  542 |       browser1.close(),
  543 |       browser2.close()
  544 |     ]);
  545 |   } finally {
  546 |     await browserServer.close();
  547 |   }
  548 | });
  549 | 
  550 | test('should allow tracing over cdp session', async ({ browserType, trace }, testInfo) => {
  551 |   test.skip(trace === 'on');
  552 | 
  553 |   const port = 9339 + testInfo.workerIndex;
  554 |   const browserServer = await browserType.launch({
  555 |     args: ['--remote-debugging-port=' + port]
  556 |   });
  557 |   try {
  558 |     const cdpBrowser = await browserType.connectOverCDP({
  559 |       endpointURL: `http://127.0.0.1:${port}/`,
  560 |     });
  561 |     const [context] = cdpBrowser.contexts();
  562 |     await context.tracing.start({ screenshots: true, snapshots: true });
  563 |     const page = await context.newPage();
  564 |     await page.evaluate(() => 2 + 2);
  565 |     const traceZip = testInfo.outputPath('trace.zip');
  566 |     await context.tracing.stop({ path: traceZip });
  567 |     await cdpBrowser.close();
  568 |     expect(fs.existsSync(traceZip)).toBe(true);
  569 |   } finally {
  570 |     await browserServer.close();
  571 |   }
  572 | });
  573 | 
  574 | test('setInputFiles should preserve lastModified timestamp', async ({ browserType, asset }) => {
  575 |   test.info().annotations.push({ type: 'issue', description: 'https://github.com/microsoft/playwright/issues/27452' });
  576 | 
  577 |   const port = 9339 + test.info().workerIndex;
  578 |   const browserServer = await browserType.launch({
  579 |     args: ['--remote-debugging-port=' + port]
  580 |   });
```