# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: page/page-set-extra-http-headers.spec.ts >> should not duplicate referer header
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/page/page-set-extra-http-headers.spec.ts:64:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "http://localhost:8943/empty.html"
Received: "http://localhost:8943/empty.html, http://localhost:8943/empty.html"
```

# Test source

```ts
  1  | /**
  2  |  * Copyright 2018 Google Inc. All rights reserved.
  3  |  * Modifications copyright (c) Microsoft Corporation.
  4  |  *
  5  |  * Licensed under the Apache License, Version 2.0 (the "License");
  6  |  * you may not use this file except in compliance with the License.
  7  |  * You may obtain a copy of the License at
  8  |  *
  9  |  *     http://www.apache.org/licenses/LICENSE-2.0
  10 |  *
  11 |  * Unless required by applicable law or agreed to in writing, software
  12 |  * distributed under the License is distributed on an "AS IS" BASIS,
  13 |  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  14 |  * See the License for the specific language governing permissions and
  15 |  * limitations under the License.
  16 |  */
  17 | 
  18 | import { test as it, expect } from './pageTest';
  19 | 
  20 | it('should work @smoke', async ({ page, server }) => {
  21 |   await page.setExtraHTTPHeaders({
  22 |     foo: 'bar',
  23 |   });
  24 |   const [request] = await Promise.all([
  25 |     server.waitForRequest('/empty.html'),
  26 |     page.goto(server.EMPTY_PAGE),
  27 |   ]);
  28 |   expect(request.headers['foo']).toBe('bar');
  29 |   expect(request.headers['baz']).toBe(undefined);
  30 | });
  31 | 
  32 | it('should work with redirects', async ({ page, server }) => {
  33 |   server.setRedirect('/foo.html', '/empty.html');
  34 |   await page.setExtraHTTPHeaders({
  35 |     foo: 'bar'
  36 |   });
  37 |   const [request] = await Promise.all([
  38 |     server.waitForRequest('/empty.html'),
  39 |     page.goto(server.PREFIX + '/foo.html'),
  40 |   ]);
  41 |   expect(request.headers['foo']).toBe('bar');
  42 | });
  43 | 
  44 | it('should work with extra headers from browser context', async ({ page, server }) => {
  45 |   await page.context().setExtraHTTPHeaders({
  46 |     'foo': 'bar',
  47 |   });
  48 |   const [request] = await Promise.all([
  49 |     server.waitForRequest('/empty.html'),
  50 |     page.goto(server.EMPTY_PAGE),
  51 |   ]);
  52 |   expect(request.headers['foo']).toBe('bar');
  53 | });
  54 | 
  55 | it('should throw for non-string header values', async ({ page }) => {
  56 |   // @ts-expect-error headers must be strings
  57 |   const error1 = await page.setExtraHTTPHeaders({ 'foo': 1 }).catch(e => e);
  58 |   expect(error1.message).toContain('Expected value of header "foo" to be String, but "number" is found.');
  59 |   // @ts-expect-error headers must be strings
  60 |   const error2 = await page.context().setExtraHTTPHeaders({ 'foo': true }).catch(e => e);
  61 |   expect(error2.message).toContain('Expected value of header "foo" to be String, but "boolean" is found.');
  62 | });
  63 | 
  64 | it('should not duplicate referer header', async ({ page, server, browserName }) => {
  65 |   it.fail(browserName === 'chromium', 'Request has referer and Referer');
  66 |   await page.setExtraHTTPHeaders({ 'referer': server.EMPTY_PAGE });
  67 |   const response = await page.goto(server.EMPTY_PAGE);
  68 |   expect(response.ok()).toBe(true);
> 69 |   expect(response.request().headers()['referer']).toBe(server.EMPTY_PAGE);
     |                                                   ^ Error: expect(received).toBe(expected) // Object.is equality
  70 | });
  71 | 
```