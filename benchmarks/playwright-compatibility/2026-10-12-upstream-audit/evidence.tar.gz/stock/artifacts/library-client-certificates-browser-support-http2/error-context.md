# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/client-certificates.spec.ts >> browser >> support http2
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/client-certificates.spec.ts:802:3

# Error details

```
Error: page.goto: net::ERR_CONNECTION_CLOSED at https://local.playwright:44273/
Call log:
  - navigating to "https://local.playwright:44273/", waiting until "load"

```

# Test source

```ts
  714 |       clientCertificates: [{
  715 |         origin: new URL(serverURL).origin,
  716 |         pfx: await fs.promises.readFile(asset('client-certificates/client/trusted/cert.pfx')),
  717 |         passphrase: 'secure'
  718 |       }],
  719 |     });
  720 |     await page.goto(serverURL);
  721 |     await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  722 |     await page.close();
  723 |   });
  724 | 
  725 |   test('should fail with matching certificates in legacy pfx format', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  726 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  727 |     await expect(browser.newPage({
  728 |       ignoreHTTPSErrors: true,
  729 |       clientCertificates: [{
  730 |         origin: new URL(serverURL).origin,
  731 |         pfxPath: asset('client-certificates/client/trusted/cert-legacy.pfx'),
  732 |         passphrase: 'secure'
  733 |       }],
  734 |     })).rejects.toThrow('Unsupported TLS certificate');
  735 |   });
  736 | 
  737 |   test('should throw a http error if the pfx passphrase is incorect', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  738 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  739 |     await expect(browser.newPage({
  740 |       ignoreHTTPSErrors: true,
  741 |       clientCertificates: [{
  742 |         origin: new URL(serverURL).origin,
  743 |         pfxPath: asset('client-certificates/client/trusted/cert.pfx'),
  744 |         passphrase: 'this-password-is-incorrect'
  745 |       }],
  746 |     })).rejects.toThrow('Failed to load client certificate: mac verify failure');
  747 |   });
  748 | 
  749 |   test('should pass with matching certificates on context APIRequestContext instance', async ({ browser, startCCServer, asset, browserName }) => {
  750 |     const serverURL = await startCCServer();
  751 |     const baseOptions = {
  752 |       certPath: asset('client-certificates/client/trusted/cert.pem'),
  753 |       keyPath: asset('client-certificates/client/trusted/key.pem'),
  754 |     };
  755 |     const page = await browser.newPage({
  756 |       ignoreHTTPSErrors: true,
  757 |       clientCertificates: [{
  758 |         origin: new URL(serverURL).origin,
  759 |         ...baseOptions,
  760 |       }, {
  761 |         origin: new URL(serverURL).origin.replace('localhost', '127.0.0.1'),
  762 |         ...baseOptions,
  763 |       }],
  764 |     });
  765 |     for (const url of [serverURL, serverURL.replace('localhost', '127.0.0.1')]) {
  766 |       const response = await page.request.get(url);
  767 |       expect(response.status()).toBe(200);
  768 |       expect(await response.text()).toContain('Hello Alice, your certificate was issued by localhost!');
  769 |     }
  770 |     await page.close();
  771 |   });
  772 | 
  773 |   test('should pass with matching certificates and trailing slash', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  774 |     const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  775 |     const page = await browser.newPage({
  776 |       ignoreHTTPSErrors: true,
  777 |       clientCertificates: [{
  778 |         origin: serverURL,
  779 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  780 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  781 |       }],
  782 |     });
  783 |     await page.goto(serverURL);
  784 |     await expect(page.getByText('Hello Alice, your certificate was issued by localhost!')).toBeVisible();
  785 |     await page.close();
  786 |   });
  787 | 
  788 |   test('should have ignoreHTTPSErrors=false by default', async ({ browser, httpsServer, asset, browserName, platform }) => {
  789 |     const targetURL = browserName === 'webkit' && platform === 'darwin' ? httpsServer.EMPTY_PAGE.replace('localhost', 'local.playwright') : httpsServer.EMPTY_PAGE;
  790 |     const page = await browser.newPage({
  791 |       clientCertificates: [{
  792 |         origin: new URL(targetURL).origin,
  793 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  794 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  795 |       }],
  796 |     });
  797 |     await page.goto(targetURL);
  798 |     await expect(page.getByText('Playwright client-certificate error: self-signed certificate')).toBeVisible();
  799 |     await page.close();
  800 |   });
  801 | 
  802 |   test('support http2', async ({ browser, startCCServer, asset, browserName, isMac }) => {
  803 |     test.skip(browserName === 'webkit' && isMac, 'WebKit on macOS doesn\n proxy localhost');
  804 |     const serverURL = await startCCServer({ http2: true });
  805 |     const page = await browser.newPage({
  806 |       ignoreHTTPSErrors: true,
  807 |       clientCertificates: [{
  808 |         origin: new URL(serverURL).origin,
  809 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  810 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  811 |       }],
  812 |     });
  813 |     {
> 814 |       await page.goto(serverURL.replace('127.0.0.1', 'local.playwright'));
      |                  ^ Error: page.goto: net::ERR_CONNECTION_CLOSED at https://local.playwright:44273/
  815 |       await expect(page.getByTestId('message')).toHaveText('Sorry, but you need to provide a client certificate to continue.');
  816 |       await expect(page.getByTestId('alpn-protocol')).toHaveText('h2');
  817 |       await expect(page.getByTestId('servername')).toHaveText('local.playwright');
  818 |     }
  819 |     {
  820 |       await page.goto(serverURL);
  821 |       await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  822 |       await expect(page.getByTestId('alpn-protocol')).toHaveText('h2');
  823 |     }
  824 |     await page.close();
  825 |   });
  826 | 
  827 |   test('support http2 if the browser only supports http1.1', async ({ browserType, browserName, startCCServer, asset }) => {
  828 |     test.skip(browserName !== 'chromium');
  829 |     const serverURL = await startCCServer({ http2: true, enableHTTP1FallbackWhenUsingHttp2: true });
  830 |     const browser = await browserType.launch({ args: ['--disable-http2'] });
  831 |     const page = await browser.newPage({
  832 |       ignoreHTTPSErrors: true,
  833 |       clientCertificates: [{
  834 |         origin: new URL(serverURL).origin,
  835 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  836 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  837 |       }],
  838 |     });
  839 |     {
  840 |       await page.goto(serverURL.replace('127.0.0.1', 'local.playwright'));
  841 |       await expect(page.getByTestId('message')).toHaveText('Sorry, but you need to provide a client certificate to continue.');
  842 |       await expect(page.getByTestId('alpn-protocol')).toHaveText('http/1.1');
  843 |     }
  844 |     {
  845 |       await page.goto(serverURL);
  846 |       await expect(page.getByTestId('message')).toHaveText('Hello Alice, your certificate was issued by localhost!');
  847 |       await expect(page.getByTestId('alpn-protocol')).toHaveText('http/1.1');
  848 |     }
  849 |     await browser.close();
  850 |   });
  851 | 
  852 |   test('should return target connection errors when using http2', async ({ browser, startCCServer, asset, browserName, isMac, nodeVersion }) => {
  853 |     test.skip(browserName === 'webkit' && isMac, 'WebKit on macOS does not proxy localhost');
  854 |     test.skip(nodeVersion.major < 20, 'http2.performServerHandshake is not supported in older Node.js versions');
  855 | 
  856 |     const serverURL = await startCCServer({ http2: true });
  857 |     const page = await browser.newPage({
  858 |       clientCertificates: [{
  859 |         origin: new URL(serverURL).origin,
  860 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  861 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  862 |       }],
  863 |     });
  864 |     await page.goto(serverURL);
  865 |     await expect(page.getByText('Playwright client-certificate error: self-signed certificate')).toBeVisible();
  866 |     await page.close();
  867 |   });
  868 | 
  869 |   test('should handle rejected certificate in handshake with HTTP/2', async ({ browser, asset, browserName, platform }) => {
  870 |     const server: http2.Http2SecureServer = createHttp2Server({
  871 |       key: fs.readFileSync(asset('client-certificates/server/server_key.pem')),
  872 |       cert: fs.readFileSync(asset('client-certificates/server/server_cert.pem')),
  873 |       ca: [fs.readFileSync(asset('client-certificates/server/server_cert.pem'))],
  874 |       requestCert: true,
  875 |     }, async (req: http2.Http2ServerRequest, res: http2.Http2ServerResponse) => {
  876 |       res.writeHead(200, { 'Content-Type': 'text/html' });
  877 |       res.end('Hello world');
  878 |     });
  879 | 
  880 |     await new Promise<void>(resolve => server.listen(0, 'localhost', resolve));
  881 |     const port = (server.address() as net.AddressInfo).port;
  882 |     const serverUrl = 'https://' + (browserName === 'webkit' && platform === 'darwin' ? 'local.playwright' : 'localhost') + ':' + port;
  883 | 
  884 |     const context = await browser.newContext({
  885 |       ignoreHTTPSErrors: true,
  886 |       clientCertificates: [{
  887 |         origin: 'https://just-there-that-the-client-certificates-proxy-server-is-getting-launched.com',
  888 |         certPath: asset('client-certificates/client/trusted/cert.pem'),
  889 |         keyPath: asset('client-certificates/client/trusted/key.pem'),
  890 |       }],
  891 |     });
  892 | 
  893 |     const page = await context.newPage();
  894 | 
  895 |     // This was triggering an unhandled error before.
  896 |     await page.goto(serverUrl).catch(() => {});
  897 | 
  898 |     await context.close();
  899 |     await new Promise<void>(resolve => server.close(() => resolve()));
  900 |   });
  901 | 
  902 |   test.describe('persistentContext', () => {
  903 |     test('validate input', async ({ launchPersistent }) => {
  904 |       test.slow();
  905 |       for (const [contextOptions, expected] of kValidationSubTests)
  906 |         await expect(launchPersistent(contextOptions)).rejects.toThrow(expected);
  907 |     });
  908 | 
  909 |     test('should pass with matching certificates', async ({ launchPersistent, startCCServer, asset, browserName, isMac }) => {
  910 |       const serverURL = await startCCServer({ useFakeLocalhost: browserName === 'webkit' && isMac });
  911 |       const { page } = await launchPersistent({
  912 |         ignoreHTTPSErrors: true,
  913 |         clientCertificates: [{
  914 |           origin: new URL(serverURL).origin,
```