# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: library/browsertype-connect.spec.ts >> launchServer only >> should be able to reconnect to a browser 12 times without warnings
- Location: ../../tmp/suitecut-playwright-upstream/playwright-1.62.1/tests/library/browsertype-connect.spec.ts:1132:3

# Error details

```
Test timeout of 90000ms exceeded.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]: "HTTP Error 401 Unauthorized: Access is denied"
```